INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('b30ecaf1-0efd-e611-80f9-00155db47807', N'ELD Driver efficiency report', 'e468d955-6924-11e3-a678-a0b3cc4a6a82', N'Compares daily driving/on duty hours to max driving/on duty hours', 1, NULL, 1, '91e29695-0d94-11e6-80f6-00155db47809', '91e29695-0d94-11e6-80f6-00155db47809', '2017-02-27 09:05:39.843', '2017-02-27 09:05:39.843', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
		<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" Name="ELD Driver efficiency report" Margins="14, 20, 100, 100" DisplayName="ELD Driver efficiency report" PageWidth="850" PageHeight="1100" DataMember="ELDDriverEfficiencyReport" DataSource="#Ref-42">
		  <Bands>
			<Item1 ControlType="TopMarginBand" Name="TopMargin1" Ref="0" />
			<Item2 ControlType="ReportHeaderBand" HeightF="164.58" Name="reportHeaderBand1" Padding="2,0,0,0,100" Ref="9">
			  <StylePriority UsePadding="false" />
			  <Controls>
				<Item1 ControlType="XRLabel" SizeF="556.25, 44.79" LocationFloat="164.58, 27.08" TextAlignment="TopCenter" Text="Driver Efficiency" Name="label11" Font="Arial Black, 25pt, style=Bold" Ref="1">
				  <StylePriority UseFont="false" UseTextAlignment="false" />
				</Item1>
				<Item2 ControlType="XRPageInfo" TextAlignment="MiddleRight" Format="{0: &quot;at &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="141.67, 22.4" LocationFloat="660.94, 79.17" Name="pageInfo1" Font="Times New Roman, 9pt" Ref="2">
				  <StylePriority UseFont="false" UseTextAlignment="false" />
				</Item2>
				<Item3 ControlType="XRLabel" SizeF="344.79, 21.88" LocationFloat="312.5, 79.17" TextAlignment="MiddleRight" Text="label12" Name="label12" Padding="2,0,0,0,100" Ref="4">
				  <DataBindings>
					<Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Created by: {0}" Ref="3" />
				  </DataBindings>
				  <StylePriority UsePadding="false" UseTextAlignment="false" />
				</Item3>
				<Item4 ControlType="XRLabel" SizeF="491.67, 22.92" LocationFloat="312.5, 101.88" TextAlignment="TopRight" Text="label13" Name="label13" Padding="2,0,0,0,100" Ref="6">
				  <DataBindings>
					<Item1 PropertyName="Text" DataMember="UserInfo.DateRange" FormatString="Date Range: {0}" Ref="5" />
				  </DataBindings>
				  <StylePriority UsePadding="false" UseTextAlignment="false" />
				</Item4>
				<Item5 ControlType="XRLabel" SizeF="215.63, 25" LocationFloat="5.21, 139.58" Text="label1" Name="label1" Padding="0,2,0,0,100" Font="Times New Roman, 10pt, style=Bold" Ref="8">
				  <DataBindings>
					<Item1 PropertyName="Text" DataMember="ELDDriverEfficiencyReport.Number" Ref="7" />
				  </DataBindings>
				  <Summary FormatString="Total: {0} records" Running="Report" Func="Count" />
				  <StylePriority UseFont="false" UsePadding="false" />
				</Item5>
			  </Controls>
			</Item2>
			<Item3 ControlType="PageHeaderBand" HeightF="25" Name="PageHeader1" TextAlignment="TopLeft" Padding="0,0,0,0,100" Ref="18">
			  <Controls>
				<Item1 ControlType="XRTable" SizeF="799.17, 25" LocationFloat="5.21, 0" Name="table1" BorderColor="DarkGray" Borders="All" Ref="17">
				  <Rows>
					<Item1 ControlType="XRTableRow" Weight="1" Name="tableRow1" Ref="16">
					  <Cells>
						<Item1 ControlType="XRTableCell" Weight="0.4227172538402956" TextAlignment="MiddleLeft" Text="Employee Number" Name="tableCell1" BackColor="255,194,194,194" Padding="5,0,0,0,100" Font="Times New Roman, 7pt, style=Bold" Ref="10">
						  <StylePriority UseBackColor="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
						</Item1>
						<Item2 ControlType="XRTableCell" Weight="0.6491879874407999" TextAlignment="MiddleLeft" Text="Employee Name" Name="tableCell2" BackColor="255,194,194,194" Padding="5,0,0,0,100" Font="Times New Roman, 7pt, style=Bold" Ref="11">
						  <StylePriority UseBackColor="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
						</Item2>
						<Item3 ControlType="XRTableCell" Weight="0.8503078692147215" TextAlignment="MiddleCenter" Text="Avg Daily Driving Hours (% of Max Driving)" Name="tableCell4" BackColor="255,194,194,194" Borders="All" Font="Times New Roman, 7pt, style=Bold" Ref="12">
						  <StylePriority UseBackColor="false" UseBorders="false" UseFont="false" UseTextAlignment="false" />
						</Item3>
						<Item4 ControlType="XRTableCell" Weight="0.9040085645811976" TextAlignment="MiddleCenter" Text="Avg Daily On Duty + Driving (% of Max On Duty)" Name="tableCell11" BackColor="255,194,194,194" BorderColor="DarkGray" Borders="All" Font="Times New Roman, 7pt, style=Bold" Ref="13">
						  <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UseFont="false" UseTextAlignment="false" />
						</Item4>
						<Item5 ControlType="XRTableCell" Weight="0.43635329428675684" TextAlignment="MiddleCenter" Text="Total Driving Hours" Name="tableCell14" BackColor="255,194,194,194" BorderColor="DarkGray" Borders="All" Font="Times New Roman, 7pt, style=Bold" Ref="14">
						  <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UseFont="false" UseTextAlignment="false" />
						</Item5>
						<Item6 ControlType="XRTableCell" Weight="0.4822753548968319" TextAlignment="MiddleCenter" Text="Total Hours On Duty + Driving" Name="tableCell15" BackColor="255,194,194,194" BorderColor="DarkGray" Borders="All" Font="Times New Roman, 7pt, style=Bold" Ref="15">
						  <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UseFont="false" UseTextAlignment="false" />
						</Item6>
					  </Cells>
					</Item1>
				  </Rows>
				  <StylePriority UseBorderColor="false" UseBorders="false" />
				</Item1>
			  </Controls>
			</Item3>
			<Item4 ControlType="DetailBand" HeightF="25" Name="Detail1" TextAlignment="TopLeft" Padding="0,0,0,0,100" Ref="37">
			  <Controls>
				<Item1 ControlType="XRTable" SizeF="799.17, 25" LocationFloat="5.21, 0" EvenStyleName="xrControlStyle1" Name="table2" Ref="36">
				  <Rows>
					<Item1 ControlType="XRTableRow" Weight="1" Name="tableRow2" Ref="35">
					  <Cells>
						<Item1 ControlType="XRTableCell" Weight="0.42271725728264636" TextAlignment="MiddleLeft" Text="tableCell5" Name="tableCell5" BorderColor="DarkGray" Padding="5,0,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 7pt" Ref="20">
						  <DataBindings>
							<Item1 PropertyName="Text" DataMember="ELDDriverEfficiencyReport.Number" Ref="19" />
						  </DataBindings>
						  <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
						</Item1>
						<Item2 ControlType="XRTableCell" Weight="0.6491879927273897" TextAlignment="MiddleLeft" Text="tableCell6" Name="tableCell6" BorderColor="DarkGray" Padding="5,0,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 8pt" Ref="22">
						  <DataBindings>
							<Item1 PropertyName="Text" DataMember="ELDDriverEfficiencyReport.EmployeeName" Ref="21" />
						  </DataBindings>
						  <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
						</Item2>
						<Item3 ControlType="XRTableCell" Weight="0.4207491689547587" TextAlignment="MiddleCenter" Text="tableCell7" Name="tableCell7" BorderColor="DarkGray" Borders="Left, Right, Bottom" Font="Times New Roman, 8pt" Ref="24">
						  <DataBindings>
							<Item1 PropertyName="Text" DataMember="ELDDriverEfficiencyReport.AvgDailyDrivingHours" FormatString="{0: MM/dd/yyyy hh:mm tt}" Ref="23" />
						  </DataBindings>
						  <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" UseTextAlignment="false" />
						</Item3>
						<Item4 ControlType="XRTableCell" Weight="0.42955870718434935" TextAlignment="MiddleCenter" Text="tableCell8" Name="tableCell8" BorderColor="DarkGray" Borders="Left, Right, Bottom" Font="Times New Roman, 7pt" Ref="26">
						  <DataBindings>
							<Item1 PropertyName="Text" DataMember="ELDDriverEfficiencyReport.PercentMaxDriving" Ref="25" />
						  </DataBindings>
						  <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" UseTextAlignment="false" />
						</Item4>
						<Item5 ControlType="XRTableCell" Weight="0.48227535882418754" TextAlignment="MiddleCenter" Text="tableCell10" Name="tableCell10" BorderColor="DarkGray" Borders="Left, Right, Bottom" Font="Times New Roman, 7pt" Ref="28">
						  <DataBindings>
							<Item1 PropertyName="Text" DataMember="ELDDriverEfficiencyReport.AvgDailyOndutyDrivingHours" Ref="27" />
						  </DataBindings>
						  <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" UseTextAlignment="false" />
						</Item5>
						<Item6 ControlType="XRTableCell" Weight="0.41976512479081535" TextAlignment="MiddleCenter" Text="tableCell12" Name="tableCell12" BorderColor="DarkGray" Borders="Left, Right, Bottom" Font="Times New Roman, 7pt" Ref="30">
						  <DataBindings>
							<Item1 PropertyName="Text" DataMember="ELDDriverEfficiencyReport.PercentMaxOnduty" Ref="29" />
						  </DataBindings>
						  <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" UseTextAlignment="false" />
						</Item6>
						<Item7 ControlType="XRTableCell" Weight="0.4373842012499967" TextAlignment="MiddleCenter" Text="tableCell13" Name="tableCell13" BorderColor="DarkGray" Borders="Left, Right, Bottom" Font="Times New Roman, 7pt" Ref="32">
						  <DataBindings>
							<Item1 PropertyName="Text" DataMember="ELDDriverEfficiencyReport.TotalDrivingHours" Ref="31" />
						  </DataBindings>
						  <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" UseTextAlignment="false" />
						</Item7>
						<Item8 ControlType="XRTableCell" Weight="0.48321254374222894" TextAlignment="MiddleCenter" Text="tableCell16" Name="tableCell16" BorderColor="DarkGray" Borders="Left, Right, Bottom" Font="Times New Roman, 7pt" Ref="34">
						  <DataBindings>
							<Item1 PropertyName="Text" DataMember="ELDDriverEfficiencyReport.TotalOndutyAndDrivingHours" Ref="33" />
						  </DataBindings>
						  <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" UseTextAlignment="false" />
						</Item8>
					  </Cells>
					</Item1>
				  </Rows>
				</Item1>
			  </Controls>
			</Item4>
			<Item5 ControlType="PageFooterBand" HeightF="30" Name="PageFooter1" TextAlignment="TopLeft" Padding="0,0,0,0,100" Ref="39">
			  <Controls>
				<Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="195.83, 22.92" LocationFloat="609.59, 6.25" Name="pageInfo2" Padding="2,2,0,0,100" Ref="38">
				  <StylePriority UseTextAlignment="false" />
				</Item1>
			  </Controls>
			</Item5>
			<Item6 ControlType="BottomMarginBand" Name="BottomMargin1" Ref="40" />
		  </Bands>
		  <StyleSheet>
			<Item1 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="xrControlStyle1" Font="Times New Roman, 9pt" BackColor="WhiteSmoke" BorderColor="DarkGray" Sides="None" Ref="41" />
		  </StyleSheet>
		  <ObjectStorage>
			<Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;ELD_x0020_Driver_x0020_efficiency_x0020_report&gt;&lt;xs:schema id=&quot;ELD_x0020_Driver_x0020_efficiency_x0020_report&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;ELD_x0020_Driver_x0020_efficiency_x0020_report&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;ELDDriverEfficiencyReport&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;NUMBER&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EMPLOYEENAME&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;AVGDAILYDRIVINGHOURS&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;PERCENTMAXDRIVING&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;AVGDAILYONDUTYDRIVINGHOURS&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;PERCENTMAXONDUTY&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TOTALDRIVINGHOURS&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TOTALONDUTYANDDRIVINGHOURS&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/ELD_x0020_Driver_x0020_efficiency_x0020_report&gt;" Type="System.Data.DataSet" Ref="42" />
		  </ObjectStorage>
		  <Extensions>
			<Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="43" />
		  </Extensions>
		</XtraReportsLayoutSerializer>', '4f1bb61f-083d-40cc-8c23-90574483ef9c', '59c4bfb5-1d57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('b40ecaf1-0efd-e611-80f9-00155db47807', N'ELD HOS Violation Report', 'e468d955-6924-11e3-a678-a0b3cc4a6a82', NULL, 0, NULL, 1, '91e29695-0d94-11e6-80f6-00155db47809', '91e29695-0d94-11e6-80f6-00155db47809', '2017-02-27 09:05:39.890', '2017-02-27 09:05:39.890', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" Name="ELD HOS Violation Report" DisplayName="ELD HOS Violation Report" PageWidth="850" PageHeight="1100" DataMember="ELDeLogViolation" DataSource="#Ref-42">
  <Bands>
    <Item1 ControlType="TopMarginBand" Name="TopMargin1" Ref="0" />
    <Item2 ControlType="ReportHeaderBand" HeightF="163.54" Name="reportHeaderBand1" Padding="2,0,0,0,100" Ref="7">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="638, 39" LocationFloat="6, 29.17" TextAlignment="TopCenter" Text="HOS Violation Report" StyleName="Title" Name="label11" Font="Arial Black, 25pt, style=Bold" Ref="1">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRPageInfo" TextAlignment="MiddleRight" Format="{0: &quot;at &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="133, 22.92" LocationFloat="511, 79.17" StyleName="PageInfo" Name="pageInfo1" Font="Times New Roman, 9pt" Ref="2">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="361.46, 22.92" LocationFloat="150, 79.17" TextAlignment="MiddleRight" Text="label12" Name="label12" Padding="2,0,0,0,100" Ref="4">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Created by: {0}" Ref="3" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="493.75, 22.92" LocationFloat="150, 102.08" TextAlignment="TopRight" Text="label13" Name="label13" Padding="2,0,0,0,100" Ref="6">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.DateRange" FormatString="Date Range: {0}" Ref="5" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item4>
      </Controls>
    </Item2>
    <Item3 ControlType="GroupHeaderBand" Level="1" HeightF="39.58" Name="groupHeaderBand1" Ref="15">
      <GroupFields>
        <Item1 FieldName="EmployeeName" Ref="8" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="345.83, 25" LocationFloat="116, 12.5" TextAlignment="MiddleLeft" StyleName="DataField" Name="label2" Font="Times New Roman, 10pt" Ref="10">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="ELDeLogViolation.EmployeeName" Ref="9" />
          </DataBindings>
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLabel" SizeF="110, 25" LocationFloat="6, 12.5" TextAlignment="MiddleLeft" Text="Employee Name" StyleName="FieldCaption" Name="label1" Ref="11">
          <StylePriority UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="182.33, 25" LocationFloat="461.46, 12.5" TextAlignment="MiddleRight" Text="label14" Name="label14" Padding="2,2,0,0,100" Font="Times New Roman, 10pt" Ref="13">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="ELDeLogViolation.ViolationType" Ref="12" />
          </DataBindings>
          <Summary FormatString="Total: {0} records" Running="Group" Func="Count" />
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRLine" SizeF="639.42, 2" LocationFloat="5.21, 37.5" Name="line1" BorderColor="255,89,89,89" Ref="14">
          <StylePriority UseBorderColor="false" />
        </Item4>
      </Controls>
    </Item3>
    <Item4 ControlType="GroupHeaderBand" StyleName="FieldCaption" HeightF="30" Name="groupHeaderBand2" Ref="22">
      <Controls>
        <Item1 ControlType="XRTable" SizeF="609.29, 25" LocationFloat="35, 5" Name="table1" BackColor="0,0,0,0" BorderColor="DarkGray" Borders="All" Ref="21">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow1" Ref="20">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.7386130488305294" TextAlignment="MiddleLeft" Text="Start Time" Name="tableCell1" BackColor="255,194,194,194" BorderColor="DarkGray" Padding="5,0,0,0,100" Borders="All" Ref="16">
                  <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.5908904390644234" TextAlignment="MiddleLeft" Text="Status Duration" Name="tableCell4" BackColor="255,194,194,194" Padding="5,0,0,0,100" Ref="17">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.7386130488305294" TextAlignment="MiddleLeft" Text="Violation Type" Name="tableCell5" BackColor="255,194,194,194" Padding="5,0,0,0,100" Ref="18">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.9318834632745179" TextAlignment="MiddleLeft" Text="City, State" Name="tableCell2" BackColor="255,194,194,194" Padding="5,0,0,0,100" Ref="19">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item4>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item4>
    <Item5 ControlType="DetailBand" StyleName="DataField" HeightF="25" Name="detailBand1" Ref="33">
      <Controls>
        <Item1 ControlType="XRTable" SizeF="609.29, 25" LocationFloat="35, 0" EvenStyleName="xrControlStyle1" Name="table2" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="32">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow2" Ref="31">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.7385645587487076" TextAlignment="MiddleLeft" Name="tableCell3" BorderColor="DarkGray" Padding="5,0,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="24">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="ELDeLogViolation.StartTime" FormatString="{0: MM/dd/yyyy hh:mm tt}" Ref="23" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.5908516469989661" TextAlignment="MiddleLeft" Name="tableCell8" BorderColor="DarkGray" Padding="5,0,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="26">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="ELDeLogViolation.Duration" Ref="25" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.7385645587487076" TextAlignment="MiddleLeft" Name="tableCell6" BorderColor="DarkGray" Padding="5,0,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="28">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="ELDeLogViolation.ViolationType" Ref="27" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.9320192355036186" TextAlignment="MiddleLeft" Name="tableCell7" BorderColor="DarkGray" Padding="5,0,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="30">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="ELDeLogViolation.CityState" Ref="29" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item4>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item5>
    <Item6 ControlType="PageFooterBand" HeightF="29" Name="pageFooterBand1" Ref="35">
      <Controls>
        <Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="313, 23" LocationFloat="331, 6" StyleName="PageInfo" Name="pageInfo2" Font="Times New Roman, 9pt" Ref="34">
          <StylePriority UseFont="false" />
        </Item1>
      </Controls>
    </Item6>
    <Item7 ControlType="BottomMarginBand" Name="BottomMargin1" Ref="36" />
  </Bands>
  <StyleSheet>
    <Item1 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="Title" Font="Times New Roman, 24pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="37" />
    <Item2 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="FieldCaption" Font="Times New Roman, 10pt, style=Bold" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="38" />
    <Item3 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="PageInfo" Font="Times New Roman, 8pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="39" />
    <Item4 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="DataField" Font="Times New Roman, 8pt" Padding="2,2,0,0,100" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="40" />
    <Item5 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="xrControlStyle1" Font="Times New Roman, 9pt" BackColor="0,245,245,245" BorderColor="DarkGray" Sides="None" Ref="41" />
  </StyleSheet>
  <ObjectStorage>
    <Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;ELD_x0020_HOS_x0020_Violation_x0020_Report&gt;&lt;xs:schema id=&quot;ELD_x0020_HOS_x0020_Violation_x0020_Report&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;ELD_x0020_HOS_x0020_Violation_x0020_Report&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;ELDeLogViolation&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;StartTime&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Duration&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;ViolationType&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;CityState&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EmployeeName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/ELD_x0020_HOS_x0020_Violation_x0020_Report&gt;" Type="System.Data.DataSet" Ref="42" />
  </ObjectStorage>
  <Extensions>
    <Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="43" />
  </Extensions>
</XtraReportsLayoutSerializer>', 'ec5661df-5f6e-4dfd-a13d-1b66492f95f7', '59c4bfb5-1d57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('2715a47c-cdea-4063-b10f-0b2049abd40b', N'Stop Report', 'd226c6d5-6924-11e3-a678-a0b3cc4a6a82', NULL, 1, NULL, 1, 'f85a4b2f-ed82-4436-8943-96548b2f0af5', 'f85a4b2f-ed82-4436-8943-96548b2f0af5', '2016-03-10 11:28:30.337', '2016-03-21 06:51:33.437', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" Name="Stop Report" Margins="100, 98, 98, 100" DisplayName="Stop Report" PageWidth="850" PageHeight="1100" DataMember="StopReport" DataSource="#Ref-51">
  <Bands>
    <Item1 ControlType="TopMarginBand" HeightF="98" Name="TopMargin1" Padding="0,5,0,0,100" Ref="0">
      <StylePriority UsePadding="false" />
    </Item1>
    <Item2 ControlType="ReportHeaderBand" HeightF="125" Name="reportHeaderBand1" Padding="2,0,0,0,100" Ref="7">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="638, 39" LocationFloat="6, 29.17" TextAlignment="TopCenter" Text="Stop Report" StyleName="Title" Name="label11" Font="Arial Black, 25pt, style=Bold" Ref="1">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRPageInfo" TextAlignment="MiddleRight" Format="{0: &quot;at &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="133, 22.92" LocationFloat="511, 79.17" StyleName="PageInfo" Name="pageInfo1" Font="Times New Roman, 9pt" Ref="2">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="361.46, 22.92" LocationFloat="150, 79.17" TextAlignment="MiddleRight" Text="label12" Name="label12" Padding="2,0,0,0,100" Ref="4">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Created by: {0}" Ref="3" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="493.75, 22.92" LocationFloat="150, 102.08" TextAlignment="TopRight" Text="label13" Name="label13" Padding="2,0,0,0,100" Ref="6">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.DateRange" FormatString="Date Range: {0}" Ref="5" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item4>
      </Controls>
    </Item2>
    <Item3 ControlType="GroupHeaderBand" Level="2" HeightF="59.38" Name="groupHeaderBand1" Ref="15">
      <GroupFields>
        <Item1 FieldName="Driver" Ref="8" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="281.25, 25" LocationFloat="72.92, 30.21" TextAlignment="MiddleLeft" StyleName="DataField" Name="label2" Font="Times New Roman, 10pt" Ref="10">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="StopReport.Driver" Ref="9" />
          </DataBindings>
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLabel" SizeF="67.83, 25" LocationFloat="5.21, 30.21" TextAlignment="MiddleLeft" Text="Driver" StyleName="FieldCaption" Name="label1" Font="Times New Roman, 10pt, style=Bold" Ref="11">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLine" ForeColor="255,82,82,82" SizeF="639, 2.08" LocationFloat="5.21, 57.29" Name="line1" Ref="12">
          <StylePriority UseForeColor="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="287.5, 23.96" LocationFloat="356.25, 29.17" TextAlignment="MiddleRight" Text="label5" Name="label5" Padding="2,2,0,0,100" Ref="14">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="StopReport.EmployeeNumberTotal" FormatString="Total Stop Duration : {0}" Ref="13" />
          </DataBindings>
          <StylePriority UseTextAlignment="false" />
        </Item4>
      </Controls>
    </Item3>
    <Item4 ControlType="GroupHeaderBand" Level="1" HeightF="27.08" Name="groupHeaderBand2" Ref="23">
      <GroupFields>
        <Item1 FieldName="Equipment" Ref="16" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="264.58, 23.96" LocationFloat="91.67, 0" TextAlignment="MiddleLeft" StyleName="DataField" Name="label4" Font="Times New Roman, 9pt" Ref="18">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="StopReport.Equipment" Ref="17" />
          </DataBindings>
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLabel" SizeF="65.63, 25" LocationFloat="26.04, 0" TextAlignment="MiddleLeft" Text="Equipment" StyleName="FieldCaption" Name="label3" Font="Times New Roman, 9pt, style=Bold" Ref="19">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLine" ForeColor="255,82,82,82" SizeF="617, 2.08" LocationFloat="26.04, 25" Name="line2" Ref="20">
          <StylePriority UseForeColor="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="284.38, 22.92" LocationFloat="357.29, 1.04" TextAlignment="MiddleRight" Name="label8" Padding="2,2,0,0,100" Ref="22">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="StopReport.EquipmentNumberTotal" FormatString="Equipment Stop Duration : {0}" Ref="21" />
          </DataBindings>
          <StylePriority UseTextAlignment="false" />
        </Item4>
      </Controls>
    </Item4>
    <Item5 ControlType="GroupHeaderBand" StyleName="FieldCaption" HeightF="40.42" Name="groupHeaderBand3" Padding="0,5,0,0,100" Ref="30">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRTable" SizeF="615.63, 35.42" LocationFloat="25.5, 5" Name="table1" BorderColor="DarkGray" Borders="All" Ref="29">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1.012" Name="tableRow1" Ref="28">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.5059667179286859" TextAlignment="MiddleCenter" Text="Equipment" Name="tableCell1" BackColor="255,194,194,194" Ref="24">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.727327157022486" TextAlignment="MiddleCenter" Text="Date time Captured" Name="tableCell2" BackColor="255,194,194,194" Ref="25">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="1.1279010076066265" TextAlignment="MiddleCenter" Text="Location" Name="tableCell3" BackColor="255,194,194,194" Ref="26">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.7536880230265708" TextAlignment="MiddleCenter" Text="Stop Duration" Name="tableCell4" BackColor="255,194,194,194" Ref="27">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item4>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item5>
    <Item6 ControlType="DetailBand" StyleName="DataField" HeightF="25" Name="detailBand1" Ref="41">
      <Controls>
        <Item1 ControlType="XRTable" SizeF="614.59, 25" LocationFloat="25.5, 0" EvenStyleName="xrControlStyle1" Name="table2" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="40">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow2" Ref="39">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.4813545010149006" TextAlignment="MiddleLeft" Name="tableCell7" Padding="5,0,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="32">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="StopReport.Equipment" Ref="31" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.6919470952089197" TextAlignment="MiddleLeft" Name="tableCell8" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="34">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="StopReport.Date Time Captured" Ref="33" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="1.073035453662417" TextAlignment="MiddleLeft" Name="tableCell9" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="36">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="StopReport.Address" FormatString="{0: MM/dd/yyyy}" Ref="35" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.7120195779012409" TextAlignment="MiddleLeft" Name="tableCell10" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="38">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="StopReport.durationinsecond" Ref="37" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item4>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item6>
    <Item7 ControlType="GroupFooterBand" HeightF="28.13" Name="GroupFooter1" Ref="42" />
    <Item8 ControlType="PageFooterBand" HeightF="48.96" Name="pageFooterBand1" Ref="44">
      <Controls>
        <Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="313, 23" LocationFloat="331, 6" StyleName="PageInfo" Name="pageInfo2" Padding="0,5,0,0,100" Font="Times New Roman, 9pt" Ref="43">
          <StylePriority UseFont="false" UsePadding="false" />
        </Item1>
      </Controls>
    </Item8>
    <Item9 ControlType="BottomMarginBand" Name="BottomMargin1" Padding="0,10,0,0,100" Ref="45">
      <StylePriority UsePadding="false" />
    </Item9>
  </Bands>
  <StyleSheet>
    <Item1 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="Title" Font="Times New Roman, 24pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="46" />
    <Item2 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="FieldCaption" Font="Times New Roman, 10pt, style=Bold" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="47" />
    <Item3 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="PageInfo" Font="Times New Roman, 8pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="48" />
    <Item4 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="DataField" Font="Times New Roman, 8pt" Padding="2,2,0,0,100" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="49" />
    <Item5 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="xrControlStyle1" Font="Times New Roman, 9pt" BackColor="WhiteSmoke" BorderColor="DarkGray" Sides="None" BorderWidthSerializable="1" Ref="50" />
  </StyleSheet>
  <ObjectStorage>
    <Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;Stop_x0020_Report&gt;&lt;xs:schema id=&quot;Stop_x0020_Report&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;Stop_x0020_Report&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;StopReport&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;Driver&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Equipment&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Date_x0020_Time_x0020_Captured&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;durationinsecond&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EmployeeNumberTotal&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EquipmentNumberTotal&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/Stop_x0020_Report&gt;" Type="System.Data.DataSet" Ref="51" />
  </ObjectStorage>
  <Extensions>
    <Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="52" />
  </Extensions>
</XtraReportsLayoutSerializer>', 'd739b6c2-c1a3-40a7-922d-c84e69495064', '8b799cdc-1d57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('b351e5b2-d546-4242-99ac-100e1ab21804', N'Driver Logs Report', 'e468d955-6924-11e3-a678-a0b3cc4a6a82', N'As a manager, I want to run a report for a single or multiple drivers that gives me their activity based off a date range.', 1, NULL, 1, '91e29695-0d94-11e6-80f6-00155db47809', '91e29695-0d94-11e6-80f6-00155db47809', '2017-02-27 17:25:13.330', '2017-02-27 17:25:13.330', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
			<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" PaperKind="A4Rotated" Name="Driver Logs Report" Margins="40, 29, 100, 100" DisplayName="Driver Logs Report" PageWidth="1169" PageHeight="827" DataMember="DriverLogs" DataSource="#Ref-51">
			  <Bands>
    <Item1 ControlType="TopMarginBand" Name="TopMargin1" Ref="0" />
    <Item2 ControlType="ReportHeaderBand" HeightF="140.63" Name="reportHeaderBand1" Padding="2,0,0,0,100" Ref="7">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="385.42, 44.79" LocationFloat="343.75, 29.17" TextAlignment="TopLeft" Text="Driver Logs Report" StyleName="Title" Name="label11" Font="Arial Black, 25pt, style=Bold" Ref="1">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLabel" SizeF="266.67, 20.83" LocationFloat="820.83, 104.17" TextAlignment="MiddleRight" Text="label13" Name="label13" Padding="2,0,0,0,100" Ref="3">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.DateRange" FormatString="Date Range: {0}" Ref="2" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="323.96, 16.67" LocationFloat="630.21, 86.46" TextAlignment="MiddleRight" Text="label12" Name="label12" Padding="2,0,0,0,100" Ref="5">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Created by: {0}" Ref="4" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRPageInfo" TextAlignment="MiddleRight" Format="{0: &quot;at &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="133.33, 16.67" LocationFloat="954.17, 87.5" StyleName="PageInfo" Name="pageInfo1" Font="Times New Roman, 9pt" Ref="6">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item4>
      </Controls>
    </Item2>
    <Item3 ControlType="GroupHeaderBand" Level="1" HeightF="39.58" Name="groupHeaderBand1" Ref="12">
      <GroupFields>
        <Item1 FieldName="EmployeeName" Ref="8" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="182.33, 25" LocationFloat="5.99, 12.5" TextAlignment="MiddleLeft" Text="label14" Name="label14" Padding="2,2,0,0,100" Font="Times New Roman, 10pt, style=Bold" Ref="10">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="DriverLogs.DriverName" Ref="9" />
          </DataBindings>
          <Summary FormatString="Total: {0} records" Running="Group" Func="Count" />
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLine" SizeF="1082.29, 2.08" LocationFloat="5.21, 37.5" Name="line1" BorderColor="255,89,89,89" Ref="11">
          <StylePriority UseBorderColor="false" />
        </Item2>
      </Controls>
    </Item3>
    <Item4 ControlType="GroupHeaderBand" StyleName="FieldCaption" HeightF="30" Name="groupHeaderBand2" Ref="23">
      <Controls>
        <Item1 ControlType="XRTable" SizeF="1081, 25" LocationFloat="7.29, 5" Name="table1" BackColor="0,0,0,0" BorderColor="DarkGray" Borders="All" Ref="22">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow1" Ref="21">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.7008028244241334" TextAlignment="MiddleLeft" Text="Driver Name" Name="tableCell1" BackColor="255,194,194,194" BorderColor="DarkGray" Padding="5,0,0,0,100" Borders="All" Ref="13">
                  <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.624002514898201" TextAlignment="MiddleLeft" Text="Co-Driver Name" Name="tableCell4" BackColor="255,194,194,194" Padding="5,0,0,0,100" Ref="14">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.4800019345370776" TextAlignment="MiddleLeft" Text="Unit#" Name="tableCell5" BackColor="255,194,194,194" Padding="5,0,0,0,100" Ref="15">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.6528026309704258" TextAlignment="MiddleLeft" Text="Start Time" Name="tableCell2" BackColor="255,194,194,194" Padding="5,0,0,0,100" Ref="16">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="0.6480026116250548" TextAlignment="MiddleLeft" Text="Activity" Name="tableCell9" BackColor="255,194,194,194" Padding="5,2,0,0,100" Ref="17">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item5>
                <Item6 ControlType="XRTableCell" Weight="0.5760023214444933" TextAlignment="MiddleLeft" Text="Duration" Name="tableCell16" BackColor="255,194,194,194" Padding="5,2,0,0,100" Ref="18">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item6>
                <Item7 ControlType="XRTableCell" Weight="0.648002611625055" TextAlignment="MiddleLeft" Text="Location" Name="tableCell15" BackColor="255,194,194,194" Padding="5,2,0,0,100" Ref="19">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item7>
                <Item8 ControlType="XRTableCell" Weight="0.8592034628213691" TextAlignment="MiddleLeft" Text="Remarks" Name="tableCell14" BackColor="255,194,194,194" Padding="5,2,0,0,100" Ref="20">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item8>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item4>
    <Item5 ControlType="DetailBand" StyleName="DataField" HeightF="25" Name="detailBand1" Ref="42">
      <Controls>
        <Item1 ControlType="XRTable" SizeF="1081, 25" LocationFloat="7.29, 0" EvenStyleName="xrControlStyle1" Name="table2" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="41">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow2" Ref="40">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.701151265149575" TextAlignment="MiddleLeft" Name="tableCell3" BorderColor="DarkGray" Padding="5,0,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="25">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DriverLogs.DriverName" FormatString="{0: MM/dd/yyyy hh:mm tt}" Ref="24" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.6243127703386627" TextAlignment="MiddleLeft" Name="tableCell8" BorderColor="DarkGray" Padding="5,0,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="27">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DriverLogs.CoDriver" Ref="26" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.48024059256820206" TextAlignment="MiddleLeft" Name="tableCell6" BorderColor="DarkGray" Padding="5,0,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="29">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DriverLogs.Unit" Ref="28" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.6531272058927547" TextAlignment="MiddleLeft" Name="tableCell7" BorderColor="DarkGray" Padding="5,0,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="31">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DriverLogs.StartTime" Ref="30" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="0.6483247999670728" TextAlignment="MiddleLeft" Text="tableCell10" Name="tableCell10" Padding="5,2,0,0,100" Ref="33">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DriverLogs.Activity" Ref="32" />
                  </DataBindings>
                  <StylePriority UsePadding="false" UseTextAlignment="false" />
                </Item5>
                <Item6 ControlType="XRTableCell" Weight="0.5762887110818424" TextAlignment="MiddleLeft" Text="tableCell13" Name="tableCell13" Padding="5,2,0,0,100" Ref="35">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DriverLogs.Duration" Ref="34" />
                  </DataBindings>
                  <StylePriority UsePadding="false" UseTextAlignment="false" />
                </Item6>
                <Item7 ControlType="XRTableCell" Weight="0.6483247999670729" TextAlignment="MiddleLeft" Text="tableCell12" Name="tableCell12" Padding="5,2,0,0,100" Ref="37">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DriverLogs.Location" Ref="36" />
                  </DataBindings>
                  <StylePriority UsePadding="false" UseTextAlignment="false" />
                </Item7>
                <Item8 ControlType="XRTableCell" Weight="0.8596306606970818" TextAlignment="MiddleLeft" Text="tableCell11" Name="tableCell11" Ref="39">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DriverLogs.Remark" Ref="38" />
                  </DataBindings>
                  <StylePriority UseTextAlignment="false" />
                </Item8>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item5>
    <Item6 ControlType="PageFooterBand" HeightF="29" Name="pageFooterBand1" Padding="5,2,0,0,100" Ref="44">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="313, 23" LocationFloat="773.54, 5.99" StyleName="PageInfo" Name="pageInfo2" Font="Times New Roman, 9pt" Ref="43">
          <StylePriority UseFont="false" />
        </Item1>
      </Controls>
    </Item6>
    <Item7 ControlType="BottomMarginBand" Name="BottomMargin1" Ref="45" />
  </Bands>
  <StyleSheet>
    <Item1 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="Title" Font="Times New Roman, 24pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="46" />
    <Item2 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="FieldCaption" Font="Times New Roman, 10pt, style=Bold" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="47" />
    <Item3 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="PageInfo" Font="Times New Roman, 8pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="48" />
    <Item4 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="DataField" Font="Times New Roman, 8pt" Padding="2,2,0,0,100" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="49" />
    <Item5 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="xrControlStyle1" Font="Times New Roman, 9pt" BackColor="0,245,245,245" BorderColor="DarkGray" Sides="None" Ref="50" />
  </StyleSheet>
  <ObjectStorage>
    <Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;Driver_x0020_Logs_x0020_Report&gt;&lt;xs:schema id=&quot;Driver_x0020_Logs_x0020_Report&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;Driver_x0020_Logs_x0020_Report&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;DriverLogs&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;Duration&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;StartTime&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DriverName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;CoDriver&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Unit&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Location&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Activity&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Remark&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/Driver_x0020_Logs_x0020_Report&gt;" Type="System.Data.DataSet" Ref="51" />
  </ObjectStorage>
  <Extensions>
    <Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="52" />
  </Extensions>
</XtraReportsLayoutSerializer>', 'f660bc58-c121-4012-bc8b-b9a7612ddcd9', '59c4bfb5-1d57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('c424730b-682d-496e-95c1-12daa6bcdd2c', N'Unidentified Driving Report', 'e468d955-6924-11e3-a678-a0b3cc4a6a82', N'Unidentified Driving Report', 1, NULL, 1, '91e29695-0d94-11e6-80f6-00155db47809', '91e29695-0d94-11e6-80f6-00155db47809', '2017-02-10 06:51:39.950', '2017-12-26 07:25:22.670', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" Name="Unidentified Driving Report" Margins="98, 59, 98, 100" DisplayName="Unidentified Driving Report" PageWidth="850" PageHeight="1100" DataMember="UnidentifiedDrivingReport" DataSource="#Ref-48">
  <Bands>
    <Item1 ControlType="TopMarginBand" HeightF="98" Name="TopMargin1" Padding="0,5,0,0,100" Ref="0">
      <StylePriority UsePadding="false" />
    </Item1>
    <Item2 ControlType="ReportHeaderBand" HeightF="125" Name="reportHeaderBand1" Padding="2,0,0,0,100" Ref="7">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="638, 39" LocationFloat="6, 29.17" TextAlignment="TopCenter" Text="Unidentified Driving Report" StyleName="Title" Name="label11" Font="Arial Black, 25pt, style=Bold" Ref="1">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRPageInfo" TextAlignment="MiddleRight" Format="{0: &quot;at &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="133, 22.92" LocationFloat="511, 79.17" StyleName="PageInfo" Name="pageInfo1" Font="Times New Roman, 9pt" Ref="2">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="361.46, 22.92" LocationFloat="150, 79.17" TextAlignment="MiddleRight" Text="label12" Name="label12" Padding="2,0,0,0,100" Ref="4">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Created by: {0}" Ref="3" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="493.75, 22.92" LocationFloat="150, 102.08" TextAlignment="TopRight" Text="label13" Name="label13" Padding="2,0,0,0,100" Ref="6">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.DateRange" FormatString="Date Range: {0}" Ref="5" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item4>
      </Controls>
    </Item2>
    <Item3 ControlType="GroupHeaderBand" Level="2" HeightF="45.83" Name="groupHeaderBand1" Ref="12">
      <GroupFields>
        <Item1 FieldName="Equipment" Ref="8" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="326.04, 25" LocationFloat="4.17, 18.75" TextAlignment="MiddleLeft" StyleName="DataField" Name="label2" Font="Times New Roman, 10pt, style=Bold" Ref="10">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UnidentifiedDrivingReport.Equipment" FormatString="Unit # {0}" Ref="9" />
          </DataBindings>
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLine" ForeColor="255,82,82,82" SizeF="639, 2.08" LocationFloat="5.21, 43.75" Name="line1" Ref="11">
          <StylePriority UseForeColor="false" />
        </Item2>
      </Controls>
    </Item3>
    <Item4 ControlType="GroupHeaderBand" Level="1" HeightF="38.54" Name="groupHeaderBand2" Ref="17">
      <GroupFields>
        <Item1 FieldName="Date" Ref="13" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="287.5, 23.96" LocationFloat="20.83, 12.5" TextAlignment="MiddleLeft" StyleName="DataField" Name="label4" Font="Times New Roman, 9pt, style=Bold" Ref="15">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UnidentifiedDrivingReport.Date" FormatString="{0: &quot;Date &quot; MM/dd/yyyy}" Ref="14" />
          </DataBindings>
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLine" ForeColor="255,82,82,82" SizeF="621.88, 2.08" LocationFloat="20.83, 36.46" Name="line2" Ref="16">
          <StylePriority UseForeColor="false" />
        </Item2>
      </Controls>
    </Item4>
    <Item5 ControlType="GroupHeaderBand" StyleName="FieldCaption" HeightF="40.42" Name="groupHeaderBand3" Padding="0,5,0,0,100" Ref="25">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRTable" SizeF="616.67, 35.42" LocationFloat="21.33, 5" Name="table1" BorderColor="DarkGray" Borders="All" Ref="24">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1.012" Name="tableRow1" Ref="23">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.384732758275405" TextAlignment="MiddleCenter" Text="Start Time" Name="tableCell1" BackColor="255,194,194,194" Ref="18">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.5955667145791415" TextAlignment="MiddleCenter" Text="Duration" Name="tableCell2" BackColor="255,194,194,194" Ref="19">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.4374538963767954" TextAlignment="MiddleCenter" Text="Distance (Miles)" Name="tableCell3" BackColor="255,194,194,194" Ref="20">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="1.011922036495016" TextAlignment="MiddleCenter" Text="Last Location" Name="tableCell5" BackColor="255,194,194,194" Ref="21">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="0.690434405500549" TextAlignment="MiddleCenter" Text="Assigned Employee" Name="tableCell4" BackColor="255,194,194,194" Ref="22">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item5>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item5>
    <Item6 ControlType="DetailBand" StyleName="DataField" HeightF="35.42" Name="detailBand1" Ref="38">
      <Controls>
        <Item1 ControlType="XRTable" SizeF="615.63, 35.42" LocationFloat="20.83, 0" EvenStyleName="xrControlStyle1" Name="table2" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="37">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="0.5574441296820901" Name="tableRow2" Ref="36">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.36602974671043087" TextAlignment="MiddleCenter" Name="tableCell7" Padding="5,0,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="27">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="UnidentifiedDrivingReport.Start Time" FormatString="{0:hh:mm tt}" Ref="26" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.5666144329995372" TextAlignment="MiddleCenter" Name="tableCell8" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="29">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="UnidentifiedDrivingReport.Duration" Ref="28" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.41618795240115525" TextAlignment="MiddleCenter" Name="tableCell9" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="31">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="UnidentifiedDrivingReport.Distance" Ref="30" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.962727419942131" TextAlignment="MiddleCenter" Text="tableCell6" Name="tableCell6" Ref="33">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="UnidentifiedDrivingReport.Last Location" Ref="32" />
                  </DataBindings>
                  <StylePriority UseTextAlignment="false" />
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="0.6518661839717658" TextAlignment="MiddleCenter" Name="tableCell10" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="35">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="UnidentifiedDrivingReport.Employee" Ref="34" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item5>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item6>
    <Item7 ControlType="GroupFooterBand" HeightF="21.88" Name="GroupFooter1" Ref="39" />
    <Item8 ControlType="PageFooterBand" HeightF="48.96" Name="pageFooterBand1" Ref="41">
      <Controls>
        <Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="313, 23" LocationFloat="331, 6" StyleName="PageInfo" Name="pageInfo2" Padding="0,5,0,0,100" Font="Times New Roman, 9pt" Ref="40">
          <StylePriority UseFont="false" UsePadding="false" />
        </Item1>
      </Controls>
    </Item8>
    <Item9 ControlType="BottomMarginBand" Name="BottomMargin1" Padding="0,10,0,0,100" Ref="42">
      <StylePriority UsePadding="false" />
    </Item9>
  </Bands>
  <StyleSheet>
    <Item1 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="Title" Font="Times New Roman, 24pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="43" />
    <Item2 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="FieldCaption" Font="Times New Roman, 10pt, style=Bold" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="44" />
    <Item3 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="PageInfo" Font="Times New Roman, 8pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="45" />
    <Item4 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="DataField" Font="Times New Roman, 8pt" Padding="2,2,0,0,100" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="46" />
    <Item5 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="xrControlStyle1" Font="Times New Roman, 9pt" BackColor="WhiteSmoke" BorderColor="DarkGray" Sides="None" BorderWidthSerializable="1" Ref="47" />
  </StyleSheet>
  <ObjectStorage>
    <Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;Unidentified_x0020_Driving_x0020_Report&gt;&lt;xs:schema id=&quot;Unidentified_x0020_Driving_x0020_Report&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;Unidentified_x0020_Driving_x0020_Report&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;UnidentifiedDrivingReport&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;Date&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Start_x0020_Time&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Distance&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Duration&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Last_x0020_Location&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Employee&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Equipment&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/Unidentified_x0020_Driving_x0020_Report&gt;" Type="System.Data.DataSet" Ref="48" />
  </ObjectStorage>
  <Extensions>
    <Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="49" />
  </Extensions>
</XtraReportsLayoutSerializer>', '7c198664-e35e-48f2-bf6a-8c46e931dff8', '8b799cdc-1d57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('a33e0a8a-f5c5-47f0-b641-1572b1b23d04', N'Miles Traveled by State', 'd226c6d5-6924-11e3-a678-a0b3cc4a6a82', NULL, 1, NULL, 1, 'f85a4b2f-ed82-4436-8943-96548b2f0af5', 'e5437ddb-6af7-11e4-80dd-00155db47809', '2015-09-14 10:03:23.003', '2016-04-26 19:35:45.877', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" Name="Miles Traveled by State" Margins="97, 95, 94, 96" ReportUnit="Pixels" SnapGridSize="12" Dpi="96" DisplayName="Miles Traveled by State" PageWidth="816" PageHeight="1056" DataMember="DistanceTraveledDataCube" FilterString="[Total Miles] &gt; 0.05 And ([Device Type] = ''Black box'' Or [Device Type] = ''Blackbox'') And ([MCS Blackbox Device ID] = ''Unknown'') And [Employee Number] &lt;&gt; ''Not Assigned''" DataSource="#Ref-52">
  <Bands>
    <Item1 ControlType="TopMarginBand" HeightF="94" Name="TopMargin1" Dpi="96" Padding="0,5,0,0,96" Ref="0">
      <StylePriority UsePadding="false" />
    </Item1>
    <Item2 ControlType="ReportHeaderBand" HeightF="145" Name="reportHeaderBand1" Dpi="96" Padding="2,0,0,0,96" Ref="7">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="612.48, 37.44" LocationFloat="5.76, 28" Dpi="96" TextAlignment="TopCenter" Text="Miles Travelled by State Report" StyleName="Title" Name="label11" Font="Arial Black, 25pt, style=Bold" Ref="1">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRPageInfo" TextAlignment="MiddleRight" Format="{0: &quot;at &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="127.68, 22" LocationFloat="490.56, 76" Dpi="96" StyleName="PageInfo" Name="pageInfo1" Padding="2,0,0,0,96" Font="Times New Roman, 9pt" Ref="2">
          <StylePriority UseFont="false" UsePadding="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="460, 22" LocationFloat="31, 76" Dpi="96" TextAlignment="MiddleRight" Text="label12" Name="label12" Padding="2,0,0,0,96" Font="Times New Roman, 9pt" Ref="4">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Created by: {0}" Ref="3" />
          </DataBindings>
          <StylePriority UseFont="false" UsePadding="false" UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="307, 22" LocationFloat="311, 98" Dpi="96" TextAlignment="TopRight" Text="label13" Name="label13" Padding="2,0,0,0,96" Font="Times New Roman, 9pt" Ref="6">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.DateRange" FormatString="Date Range: {0}" Ref="5" />
          </DataBindings>
          <StylePriority UseFont="false" UsePadding="false" UseTextAlignment="false" />
        </Item4>
      </Controls>
    </Item2>
    <Item3 ControlType="GroupHeaderBand" Level="3" HeightF="50" Name="GroupHeader1" Dpi="96" Expanded="false" Ref="15">
      <GroupFields>
        <Item1 FieldName="State" Ref="8" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="210.68, 24" LocationFloat="408, 24" Dpi="96" TextAlignment="MiddleRight" Text="label14" Name="label15" BackColor="33,255,241,46" Padding="0,5,0,0,96" Font="Times New Roman, 9pt" Ref="10">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="DistanceTraveledDataCube.Total Miles" FormatString="{0:#,##0}" Ref="9" />
          </DataBindings>
          <Summary FormatString="{0: Total Miles: #,##0.0}" Running="Group" />
          <StylePriority UseBackColor="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLabel" SizeF="361.12, 24" LocationFloat="46.88, 24" Dpi="96" TextAlignment="MiddleLeft" StyleName="DataField" Name="label2" BackColor="33,255,241,46" Font="Times New Roman, 9pt" Ref="12">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="DistanceTraveledDataCube.State" Ref="11" />
          </DataBindings>
          <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="40.92, 24" LocationFloat="5.77, 24" Dpi="96" TextAlignment="MiddleLeft" Text="State" StyleName="FieldCaption" Name="label1" BackColor="33,255,241,46" Padding="5,0,0,0,96" Font="Times New Roman, 9pt, style=Bold" Ref="13">
          <StylePriority UseBackColor="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRLine" ForeColor="255,82,82,82" SizeF="612.96, 2" LocationFloat="5.64, 48" Dpi="96" Name="line1" Ref="14">
          <StylePriority UseForeColor="false" />
        </Item4>
      </Controls>
    </Item3>
    <Item4 ControlType="GroupHeaderBand" Level="2" HeightF="30.72" Name="groupHeaderBand1" Dpi="96" Ref="21">
      <GroupFields>
        <Item1 FieldName="Fuel Type" Ref="16" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="522, 24" LocationFloat="96.23, 5" Dpi="96" TextAlignment="MiddleLeft" StyleName="DataField" Name="label4" Font="Times New Roman, 9pt" Ref="18">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="DistanceTraveledDataCube.Fuel Type" Ref="17" />
          </DataBindings>
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLabel" SizeF="60, 24" LocationFloat="36, 5" Dpi="96" TextAlignment="MiddleLeft" Text="Fuel Type" StyleName="FieldCaption" Name="label3" Font="Times New Roman, 9pt, style=Bold" Ref="19">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLine" ForeColor="255,82,82,82" SizeF="582.72, 2" LocationFloat="35.23, 28.72" Dpi="96" Name="line2" Ref="20">
          <StylePriority UseForeColor="false" />
        </Item3>
      </Controls>
    </Item4>
    <Item5 ControlType="GroupHeaderBand" Level="1" HeightF="30.8" Name="groupHeaderBand2" Dpi="96" Ref="28">
      <Controls>
        <Item1 ControlType="XRTable" SizeF="613, 24" LocationFloat="5.24, 6.8" Dpi="96" Name="table1" BorderColor="DarkGray" Borders="All" Ref="27">
          <Rows>
            <Item1 ControlType="XRTableRow" Dpi="96" Weight="1" Name="tableRow1" Ref="26">
              <Cells>
                <Item1 ControlType="XRTableCell" Dpi="96" Weight="0.7581330981421329" TextAlignment="MiddleCenter" Text="Employee Number" Name="tableCell1" BackColor="255,194,194,194" Ref="22">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Dpi="96" Weight="0.7581330981421329" TextAlignment="MiddleCenter" Text="Equipment Number" Name="tableCell2" BackColor="255,194,194,194" Ref="23">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Dpi="96" Weight="0.8122854622951424" TextAlignment="MiddleLeft" Text="Device Serial Number" Name="tableCell7" BackColor="255,194,194,194" Padding="5,0,0,0,100" Ref="24">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Dpi="96" Weight="0.9909882640000738" TextAlignment="MiddleCenter" Text="Miles Traveled" Name="tableCell3" BackColor="255,194,194,194" Ref="25">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item4>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item5>
    <Item6 ControlType="GroupHeaderBand" StyleName="FieldCaption" HeightF="24" Name="groupHeaderBand3" Dpi="96" Padding="0,5,0,0,96" Ref="40">
      <GroupFields>
        <Item1 FieldName="Employee Number" Ref="29" />
      </GroupFields>
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRTable" SizeF="613, 24" LocationFloat="5.24, 0" Dpi="96" EvenStyleName="xrControlStyle1" Name="table2" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="39">
          <Rows>
            <Item1 ControlType="XRTableRow" Dpi="96" Weight="1" Name="tableRow2" Ref="38">
              <Cells>
                <Item1 ControlType="XRTableCell" Dpi="96" Weight="0.756756235772343" TextAlignment="MiddleLeft" Name="tableCell4" Padding="5,0,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="31">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DistanceTraveledDataCube.Employee Number" Ref="30" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Dpi="96" Weight="0.7567562357723432" TextAlignment="MiddleCenter" Text="label" Name="tableCell5" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="33">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DistanceTraveledDataCube.Equipment Number" Ref="32" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Dpi="96" Weight="0.8108102526132248" TextAlignment="MiddleLeft" Text="tableCell8" Name="tableCell8" Font="Times New Roman, 9pt" Ref="35">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DistanceTraveledDataCube.Device Serial Number" FormatString="{0}" Ref="34" />
                  </DataBindings>
                  <StylePriority UseFont="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Dpi="96" Weight="0.9891885081881342" TextAlignment="MiddleRight" Name="tableCell6" Padding="0,5,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="37">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DistanceTraveledDataCube.Total Miles" FormatString="{0:#,##0}" Ref="36" />
                  </DataBindings>
                  <Summary FormatString="{0:#,##0.0}" Running="Group" />
                  <StylePriority UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item4>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item6>
    <Item7 ControlType="DetailBand" StyleName="DataField" HeightF="0" Name="detailBand1" Dpi="96" Ref="42">
      <SortFields>
        <Item1 FieldName="Total Miles" SortOrder="Descending" Ref="41" />
      </SortFields>
    </Item7>
    <Item8 ControlType="GroupFooterBand" HeightF="38" Name="GroupFooter1" Dpi="96" Ref="43" />
    <Item9 ControlType="PageFooterBand" HeightF="47" Name="pageFooterBand1" Dpi="96" Padding="2,0,0,0,96" Ref="45">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="300.48, 22.08" LocationFloat="317.76, 5.76" Dpi="96" StyleName="PageInfo" Name="pageInfo2" Ref="44" />
      </Controls>
    </Item9>
    <Item10 ControlType="BottomMarginBand" HeightF="96" Name="BottomMargin1" Dpi="96" Padding="0,10,0,0,96" Ref="46">
      <StylePriority UsePadding="false" />
    </Item10>
  </Bands>
  <StyleSheet>
    <Item1 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="Title" Font="Times New Roman, 24pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="47" />
    <Item2 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="FieldCaption" Font="Times New Roman, 10pt, style=Bold" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="48" />
    <Item3 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="PageInfo" Font="Times New Roman, 8pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="49" />
    <Item4 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="DataField" Font="Times New Roman, 8pt" Padding="2,2,0,0,100" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="50" />
    <Item5 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="xrControlStyle1" Font="Times New Roman, 9pt" BackColor="WhiteSmoke" BorderColor="DarkGray" Sides="None" BorderWidthSerializable="1" Ref="51" />
  </StyleSheet>
  <ObjectStorage>
    <Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;Miles_x0020_Traveled_x0020_by_x0020_State&gt;&lt;xs:schema id=&quot;Miles_x0020_Traveled_x0020_by_x0020_State&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;Miles_x0020_Traveled_x0020_by_x0020_State&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;MileOrKm&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;DistanceTraveledDataCube&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;State&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Fuel_x0020_Type&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Equipment_x0020_Number&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Employee_x0020_Number&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Date&quot; type=&quot;xs:dateTime&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Device_x0020_Serial_x0020_Number&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Device_x0020_Type&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;MCS_x0020_Blackbox_x0020_Device_x0020_ID&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Total_x0020_Miles&quot; type=&quot;xs:decimal&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/Miles_x0020_Traveled_x0020_by_x0020_State&gt;" Type="System.Data.DataSet" Ref="52" />
  </ObjectStorage>
  <Extensions>
    <Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="53" />
  </Extensions>
</XtraReportsLayoutSerializer>', 'fd3dc247-b4ce-4e20-889d-49d197880677', '8b799cdc-1d57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('23061eb2-59cb-4356-a6fd-187b89c23b7d', N'Vehicle Mileage Report', 'd226c6d5-6924-11e3-a678-a0b3cc4a6a82', N'Vehicle Mileage Report', 1, NULL, 1, '91e29695-0d94-11e6-80f6-00155db47809', '91e29695-0d94-11e6-80f6-00155db47809', '2017-02-15 09:47:31.903', '2017-02-16 08:43:10.733', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" PaperKind="A4Rotated" Name="Vehicle Mileage Report" Margins="30, 19, 0, 0" DisplayName="Vehicle Mileage Report" PageWidth="1169" PageHeight="827" DataMember="VehicleMileageReport" DataSource="#Ref-57">
  <Watermark Font="Times New Roman, 9pt" />
  <Bands>
    <Item1 ControlType="TopMarginBand" HeightF="0" Name="TopMargin1" Ref="0" />
    <Item2 ControlType="ReportHeaderBand" HeightF="136.46" Name="reportHeaderBand1" Padding="2,0,0,0,100" Ref="7">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="637.5, 53.13" LocationFloat="232.29, 14.58" TextAlignment="TopCenter" Text="Vehicles Mileage Report" StyleName="Title" Name="label11" Font="Arial Black, 25pt, style=Bold" Ref="1">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRPageInfo" TextAlignment="MiddleRight" Format="{0: &quot;at &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="133, 22.92" LocationFloat="967.25, 79.19" StyleName="PageInfo" Name="pageInfo1" Font="Times New Roman, 9pt" Ref="2">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="361.46, 22.92" LocationFloat="605.73, 79.19" TextAlignment="MiddleRight" Text="label12" Name="label12" Padding="2,0,0,0,100" Ref="4">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Created by: {0}" Ref="3" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="493.75, 22.92" LocationFloat="606.25, 102.09" TextAlignment="TopRight" Text="label13" Name="label13" Padding="2,0,0,0,100" Ref="6">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.DateRange" FormatString="Date Range: {0}" Ref="5" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item4>
      </Controls>
    </Item2>
    <Item3 ControlType="GroupHeaderBand" Level="1" HeightF="48.96" Name="groupHeaderBand1" Ref="21">
      <GroupFields>
        <Item1 FieldName="Employee Name" SortOrder="Descending" Ref="8" />
        <Item2 Ref="9" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLine" SizeF="1094.79, 2.08" LocationFloat="5.21, 44.79" Name="line1" BorderColor="255,89,89,89" Ref="10">
          <StylePriority UseBorderColor="false" />
        </Item1>
        <Item2 ControlType="XRTable" SizeF="820.84, 25" LocationFloat="6.25, 12.5" Name="table3" Ref="18">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow2" Ref="17">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="2.4896000000000003" Text="tableCell1" Name="tableCell1" Font="Times New Roman, 10pt, style=Bold" CanShrink="true" Ref="12">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="VehicleMileageReport.Employee Name" FormatString="Employee Name: {0}" Ref="11" />
                  </DataBindings>
                  <StylePriority UseFont="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="2.3021000000000003" Text="tableCell2" Name="tableCell2" Font="Times New Roman, 10pt, style=Bold" CanShrink="true" Ref="14">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="VehicleMileageReport.Employee Number" FormatString="Employee # {0}" Ref="13" />
                  </DataBindings>
                  <StylePriority UseFont="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="3.416699999999999" Text="tableCell3" Name="tableCell3" Font="Times New Roman, 10pt" CanShrink="true" Ref="16">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="VehicleMileageReport.Phone Number" FormatString="Phone # {0}" Ref="15" />
                  </DataBindings>
                  <StylePriority UseFont="false" />
                </Item3>
              </Cells>
            </Item1>
          </Rows>
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="261.46, 22.92" LocationFloat="838.54, 12.5" TextAlignment="TopRight" Name="label1" Padding="2,2,0,0,100" Font="Times New Roman, 10pt, style=Bold" Ref="20">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="VehicleMileageReport.TotalDistance" FormatString="Total Mileage : {0}" Ref="19" />
          </DataBindings>
          <Summary FormatString="Total Mileage : {0}" Running="Group" />
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item3>
      </Controls>
    </Item3>
    <Item4 ControlType="GroupHeaderBand" StyleName="FieldCaption" HeightF="29.17" Name="groupHeaderBand2" Ref="31">
      <Controls>
        <Item1 ControlType="XRTable" Font="Times New Roman, 9pt, style=Bold" SizeF="1081.25, 25" LocationFloat="17.71, 4.17" Name="table1" BackColor="0,0,0,0" BorderColor="DarkGray" Borders="All" Ref="30">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow1" Ref="29">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.7387785526812237" TextAlignment="MiddleCenter" Text="Unit #" Name="tableCell5" BackColor="255,194,194,194" Padding="5,0,0,0,100" Font="Times New Roman, 10pt, style=Bold" Ref="22">
                  <StylePriority UseBackColor="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.5979990962243693" TextAlignment="MiddleCenter" Text="Date" Name="tableCell13" BackColor="255,194,194,194" Font="Times New Roman, 10pt, style=Bold" Ref="23">
                  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="1.3317601494294065" TextAlignment="MiddleCenter" Text="Origin" Name="tableCell7" BackColor="255,194,194,194" Font="Times New Roman, 10pt, style=Bold" Ref="24">
                  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="1.4323031197022253" TextAlignment="MiddleCenter" Text="Destination" Name="tableCell11" BackColor="255,194,194,194" Font="Times New Roman, 10pt, style=Bold" Ref="25">
                  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="0.36183890453269585" TextAlignment="MiddleCenter" Text="Starting Odometer" Name="tableCell14" BackColor="255,194,194,194" Font="Times New Roman, 10pt, style=Bold" Ref="26">
                  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
                </Item5>
                <Item6 ControlType="XRTableCell" Weight="0.44226363171349686" TextAlignment="MiddleCenter" Text="Ending Odometer" Name="tableCell16" BackColor="255,194,194,194" Font="Times New Roman, 10pt, style=Bold" Ref="27">
                  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
                </Item6>
                <Item7 ControlType="XRTableCell" Weight="0.3115674193962867" TextAlignment="MiddleCenter" Text="Miles in Unit #" Name="tableCell18" BackColor="255,194,194,194" Font="Times New Roman, 10pt, style=Bold" Ref="28">
                  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
                </Item7>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UseFont="false" />
        </Item1>
      </Controls>
    </Item4>
    <Item5 ControlType="DetailBand" StyleName="DataField" HeightF="16.67" Name="detailBand1" Ref="48">
      <Controls>
        <Item1 ControlType="XRTable" Font="Times New Roman, 9pt" SizeF="1081.25, 16.67" LocationFloat="17.78, 0" EvenStyleName="xrControlStyle1" Name="table2" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="47">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1.0081079024263615" Name="tableRow3" Ref="46">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.42088761690543314" TextAlignment="MiddleCenter" Text="tableCell29" Name="tableCell29" Borders="Left, Right, Bottom" Ref="33">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="VehicleMileageReport.Unit Number" Ref="32" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.3459426098972851" TextAlignment="MiddleCenter" Text="tableCell30" Name="tableCell30" Ref="35">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="VehicleMileageReport.Date" FormatString="{0 : MM/dd/yyyy}" Ref="34" />
                  </DataBindings>
                  <StylePriority UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.7639519842883731" TextAlignment="MiddleLeft" Text="tableCell8" Name="tableCell8" Borders="Left, Right, Bottom" Ref="37">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="VehicleMileageReport.Origin" Ref="36" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.8216275362104485" TextAlignment="MiddleLeft" Text="tableCell12" Name="tableCell12" Borders="Left, Right, Bottom" Ref="39">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="VehicleMileageReport.Destination" Ref="38" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseTextAlignment="false" />
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="0.20756556593837133" TextAlignment="MiddleCenter" Text="tableCell15" Name="tableCell15" Borders="Left, Right, Bottom" Ref="41">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="VehicleMileageReport.StartingOdometer" Ref="40" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseTextAlignment="false" />
                </Item5>
                <Item6 ControlType="XRTableCell" Weight="0.25370047239427307" TextAlignment="MiddleCenter" Text="tableCell17" Name="tableCell17" Borders="Left, Right, Bottom" Ref="43">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="VehicleMileageReport.EndingOdometer" Ref="42" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseTextAlignment="false" />
                </Item6>
                <Item7 ControlType="XRTableCell" Weight="0.1787277899773333" TextAlignment="MiddleCenter" Text="tableCell19" Name="tableCell19" Borders="Left, Right, Bottom" Ref="45">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="VehicleMileageReport.TotalDistance" Ref="44" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseTextAlignment="false" />
                </Item7>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" />
        </Item1>
      </Controls>
    </Item5>
    <Item6 ControlType="PageFooterBand" HeightF="47.17" Name="pageFooterBand1" Expanded="false" Ref="50">
      <Controls>
        <Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="313, 23" LocationFloat="787.5, 12.24" StyleName="PageInfo" Name="pageInfo2" Font="Times New Roman, 9pt" Ref="49">
          <StylePriority UseFont="false" />
        </Item1>
      </Controls>
    </Item6>
    <Item7 ControlType="BottomMarginBand" HeightF="0" Name="BottomMargin1" Ref="51" />
  </Bands>
  <StyleSheet>
    <Item1 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="Title" Font="Times New Roman, 24pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="52" />
    <Item2 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="FieldCaption" Font="Times New Roman, 10pt, style=Bold" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="53" />
    <Item3 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="PageInfo" Font="Times New Roman, 8pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="54" />
    <Item4 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="DataField" Font="Times New Roman, 8pt" Padding="2,2,0,0,100" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="55" />
    <Item5 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="xrControlStyle1" Font="Times New Roman, 9pt" BackColor="0,245,245,245" BorderColor="DarkGray" Sides="None" Ref="56" />
  </StyleSheet>
  <ObjectStorage>
    <Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;Vehicle_x0020_Mileage_x0020_Report&gt;&lt;xs:schema id=&quot;Vehicle_x0020_Mileage_x0020_Report&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;Vehicle_x0020_Mileage_x0020_Report&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;VehicleMileageReport&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;Date&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;GpsTimeStamp&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;StartingOdometer&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EndingOdometer&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TotalDistance&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Origin&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Destination&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Employee_x0020_Name&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Employee_x0020_Number&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone_x0020_Number&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Unit_x0020_Number&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/Vehicle_x0020_Mileage_x0020_Report&gt;" Type="System.Data.DataSet" Ref="57" />
  </ObjectStorage>
  <Extensions>
    <Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="58" />
  </Extensions>
</XtraReportsLayoutSerializer>', 'a483f68c-e25e-4128-a4ad-8329849a694c', '8b799cdc-1d57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('d7d08a90-dafc-4da7-af58-36a30a5cb706', N'ELD Uncertified Logs Report', 'e468d955-6924-11e3-a678-a0b3cc4a6a82', NULL, 1, NULL, 1, '91e29695-0d94-11e6-80f6-00155db47809', '91e29695-0d94-11e6-80f6-00155db47809', '2017-02-10 09:05:00.683', '2018-03-14 03:29:54.593', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" Name="ELD Uncertified Logs Report" DisplayName="ELD Uncertified Logs Report" PageWidth="850" PageHeight="1100" DataMember="ELDUncertifiedLogsReport" DataSource="#Ref-32">
  <Bands>
    <Item1 ControlType="TopMarginBand" Name="TopMargin1" Ref="0" />
    <Item2 ControlType="ReportHeaderBand" HeightF="164.58" Name="reportHeaderBand1" Padding="2,0,0,0,100" Ref="9">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="637.5, 44.79" LocationFloat="5.21, 27.08" TextAlignment="TopCenter" Text="Uncertified Logs Report" Name="label11" Font="Arial Black, 25pt, style=Bold" Ref="1">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRPageInfo" TextAlignment="MiddleRight" Format="{0: &quot;at &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="133, 22.92" LocationFloat="511, 79.17" Name="pageInfo1" Font="Times New Roman, 9pt" Ref="2">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="361.46, 22.92" LocationFloat="150, 79.17" TextAlignment="MiddleRight" Text="label12" Name="label12" Padding="2,0,0,0,100" Ref="4">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Created by: {0}" Ref="3" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="493.75, 22.92" LocationFloat="150, 102.08" TextAlignment="TopRight" Text="label13" Name="label13" Padding="2,0,0,0,100" Ref="6">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.DateRange" FormatString="Date Range: {0}" Ref="5" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item4>
        <Item5 ControlType="XRLabel" SizeF="215.63, 25" LocationFloat="5.21, 139.58" Name="label1" Padding="0,2,0,0,100" Font="Times New Roman, 10pt, style=Bold" Ref="8">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="ELDUncertifiedLogsReport.Employee Number" Ref="7" />
          </DataBindings>
          <Summary FormatString="Total: {0} records" Running="Report" Func="Count" />
          <StylePriority UseFont="false" UsePadding="false" />
        </Item5>
      </Controls>
    </Item2>
    <Item3 ControlType="PageHeaderBand" HeightF="25" Name="PageHeader1" TextAlignment="TopLeft" Padding="0,0,0,0,100" Ref="16">
      <Controls>
        <Item1 ControlType="XRTable" SizeF="640.21, 25" LocationFloat="5.21, 0" Name="table1" BorderColor="DarkGray" Borders="All" Ref="15">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow1" Ref="14">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.6091751144155825" TextAlignment="MiddleLeft" Text="Employee Number" Name="tableCell1" BackColor="255,194,194,194" Padding="5,0,0,0,100" Font="Times New Roman, 9pt, style=Bold" Ref="10">
                  <StylePriority UseBackColor="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.7966136111588382" TextAlignment="MiddleLeft" Text="Employee Name" Name="tableCell2" BackColor="255,194,194,194" Padding="5,0,0,0,100" Font="Times New Roman, 9pt, style=Bold" Ref="11">
                  <StylePriority UseBackColor="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.7497539869730245" TextAlignment="MiddleCenter" Text="Last Approval Date" Name="tableCell3" BackColor="255,194,194,194" Font="Times New Roman, 9pt, style=Bold" Ref="12">
                  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.8444572874525552" TextAlignment="MiddleCenter" Text="Number of Unapproved Logs" Name="tableCell4" BackColor="255,194,194,194" Font="Times New Roman, 9pt, style=Bold" Ref="13">
                  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
                </Item4>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item3>
    <Item4 ControlType="DetailBand" HeightF="25" Name="Detail1" TextAlignment="TopLeft" Padding="0,0,0,0,100" Ref="27">
      <Controls>
        <Item1 ControlType="XRTable" SizeF="640.21, 25" LocationFloat="5.21, 0" EvenStyleName="xrControlStyle1" Name="table2" Ref="26">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow2" Ref="25">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.6091751144155823" TextAlignment="MiddleLeft" Name="tableCell5" BorderColor="DarkGray" Padding="5,0,0,0,100" Borders="Left, Right, Bottom" Ref="18">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="ELDUncertifiedLogsReport.Employee Number" Ref="17" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.7966136111588384" TextAlignment="MiddleLeft" Name="tableCell6" BorderColor="DarkGray" Padding="5,0,0,0,100" Borders="Left, Right, Bottom" Ref="20">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="ELDUncertifiedLogsReport.Employee Name" Ref="19" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UsePadding="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.7497539869730243" TextAlignment="MiddleCenter" Name="tableCell7" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="22">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="ELDUncertifiedLogsReport.Last Approval Date" FormatString="{0: MM/dd/yyyy}" Ref="21" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.8444572874525549" TextAlignment="MiddleCenter" Name="tableCell8" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="24">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="ELDUncertifiedLogsReport.Number Unapproved" Ref="23" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UseTextAlignment="false" />
                </Item4>
              </Cells>
            </Item1>
          </Rows>
        </Item1>
      </Controls>
    </Item4>
    <Item5 ControlType="PageFooterBand" HeightF="30" Name="PageFooter1" TextAlignment="TopLeft" Padding="0,0,0,0,100" Ref="29">
      <Controls>
        <Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="195.83, 22.92" LocationFloat="448.96, 6.25" Name="pageInfo2" Padding="2,2,0,0,100" Ref="28">
          <StylePriority UseTextAlignment="false" />
        </Item1>
      </Controls>
    </Item5>
    <Item6 ControlType="BottomMarginBand" Name="BottomMargin1" Ref="30" />
  </Bands>
  <StyleSheet>
    <Item1 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="xrControlStyle1" Font="Times New Roman, 9pt" BackColor="WhiteSmoke" BorderColor="DarkGray" Sides="None" Ref="31" />
  </StyleSheet>
  <ObjectStorage>
    <Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;ELD_x0020_Uncertified_x0020_Logs_x0020_Report&gt;&lt;xs:schema id=&quot;ELD_x0020_Uncertified_x0020_Logs_x0020_Report&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;ELD_x0020_Uncertified_x0020_Logs_x0020_Report&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;MileOrKm&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;ELDUncertifiedLogsReport&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;Employee_x0020_Number&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Employee_x0020_Name&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Last_x0020_Approval_x0020_Date&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Number_x0020_Unapproved&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/ELD_x0020_Uncertified_x0020_Logs_x0020_Report&gt;" Type="System.Data.DataSet" Ref="32" />
  </ObjectStorage>
  <Extensions>
    <Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="33" />
  </Extensions>
</XtraReportsLayoutSerializer>', 'f2d7df4a-ec0c-4433-a6db-fbb2dcdf2ce5', '59c4bfb5-1d57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('64612ab8-6625-43d6-8139-385e6cbfbc1c', N'ELD Off-Driving Report', 'e468d955-6924-11e3-a678-a0b3cc4a6a82', NULL, 0, NULL, 1, '91e29695-0d94-11e6-80f6-00155db47809', '91e29695-0d94-11e6-80f6-00155db47809', '2017-03-01 04:44:18.817', '2017-03-02 09:07:36.880', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" Name="ELD Off-Driving Report" Margins="105, 95, 100, 100" DisplayName="ELD Off-Driving Report" PageWidth="850" PageHeight="1100" DataMember="ELDOffDutyDriving" DataSource="#Ref-33">
  <Bands>
    <Item1 ControlType="TopMarginBand" Name="TopMargin1" TextAlignment="TopLeft" Padding="0,0,0,0,100" Ref="0" />
    <Item2 ControlType="ReportHeaderBand" HeightF="151.04" Name="ReportHeader1" TextAlignment="TopLeft" Padding="0,0,0,0,100" Ref="7">
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="638.54, 50" LocationFloat="6.25, 25" TextAlignment="TopCenter" Text="Off-Duty Driving Report" Name="label1" Padding="2,2,0,0,100" Font="Arial Black, 25pt, style=Bold" Ref="1">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRPageInfo" TextAlignment="MiddleRight" WordWrap="false" Format="{0: &quot;at &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="174, 23" LocationFloat="470.83, 84.38" Name="pageInfo1" Padding="2,0,0,0,100" Ref="2">
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="319.79, 22.92" LocationFloat="151.04, 84.38" TextAlignment="MiddleRight" Text="label2" Name="label2" Padding="2,2,0,0,100" Ref="4">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Created by: {0}" Ref="3" />
          </DataBindings>
          <StylePriority UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="493.75, 23" LocationFloat="151.04, 107.29" TextAlignment="MiddleRight" Text="label3" Name="label3" Padding="2,0,0,0,100" Ref="6">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.DateRange" FormatString="Date Range: {0}" Ref="5" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item4>
      </Controls>
    </Item2>
    <Item3 ControlType="GroupHeaderBand" Level="1" HeightF="36.46" Name="GroupHeader2" Ref="14">
      <GroupFields>
        <Item1 FieldName="Employee Name" Ref="8" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLabel" AutoWidth="true" SizeF="66.67, 25" LocationFloat="6.25, 9.38" Text="label4" WordWrap="false" Name="label4" Padding="2,2,0,0,100" Font="Times New Roman, 10pt, style=Bold" Ref="10">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="ELDOffDutyDriving.Employee Name" Ref="9" />
          </DataBindings>
          <StylePriority UseFont="false" />
        </Item1>
        <Item2 ControlType="XRLine" ForeColor="204,0,0,0" SizeF="638, 2.08" LocationFloat="6.25, 34.38" Name="line1" Ref="11">
          <StylePriority UseForeColor="false" />
        </Item2>
        <Item3 ControlType="XRLabel" AutoWidth="true" SizeF="66.67, 25" LocationFloat="72.92, 9.38" Text="label4" WordWrap="false" Name="label6" Padding="2,2,0,0,100" Font="Times New Roman, 10pt, style=Bold" Ref="13">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="ELDOffDutyDriving.Employee Number" FormatString="[{0}]" Ref="12" DataSource="#Ref-33" />
          </DataBindings>
          <StylePriority UseFont="false" />
        </Item3>
      </Controls>
    </Item3>
    <Item4 ControlType="GroupHeaderBand" HeightF="30" Name="GroupHeader1" Ref="20">
      <Controls>
        <Item1 ControlType="XRTable" SizeF="593.54, 25" LocationFloat="50.01, 5" Name="table1" Ref="19">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow1" Ref="18">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.9142857142857144" TextAlignment="MiddleCenter" Text="Start Time" Name="tableCell1" BackColor="255,194,194,194" BorderColor="DarkGray" Borders="All" Font="Times New Roman, 10pt, style=Bold" Ref="15">
                  <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.8000000000000002" TextAlignment="MiddleCenter" Text="Duration" Name="tableCell2" BackColor="255,194,194,194" BorderColor="DarkGray" Borders="All" Font="Times New Roman, 10pt, style=Bold" Ref="16">
                  <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="1.677371428571429" TextAlignment="MiddleCenter" Text="Location" Name="tableCell3" BackColor="255,194,194,194" BorderColor="DarkGray" Borders="All" Font="Times New Roman, 10pt, style=Bold" Ref="17">
                  <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item3>
              </Cells>
            </Item1>
          </Rows>
        </Item1>
      </Controls>
    </Item4>
    <Item5 ControlType="DetailBand" HeightF="25" Name="Detail1" TextAlignment="TopLeft" Padding="0,0,0,0,100" Ref="29">
      <Controls>
        <Item1 ControlType="XRTable" SizeF="593.53, 25" LocationFloat="50.01, 0" Name="table2" Ref="28">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow2" Ref="27">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.9088671349857045" TextAlignment="MiddleLeft" Text="startTime" WordWrap="false" Name="tableCell4" BorderColor="DarkGray" Padding="4,0,0,0,100" Borders="Left, Right, Bottom" Ref="22">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="ELDOffDutyDriving.StartTime" FormatString="{0:MM/dd/yyyy hh:mm tt}" Ref="21" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.7952587431124913" TextAlignment="MiddleCenter" Text="tableCell5" Name="tableCell5" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="24">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="ELDOffDutyDriving.Duration" Ref="23" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="1.6673735633272109" TextAlignment="MiddleLeft" Text="tableCell6" Name="tableCell6" BorderColor="DarkGray" Padding="4,0,0,0,100" Borders="Left, Right, Bottom" Ref="26">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="ELDOffDutyDriving.Location" Ref="25" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UsePadding="false" UseTextAlignment="false" />
                </Item3>
              </Cells>
            </Item1>
          </Rows>
        </Item1>
      </Controls>
    </Item5>
    <Item6 ControlType="PageFooterBand" HeightF="52.08" Name="PageFooter1" TextAlignment="TopLeft" Padding="0,0,0,0,100" Ref="31">
      <Controls>
        <Item1 ControlType="XRPageInfo" TextAlignment="MiddleRight" Format="Page {0} of {1}" SizeF="192.71, 22.92" LocationFloat="452.08, 7.29" Name="pageInfo2" Padding="2,2,0,0,100" Ref="30">
          <StylePriority UseTextAlignment="false" />
        </Item1>
      </Controls>
    </Item6>
    <Item7 ControlType="BottomMarginBand" Name="BottomMargin1" TextAlignment="TopLeft" Padding="0,0,0,0,100" Ref="32" />
  </Bands>
  <ObjectStorage>
    <Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;ELD_x0020_Off-Driving_x0020_Report&gt;&lt;xs:schema id=&quot;ELD_x0020_Off-Driving_x0020_Report&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;ELD_x0020_Off-Driving_x0020_Report&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;ELDOffDutyDriving&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;StartTime&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Duration&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Location&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Employee_x0020_Name&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Employee_x0020_Number&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/ELD_x0020_Off-Driving_x0020_Report&gt;" Type="System.Data.DataSet" Ref="33" />
  </ObjectStorage>
  <Extensions>
    <Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="34" />
  </Extensions>
</XtraReportsLayoutSerializer>', 'f92c2911-6847-42c6-a7d4-bf2a88be0d8f', '59c4bfb5-1d57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('0618f7ff-fd49-4569-bec4-4ca8cd3d40b9', N'Fuel Usage Summary Report ', '05884549-8764-11e4-b90a-ac68328aed23', NULL, 1, NULL, 1, 'f85a4b2f-ed82-4436-8943-96548b2f0af5', 'f85a4b2f-ed82-4436-8943-96548b2f0af5', '2015-09-17 07:09:24.860', '2015-11-20 03:43:07.293', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" PaperKind="A4Extra" Name="Fuel Usage Summary Report" Margins="102, 96, 98, 100" DisplayName="Fuel Usage Summary Report" PageWidth="929" PageHeight="1268" DataMember="DataMember" DataSource="#Ref-63">
  <Watermark Font="Times New Roman, 9pt" />
  <Bands>
    <Item1 ControlType="TopMarginBand" HeightF="98" Name="TopMargin1" Padding="0,5,0,0,100" Ref="0">
      <StylePriority UsePadding="false" />
    </Item1>
    <Item2 ControlType="ReportHeaderBand" HeightF="150" Name="reportHeaderBand1" Padding="2,0,0,0,100" Ref="7">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="719.79, 40.63" LocationFloat="5.21, 22.92" TextAlignment="TopCenter" Text="Fuel Usage Summary Report" StyleName="Title" Name="label11" Font="Arial Black, 25pt, style=Bold" Ref="1">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRPageInfo" TextAlignment="MiddleRight" Format="{0: &quot;at &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="133, 22.92" LocationFloat="593.75, 76.04" StyleName="PageInfo" Name="pageInfo1" Font="Times New Roman, 9pt" Ref="2">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="361.46, 22.92" LocationFloat="232.42, 76.04" TextAlignment="MiddleRight" Text="label12" Name="label12" Padding="2,0,0,0,100" Ref="4">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Created by: {0}" Ref="3" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="493.75, 22.92" LocationFloat="233, 98.96" TextAlignment="TopRight" Text="label13" Name="label13" Padding="2,0,0,0,100" Ref="6">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.DateRange" FormatString="Date Range: {0}" Ref="5" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item4>
      </Controls>
    </Item2>
    <Item3 ControlType="GroupHeaderBand" Level="2" HeightF="27.08" Name="groupHeaderBand1" Ref="17">
      <GroupFields>
        <Item1 FieldName="Fuel Type" Ref="8" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="139.58, 25" LocationFloat="69.79, 0" TextAlignment="MiddleLeft" StyleName="DataField" Name="label2" BackColor="33,255,241,46" Font="Times New Roman, 9pt, style=Bold" Ref="10">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="DataMember.Fuel Type" Ref="9" />
          </DataBindings>
          <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLabel" SizeF="64.58, 25" LocationFloat="5.21, 0" TextAlignment="MiddleLeft" Text="Fuel Type" StyleName="FieldCaption" Name="label1" BackColor="33,255,241,46" Font="Times New Roman, 9pt, style=Bold" Ref="11">
          <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="256.25, 25" LocationFloat="469.79, 0" TextAlignment="MiddleRight" Text="label14" Name="label15" BackColor="33,255,241,46" BorderColor="255,120,120,120" Padding="0,5,0,0,100" Borders="Left" Font="Times New Roman, 9pt, style=Bold" Ref="13">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="DataMember.Purchase Cost" Ref="12" />
          </DataBindings>
          <Summary FormatString="{0: &quot;Total Purchase Cost: $ &quot;#,##0.00}" Running="Group" />
          <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRLine" ForeColor="255,120,120,120" SizeF="721.75, 2" LocationFloat="5.21, 25" Name="line1" Ref="14">
          <StylePriority UseForeColor="false" />
        </Item4>
        <Item5 ControlType="XRLabel" SizeF="260.42, 25" LocationFloat="209.38, 0" TextAlignment="MiddleRight" Text="label14" Name="label5" BackColor="33,255,241,46" BorderColor="255,120,120,120" Padding="0,5,0,0,100" Borders="None" Font="Times New Roman, 9pt, style=Bold" Ref="16">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="DataMember.Gallons Purchased" Ref="15" />
          </DataBindings>
          <Summary FormatString="{0: Total Gallons Purchased: #,##0.00}" Running="Group" />
          <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
        </Item5>
      </Controls>
    </Item3>
    <Item4 ControlType="GroupHeaderBand" Level="1" HeightF="27.08" Name="groupHeaderBand2" Ref="23">
      <GroupFields>
        <Item1 FieldName="StateName" Ref="18" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="661.46, 25" LocationFloat="64.58, 0" TextAlignment="MiddleLeft" StyleName="DataField" Name="label4" Font="Times New Roman, 9pt" Ref="20">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="DataMember.StateName" Ref="19" />
          </DataBindings>
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLabel" SizeF="36.46, 25" LocationFloat="28.13, 0" TextAlignment="MiddleLeft" Text="State" StyleName="FieldCaption" Name="label3" Font="Times New Roman, 9pt, style=Bold" Ref="21">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLine" ForeColor="255,120,120,120" SizeF="698.83, 2.08" LocationFloat="28.13, 25" Name="line2" Ref="22">
          <StylePriority UseForeColor="false" />
        </Item3>
      </Controls>
    </Item4>
    <Item5 ControlType="GroupHeaderBand" StyleName="FieldCaption" HeightF="30.21" Name="groupHeaderBand3" Padding="0,5,0,0,100" Ref="32">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRTable" SizeF="676, 25" LocationFloat="50, 5.21" Name="table1" BorderColor="DarkGray" Borders="All" Ref="31">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="0.7271669575334496" Name="tableRow1" Ref="30">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.5055436087629345" TextAlignment="MiddleCenter" Text="Submitted By" Name="tableCell1" BackColor="255,194,194,194" Padding="1,1,0,0,100" Ref="24">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.5519392790404558" TextAlignment="MiddleCenter" Text="Equipment Number" Name="tableCell2" BackColor="255,194,194,194" Padding="1,1,0,0,100" Ref="25">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.4626519133112943" TextAlignment="MiddleCenter" Text="Purchase Date" Name="tableCell3" BackColor="255,194,194,194" Padding="1,1,0,0,100" Ref="26">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.3536668032767296" TextAlignment="MiddleCenter" Text="City" Name="tableCell4" BackColor="255,194,194,194" Padding="1,1,0,0,100" Ref="27">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="0.5426779552230618" TextAlignment="MiddleCenter" Text="Gallons Purchased" Name="tableCell5" BackColor="255,194,194,194" Padding="1,1,0,0,100" Ref="28">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item5>
                <Item6 ControlType="XRTableCell" Weight="0.5934506810385426" TextAlignment="MiddleRight" Text="Purchase Cost" Name="tableCell6" BackColor="255,194,194,194" Ref="29">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item6>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item5>
    <Item6 ControlType="DetailBand" StyleName="DataField" HeightF="25" Name="detailBand1" Ref="47">
      <Controls>
        <Item1 ControlType="XRTable" SizeF="676, 25" LocationFloat="50, 0" EvenStyleName="xrControlStyle1" Name="table2" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="46">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow2" Ref="45">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.4809562519006368" TextAlignment="MiddleLeft" Name="tableCell7" Padding="5,0,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="34">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DataMember.SubmittedBy" Ref="33" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.525095446411863" TextAlignment="MiddleCenter" Name="tableCell8" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="36">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DataMember.Equipment Number" Ref="35" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.44015061471225686" TextAlignment="MiddleCenter" Name="tableCell9" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="38">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DataMember.Purchased Date" FormatString="{0: MM/dd/yyyy}" Ref="37" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.33646604798720786" TextAlignment="MiddleLeft" Name="tableCell10" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="40">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DataMember.City" Ref="39" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="0.516284551538221" TextAlignment="MiddleCenter" Name="tableCell11" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="42">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DataMember.Gallons Purchased" FormatString="{0: #,##0.00}" Ref="41" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item5>
                <Item6 ControlType="XRTableCell" Weight="0.5645879213834981" TextAlignment="MiddleRight" Name="tableCell12" Padding="0,5,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="44">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DataMember.Purchase Cost" FormatString="{0: &quot;$&quot; #,##0.00}" Ref="43" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item6>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item6>
    <Item7 ControlType="GroupFooterBand" HeightF="39.58" Name="GroupFooter1" Ref="54">
      <Controls>
        <Item1 ControlType="XRTable" SizeF="676, 25" LocationFloat="50, 0" Name="table3" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="53">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1.012" Name="tableRow1" Ref="52">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="1.936811976064464" TextAlignment="MiddleRight" Name="tableCell13" BackColor="255,194,194,194" Padding="0,5,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt, style=Bold" Ref="49">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DataMember.Gallons Purchased" Ref="48" />
                  </DataBindings>
                  <Summary FormatString="{0: Total Gallons Purchased: #,##0.00}" Running="Group" />
                  <StylePriority UseBackColor="false" UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="1.1743846967477822" TextAlignment="MiddleRight" Name="tableCell14" BackColor="255,194,194,194" Padding="0,5,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt, style=Bold" Ref="51">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DataMember.Purchase Cost" Ref="50" />
                  </DataBindings>
                  <Summary FormatString="{0: &quot;Total Purchase Cost: $ &quot;#,##0.00}" Running="Group" />
                  <StylePriority UseBackColor="false" UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item2>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item7>
    <Item8 ControlType="PageFooterBand" HeightF="48.96" Name="pageFooterBand1" Ref="56">
      <Controls>
        <Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="313, 23" LocationFloat="412.5, 5.99" StyleName="PageInfo" Name="pageInfo2" Padding="0,5,0,0,100" Font="Times New Roman, 9pt" Ref="55">
          <StylePriority UseFont="false" UsePadding="false" />
        </Item1>
      </Controls>
    </Item8>
    <Item9 ControlType="BottomMarginBand" Name="BottomMargin1" Padding="0,10,0,0,100" Ref="57">
      <StylePriority UsePadding="false" />
    </Item9>
  </Bands>
  <StyleSheet>
    <Item1 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="Title" Font="Times New Roman, 24pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="58" />
    <Item2 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="FieldCaption" Font="Times New Roman, 10pt, style=Bold" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="59" />
    <Item3 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="PageInfo" Font="Times New Roman, 8pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="60" />
    <Item4 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="DataField" Font="Times New Roman, 8pt" Padding="2,2,0,0,100" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="61" />
    <Item5 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="xrControlStyle1" Font="Times New Roman, 9pt" BackColor="WhiteSmoke" BorderColor="DarkGray" Sides="None" BorderWidthSerializable="1" Ref="62" />
  </StyleSheet>
  <ObjectStorage>
    <Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;DataSource&gt;&lt;xs:schema id=&quot;DataSource&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;DataSource&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;DataMember&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;Purchased_x0020_Date&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Odometer&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Gallon_x0020_Cost&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Gallons_x0020_Purchased&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Purchase_x0020_Cost&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;SubmittedBy&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;City&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;State&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;StateName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Fuel_x0020_Type&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Equipment_x0020_Number&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/DataSource&gt;" Type="System.Data.DataSet" Ref="63" />
  </ObjectStorage>
  <Extensions>
    <Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="64" />
  </Extensions>
</XtraReportsLayoutSerializer>', 'bf0ccf53-bcc8-480d-b028-59122d01516e', '59c4bfb5-1d57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('bc7581d1-9ce1-468f-9a46-4df7c0807f4e', N'Distance Traveled by Driver and Vehicle', 'd226c6d5-6924-11e3-a678-a0b3cc4a6a82', N'Distance Traveled by Driver and Vehicle', 1, NULL, 1, '91e29695-0d94-11e6-80f6-00155db47809', '91e29695-0d94-11e6-80f6-00155db47809', '2020-07-28 07:59:01.833', '2020-07-28 08:29:33.653', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>  <XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" Name="Mileage by Date Updated" Margins="90, 10, 100, 100" DisplayName="Mileage by Date Updated" PageWidth="850" PageHeight="1100" DataMember="MilesTraveledUpdated" DataSource="#Ref-43">    <Bands>      <Item1 ControlType="TopMarginBand" Name="TopMargin1" Ref="0" />      <Item2 ControlType="ReportHeaderBand" HeightF="165.62" Name="reportHeaderBand1" Padding="2,0,0,0,100" Ref="9">        <StylePriority UsePadding="false" />        <Controls>          <Item1 ControlType="XRLabel" SizeF="638, 39" LocationFloat="6, 29.17" TextAlignment="TopCenter" Text="Mileage by Day Report" StyleName="Title" Name="label10" Font="Arial Black, 25pt, style=Bold" Ref="1">            <StylePriority UseFont="false" UseTextAlignment="false" />          </Item1>          <Item2 ControlType="XRPageInfo" TextAlignment="MiddleRight" Format="{0: &quot;at &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="133, 22.92" LocationFloat="511, 79.17" StyleName="PageInfo" Name="pageInfo1" Font="Times New Roman, 9pt" Ref="2">            <StylePriority UseFont="false" UseTextAlignment="false" />          </Item2>          <Item3 ControlType="XRLabel" SizeF="361.46, 22.92" LocationFloat="150, 79.17" TextAlignment="MiddleRight" Text="label12" Name="label11" Padding="2,0,0,0,100" Ref="4">            <DataBindings>              <Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Created by: {0}" Ref="3" />            </DataBindings>            <StylePriority UsePadding="false" UseTextAlignment="false" />          </Item3>          <Item4 ControlType="XRLabel" SizeF="493.75, 22.92" LocationFloat="150, 102.08" TextAlignment="TopRight" Text="label13" Name="label12" Padding="2,0,0,0,100" Ref="6">            <DataBindings>              <Item1 PropertyName="Text" DataMember="UserInfo.DateRange" FormatString="Date Range: {0}" Ref="5" />            </DataBindings>            <StylePriority UsePadding="false" UseTextAlignment="false" />          </Item4>          <Item5 ControlType="XRLabel" SizeF="292.71, 27.08" LocationFloat="351.04, 138.54" TextAlignment="MiddleRight" Text="label9" Name="label9" Padding="2,0,0,0,100" Font="Times New Roman, 13pt, style=Bold" Ref="8">            <DataBindings>              <Item1 PropertyName="Text" DataMember="MilesTraveledUpdated.DistanceTraveledInMiles" Ref="7" />            </DataBindings>            <Summary FormatString="{0: Total Miles #,##0.0}" Running="Report" />            <StylePriority UseFont="false" UsePadding="false" UseTextAlignment="false" />          </Item5>        </Controls>      </Item2>      <Item3 ControlType="GroupHeaderBand" Level="1" HeightF="48.96" Name="groupHeaderBand1" Ref="16">        <GroupFields>          <Item1 FieldName="Date" Ref="10" />        </GroupFields>        <Controls>          <Item1 ControlType="XRLabel" SizeF="441.67, 25" LocationFloat="5.21, 21.88" TextAlignment="MiddleLeft" Text="label2" StyleName="DataField" Name="label2" BackColor="33,255,241,46" Padding="5,0,0,0,100" Font="Times New Roman, 12pt, style=Bold" Ref="12">            <DataBindings>              <Item1 PropertyName="Text" DataMember="MilesTraveledUpdated.Date" FormatString="{0:dd-MMM-yyy}" Ref="11" />            </DataBindings>            <StylePriority UseBackColor="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />          </Item1>          <Item2 ControlType="XRLine" SizeF="637.33, 2.08" LocationFloat="6.49, 46.88" Name="line1" Ref="13" />          <Item3 ControlType="XRLabel" SizeF="197.75, 25" LocationFloat="446.88, 21.88" TextAlignment="MiddleRight" Text="label1" Name="label1" BackColor="33,255,241,46" Padding="0,5,0,0,100" Font="Times New Roman, 12pt, style=Bold" Ref="15">            <DataBindings>              <Item1 PropertyName="Text" DataMember="MilesTraveledUpdated.DistanceTraveledInMiles" Ref="14" />            </DataBindings>            <Summary FormatString="{0: #,##0.0 mi}" Running="Group" />            <StylePriority UseBackColor="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />          </Item3>        </Controls>      </Item3>      <Item4 ControlType="GroupHeaderBand" StyleName="FieldCaption" HeightF="32" Name="groupHeaderBand2" Ref="23">        <Controls>          <Item1 ControlType="XRTable" SizeF="636.45, 25" LocationFloat="7.54, 7" Name="table1" BorderColor="DarkGray" Borders="All" Ref="22">            <Rows>              <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow1" Ref="21">                <Cells>                  <Item1 ControlType="XRTableCell" Weight="1.7999999999999998" TextAlignment="MiddleLeft" Text="Employee" Name="tableCell1" BackColor="255,194,194,194" BorderColor="DarkGray" Padding="5,0,0,0,100" Ref="17">                    <StylePriority UseBackColor="false" UseBorderColor="false" UsePadding="false" UseTextAlignment="false" />                  </Item1>                  <Item2 ControlType="XRTableCell" Weight="1.5999999999999994" TextAlignment="MiddleLeft" Text="Equipment" Name="tableCell2" BackColor="255,194,194,194" BorderColor="DarkGray" Padding="5,0,0,0,100" Ref="18">                    <StylePriority UseBackColor="false" UseBorderColor="false" UsePadding="false" UseTextAlignment="false" />                  </Item2>                  <Item3 ControlType="XRTableCell" Weight="1.4499999999999997" TextAlignment="MiddleLeft" Text="Device Serial Number" Name="tableCell7" BackColor="255,194,194,194" BorderColor="DarkGray" Padding="5,0,0,0,100" Ref="19">                    <StylePriority UseBackColor="false" UseBorderColor="false" UsePadding="false" UseTextAlignment="false" />                  </Item3>                  <Item4 ControlType="XRTableCell" Weight="1.5145000000000002" TextAlignment="MiddleRight" Text="Miles" Name="tableCell3" BackColor="255,194,194,194" BorderColor="DarkGray" Padding="0,5,0,0,100" Ref="20">                    <StylePriority UseBackColor="false" UseBorderColor="false" UsePadding="false" UseTextAlignment="false" />                  </Item4>                </Cells>              </Item1>            </Rows>            <StylePriority UseBorderColor="false" UseBorders="false" />          </Item1>        </Controls>      </Item4>      <Item5 ControlType="DetailBand" StyleName="DataField" HeightF="25" Name="detailBand1" Ref="34">        <Controls>          <Item1 ControlType="XRTable" SizeF="636.46, 25" LocationFloat="7.54, 0" EvenStyleName="xrControlStyle1" Name="table2" Ref="33">            <Rows>              <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow2" Ref="32">                <Cells>                  <Item1 ControlType="XRTableCell" Weight="1.2415893222647834" TextAlignment="MiddleLeft" Text="tableCell4" Name="tableCell4" BorderColor="DarkGray" Padding="5,2,0,0,100" Borders="Left,Right,Bottom" Ref="25">                    <DataBindings>                      <Item1 PropertyName="Text" DataMember="MilesTraveledUpdated.EmployeeName" Ref="24" />                    </DataBindings>                    <StylePriority UseBorderColor="false" UseBorders="false" UsePadding="false" UseTextAlignment="false" />                  </Item1>                  <Item2 ControlType="XRTableCell" Weight="1.103634953124252" TextAlignment="MiddleLeft" Text="tableCell5" Name="tableCell5" BorderColor="DarkGray" Padding="5,2,0,0,100" Borders="Left,Right,Bottom" Ref="27">                    <DataBindings>                      <Item1 PropertyName="Text" DataMember="MilesTraveledUpdated.EquipmentNumber" Ref="26" />                    </DataBindings>                    <StylePriority UseBorderColor="false" UseBorders="false" UsePadding="false" UseTextAlignment="false" />                  </Item2>                  <Item3 ControlType="XRTableCell" Weight="1.0001691762688534" TextAlignment="MiddleLeft" Text="tableCell8" Name="tableCell8" BorderColor="DarkGray" Padding="5,2,0,0,100" Borders="Left,Right,Bottom" Ref="29">                    <DataBindings>                      <Item1 PropertyName="Text" DataMember="MilesTraveledUpdated.SerialNumber" FormatString="" Ref="28" />                    </DataBindings>                    <StylePriority UseBorderColor="false" UseBorders="false" UsePadding="false" UseTextAlignment="false" />                  </Item3>                  <Item4 ControlType="XRTableCell" Weight="1.0447284375012467" TextAlignment="MiddleRight" Text="tableCell6" Name="tableCell6" BorderColor="DarkGray" Padding="0,5,0,0,100" Borders="Left, Right, Bottom" Ref="31">                    <DataBindings>                      <Item1 PropertyName="Text" DataMember="MilesTraveledUpdated.DistanceTraveledInMiles" FormatString="{0:#,##0.0}" Ref="30" />                    </DataBindings>                    <StylePriority UseBorderColor="false" UseBorders="false" UsePadding="false" UseTextAlignment="false" />                  </Item4>                </Cells>              </Item1>            </Rows>          </Item1>        </Controls>      </Item5>      <Item6 ControlType="PageFooterBand" HeightF="39" Name="pageFooterBand1" Ref="36">        <Controls>          <Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="313, 23" LocationFloat="331, 6" StyleName="PageInfo" Name="pageInfo3" Ref="35" />        </Controls>      </Item6>      <Item7 ControlType="BottomMarginBand" Name="BottomMargin1" Padding="0,5,0,0,100" Ref="37">        <StylePriority UsePadding="false" />      </Item7>    </Bands>    <StyleSheet>      <Item1 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="Title" Font="Times New Roman, 24pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="38" />      <Item2 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="FieldCaption" Font="Times New Roman, 10pt, style=Bold" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="39" />      <Item3 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="PageInfo" Font="Times New Roman, 8pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="40" />      <Item4 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="DataField" Font="Times New Roman, 8pt" Padding="2,2,0,0,100" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="41" />      <Item5 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="xrControlStyle1" Font="Times New Roman, 9pt" BackColor="WhiteSmoke" Sides="None" Ref="42" />    </StyleSheet>    <ObjectStorage>      <Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;Mileage_x0020_by_x0020_Date_x0020_Updated&gt;&lt;xs:schema id=&quot;Mileage_x0020_by_x0020_Date_x0020_Updated&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;Mileage_x0020_by_x0020_Date_x0020_Updated&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;MileOrKm&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;MilesTraveledUpdated&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;EmployeeName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EquipmentNumber&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Date&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;SerialNumber&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DistanceTraveledInMiles&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/Mileage_x0020_by_x0020_Date_x0020_Updated&gt;" Type="System.Data.DataSet" Ref="43" />    </ObjectStorage>    <Extensions>      <Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="44" />    </Extensions>  </XtraReportsLayoutSerializer>', 'e0defc5b-ea03-4ef4-b1a1-c2cd4b137940', '8b799cdc-1d57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('3ef78a67-3bf5-491c-892b-55928e7130ea', N'TMS On Time Delivery Report', 'be7768b5-6924-11e3-a678-a0b3cc4a6a82', N'TMS On Time Delivery Report', 0, NULL, 1, 'f85a4b2f-ed82-4436-8943-96548b2f0af5', 'f85a4b2f-ed82-4436-8943-96548b2f0af5', '2025-01-10 14:56:19.277', '2025-01-10 14:56:19.647', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" PaperKind="LetterExtra" Name="TMS On Time Delivery Report" Margins="8, 10, 98, 22" DisplayName="TMS On Time Delivery Report" PageWidth="927" PageHeight="1200" DataMember="TMSOnTimeDelivery" DataSource="#Ref-67">
  <Watermark Font="Times New Roman, 9pt" />
  <Bands>
    <Item1 ControlType="TopMarginBand" HeightF="98" Name="TopMargin1" Ref="0" />
    <Item2 ControlType="ReportHeaderBand" HeightF="136.46" Name="reportHeaderBand1" Ref="7">
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="633.33, 31.25" LocationFloat="134.38, 1.99" TextAlignment="TopCenter" Text="TMS On Time Delivery Report" Name="label3" Padding="2,2,0,0,100" Font="Times New Roman, 20pt, style=Bold" Ref="1">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLabel" SizeF="270.83, 22.92" LocationFloat="484.38, 98.96" TextAlignment="TopRight" Name="label4" Padding="2,2,0,0,100" Ref="3">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.FullName" Ref="2" />
          </DataBindings>
          <StylePriority UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRPageInfo" PageInfo="DateTime" SizeF="146.88, 22.92" LocationFloat="755.21, 98.96" Name="pageInfo1" Padding="2,2,0,0,100" Ref="4" />
        <Item4 ControlType="XRLabel" SizeF="404.17, 22.92" LocationFloat="497.92, 75" TextAlignment="TopRight" Text="label5" Name="label5" Padding="2,2,0,0,100" Ref="6">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.DateRange" Ref="5" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item4>
      </Controls>
    </Item2>
    <Item3 ControlType="PageHeaderBand" HeightF="0" Name="pageHeaderBand1" Ref="8" />
    <Item4 ControlType="GroupHeaderBand" StyleName="DataField" HeightF="75" Name="groupHeaderBand1" Ref="30">
      <GroupFields>
        <Item1 FieldName="DriverID" Ref="9" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="455.21, 16.67" LocationFloat="5.21, 14.58" Name="label10" Ref="11">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="TMSOnTimeDelivery.DriverName" Ref="10" />
          </DataBindings>
        </Item1>
        <Item2 ControlType="XRLine" SizeF="895.83, 2.08" LocationFloat="5.21, 32.29" Name="line2" Ref="12" />
        <Item3 ControlType="XRTable" SizeF="897.92, 17.71" LocationFloat="5.21, 57.29" Name="table1" BackColor="255,227,225,225" Borders="All" Ref="27">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow2" Ref="26">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.5415999786401573" Text="Order #" Name="tableCell9" Ref="13" />
                <Item2 ControlType="XRTableCell" Weight="0.5313044515028663" Text="Load #" Name="tableCell1" Ref="14" />
                <Item3 ControlType="XRTableCell" Weight="0.781306546130603" Text="Customer" Name="tableCell3" Ref="15" />
                <Item4 ControlType="XRTableCell" Weight="0.5208043635285013" Text="City" Name="tableCell13" Ref="16" />
                <Item5 ControlType="XRTableCell" Weight="0.5417045386393802" Text="Truck #" Name="tableCell15" Ref="17" />
                <Item6 ControlType="XRTableCell" Weight="0.5521361905864911" Text="Org" Name="tableCell8" Ref="18" />
                <Item7 ControlType="XRTableCell" Weight="0.6250025664397313" Text="Model" Name="tableCell16" Ref="19" />
                <Item8 ControlType="XRTableCell" Weight="1.020800727636992" Text="Schedule" Name="tableCell17" Ref="20" />
                <Item9 ControlType="XRTableCell" Weight="0.8750035930156236" Text="Out for Delivery" Name="tableCell18" Ref="21" />
                <Item10 ControlType="XRTableCell" Weight="0.9896040635980122" Text="At Delivery" Name="tableCell19" Ref="22" />
                <Item11 ControlType="XRTableCell" Weight="0.8958036784267381" Text="Delivery Completed" Name="tableCell10" Ref="23" />
                <Item12 ControlType="XRTableCell" Weight="0.5521022670902008" Text="Variance" Name="tableCell4" Ref="24" />
                <Item13 ControlType="XRTableCell" Weight="0.5521022670902009" Text="Status" Name="tableCell7" BackColor="255,227,225,225" Ref="25">
                  <StylePriority UseBackColor="false" />
                </Item13>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBackColor="false" UseBorders="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="29.17, 16.67" LocationFloat="860.42, 14.58" Name="label1" Padding="2,2,0,0,100" Ref="28">
          <Summary Running="Group" Func="Count" />
        </Item4>
        <Item5 ControlType="XRLabel" SizeF="191.67, 16.67" LocationFloat="667.71, 14.58" TextAlignment="TopRight" Text="Total Load Count :" Name="label2" Padding="2,2,0,0,100" Ref="29">
          <StylePriority UseTextAlignment="false" />
        </Item5>
      </Controls>
    </Item4>
    <Item5 ControlType="DetailBand" StyleName="DataField" HeightF="17.71" Name="detailBand1" Ref="59">
      <Controls>
        <Item1 ControlType="XRTable" SizeF="895.83, 17.71" LocationFloat="5.21000147, 0" Name="table2" Borders="Left, Right, Bottom" Ref="58">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow1" Ref="57">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="1.3413985076540758" Name="tableCell5" Ref="32">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMSOnTimeDelivery.OrderNumber" Ref="31" />
                  </DataBindings>
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="1.3158929847508458" Name="tableCell2" Ref="34">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMSOnTimeDelivery.OrderItemNumber" Ref="33" />
                  </DataBindings>
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="1.935078466000067" Name="tableCell11" Ref="36">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMSOnTimeDelivery.CustomerName" Ref="35" />
                  </DataBindings>
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="1.2898871945383783" Name="tableCell20" Ref="38">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMSOnTimeDelivery.CustomerCity" Ref="37" />
                  </DataBindings>
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="1.3416511007708132" Name="tableCell12" Ref="40">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMSOnTimeDelivery.TruckNo" Ref="39" />
                  </DataBindings>
                </Item5>
                <Item6 ControlType="XRTableCell" Weight="1.3675971437449785" Text="tableCell14" Name="tableCell14" Ref="42">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMSOnTimeDelivery.Organization" Ref="41" />
                  </DataBindings>
                </Item6>
                <Item7 ControlType="XRTableCell" Weight="1.547716028930555" Name="tableCell6" Borders="Left, Right, Bottom" Ref="44">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMSOnTimeDelivery.Model" Ref="43" />
                  </DataBindings>
                  <StylePriority UseBorders="false" />
                </Item7>
                <Item8 ControlType="XRTableCell" Weight="2.528258157036822" Name="xrTableCell1" Ref="46">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMSOnTimeDelivery.DeliverySchedule" Ref="45" />
                  </DataBindings>
                </Item8>
                <Item9 ControlType="XRTableCell" Weight="2.1671491843722754" Multiline="true" Name="xrTableCell2" Ref="48">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMSOnTimeDelivery.OutForDelivery" Ref="47" />
                  </DataBindings>
                </Item9>
                <Item10 ControlType="XRTableCell" Weight="2.4512265727723634" Multiline="true" Name="xrTableCell3" Ref="50">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMSOnTimeDelivery.AtDelivery" Ref="49" />
                  </DataBindings>
                </Item10>
                <Item11 ControlType="XRTableCell" Weight="2.2187835158678477" Multiline="true" Name="xrTableCell4" Ref="52">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMSOnTimeDelivery.DeliveryComplete" Ref="51" />
                  </DataBindings>
                </Item11>
                <Item12 ControlType="XRTableCell" Weight="1.3668701742664104" Multiline="true" Name="xrTableCell5" Ref="54">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMSOnTimeDelivery.DeliveryVariance" Ref="53" />
                  </DataBindings>
                </Item12>
                <Item13 ControlType="XRTableCell" Weight="1.315888155994174" Multiline="true" Name="xrTableCell6" Ref="56">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMSOnTimeDelivery.DeliveryStatus" Ref="55" />
                  </DataBindings>
                </Item13>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBorders="false" />
        </Item1>
      </Controls>
    </Item5>
    <Item6 ControlType="PageFooterBand" HeightF="29" Name="pageFooterBand1" Ref="61">
      <Controls>
        <Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="313, 23" LocationFloat="550, 6" StyleName="PageInfo" Name="pageInfo2" Padding="0,5,0,0,100" Font="Times New Roman, 9pt" Ref="60">
          <StylePriority UseFont="false" UsePadding="false" />
        </Item1>
      </Controls>
    </Item6>
    <Item7 ControlType="BottomMarginBand" HeightF="22" Name="BottomMargin1" Ref="62" />
  </Bands>
  <StyleSheet>
    <Item1 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;GenericDefault" Name="Title" Font="Times New Roman, 20pt, style=Bold" ForeColor="Maroon" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="63" />
    <Item2 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;GenericDefault" Name="FieldCaption" Font="Arial, 10pt, style=Bold" ForeColor="Maroon" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="64" />
    <Item3 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;GenericDefault" Name="PageInfo" Font="Times New Roman, 10pt, style=Bold" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="65" />
    <Item4 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;GenericDefault" Name="DataField" Font="Times New Roman, 10pt" Padding="2,2,0,0,100" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="66" />
  </StyleSheet>
  <ObjectStorage>
    <Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;TMS_x0020_On_x0020_Time_x0020_Delivery_x0020_Report&gt;&lt;xs:schema id=&quot;TMS_x0020_On_x0020_Time_x0020_Delivery_x0020_Report&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;TMS_x0020_On_x0020_Time_x0020_Delivery_x0020_Report&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;MileOrKm&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;TMSOnTimeDelivery&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;ScheduledTime&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;OrderNumber&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;OrderItemNumber&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;CustomerName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;CustomerCity&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Model&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TruckNo&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DeliverySchedule&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;OutForDelivery&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;AtDelivery&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DeliveryComplete&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DeliveryVariance&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DeliveryStatus&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DriverName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DriverID&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Organization&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/TMS_x0020_On_x0020_Time_x0020_Delivery_x0020_Report&gt;" Type="System.Data.DataSet" Ref="67" />
  </ObjectStorage>
  <Extensions>
    <Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="68" />
  </Extensions>
</XtraReportsLayoutSerializer>', 'aac0ab83-b7c1-4dd0-a99d-9069e0091301', 'c7aed3f5-1c57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('3caaf524-36d5-4614-94ef-5c44eea1e5dc', N'Mileage by Day', 'd226c6d5-6924-11e3-a678-a0b3cc4a6a82', NULL, 1, NULL, 1, 'f85a4b2f-ed82-4436-8943-96548b2f0af5', '91e29695-0d94-11e6-80f6-00155db47809', '2015-11-11 07:35:10.487', '2017-10-19 10:03:53.087', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" Name="Mileage by Day" DisplayName="Mileage by Day" PageWidth="850" PageHeight="1100" DataMember="MileagebyDay" FilterString="[Device Type] = ''Blackbox'' Or ([Device Type] = ''Smartphone'' And Not IsNullOrEmpty([MCS Original Device ID]))" DataSource="#Ref-43">
  <Bands>
    <Item1 ControlType="TopMarginBand" Name="TopMargin1" Ref="0" />
    <Item2 ControlType="ReportHeaderBand" HeightF="165.62" Name="reportHeaderBand1" Padding="2,0,0,0,100" Ref="9">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="638, 39" LocationFloat="6, 29.17" TextAlignment="TopCenter" Text="Mileage by Day Report" StyleName="Title" Name="label10" Font="Arial Black, 25pt, style=Bold" Ref="1">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRPageInfo" TextAlignment="MiddleRight" Format="{0: &quot;at &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="133, 22.92" LocationFloat="511, 79.17" StyleName="PageInfo" Name="pageInfo1" Font="Times New Roman, 9pt" Ref="2">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="361.46, 22.92" LocationFloat="150, 79.17" TextAlignment="MiddleRight" Text="label12" Name="label11" Padding="2,0,0,0,100" Ref="4">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Created by: {0}" Ref="3" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="493.75, 22.92" LocationFloat="150, 102.08" TextAlignment="TopRight" Text="label13" Name="label12" Padding="2,0,0,0,100" Ref="6">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.DateRange" FormatString="Date Range: {0}" Ref="5" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item4>
        <Item5 ControlType="XRLabel" SizeF="292.71, 27.08" LocationFloat="351.04, 138.54" TextAlignment="MiddleRight" Text="label9" Name="label9" Padding="2,0,0,0,100" Font="Times New Roman, 13pt, style=Bold" Ref="8">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="MileagebyDay.Total Miles" Ref="7" />
          </DataBindings>
          <Summary FormatString="{0: Total Miles #,##0.0}" Running="Report" />
          <StylePriority UseFont="false" UsePadding="false" UseTextAlignment="false" />
        </Item5>
      </Controls>
    </Item2>
    <Item3 ControlType="GroupHeaderBand" Level="1" HeightF="48.96" Name="groupHeaderBand1" Ref="16">
      <GroupFields>
        <Item1 FieldName="Date" Ref="10" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="441.67, 25" LocationFloat="5.21, 21.88" TextAlignment="MiddleLeft" Text="label2" StyleName="DataField" Name="label2" BackColor="33,255,241,46" Padding="5,0,0,0,100" Font="Times New Roman, 12pt, style=Bold" Ref="12">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="MileagebyDay.Date" FormatString="{0:dd-MMM-yyy}" Ref="11" />
          </DataBindings>
          <StylePriority UseBackColor="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLine" SizeF="637.33, 2.08" LocationFloat="6.49, 46.88" Name="line1" Ref="13" />
        <Item3 ControlType="XRLabel" SizeF="197.75, 25" LocationFloat="446.88, 21.88" TextAlignment="MiddleRight" Text="label1" Name="label1" BackColor="33,255,241,46" Padding="0,5,0,0,100" Font="Times New Roman, 12pt, style=Bold" Ref="15">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="MileagebyDay.Total Miles" Ref="14" />
          </DataBindings>
          <Summary FormatString="{0: #,##0.0 mi}" Running="Group" />
          <StylePriority UseBackColor="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
        </Item3>
      </Controls>
    </Item3>
    <Item4 ControlType="GroupHeaderBand" StyleName="FieldCaption" HeightF="32" Name="groupHeaderBand2" Ref="23">
      <Controls>
        <Item1 ControlType="XRTable" SizeF="636.45, 25" LocationFloat="7.54, 7" Name="table1" BorderColor="DarkGray" Borders="All" Ref="22">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow1" Ref="21">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="1.7999999999999998" TextAlignment="MiddleLeft" Text="Employee" Name="tableCell1" BackColor="255,194,194,194" BorderColor="DarkGray" Padding="5,0,0,0,100" Ref="17">
                  <StylePriority UseBackColor="false" UseBorderColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="1.5999999999999994" TextAlignment="MiddleLeft" Text="Equipment" Name="tableCell2" BackColor="255,194,194,194" BorderColor="DarkGray" Padding="5,0,0,0,100" Ref="18">
                  <StylePriority UseBackColor="false" UseBorderColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="1.4499999999999997" TextAlignment="MiddleLeft" Text="Device Serial Number" Name="tableCell7" BackColor="255,194,194,194" BorderColor="DarkGray" Padding="5,0,0,0,100" Ref="19">
                  <StylePriority UseBackColor="false" UseBorderColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="1.5145000000000002" TextAlignment="MiddleRight" Text="Miles" Name="tableCell3" BackColor="255,194,194,194" BorderColor="DarkGray" Padding="0,5,0,0,100" Ref="20">
                  <StylePriority UseBackColor="false" UseBorderColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item4>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item4>
    <Item5 ControlType="DetailBand" StyleName="DataField" HeightF="25" Name="detailBand1" Ref="34">
      <Controls>
        <Item1 ControlType="XRTable" SizeF="636.46, 25" LocationFloat="7.54, 0" EvenStyleName="xrControlStyle1" Name="table2" Ref="33">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow2" Ref="32">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="1.2415893222647834" TextAlignment="MiddleLeft" Text="tableCell4" Name="tableCell4" BorderColor="DarkGray" Padding="5,2,0,0,100" Borders="Left, Right, Bottom" Ref="25">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="MileagebyDay.Full Name" Ref="24" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="1.103634953124252" TextAlignment="MiddleLeft" Text="tableCell5" Name="tableCell5" BorderColor="DarkGray" Padding="5,2,0,0,100" Borders="Left, Right, Bottom" Ref="27">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="MileagebyDay.Equipment Number" Ref="26" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UsePadding="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="1.0001691762688534" TextAlignment="MiddleLeft" Text="tableCell8" Name="tableCell8" BorderColor="DarkGray" Padding="5,2,0,0,100" Borders="Left, Right, Bottom" Ref="29">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="MileagebyDay.Device Serial Number" FormatString="{0}" Ref="28" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UsePadding="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="1.0447284375012467" TextAlignment="MiddleRight" Text="tableCell6" Name="tableCell6" BorderColor="DarkGray" Padding="0,5,0,0,100" Borders="Left, Right, Bottom" Ref="31">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="MileagebyDay.Total Miles" FormatString="{0:#,##0.0}" Ref="30" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UsePadding="false" UseTextAlignment="false" />
                </Item4>
              </Cells>
            </Item1>
          </Rows>
        </Item1>
      </Controls>
    </Item5>
    <Item6 ControlType="PageFooterBand" HeightF="39" Name="pageFooterBand1" Ref="36">
      <Controls>
        <Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="313, 23" LocationFloat="331, 6" StyleName="PageInfo" Name="pageInfo3" Ref="35" />
      </Controls>
    </Item6>
    <Item7 ControlType="BottomMarginBand" Name="BottomMargin1" Padding="0,5,0,0,100" Ref="37">
      <StylePriority UsePadding="false" />
    </Item7>
  </Bands>
  <StyleSheet>
    <Item1 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="Title" Font="Times New Roman, 24pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="38" />
    <Item2 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="FieldCaption" Font="Times New Roman, 10pt, style=Bold" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="39" />
    <Item3 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="PageInfo" Font="Times New Roman, 8pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="40" />
    <Item4 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="DataField" Font="Times New Roman, 8pt" Padding="2,2,0,0,100" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="41" />
    <Item5 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="xrControlStyle1" Font="Times New Roman, 9pt" BackColor="WhiteSmoke" Sides="None" Ref="42" />
  </StyleSheet>
  <ObjectStorage>
    <Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;Mileage_x0020_by_x0020_Day&gt;&lt;xs:schema id=&quot;Mileage_x0020_by_x0020_Day&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;Mileage_x0020_by_x0020_Day&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;MileagebyDay&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;Date&quot; type=&quot;xs:dateTime&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Full_x0020_Name&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Employee_x0020_Number&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Equipment_x0020_Number&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Device_x0020_Serial_x0020_Number&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;MCS_x0020_Original_x0020_Device_x0020_ID&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Device_x0020_Type&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Total_x0020_Miles&quot; type=&quot;xs:decimal&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/Mileage_x0020_by_x0020_Day&gt;" Type="System.Data.DataSet" Ref="43" />
  </ObjectStorage>
  <Extensions>
    <Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="44" />
  </Extensions>
</XtraReportsLayoutSerializer>', '302d7a00-2956-4618-87d4-52bb70e4fcf8', '8b799cdc-1d57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('3af12428-1c65-4d8b-b9d1-5e48cf0390c9', N'TMS Status Push Times By Load', 'be7768b5-6924-11e3-a678-a0b3cc4a6a82', N'TMS Status Push Times By Load', 0, NULL, 1, 'f85a4b2f-ed82-4436-8943-96548b2f0af5', 'f85a4b2f-ed82-4436-8943-96548b2f0af5', '2025-01-10 14:59:27.137', '2025-01-10 14:59:27.137', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?><XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" PaperKind="A4" Name="TMS Status Push Times By Load" Margins="90, 13, 98, 100" DisplayName="TMS Status Push Times By Load" PageWidth="827" PageHeight="1169" DataMember="TMSStatusPushTimesByLoad" DataSource="#Ref-66"><Bands><Item1 ControlType="TopMarginBand" HeightF="98" Name="TopMargin1" Padding="0,5,0,0,100" Ref="0"><StylePriority UsePadding="false"/></Item1><Item2 ControlType="ReportHeaderBand" HeightF="136.88" Name="reportHeaderBand1" Padding="2,0,0,0,100" Ref="7"><StylePriority UsePadding="false"/><Controls><Item1 ControlType="XRLabel" SizeF="638.54, 41.67" LocationFloat="5.21, 13.54" TextAlignment="TopCenter" Text="TMS Status Push Times By Load" Name="label11" Font="Arial Black, 25pt, style=Bold" Ref="1"><StylePriority UseFont="false" UseTextAlignment="false"/></Item1><Item2 ControlType="XRPageInfo" TextAlignment="MiddleRight" Format="{0: &quot;at &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="133, 22.92" LocationFloat="554.5, 79.17" Name="pageInfo1" Font="Times New Roman, 9pt" Ref="2"><StylePriority UseFont="false" UseTextAlignment="false"/></Item2><Item3 ControlType="XRLabel" SizeF="353.13, 20.83" LocationFloat="193.75, 79.17" TextAlignment="MiddleRight" Text="label12" Name="label12" Padding="2,0,0,0,100" Ref="4"><DataBindings><Item1 PropertyName="Text" DataMember="UserInfo.FullName" Ref="3"/></DataBindings><StylePriority UsePadding="false" UseTextAlignment="false"/></Item3><Item4 ControlType="XRLabel" SizeF="493.75, 22.92" LocationFloat="193.75, 102.08" TextAlignment="TopRight" Text="label13" Name="label13" Padding="2,0,0,0,100" Ref="6"><DataBindings><Item1 PropertyName="Text" DataMember="UserInfo.DateRange" FormatString="Date Range: {0}" Ref="5"/></DataBindings><StylePriority UsePadding="false" UseTextAlignment="false"/></Item4></Controls></Item2><Item3 ControlType="GroupHeaderBand" Level="1" HeightF="27.08" Name="groupHeaderBand2" Ref="14"><GroupFields><Item1 FieldName="DriverID" Ref="8"/></GroupFields><Controls><Item1 ControlType="XRLabel" SizeF="269.27, 25" LocationFloat="5.21, 0" TextAlignment="MiddleLeft" Name="label4" Font="Times New Roman, 10pt, style=Bold" Ref="10"><DataBindings><Item1 PropertyName="Text" DataMember="TMSStatusPushTimesByLoad.DriverName" Ref="9"/></DataBindings><StylePriority UseFont="false" UseTextAlignment="false"/></Item1><Item2 ControlType="XRLine" ForeColor="255,82,82,82" SizeF="688.2, 2.08" LocationFloat="4.17, 25" Name="line2" Ref="11"><StylePriority UseForeColor="false"/></Item2><Item3 ControlType="XRLabel" SizeF="214.58, 22.92" LocationFloat="434.38, 0" TextAlignment="MiddleRight" Text="Total Load Count :" Name="label1" Padding="2,2,0,0,100" Font="Times New Roman, 9pt, style=Bold" Ref="12"><StylePriority UseFont="false" UseTextAlignment="false"/></Item3><Item4 ControlType="XRLabel" SizeF="36.46, 22.92" LocationFloat="651.04, 0" TextAlignment="MiddleLeft" Name="label2" Padding="2,2,0,0,100" Font="Times New Roman, 9pt, style=Bold" Ref="13"><Summary Running="Group" Func="Count"/><StylePriority UseFont="false" UseTextAlignment="false"/></Item4></Controls></Item3><Item4 ControlType="GroupHeaderBand" HeightF="42.5" Name="groupHeaderBand3" Padding="0,5,0,0,100" Ref="30"><StylePriority UsePadding="false"/><Controls><Item1 ControlType="XRTable" SizeF="688.88, 37.5" LocationFloat="3.65, 5" Name="table1" BorderColor="DarkGray" Borders="All" Ref="29"><Rows><Item1 ControlType="XRTableRow" Weight="1.0714285714285714" Name="tableRow1" Ref="28"><Cells><Item1 ControlType="XRTableCell" Weight="0.5588488990841255" TextAlignment="MiddleCenter" Text="Order#" Name="tableCell1" BackColor="255,194,194,194" Ref="15"><StylePriority UseBackColor="false" UseTextAlignment="false"/></Item1><Item2 ControlType="XRTableCell" Weight="0.5158605222315005" TextAlignment="MiddleCenter" Text="Load#" Name="tableCell2" BackColor="255,194,194,194" Ref="16"><StylePriority UseBackColor="false" UseTextAlignment="false"/></Item2><Item3 ControlType="XRTableCell" Weight="0.5158605222315004" TextAlignment="MiddleCenter" Text="Model" Name="tableCell3" BackColor="255,194,194,194" Ref="17"><StylePriority UseBackColor="false" UseTextAlignment="false"/></Item3><Item4 ControlType="XRTableCell" Weight="0.7246612098013934" TextAlignment="MiddleCenter" Text="Pickup Schedule" Name="tableCell4" BackColor="255,194,194,194" Ref="18"><StylePriority UseBackColor="false" UseTextAlignment="false"/></Item4><Item5 ControlType="XRTableCell" Weight="0.7246612098013934" TextAlignment="MiddleCenter" Text="Delivery Schedule" Name="tableCell5" BackColor="255,194,194,194" Ref="19"><StylePriority UseBackColor="false" UseTextAlignment="false"/></Item5><Item6 ControlType="XRTableCell" Weight="0.7246612098013931" TextAlignment="MiddleCenter" Text="Out For Pickup" Name="tableCell6" BackColor="255,194,194,194" Ref="20"><StylePriority UseBackColor="false" UseTextAlignment="false"/></Item6><Item7 ControlType="XRTableCell" Weight="0.7246612098013934" TextAlignment="MiddleCenter" Text="At Pickup" Name="tableCell7" BackColor="255,194,194,194" Ref="21"><StylePriority UseBackColor="false" UseTextAlignment="false"/></Item7><Item8 ControlType="XRTableCell" Weight="0.7246612098013934" TextAlignment="MiddleCenter" Text="Out For Delivery" Name="tableCell8" BackColor="255,194,194,194" Ref="22"><StylePriority UseBackColor="false" UseTextAlignment="false"/></Item8><Item9 ControlType="XRTableCell" Weight="0.7246612098013934" TextAlignment="MiddleCenter" Text="At Delivery" Name="tableCell9" BackColor="255,194,194,194" Ref="23"><StylePriority UseBackColor="false" UseTextAlignment="false"/></Item9><Item10 ControlType="XRTableCell" Weight="0.7246612098013934" TextAlignment="MiddleCenter" Text="Complete" Name="tableCell10" BackColor="255,194,194,194" Ref="24"><StylePriority UseBackColor="false" UseTextAlignment="false"/></Item10><Item11 ControlType="XRTableCell" Weight="0.5404253090044289" Text="Pickup City" Name="tableCell11" BackColor="255,194,194,194" Ref="25"><StylePriority UseBackColor="false"/></Item11><Item12 ControlType="XRTableCell" Weight="0.6632492428690718" Text="Delivery City" Name="tableCell13" BackColor="255,194,194,194" Ref="26"><StylePriority UseBackColor="false"/></Item12><Item13 ControlType="XRTableCell" Weight="0.5942221920371435" Text="Change" Name="tableCell14" BackColor="255,194,194,194" Ref="27"><StylePriority UseBackColor="false"/></Item13></Cells></Item1></Rows><StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false"/></Item1></Controls></Item4><Item5 ControlType="DetailBand" HeightF="60" Name="detailBand1" Ref="61"><SortFields><Item1 FieldName="PickupPromiseTime" Ref="31"/><Item2 FieldName="DeliveryPromiseTime" Ref="32"/></SortFields><Controls><Item1 ControlType="XRTable" SizeF="688.2, 59.9" LocationFloat="4.17, 0" Name="table2" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="60"><Rows><Item1 ControlType="XRTableRow" Weight="1.1501536098310292" Name="tableRow2" Ref="59"><Cells><Item1 ControlType="XRTableCell" Weight="0.5136342535630098" TextAlignment="MiddleCenter" Name="tableCell1" Padding="5,0,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="34"><DataBindings><Item1 PropertyName="Text" DataMember="TMSStatusPushTimesByLoad.OrderNumber" Ref="33"/></DataBindings><StylePriority UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false"/></Item1><Item2 ControlType="XRTableCell" Weight="0.5055335076211018" TextAlignment="MiddleCenter" Text="tableCell2" Name="tableCell12" Ref="36"><DataBindings><Item1 PropertyName="Text" DataMember="TMSStatusPushTimesByLoad.OrderItemNumber" Ref="35"/></DataBindings><StylePriority UseTextAlignment="false"/></Item2><Item3 ControlType="XRTableCell" Weight="0.49731535956409334" TextAlignment="MiddleCenter" Multiline="true" Name="tableCell3" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="38"><DataBindings><Item1 PropertyName="Text" DataMember="TMSStatusPushTimesByLoad.Model" Ref="37"/></DataBindings><StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false"/></Item3><Item4 ControlType="XRTableCell" Weight="0.6909114473641859" TextAlignment="MiddleCenter" Multiline="true" Name="tableCell4" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="40"><DataBindings><Item1 PropertyName="Text" DataMember="TMSStatusPushTimesByLoad.PickupSchedule" Ref="39"/></DataBindings><StylePriority UseBorders="false" UseBorderWidth="false" UseTextAlignment="false"/></Item4><Item5 ControlType="XRTableCell" Weight="0.6971337594644921" TextAlignment="MiddleCenter" Name="tableCell5" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="42"><DataBindings><Item1 PropertyName="Text" DataMember="TMSStatusPushTimesByLoad.DeliverySchedule" Ref="41"/></DataBindings><StylePriority UseBorders="false" UseBorderWidth="false" UseTextAlignment="false"/></Item5><Item6 ControlType="XRTableCell" Weight="0.6909114473641859" TextAlignment="MiddleCenter" Multiline="true" Name="tableCell6" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="44"><DataBindings><Item1 PropertyName="Text" DataMember="TMSStatusPushTimesByLoad.OutForPickup" Ref="43"/></DataBindings><StylePriority UseBorders="false" UseBorderWidth="false"/></Item6><Item7 ControlType="XRTableCell" Weight="0.6909114473641859" TextAlignment="MiddleCenter" Multiline="true" Name="tableCell7" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="46"><DataBindings><Item1 PropertyName="Text" DataMember="TMSStatusPushTimesByLoad.AtPickup" Ref="45"/></DataBindings><StylePriority UseBorders="false" UseBorderWidth="false"/></Item7><Item8 ControlType="XRTableCell" Weight="0.6971337594644921" TextAlignment="MiddleCenter" Name="tableCell18" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="48"><DataBindings><Item1 PropertyName="Text" DataMember="TMSStatusPushTimesByLoad.OutForDelivery" Ref="47"/></DataBindings><StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false"/></Item8><Item9 ControlType="XRTableCell" Weight="0.6909114473641856" TextAlignment="MiddleCenter" Name="tableCell19" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="50"><DataBindings><Item1 PropertyName="Text" DataMember="TMSStatusPushTimesByLoad.AtDelivery" Ref="49"/></DataBindings><StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false"/></Item9><Item10 ControlType="XRTableCell" Weight="0.6788190295088726" TextAlignment="MiddleCenter" Name="tableCell10" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="52"><DataBindings><Item1 PropertyName="Text" DataMember="TMSStatusPushTimesByLoad.DeliveryComplete" Ref="51"/></DataBindings><StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false"/></Item10><Item11 ControlType="XRTableCell" Weight="0.5319489835186281" TextAlignment="MiddleCenter" Name="tableCell11" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="54"><DataBindings><Item1 PropertyName="Text" DataMember="TMSStatusPushTimesByLoad.PickupCity" Ref="53"/></DataBindings><StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false"/></Item11><Item12 ControlType="XRTableCell" Weight="0.6298623475121252" TextAlignment="MiddleCenter" Text="tableCell13" Name="tableCell12" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="56"><DataBindings><Item1 PropertyName="Text" DataMember="TMSStatusPushTimesByLoad.DeliveryCity" Ref="55"/></DataBindings><StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false"/></Item12><Item13 ControlType="XRTableCell" Weight="0.5645867715164612" TextAlignment="MiddleCenter" Text="tableCell15" Name="tableCell15" Ref="58"><DataBindings><Item1 PropertyName="Text" DataMember="TMSStatusPushTimesByLoad.Changes" Ref="57"/></DataBindings><StylePriority UseTextAlignment="false"/></Item13></Cells></Item1></Rows><StylePriority UseBorderColor="false" UseBorders="false"/></Item1></Controls></Item5><Item6 ControlType="GroupFooterBand" HeightF="24.38" Name="GroupFooter1" Ref="62"/><Item7 ControlType="PageFooterBand" HeightF="48.96" Name="pageFooterBand1" Ref="64"><Controls><Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="400, 22.92" LocationFloat="287.27, 5.4" Name="pageInfo2" Padding="0,5,0,0,100" Font="Times New Roman, 9pt" Ref="63"><StylePriority UseFont="false" UsePadding="false"/></Item1></Controls></Item7><Item8 ControlType="BottomMarginBand" Name="BottomMargin1" Padding="0,10,0,0,100" Ref="65"><StylePriority UsePadding="false"/></Item8></Bands><ObjectStorage><Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;TMS_x0020_Status_x0020_Push_x0020_Times_x0020_By_x0020_Load&gt;&lt;xs:schema id=&quot;TMS_x0020_Status_x0020_Push_x0020_Times_x0020_By_x0020_Load&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;TMS_x0020_Status_x0020_Push_x0020_Times_x0020_By_x0020_Load&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;MileOrKm&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;TMSStatusPushTimesByLoad&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;ScheduledTime&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;OrderNumber&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;OrderItemNumber&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DriverID&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DriverName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Model&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Changes&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;PickupSchedule&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DeliverySchedule&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;OutForPickup&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;AtPickup&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;OutForDelivery&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;AtDelivery&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DeliveryComplete&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;PickupCity&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DeliveryCity&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/TMS_x0020_Status_x0020_Push_x0020_Times_x0020_By_x0020_Load&gt;" Type="System.Data.DataSet" Ref="66"/></ObjectStorage><Extensions><Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="67"/></Extensions></XtraReportsLayoutSerializer>', '58496605-89ea-4844-a380-c2a15fd5d962', 'c7aed3f5-1c57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('dbe634e5-0dbb-4de5-ab18-6be126c3bf6a', N'Ignition Report', 'd226c6d5-6924-11e3-a678-a0b3cc4a6a82', NULL, 0, NULL, 1, 'f85a4b2f-ed82-4436-8943-96548b2f0af5', 'f85a4b2f-ed82-4436-8943-96548b2f0af5', '2016-03-14 07:46:10.063', '2016-03-21 07:15:03.327', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" Name="Ignition Report" Margins="96, 91, 98, 100" DisplayName="Ignition Report" ScriptsSource="private void tableCell10_BeforePrint(object sender, System.EventArgs e) {&#xD;&#xA;    object status= GetCurrentColumnValue(&quot;Status&quot;);&#xD;&#xA;    if(status!=null &amp;&amp; status.ToString()==&quot;ON&quot;)&#xD;&#xA;    {&#xD;&#xA;        (sender as XRTableCell).BackColor = System.Drawing.Color.Green;&#xD;&#xA;    }else if(status!=null &amp;&amp; status.ToString()==&quot;OFF&quot;)&#xD;&#xA;    {&#xD;&#xA;        (sender as XRTableCell).BackColor = System.Drawing.Color.Pink;&#xD;&#xA;    }&#xD;&#xA;    &#xD;&#xA;}" PageWidth="850" PageHeight="1100" DataMember="IgnitionReport" DataSource="#Ref-57">
  <Bands>
    <Item1 ControlType="TopMarginBand" HeightF="98" Name="TopMargin1" Padding="0,5,0,0,100" Ref="0">
      <StylePriority UsePadding="false" />
    </Item1>
    <Item2 ControlType="ReportHeaderBand" HeightF="125" Name="reportHeaderBand1" Padding="2,0,0,0,100" Ref="7">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="638, 39" LocationFloat="6, 29.17" TextAlignment="TopCenter" Text="Ignition Report" StyleName="Title" Name="label11" Font="Arial Black, 25pt, style=Bold" Ref="1">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRPageInfo" TextAlignment="MiddleRight" Format="{0: &quot;at &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="133, 22.92" LocationFloat="511, 79.17" StyleName="PageInfo" Name="pageInfo1" Font="Times New Roman, 9pt" Ref="2">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="361.46, 22.92" LocationFloat="150, 79.17" TextAlignment="MiddleRight" Text="label12" Name="label12" Padding="2,0,0,0,100" Ref="4">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Created by: {0}" Ref="3" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="493.75, 22.92" LocationFloat="150, 102.08" TextAlignment="TopRight" Text="label13" Name="label13" Padding="2,0,0,0,100" Ref="6">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.DateRange" FormatString="Date Range: {0}" Ref="5" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item4>
      </Controls>
    </Item2>
    <Item3 ControlType="GroupHeaderBand" Level="2" HeightF="84.38" Name="groupHeaderBand1" BackColor="0,46,34,34" Ref="17">
      <GroupFields>
        <Item1 FieldName="Driver" Ref="8" />
      </GroupFields>
      <StylePriority UseBackColor="false" />
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="185.42, 25" LocationFloat="72.92, 30.21" TextAlignment="MiddleLeft" StyleName="DataField" Name="label2" Font="Times New Roman, 10pt" Ref="10">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="IgnitionReport.Driver" Ref="9" />
          </DataBindings>
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLabel" SizeF="67.83, 25" LocationFloat="5.21, 30.21" TextAlignment="MiddleLeft" Text="Driver" StyleName="FieldCaption" Name="label1" Font="Times New Roman, 10pt, style=Bold" Ref="11">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLine" ForeColor="255,82,82,82" SizeF="639, 2.08" LocationFloat="5.21, 82.29" Name="line1" Ref="12">
          <StylePriority UseForeColor="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="378.13, 26.04" LocationFloat="259.38, 30.21" TextAlignment="MiddleRight" Text="Driver''s Total Ignition ON" Name="label6" Padding="2,2,0,0,100" Ref="14">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="IgnitionReport.EmployeeNumberTotalON" FormatString="Driver''s Total Ignition ON: {0}" Ref="13" />
          </DataBindings>
          <StylePriority UseTextAlignment="false" />
        </Item4>
        <Item5 ControlType="XRLabel" SizeF="373.96, 26.04" LocationFloat="260.42, 56.25" TextAlignment="MiddleRight" Text="Driver''s Total Ignition OFF" Name="label9" Padding="2,2,0,0,100" Ref="16">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="IgnitionReport.EmployeeNumberTotalOFF" FormatString="Driver''s Total Ignition OFF: {0}" Ref="15" />
          </DataBindings>
          <StylePriority UseTextAlignment="false" />
        </Item5>
      </Controls>
    </Item3>
    <Item4 ControlType="GroupHeaderBand" Level="1" HeightF="50" Name="groupHeaderBand2" Ref="26">
      <GroupFields>
        <Item1 FieldName="Equipment" Ref="18" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="143.75, 26.04" LocationFloat="91.67, 0" TextAlignment="MiddleLeft" StyleName="DataField" Name="label4" Font="Times New Roman, 9pt" Ref="20">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="IgnitionReport.Equipment" Ref="19" />
          </DataBindings>
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLabel" SizeF="65.63, 26.04" LocationFloat="26.04, 0" TextAlignment="MiddleLeft" Text="Equipment" StyleName="FieldCaption" Name="label3" Font="Times New Roman, 9pt, style=Bold" Ref="21">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="404.17, 22.92" LocationFloat="237.5, 1.04" TextAlignment="MiddleRight" Name="label8" Padding="2,2,0,0,100" Ref="23">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="IgnitionReport.EquipmentNumberTotalON" FormatString="Equipment Ignition ON: {0}" Ref="22" />
          </DataBindings>
          <StylePriority UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="403.13, 20.83" LocationFloat="236.46, 26.04" TextAlignment="MiddleRight" Text="label15" Name="label15" Padding="2,2,0,0,100" Ref="25">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="IgnitionReport.EquipmentNumberTotalOFF" FormatString="Equipment Ignition OFF: {0}" Ref="24" />
          </DataBindings>
          <StylePriority UseTextAlignment="false" />
        </Item4>
      </Controls>
    </Item4>
    <Item5 ControlType="GroupHeaderBand" StyleName="FieldCaption" HeightF="40.42" Name="groupHeaderBand3" Padding="0,5,0,0,100" Ref="34">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRTable" SizeF="614.58, 35.42" LocationFloat="25.5, 5" Name="table1" BorderColor="DarkGray" Borders="All" Ref="33">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1.012" Name="tableRow1" Ref="32">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.6784879988824379" TextAlignment="MiddleCenter" Text="Equipment" Name="tableCell1" BackColor="255,194,194,194" Ref="27">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.8777198985014307" TextAlignment="MiddleCenter" Text="Time Start" Name="tableCell2" BackColor="255,194,194,194" Ref="28">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.8278820447875019" TextAlignment="MiddleCenter" Text="Time End" Name="tableCell5" BackColor="255,194,194,194" Ref="29">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="1.0208393944784822" TextAlignment="MiddleCenter" Text="Duration (minutes)" Name="tableCell3" BackColor="255,194,194,194" Ref="30">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="0.26765437264351244" TextAlignment="MiddleCenter" Text="Status" Name="tableCell4" BackColor="255,194,194,194" Ref="31">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item5>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item5>
    <Item6 ControlType="DetailBand" StyleName="DataField" HeightF="25" Name="detailBand1" Ref="47">
      <Controls>
        <Item1 ControlType="XRTable" SizeF="614.58, 25" LocationFloat="25.5, 0" EvenStyleName="xrControlStyle1" Name="table2" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="46">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow2" Ref="45">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.5465225274386004" TextAlignment="MiddleLeft" Name="tableCell7" Padding="5,0,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="36">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="IgnitionReport.Equipment" Ref="35" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.7070039530577911" TextAlignment="MiddleLeft" Name="tableCell8" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="38">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="IgnitionReport.Date Time Captured" Ref="37" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.6668595292526307" TextAlignment="MiddleLeft" Text="tableCell6" Name="tableCell6" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="40">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="IgnitionReport.TimeEnd" Ref="39" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.8272927747063937" TextAlignment="MiddleCenter" Name="tableCell9" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="42">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="IgnitionReport.durationinsecond" FormatString="{0: MM/dd/yyyy}" Ref="41" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="0.21058979853925566" TextAlignment="MiddleLeft" Name="tableCell10" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="44">
                  <Scripts OnBeforePrint="tableCell10_BeforePrint" />
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="IgnitionReport.Status" Ref="43" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item5>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item6>
    <Item7 ControlType="GroupFooterBand" HeightF="27.08" Name="GroupFooter1" Ref="48" />
    <Item8 ControlType="PageFooterBand" HeightF="48.96" Name="pageFooterBand1" Ref="50">
      <Controls>
        <Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="313, 23" LocationFloat="331, 6" StyleName="PageInfo" Name="pageInfo2" Padding="0,5,0,0,100" Font="Times New Roman, 9pt" Ref="49">
          <StylePriority UseFont="false" UsePadding="false" />
        </Item1>
      </Controls>
    </Item8>
    <Item9 ControlType="BottomMarginBand" Name="BottomMargin1" Padding="0,10,0,0,100" Ref="51">
      <StylePriority UsePadding="false" />
    </Item9>
  </Bands>
  <StyleSheet>
    <Item1 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="Title" Font="Times New Roman, 24pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="52" />
    <Item2 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="FieldCaption" Font="Times New Roman, 10pt, style=Bold" ForeColor="Black" BackColor="0,28,16,16" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="53" />
    <Item3 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="PageInfo" Font="Times New Roman, 8pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="54" />
    <Item4 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="DataField" Font="Times New Roman, 8pt" Padding="2,2,0,0,100" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="55" />
    <Item5 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="xrControlStyle1" Font="Times New Roman, 9pt" BackColor="WhiteSmoke" BorderColor="DarkGray" Sides="None" BorderWidthSerializable="1" Ref="56" />
  </StyleSheet>
  <ObjectStorage>
    <Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;Ignition_x0020_Report&gt;&lt;xs:schema id=&quot;Ignition_x0020_Report&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;Ignition_x0020_Report&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;IgnitionReport&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;Driver&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Equipment&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Status&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Date_x0020_Time_x0020_Captured&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeEnd&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;durationinsecond&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EmployeeNumberTotalON&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EmployeeNumberTotalOFF&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EquipmentNumberTotalON&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EquipmentNumberTotalOFF&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/Ignition_x0020_Report&gt;" Type="System.Data.DataSet" Ref="57" />
  </ObjectStorage>
  <Extensions>
    <Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="58" />
  </Extensions>
</XtraReportsLayoutSerializer>', 'e95483cd-77b4-4fb6-80e3-d5cf3b59ff82', '8b799cdc-1d57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('c648f2fe-d75e-49c4-894f-7a27155fd892', N'Vehicle Idling Report', 'd226c6d5-6924-11e3-a678-a0b3cc4a6a82', N'Good Idle/Bad Idle Report', 1, NULL, 1, 'f85a4b2f-ed82-4436-8943-96548b2f0af5', '91e29695-0d94-11e6-80f6-00155db47809', '2015-09-03 07:15:22.903', '2016-05-23 04:07:53.980', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" Name="Vehicle Idling Report" Margins="56, 50, 100, 100" DisplayName="Vehicle Idling Report" PageWidth="850" PageHeight="1100" DataMember="IdlingReport" DataSource="#Ref-73">
  <Bands>
    <Item1 ControlType="TopMarginBand" Name="TopMargin1" Ref="0" />
    <Item2 ControlType="ReportHeaderBand" HeightF="98.96" Name="reportHeaderBand1" Ref="8">
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="646.88, 47.92" LocationFloat="53.13, 0" TextAlignment="MiddleCenter" Text="Vehicle Idling Report" StyleName="Title" Name="label39" Font="Arial Black, 25pt" Ref="1">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLabel" SizeF="162.5, 22.92" LocationFloat="538.54, 76.04" TextAlignment="MiddleRight" Text="label10" Name="label10" Padding="2,2,0,0,100" Ref="3">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.DateRange" Ref="2" />
          </DataBindings>
          <StylePriority UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="334.38, 22.92" LocationFloat="198.96, 53.13" TextAlignment="MiddleRight" Text="label11" Name="label11" Padding="2,2,0,0,100" Ref="5">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Created by: {0}" Ref="4" />
          </DataBindings>
          <StylePriority UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRPageInfo" TextAlignment="MiddleRight" Format="{0: &quot;at &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="165.63, 22.92" LocationFloat="535.42, 53.13" Name="pageInfo3" Padding="2,2,0,0,100" Ref="6">
          <StylePriority UseTextAlignment="false" />
        </Item4>
        <Item5 ControlType="XRLabel" SizeF="331.25, 22.92" LocationFloat="204.17, 76.04" TextAlignment="MiddleRight" Text="Date Range" Name="label3" Padding="2,2,0,0,100" Ref="7">
          <StylePriority UseTextAlignment="false" />
        </Item5>
      </Controls>
    </Item2>
    <Item3 ControlType="GroupHeaderBand" Level="2" HeightF="59.79" Name="groupHeaderBand1" Ref="26">
      <GroupFields>
        <Item1 FieldName="Equipment Number" Ref="9" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRTable" SizeF="697.92, 25" LocationFloat="2.08, 25" Name="table3" Ref="25">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow2" Ref="24">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.6966695581155434" Text="tableCell7" Name="tableCell6" Ref="11">
                  <Controls>
                    <Item1 ControlType="XRLabel" SizeF="75, 23.96" LocationFloat="0, 0" TextAlignment="MiddleCenter" Text="Equipment:" StyleName="FieldCaption" Name="label1" BackColor="255,194,194,194" Font="Times New Roman, 9pt, style=Bold" Ref="10">
                      <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
                    </Item1>
                  </Controls>
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="1.3012760488308117" Text="tableCell7" Name="tableCell7" Ref="14">
                  <Controls>
                    <Item1 ControlType="XRLabel" SizeF="126.04, 23.96" LocationFloat="0, 0" TextAlignment="MiddleLeft" StyleName="DataField" Name="label2" Font="Times New Roman, 9pt" Ref="13">
                      <DataBindings>
                        <Item1 PropertyName="Text" DataMember="IdlingReport.Equipment Number" Ref="12" />
                      </DataBindings>
                      <StylePriority UseFont="false" UseTextAlignment="false" />
                    </Item1>
                  </Controls>
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="1.9056858235900962" Text="tableCell8" Name="tableCell8" Ref="17">
                  <Controls>
                    <Item1 ControlType="XRLabel" SizeF="192.71, 23.96" LocationFloat="0, 0" TextAlignment="MiddleLeft" Text="Total Idle :" Name="label40" Padding="2,2,0,0,100" Ref="16">
                      <DataBindings>
                        <Item1 PropertyName="Text" DataMember="IdlingReport.TotalDuration" FormatString="Total Idle: {0}," Ref="15" />
                      </DataBindings>
                      <StylePriority UseTextAlignment="false" />
                    </Item1>
                  </Controls>
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="1.2294747248968363" Text="tableCell10" Name="tableCell10" Ref="20">
                  <Controls>
                    <Item1 ControlType="XRLabel" SizeF="125, 23.96" LocationFloat="0, 0" TextAlignment="MiddleLeft" Text="label41" Name="label41" Padding="2,2,0,0,100" Ref="19">
                      <DataBindings>
                        <Item1 PropertyName="Text" DataMember="IdlingReport.TotalPTOON" FormatString="{0}% PTO ON," Ref="18" />
                      </DataBindings>
                      <StylePriority UseTextAlignment="false" />
                    </Item1>
                  </Controls>
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="1.731493844566712" Text="tableCell9" Name="tableCell9" Ref="23">
                  <Controls>
                    <Item1 ControlType="XRLabel" SizeF="182.29, 23.96" LocationFloat="0, 0" TextAlignment="MiddleLeft" Text="label42" Name="label42" Padding="2,2,0,0,100" Ref="22">
                      <DataBindings>
                        <Item1 PropertyName="Text" DataMember="IdlingReport.TotalPTOOFF" FormatString="{0}% PTO OFF" Ref="21" />
                      </DataBindings>
                      <StylePriority UseTextAlignment="false" />
                    </Item1>
                  </Controls>
                </Item5>
              </Cells>
            </Item1>
          </Rows>
        </Item1>
      </Controls>
    </Item3>
    <Item4 ControlType="GroupHeaderBand" Level="1" HeightF="59.35" Name="groupHeaderBand2" Ref="50">
      <GroupFields>
        <Item1 FieldName="grp" Ref="27" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRTable" SizeF="667.71, 25" LocationFloat="32.29, 9.38" Name="table1" Ref="34">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow1" Ref="33">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="1.1354000000000002" TextAlignment="MiddleCenter" Text="Idle Start Time" Name="tableCell1" BackColor="255,194,194,194" BorderColor="DarkGray" Borders="All" Font="Times New Roman, 9pt, style=Bold" Ref="28">
                  <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="1.2708000000000002" TextAlignment="MiddleCenter" Text="Idle Duration" Name="tableCell2" BackColor="255,194,194,194" BorderColor="DarkGray" Borders="All" Font="Times New Roman, 9pt, style=Bold" Ref="29">
                  <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="1.9376000000000007" TextAlignment="MiddleCenter" Text="Address, City , State" Name="tableCell3" BackColor="255,194,194,194" BorderColor="DarkGray" Borders="All" Font="Times New Roman, 9pt, style=Bold" Ref="30">
                  <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="1.1770000000000003" TextAlignment="MiddleCenter" Text="PTO ON" Name="tableCell5" BackColor="255,194,194,194" BorderColor="255,194,194,194" Borders="All" Font="Times New Roman, 9pt, style=Bold" Ref="31">
                  <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="1.1563000000000003" TextAlignment="MiddleCenter" Text="PTO OFF" Name="tableCell4" BackColor="255,194,194,194" BorderColor="DarkGray" Borders="All" Font="Times New Roman, 9pt, style=Bold" Ref="32">
                  <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item5>
              </Cells>
            </Item1>
          </Rows>
        </Item1>
        <Item2 ControlType="XRTable" SizeF="667.71, 25" LocationFloat="32.29, 34.35" Name="table2" Ref="46">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow1" Ref="45">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="1.1353999999999995" TextAlignment="MiddleLeft" Text="tableCell1" Name="tableCell1" BorderColor="DarkGray" Borders="Left, Right, Bottom" Font="Times New Roman, 8pt" Ref="36">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="IdlingReport.IdleStartTime" FormatString="{0: MM/dd/yyyy hh:mm tt}" Ref="35" />
                  </DataBindings>
                  <Summary FormatString="{0: MM/dd/yyyy hh:mm tt}" />
                  <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="1.2707999999999993" TextAlignment="MiddleLeft" Text="tableCell2" Name="tableCell2" BorderColor="DarkGray" Borders="Left, Right, Bottom" Font="Times New Roman, 8pt" Ref="38">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="IdlingReport.IdleDurationInMinStr" Ref="37" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="1.9375999999999989" TextAlignment="MiddleLeft" Text="tableCell3" Name="tableCell3" BorderColor="DarkGray" Borders="Left, Right, Bottom" Font="Times New Roman, 8pt" Ref="40">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="IdlingReport.Address" Ref="39" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="1.1770999999999994" TextAlignment="MiddleLeft" Text="tableCell5" Name="tableCell5" BorderColor="DarkGray" Borders="Left, Right, Bottom" Font="Times New Roman, 8pt" Ref="42">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="IdlingReport.PTOOnInMinStr" Ref="41" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="1.1561999999999995" TextAlignment="MiddleLeft" Text="tableCell4" Name="tableCell4" BorderColor="DarkGray" Borders="Left, Right, Bottom" Font="Times New Roman, 8pt" Ref="44">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="IdlingReport.PTOOffInMinStr" Ref="43" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item5>
              </Cells>
            </Item1>
          </Rows>
        </Item2>
        <Item3 ControlType="XRLine" SizeF="667.71, 9.38" LocationFloat="32.29, 0" Name="line3" Ref="47" />
        <Item4 ControlType="XRLabel" SizeF="19.17, 33.75" LocationFloat="5.21, 9.38" StyleName="DataField" Name="label4" Ref="49">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="IdlingReport.grp" FormatString="{0:&quot;&quot;}" Ref="48" />
          </DataBindings>
        </Item4>
      </Controls>
    </Item4>
    <Item5 ControlType="GroupHeaderBand" StyleName="FieldCaption" HeightF="25" Name="groupHeaderBand3" Ref="56">
      <Controls>
        <Item1 ControlType="XRTable" SizeF="629.15, 25" LocationFloat="70.85, 0" Name="table5" Ref="55">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow4" Ref="54">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="1.833300000000003" TextAlignment="MiddleCenter" Text="Event Type" Name="tableCell14" BackColor="255,194,194,194" BorderColor="DarkGray" Borders="All" Ref="51">
                  <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="2.437400000000004" TextAlignment="MiddleCenter" Text="Event Time" Name="tableCell15" BackColor="255,194,194,194" BorderColor="DarkGray" Borders="All" Ref="52">
                  <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="2.0208000000000017" TextAlignment="MiddleCenter" Text="Duration" Name="tableCell16" BackColor="255,194,194,194" BorderColor="DarkGray" Borders="All" Ref="53">
                  <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UseTextAlignment="false" />
                </Item3>
              </Cells>
            </Item1>
          </Rows>
        </Item1>
      </Controls>
    </Item5>
    <Item6 ControlType="DetailBand" StyleName="DataField" HeightF="25" Name="detailBand1" Ref="65">
      <Controls>
        <Item1 ControlType="XRTable" SizeF="629.16, 25" LocationFloat="70.84, 0" Name="table4" Ref="64">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow3" Ref="63">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="1.8333000000000017" TextAlignment="MiddleLeft" Text="tableCell11" Name="tableCell11" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="58">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="IdlingReport.EventType" Ref="57" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="2.4375000000000013" TextAlignment="MiddleLeft" Text="tableCell12" Name="tableCell12" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="60">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="IdlingReport.GpsTimeStamp" FormatString="{0: MM/dd/yyyy hh:mm tt}" Ref="59" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="2.0208000000000017" TextAlignment="MiddleLeft" Text="tableCell13" Name="tableCell13" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="62">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="IdlingReport.DurationStr" Ref="61" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UseTextAlignment="false" />
                </Item3>
              </Cells>
            </Item1>
          </Rows>
        </Item1>
      </Controls>
    </Item6>
    <Item7 ControlType="PageFooterBand" HeightF="29" Name="pageFooterBand1" Ref="67">
      <Controls>
        <Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="313, 23" LocationFloat="387.25, 6" StyleName="PageInfo" Name="pageInfo2" Ref="66" />
      </Controls>
    </Item7>
    <Item8 ControlType="BottomMarginBand" Name="BottomMargin1" BackColor="0,194,194,194" Ref="68">
      <StylePriority UseBackColor="false" />
    </Item8>
  </Bands>
  <StyleSheet>
    <Item1 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="Title" Font="Times New Roman, 24pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="69" />
    <Item2 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="FieldCaption" Font="Times New Roman, 10pt, style=Bold" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="70" />
    <Item3 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="PageInfo" Font="Times New Roman, 8pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="71" />
    <Item4 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="DataField" Font="Times New Roman, 8pt" Padding="2,2,0,0,100" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="72" />
  </StyleSheet>
  <ObjectStorage>
    <Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;Vehicle_x0020_Idling_x0020_Report&gt;&lt;xs:schema id=&quot;Vehicle_x0020_Idling_x0020_Report&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;Vehicle_x0020_Idling_x0020_Report&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;IdlingReport&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;TotalPTOON&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TotalPTOOFF&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;GpsTimeStamp&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;IdleStartTime&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;IdleEndTime&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;grp&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TotalDuration&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EventType&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DurationStr&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;IdleDurationInMinStr&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;PTOOnInMinStr&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;PTOOffInMinStr&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Equipment_x0020_Number&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/Vehicle_x0020_Idling_x0020_Report&gt;" Type="System.Data.DataSet" Ref="73" />
  </ObjectStorage>
  <Extensions>
    <Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="74" />
  </Extensions>
</XtraReportsLayoutSerializer>', '8adafa47-4334-4b1e-a97b-792aca8cf598', '8b799cdc-1d57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('07f11ac1-d955-41c7-97f8-847596b5f191', N'ELD Edited eLog Data Report', 'e468d955-6924-11e3-a678-a0b3cc4a6a82', N'Displays changes made for eLog item', 1, NULL, 1, '91e29695-0d94-11e6-80f6-00155db47809', '91e29695-0d94-11e6-80f6-00155db47809', '2017-04-05 06:23:44.850', '2017-06-26 03:33:25.760', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" PaperKind="A4Rotated" Name="ELD Edited eLog Data Report" Margins="38, 19, 0, 0" DisplayName="ELD Edited eLog Data Report" ScriptsSource="private void tableCell18_BeforePrint(object sender, System.EventArgs e) {&#xD;&#xA;    if (((XRTableCell)sender).Text != null &amp;&amp; ((XRTableCell)sender).Text != &quot;&quot;)&#xD;&#xA;    {&#xD;&#xA;        ((XRTableCell)sender).Text = Convert.ToString((sender as XRTableCell).Text).Replace(&quot;&lt;br&gt;&quot;, &quot;\r\n&quot;);&#xD;&#xA;    }&#xD;&#xA;    &#xD;&#xA; string removeText = &quot;Edit Remark&quot;;&#xD;&#xA;    if (((XRTableCell)sender).Text != null &amp;&amp; ((XRTableCell)sender).Text.IndexOf(removeText) &gt; -1)&#xD;&#xA;    {&#xD;&#xA;        ((XRTableCell)sender).Text = Convert.ToString((sender as XRTableCell).Text.Remove(1, ((XRTableCell)sender).Text.IndexOf(removeText) - 1));&#xD;&#xA;    }&#xD;&#xA;}&#xD;&#xA;&#xD;&#xA;private void tableCell17_BeforePrint(object sender, System.EventArgs e) {&#xD;&#xA;    if (((XRTableCell)sender).Text != null &amp;&amp; ((XRTableCell)sender).Text != &quot;&quot;)&#xD;&#xA; {&#xD;&#xA;  ((XRTableCell)sender).Text = Convert.ToString(&quot;Original Remark : &quot;) + Convert.ToString((sender as XRTableCell).Text);&#xD;&#xA; }&#xD;&#xA;}" PageWidth="1169" PageHeight="827" DataMember="ELDEditeLogDataReport" DataSource="#Ref-72">
  <Watermark Font="Times New Roman, 9pt" />
  <Bands>
    <Item1 ControlType="TopMarginBand" HeightF="0" Name="TopMargin1" Ref="0" />
    <Item2 ControlType="ReportHeaderBand" HeightF="132.29" Name="reportHeaderBand1" Padding="2,0,0,0,100" Ref="7">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="637.5, 53.13" LocationFloat="232.29, 14.58" TextAlignment="TopCenter" Text="Edited eLog Data Report" StyleName="Title" Name="label11" Font="Arial Black, 25pt, style=Bold" Ref="1">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRPageInfo" TextAlignment="MiddleRight" Format="{0: &quot;at &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="133, 22.92" LocationFloat="967.25, 79.19" StyleName="PageInfo" Name="pageInfo1" Font="Times New Roman, 9pt" Ref="2">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="361.46, 22.92" LocationFloat="605.73, 79.19" TextAlignment="MiddleRight" Text="label12" Name="label12" Padding="2,0,0,0,100" Ref="4">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Created by: {0}" Ref="3" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="493.75, 22.92" LocationFloat="606.25, 102.09" TextAlignment="TopRight" Text="label13" Name="label13" Padding="2,0,0,0,100" Ref="6">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.DateRange" FormatString="Date Range: {0}" Ref="5" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item4>
      </Controls>
    </Item2>
    <Item3 ControlType="GroupHeaderBand" Level="1" HeightF="39.58" Name="groupHeaderBand1" Ref="14">
      <GroupFields>
        <Item1 FieldName="EmployeeName" Ref="8" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="104.17, 25" LocationFloat="5.73, 11.46" TextAlignment="MiddleLeft" Text="Employee Name:" StyleName="FieldCaption" Name="label1" Ref="9">
          <StylePriority UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLabel" SizeF="197.92, 25" LocationFloat="902.08, 10.42" TextAlignment="MiddleRight" Text="total" Name="label14" Padding="2,2,0,0,100" Font="Times New Roman, 10pt, style=Bold" Ref="10">
          <Summary FormatString="Total: {0} records" Running="Group" Func="Count" />
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLine" SizeF="1094.79, 2.08" LocationFloat="5.21, 37.5" Name="line1" BorderColor="255,89,89,89" Ref="11">
          <StylePriority UseBorderColor="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="279.17, 25" LocationFloat="110.42, 12.5" TextAlignment="MiddleLeft" Text="label2" NullValueText="Employee #:" Name="label2" Padding="2,2,0,0,100" Font="Times New Roman, 9pt, style=Bold" Ref="13">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="ELDEditeLogDataReport.EmployeeNameToGroup" Ref="12" />
          </DataBindings>
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item4>
      </Controls>
    </Item3>
    <Item4 ControlType="GroupHeaderBand" StyleName="FieldCaption" HeightF="29.17" Name="groupHeaderBand2" Ref="25">
      <Controls>
        <Item1 ControlType="XRTable" Font="Times New Roman, 9pt, style=Bold" SizeF="1082.5, 25" LocationFloat="17.71, 4.17" Name="table1" BackColor="0,0,0,0" BorderColor="DarkGray" Borders="All" Ref="24">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow1" Ref="23">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.6412750292064797" TextAlignment="MiddleLeft" Text="Activite" Name="tableCell1" BackColor="255,194,194,194" BorderColor="DarkGray" Padding="5,0,0,0,100" Borders="All" Ref="15">
                  <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.6402618802737883" TextAlignment="MiddleLeft" Text="Start Time" Name="tableCell4" BackColor="255,194,194,194" Padding="5,0,0,0,100" Ref="16">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.554819653616801" TextAlignment="MiddleLeft" Text="Duration" Name="tableCell5" BackColor="255,194,194,194" Padding="5,0,0,0,100" Ref="17">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.3618389045326963" TextAlignment="MiddleLeft" Text="Distance" Name="tableCell13" BackColor="255,194,194,194" Padding="5,2,0,0,100" Ref="18">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="0.9649037454205235" TextAlignment="MiddleLeft" Text="Lacation" Name="tableCell14" BackColor="255,194,194,194" Padding="5,2,0,0,100" Ref="19">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item5>
                <Item6 ControlType="XRTableCell" Weight="0.6754326217943665" TextAlignment="MiddleLeft" Text="Edited By" Name="tableCell19" BackColor="255,194,194,194" Padding="5,2,0,0,100" Ref="20">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item6>
                <Item7 ControlType="XRTableCell" Weight="0.6706081030672638" TextAlignment="MiddleLeft" Text="Edit Time" Name="tableCell22" BackColor="255,194,194,194" Padding="5,2,0,0,100" Ref="21">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item7>
                <Item8 ControlType="XRTableCell" Weight="0.7134015841766641" TextAlignment="MiddleLeft" Text="Edit Reason" Name="tableCell23" BackColor="255,194,194,194" Padding="5,2,0,0,100" Ref="22">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item8>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UseFont="false" />
        </Item1>
      </Controls>
    </Item4>
    <Item5 ControlType="DetailBand" StyleName="DataField" HeightF="33.34" Name="detailBand1" Ref="63">
      <Controls>
        <Item1 ControlType="XRTable" Font="Times New Roman, 9pt" SizeF="1082.5, 33.34" LocationFloat="17.78, 0" EvenStyleName="xrControlStyle1" Name="table2" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="62">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1.0081079024263615" Name="tableRow2" Ref="44">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.6538192090922881" Text="tableCell2" Name="tableCell2" Borders="Left, Right" Ref="27">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="ELDEditeLogDataReport.Activity" Ref="26" />
                  </DataBindings>
                  <StylePriority UseBorders="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.6538192090922881" TextAlignment="TopLeft" Name="tableCell8" BorderColor="DarkGray" Padding="5,0,0,0,100" Borders="Left, Right" Font="Times New Roman, 9pt" Ref="29">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="ELDEditeLogDataReport.StartTime" FormatString="{0:g}" Ref="28" />
                  </DataBindings>
                  <Summary FormatString="dd/MM/yyyy hh:mm:ss" />
                  <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.566567772177026" Text="tableCell27" Name="tableCell27" Borders="Left, Right" Ref="31">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="ELDEditeLogDataReport.DDuration" Ref="30" />
                  </DataBindings>
                  <StylePriority UseBorders="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.369500720985017" Text="tableCell26" Name="tableCell26" Borders="Left, Right" Ref="33">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="ELDEditeLogDataReport.DDistance" Ref="32" />
                  </DataBindings>
                  <StylePriority UseBorders="false" />
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="0.984300653941287" Text="tableCell25" Name="tableCell25" Borders="Left, Right" Ref="35">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="ELDEditeLogDataReport.Location" Ref="34" />
                  </DataBindings>
                  <StylePriority UseBorders="false" />
                </Item5>
                <Item6 ControlType="XRTableCell" Weight="0.6897346791720317" TextAlignment="TopLeft" Name="tableCell7" BorderColor="DarkGray" Padding="5,0,0,0,100" Borders="Left, Right" Font="Times New Roman, 9pt" Ref="38">
                  <Scripts OnBeforePrint="tableCell7_BeforePrint" />
                  <Controls>
                    <Item1 ControlType="XRLabel" SizeF="145.83, 22.92" LocationFloat="0, 0" Text="label4" Name="label4" Padding="2,2,0,0,100" Borders="Right" Ref="37">
                      <DataBindings>
                        <Item1 PropertyName="Text" DataMember="ELDEditeLogDataReport.EditedBy" Ref="36" />
                      </DataBindings>
                      <StylePriority UseBorders="false" />
                    </Item1>
                  </Controls>
                  <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item6>
                <Item7 ControlType="XRTableCell" Weight="0.6872713410321315" TextAlignment="TopLeft" Text="tableCell15" Name="tableCell15" Borders="Left, Right" Ref="40">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="ELDEditeLogDataReport.EditTime" Ref="39" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseTextAlignment="false" />
                </Item7>
                <Item8 ControlType="XRTableCell" Weight="0.7281134873916754" Multiline="true" Name="tableCell3" Borders="Right" Ref="43">
                  <Controls>
                    <Item1 ControlType="XRLabel" SizeF="134.38, 22.92" LocationFloat="0, 0" Text="label3" Multiline="true" Name="label3" Padding="2,2,0,0,100" Borders="None" Ref="42">
                      <DataBindings>
                        <Item1 PropertyName="Text" DataMember="ELDEditeLogDataReport.DEditReason" Ref="41" />
                      </DataBindings>
                      <StylePriority UseBorders="false" />
                    </Item1>
                  </Controls>
                  <StylePriority UseBorders="false" />
                </Item8>
              </Cells>
            </Item1>
            <Item2 ControlType="XRTableRow" Weight="1.0081079024263615" Name="tableRow3" Ref="61">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.3661179829064947" Name="tableCell9" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="46">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="ELDEditeLogDataReport.HActivity" Ref="45" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.36844271724500455" Text="tableCell10" Name="tableCell10" Borders="Left, Right, Bottom" Ref="48">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="ELDEditeLogDataReport.HStartTime" Ref="47" />
                  </DataBindings>
                  <StylePriority UseBorders="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.3182672011055023" Text="tableCell29" Name="tableCell29" Ref="50">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="ELDEditeLogDataReport.HDuration" Ref="49" />
                  </DataBindings>
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.20756556593837108" Text="tableCell11" Name="tableCell11" Borders="Left, Right, Bottom" Ref="52">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="ELDEditeLogDataReport.HDistance" Ref="51" />
                  </DataBindings>
                  <StylePriority UseBorders="false" />
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="0.5535081758356563" Text="City" Name="tableCell12" Borders="Left, Right, Bottom" Ref="54">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="ELDEditeLogDataReport.HLocation" Ref="53" />
                  </DataBindings>
                  <StylePriority UseBorders="false" />
                </Item5>
                <Item6 ControlType="XRTableCell" Weight="0.3874557230849593" TextAlignment="TopLeft" Text="tableCell16" Name="tableCell16" Ref="56">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="ELDEditeLogDataReport.HEditedBy" Ref="55" />
                  </DataBindings>
                  <StylePriority UseTextAlignment="false" />
                </Item6>
                <Item7 ControlType="XRTableCell" Weight="0.3854907690607427" TextAlignment="TopLeft" Text="tableCell30" Name="tableCell30" Ref="58">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="ELDEditeLogDataReport.HEditTIme" Ref="57" />
                  </DataBindings>
                  <StylePriority UseTextAlignment="false" />
                </Item7>
                <Item8 ControlType="XRTableCell" Weight="0.40901486653375824" Multiline="true" Name="tableCell18" Borders="Left, Right, Bottom" Ref="60">
                  <Scripts OnBeforePrint="tableCell18_BeforePrint" />
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="ELDEditeLogDataReport.HEditReason" Ref="59" />
                  </DataBindings>
                  <StylePriority UseBorders="false" />
                </Item8>
              </Cells>
            </Item2>
          </Rows>
          <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" />
        </Item1>
      </Controls>
    </Item5>
    <Item6 ControlType="PageFooterBand" HeightF="47.17" Name="pageFooterBand1" Padding="5,2,0,0,100" Ref="65">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="313, 23" LocationFloat="787.5, 12.24" StyleName="PageInfo" Name="pageInfo2" Font="Times New Roman, 9pt" Ref="64">
          <StylePriority UseFont="false" />
        </Item1>
      </Controls>
    </Item6>
    <Item7 ControlType="BottomMarginBand" HeightF="0" Name="BottomMargin1" Ref="66" />
  </Bands>
  <StyleSheet>
    <Item1 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="Title" Font="Times New Roman, 24pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="67" />
    <Item2 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="FieldCaption" Font="Times New Roman, 10pt, style=Bold" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="68" />
    <Item3 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="PageInfo" Font="Times New Roman, 8pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="69" />
    <Item4 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="DataField" Font="Times New Roman, 8pt" Padding="2,2,0,0,100" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="70" />
    <Item5 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="xrControlStyle1" Font="Times New Roman, 9pt" BackColor="0,245,245,245" BorderColor="DarkGray" Sides="None" Ref="71" />
  </StyleSheet>
  <ObjectStorage>
    <Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;ELD_x0020_Edited_x0020_eLog_x0020_Data_x0020_Report&gt;&lt;xs:schema id=&quot;ELD_x0020_Edited_x0020_eLog_x0020_Data_x0020_Report&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;ELD_x0020_Edited_x0020_eLog_x0020_Data_x0020_Report&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;ELDEditeLogDataReport&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;StartTime&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DDistance&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DDuration&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;HDuration&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Location&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;HLocation&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EditedBy&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;HEditedBy&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EditTime&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;HEditTIme&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DEditReason&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;HEditReason&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;HDistance&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;HStartTime&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EmployeeNameToGroup&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EmployeeName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EmployeeNumber&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Activity&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;HActivity&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/ELD_x0020_Edited_x0020_eLog_x0020_Data_x0020_Report&gt;" Type="System.Data.DataSet" Ref="72" />
  </ObjectStorage>
  <Extensions>
    <Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="73" />
  </Extensions>
</XtraReportsLayoutSerializer>', 'f46d7d51-89f8-42be-b721-98f438e3081e', '59c4bfb5-1d57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('3fb0be74-e7cf-484c-ac45-8b75ffffc02c', N'TMS Efficiency Report', 'be7768b5-6924-11e3-a678-a0b3cc4a6a82', N'TMS Efficiency Report', 0, NULL, 1, 'f85a4b2f-ed82-4436-8943-96548b2f0af5', '91e29695-0d94-11e6-80f6-00155db47809', '2016-08-23 02:00:21.870', '2016-09-01 01:48:02.157', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" Name="TMS Efficiency Report" Margins="63, 100, 98, 100" DisplayName="TMS Efficiency Report" PageWidth="850" PageHeight="1100" DataMember="TMS Efficiency" DataSource="#Ref-70">
  <Watermark Font="Times New Roman, 9pt" />
  <Bands>
    <Item1 ControlType="TopMarginBand" HeightF="98" Name="TopMargin1" Padding="0,5,0,0,100" Ref="0">
      <StylePriority UsePadding="false" />
    </Item1>
    <Item2 ControlType="ReportHeaderBand" HeightF="136.88" Name="reportHeaderBand1" Padding="2,0,0,0,100" Ref="7">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="638, 39" LocationFloat="6, 29.17" TextAlignment="TopCenter" Text="TMS Driver Efficiency Report" StyleName="Title" Name="label11" Font="Arial Black, 25pt, style=Bold" Ref="1">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRPageInfo" TextAlignment="MiddleRight" Format="{0: &quot;at &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="133, 22.92" LocationFloat="511, 79.17" StyleName="PageInfo" Name="pageInfo1" Font="Times New Roman, 9pt" Ref="2">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="361.46, 22.92" LocationFloat="150, 79.17" TextAlignment="MiddleRight" Text="label12" Name="label12" Padding="2,0,0,0,100" Ref="4">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Created by: {0}" Ref="3" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="493.75, 22.92" LocationFloat="150, 102.08" TextAlignment="TopRight" Text="label13" Name="label13" Padding="2,0,0,0,100" Ref="6">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.DateRange" FormatString="Date Range: {0}" Ref="5" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item4>
      </Controls>
    </Item2>
    <Item3 ControlType="GroupHeaderBand" Level="2" HeightF="35.83" Name="groupHeaderBand1" Ref="12">
      <GroupFields>
        <Item1 FieldName="ScheduledTime" Ref="8" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="232.29, 25" LocationFloat="0, 6.25" TextAlignment="MiddleLeft" StyleName="DataField" Name="label2" Font="Times New Roman, 11pt, style=Bold" Ref="10">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="TMS Efficiency.ScheduledTime" FormatString="{0:dddd MM/dd/yyyy}" Ref="9" />
          </DataBindings>
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLine" ForeColor="255,82,82,82" SizeF="680, 2.08" LocationFloat="4.17, 31.25" Name="line1" Ref="11">
          <StylePriority UseForeColor="false" />
        </Item2>
      </Controls>
    </Item3>
    <Item4 ControlType="GroupHeaderBand" Level="1" HeightF="27.08" Name="groupHeaderBand2" Ref="27">
      <GroupFields>
        <Item1 FieldName="Driver" Ref="13" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="120.83, 25" LocationFloat="5.21, 0" TextAlignment="MiddleLeft" StyleName="DataField" Name="label4" Font="Times New Roman, 10pt, style=Bold" Ref="15">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="TMS Efficiency.Driver" Ref="14" />
          </DataBindings>
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLine" ForeColor="255,82,82,82" SizeF="680, 2.08" LocationFloat="4.17, 25" Name="line2" Ref="16">
          <StylePriority UseForeColor="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="175, 22.92" LocationFloat="221.88, 0" TextAlignment="MiddleRight" Multiline="true" Name="label1" Padding="2,2,0,0,100" Font="Times New Roman, 9pt, style=Bold" Ref="18">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="TMS Efficiency.Totaldrivendistance" FormatString="Total Driven Distance: {0}" Ref="17" />
          </DataBindings>
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="161.46, 25" LocationFloat="403.13, 0" TextAlignment="MiddleRight" Text="label3" Multiline="true" Name="label3" Padding="2,2,0,0,100" Font="Times New Roman, 9pt, style=Bold" Ref="20">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="TMS Efficiency.Totalduration" FormatString="Total Duration: {0}" Ref="19" />
          </DataBindings>
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item4>
        <Item5 ControlType="XRLabel" SizeF="47.4, 25" LocationFloat="571.88, 0" TextAlignment="MiddleRight" Text="label5" Multiline="true" Name="label5" Padding="2,2,0,0,100" Font="Times New Roman, 9pt, style=Bold" Ref="22">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="TMS Efficiency.Effiency" FormatString="{0}Hr" Ref="21" />
          </DataBindings>
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item5>
        <Item6 ControlType="XRLabel" SizeF="63.54, 25" LocationFloat="618.75, 0" TextAlignment="MiddleLeft" Text="label5" Multiline="true" Name="label6" Padding="2,2,0,0,100" Font="Times New Roman, 9pt, style=Bold" Ref="24">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="TMS Efficiency.DailyHours" FormatString="/  {0}Hr" Ref="23" />
          </DataBindings>
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item6>
        <Item7 ControlType="XRLabel" SizeF="87.5, 23.96" LocationFloat="129.17, 0" TextAlignment="MiddleLeft" Text="999.99%" StyleName="DataField" Name="label7" Font="Times New Roman, 10pt, style=Bold" Ref="26">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="TMS Efficiency.TimePercent" FormatString="{0}%" Ref="25" />
          </DataBindings>
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item7>
      </Controls>
    </Item4>
    <Item5 ControlType="GroupHeaderBand" StyleName="FieldCaption" HeightF="39.38" Name="groupHeaderBand3" Padding="0,5,0,0,100" Ref="39">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRTable" SizeF="683, 34.38" LocationFloat="3.65, 5" Name="table1" BorderColor="DarkGray" Borders="All" Ref="38">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="0.9822857142857143" Name="tableRow1" Ref="37">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.25612920922103566" TextAlignment="MiddleCenter" Text="Order #" Name="tableCell1" BackColor="255,194,194,194" Font="Times New Roman, 9pt, style=Bold" Ref="28">
                  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.4002018894078682" TextAlignment="MiddleCenter" Text="Customer" Name="tableCell2" BackColor="255,194,194,194" Font="Times New Roman, 9pt, style=Bold" Ref="29">
                  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.4002018894078682" TextAlignment="MiddleCenter" Text="Description" Name="tableCell3" BackColor="255,194,194,194" Font="Times New Roman, 9pt, style=Bold" Ref="30">
                  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.37352176344734367" TextAlignment="MiddleCenter" Text="Status" Name="tableCell4" BackColor="255,194,194,194" Font="Times New Roman, 9pt, style=Bold" Ref="31">
                  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="0.4535621413289173" TextAlignment="MiddleCenter" Text="Scheduled Pickup" Name="tableCell6" BackColor="255,194,194,194" Font="Times New Roman, 9pt, style=Bold" Ref="32">
                  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
                </Item5>
                <Item6 ControlType="XRTableCell" Weight="0.45356214132891737" TextAlignment="MiddleCenter" Text="Out For Pickup" Name="tableCell13" BackColor="255,194,194,194" Font="Times New Roman, 9pt, style=Bold" Ref="33">
                  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
                </Item6>
                <Item7 ControlType="XRTableCell" Weight="0.4535621413289173" TextAlignment="MiddleCenter" Text="Delivery Complete" Name="tableCell17" BackColor="255,194,194,194" Font="Times New Roman, 9pt, style=Bold" Ref="34">
                  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
                </Item7>
                <Item8 ControlType="XRTableCell" Weight="0.40020188940786827" TextAlignment="MiddleCenter" Text="Duration" Name="tableCell18" BackColor="255,194,194,194" Font="Times New Roman, 9pt, style=Bold" Ref="35">
                  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
                </Item8>
                <Item9 ControlType="XRTableCell" Weight="0.4535621413289173" TextAlignment="MiddleCenter" Text="Driven (mi)" Name="tableCell5" BackColor="255,194,194,194" Font="Times New Roman, 9pt, style=Bold" Ref="36">
                  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
                </Item9>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item5>
    <Item6 ControlType="DetailBand" StyleName="DataField" HeightF="60" Name="detailBand1" Ref="60">
      <Controls>
        <Item1 ControlType="XRTable" SizeF="682.5, 59.38" LocationFloat="4.17, 0" EvenStyleName="xrControlStyle1" Name="table2" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="59">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1.1401689708141323" Name="tableRow2" Ref="58">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.22573328479591465" TextAlignment="MiddleCenter" Multiline="true" Name="tableCell7" Padding="5,0,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="41">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMS Efficiency.Order" Ref="40" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.3527082574936166" TextAlignment="MiddleCenter" Multiline="true" Name="tableCell8" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="43">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMS Efficiency.Customer" Ref="42" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.3527082574936166" TextAlignment="MiddleCenter" Multiline="true" Name="tableCell9" Borders="Left,Right,Bottom" Font="Times New Roman, 9pt" Ref="45">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMS Efficiency.Description" Ref="44" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.32919437366070886" TextAlignment="MiddleCenter" Multiline="true" Name="tableCell10" Borders="Left,Right,Bottom" Font="Times New Roman, 9pt" Ref="47">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMS Efficiency.Status" Ref="46" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="0.3997360251594322" TextAlignment="MiddleCenter" Text="tableCell12" Multiline="true" Name="tableCell12" Font="Times New Roman, 9pt" Ref="49">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMS Efficiency.ScheduledPickup" FormatString="{0:MM/dd/yyyy hh:mm tt}" Ref="48" />
                  </DataBindings>
                  <StylePriority UseFont="false" UseTextAlignment="false" />
                </Item5>
                <Item6 ControlType="XRTableCell" Weight="0.3997360251594321" TextAlignment="MiddleCenter" Text="tableCell14" Multiline="true" Name="tableCell14" Ref="51">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMS Efficiency.OutForPickup" FormatString="{0:MM/dd/yyyy hh:mm tt}" Ref="50" />
                  </DataBindings>
                  <StylePriority UseTextAlignment="false" />
                </Item6>
                <Item7 ControlType="XRTableCell" Weight="0.3997360251594322" TextAlignment="MiddleCenter" Text="tableCell15" Multiline="true" Name="tableCell15" Borders="Left, Right, Bottom" Ref="53">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMS Efficiency.DeliveryComplete" FormatString="{0:MM/dd/yyyy hh:mm tt}" Ref="52" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseTextAlignment="false" />
                </Item7>
                <Item8 ControlType="XRTableCell" Weight="0.3527082574936166" TextAlignment="MiddleCenter" Text="tableCell16" Multiline="true" Name="tableCell16" Borders="Left, Right, Bottom" Ref="55">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMS Efficiency.Duration" Ref="54" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseTextAlignment="false" />
                </Item8>
                <Item9 ControlType="XRTableCell" Weight="0.39738463677614133" TextAlignment="MiddleCenter" Multiline="true" Name="tableCell11" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="57">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMS Efficiency.Driven" Ref="56" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item9>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item6>
    <Item7 ControlType="GroupFooterBand" HeightF="24.38" Name="GroupFooter1" Ref="61" />
    <Item8 ControlType="PageFooterBand" HeightF="48.96" Name="pageFooterBand1" Ref="63">
      <Controls>
        <Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="313, 23" LocationFloat="331, 6" StyleName="PageInfo" Name="pageInfo2" Padding="0,5,0,0,100" Font="Times New Roman, 9pt" Ref="62">
          <StylePriority UseFont="false" UsePadding="false" />
        </Item1>
      </Controls>
    </Item8>
    <Item9 ControlType="BottomMarginBand" Name="BottomMargin1" Padding="0,10,0,0,100" Ref="64">
      <StylePriority UsePadding="false" />
    </Item9>
  </Bands>
  <StyleSheet>
    <Item1 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="Title" Font="Times New Roman, 24pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="65" />
    <Item2 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="FieldCaption" Font="Times New Roman, 10pt, style=Bold" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="66" />
    <Item3 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="PageInfo" Font="Times New Roman, 8pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="67" />
    <Item4 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="DataField" Font="Times New Roman, 8pt" Padding="2,2,0,0,100" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="68" />
    <Item5 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="xrControlStyle1" Font="Times New Roman, 9pt" BackColor="WhiteSmoke" BorderColor="DarkGray" Sides="None" BorderWidthSerializable="1" Ref="69" />
  </StyleSheet>
  <ObjectStorage>
    <Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;TMS_x0020_Efficiency_x0020_Report&gt;&lt;xs:schema id=&quot;TMS_x0020_Efficiency_x0020_Report&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;TMS_x0020_Efficiency_x0020_Report&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;TMS_x0020_Efficiency&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;ScheduledTime&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Driver&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Driven&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Totaldrivendistance&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Duration&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Totalduration&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Effiency&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DailyHours&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimePercent&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Order&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Customer&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Description&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Status&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;ScheduledPickup&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;OutForPickup&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DeliveryComplete&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/TMS_x0020_Efficiency_x0020_Report&gt;" Type="System.Data.DataSet" Ref="70" />
  </ObjectStorage>
  <Extensions>
    <Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="71" />
  </Extensions>
</XtraReportsLayoutSerializer>', 'a01cda1f-782d-4478-98db-c3e825491081', 'c7aed3f5-1c57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('dabc3794-6c17-4c0a-a078-a213e4525695', N'Drivers Report', 'be7768b5-6924-11e3-a678-a0b3cc4a6a82', N'User can generate a Drivers Report.', 1, NULL, 1, '91e29695-0d94-11e6-80f6-00155db47809', '91e29695-0d94-11e6-80f6-00155db47809', '2017-02-28 17:32:10.200', '2017-02-28 10:13:11.267', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" Name="Drivers Report" Margins="99, 105, 61, 100" DisplayName="Drivers Report" PageWidth="850" PageHeight="1100" DataMember="DriversReport" DataSource="#Ref-35">
  <Bands>
    <Item1 ControlType="TopMarginBand" HeightF="61" Name="TopMargin1" Ref="0" />
    <Item2 ControlType="ReportHeaderBand" HeightF="102.1" Name="reportHeaderBand1" Padding="2,0,0,0,100" Ref="6">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="298.96, 44.79" LocationFloat="195.83, 29.17" TextAlignment="TopLeft" Text="Drivers Report" StyleName="Title" Name="label11" Font="Arial Black, 25pt, style=Bold" Ref="1">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLabel" SizeF="323.96, 16.67" LocationFloat="143.22, 83.34" TextAlignment="MiddleRight" Text="label12" Name="label12" Padding="2,0,0,0,100" Ref="3">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Created by: {0}" Ref="2" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRPageInfo" TextAlignment="MiddleRight" Format="{0: &quot;at &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="133.33, 16.67" LocationFloat="467.19, 85.43" StyleName="PageInfo" Name="pageInfo1" Font="Times New Roman, 9pt" Ref="4">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item3>
      </Controls>
      <SubBands>
        <Item1 ControlType="SubBand" HeightF="0" Name="SubBand1" Ref="5" />
      </SubBands>
    </Item2>
    <Item3 ControlType="PageHeaderBand" HeightF="0" Name="PageHeader1" Ref="7" />
    <Item4 ControlType="GroupHeaderBand" Level="3" HeightF="58.85" Name="GroupHeader2" Ref="11">
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="182.33, 25" LocationFloat="37.26, 31.77" TextAlignment="MiddleLeft" Text="label14" Name="label14" Padding="2,2,0,0,100" Font="Times New Roman, 10pt, style=Bold" Ref="9">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="DriversReport.EmployeeName" Ref="8" />
          </DataBindings>
          <Summary FormatString="Total: {0} records" Running="Group" Func="Count" />
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLine" SizeF="565, 2.08" LocationFloat="36.98, 56.77" Name="line1" BorderColor="255,89,89,89" Ref="10">
          <StylePriority UseBorderColor="false" />
        </Item2>
      </Controls>
    </Item4>
    <Item5 ControlType="GroupHeaderBand" Level="2" HeightF="36.44" Name="GroupHeader1" Ref="16">
      <Controls>
        <Item1 ControlType="XRTable" SizeF="565, 25" LocationFloat="37.5, 11.44" Name="table1" BackColor="0,0,0,0" BorderColor="DarkGray" Borders="All" Ref="15">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow1" Ref="14">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="1.4400058036112326" TextAlignment="MiddleLeft" Text="Driver Name" Name="tableCell1" BackColor="255,194,194,194" BorderColor="DarkGray" Padding="5,0,0,0,100" Borders="All" Ref="12">
                  <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="1.2720051265232557" TextAlignment="MiddleLeft" Text="Driver Id" Name="tableCell4" BackColor="255,194,194,194" Padding="5,0,0,0,100" Ref="13">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item2>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item5>
    <Item6 ControlType="GroupHeaderBand" Level="1" HeightF="0" Name="groupHeaderBand1" Ref="18">
      <GroupFields>
        <Item1 FieldName="EmployeeName" Ref="17" />
      </GroupFields>
    </Item6>
    <Item7 ControlType="GroupHeaderBand" StyleName="FieldCaption" HeightF="0" Name="groupHeaderBand2" Ref="19" />
    <Item8 ControlType="DetailBand" StyleName="DataField" HeightF="25" Name="detailBand1" Ref="26">
      <Controls>
        <Item1 ControlType="XRTable" SizeF="565, 25" LocationFloat="37.5, 0" EvenStyleName="xrControlStyle1" Name="table2" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="25">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow2" Ref="24">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="1.4407217777046064" TextAlignment="MiddleLeft" Name="tableCell3" BorderColor="DarkGray" Padding="5,0,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="21">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DriversReport.EmployeeName" FormatString="{0: MM/dd/yyyy hh:mm tt}" Ref="20" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="1.2726375703057358" TextAlignment="MiddleLeft" Name="tableCell8" BorderColor="DarkGray" Padding="5,0,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="23">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DriversReport.Number" Ref="22" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item2>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item8>
    <Item9 ControlType="PageFooterBand" HeightF="29" Name="pageFooterBand1" Padding="5,2,0,0,100" Ref="28">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="206.77, 22.92" LocationFloat="395, 5.73" StyleName="PageInfo" Name="pageInfo2" Font="Times New Roman, 9pt" Ref="27">
          <StylePriority UseFont="false" />
        </Item1>
      </Controls>
    </Item9>
    <Item10 ControlType="BottomMarginBand" Name="BottomMargin1" Ref="29" />
  </Bands>
  <StyleSheet>
    <Item1 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="Title" Font="Times New Roman, 24pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="30" />
    <Item2 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="FieldCaption" Font="Times New Roman, 10pt, style=Bold" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="31" />
    <Item3 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="PageInfo" Font="Times New Roman, 8pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="32" />
    <Item4 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="DataField" Font="Times New Roman, 8pt" Padding="2,2,0,0,100" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="33" />
    <Item5 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="xrControlStyle1" Font="Times New Roman, 9pt" BackColor="0,245,245,245" BorderColor="DarkGray" Sides="None" Ref="34" />
  </StyleSheet>
  <ObjectStorage>
    <Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;Drivers_x0020_Report&gt;&lt;xs:schema id=&quot;Drivers_x0020_Report&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;Drivers_x0020_Report&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;DriversReport&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;EmployeeName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Number&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/Drivers_x0020_Report&gt;" Type="System.Data.DataSet" Ref="35" />
  </ObjectStorage>
  <Extensions>
    <Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="36" />
  </Extensions>
</XtraReportsLayoutSerializer>', '7c41f36f-d8d9-48c0-b689-857bd93cd611', 'c7aed3f5-1c57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('1c1ce2e3-eafd-4856-bf7b-aa705f7ee114', N'Current Odometer Report', 'd226c6d5-6924-11e3-a678-a0b3cc4a6a82', N'Current Odometer Report', 1, NULL, 1, 'f85a4b2f-ed82-4436-8943-96548b2f0af5', '91e29695-0d94-11e6-80f6-00155db47809', '2016-06-10 04:19:49.317', '2017-12-08 04:08:36.267', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" PaperKind="A4Rotated" Name="Current Odometer Report" Margins="38, 19, 0, 0" DisplayName="Current Odometer Report" PageWidth="1169" PageHeight="827" DataMember="CurrentOdometer" DataSource="#Ref-49">
  <Watermark Font="Times New Roman, 9pt" />
  <CalculatedFields>
    <Item1 Name="calculatedField1" DataMember="CurrentOdometer" Ref="0" DataSource="#Ref-48" />
  </CalculatedFields>
  <Bands>
    <Item1 ControlType="TopMarginBand" HeightF="0" Name="TopMargin1" Ref="1" />
    <Item2 ControlType="ReportHeaderBand" HeightF="132.29" Name="reportHeaderBand1" Padding="2,0,0,0,100" Ref="8">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="637.5, 53.13" LocationFloat="232.29, 14.58" TextAlignment="TopCenter" Text="Current Odometer Report" StyleName="Title" Name="label11" Font="Arial Black, 25pt, style=Bold" Ref="2">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRPageInfo" TextAlignment="MiddleRight" Format="{0: &quot;at &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="133, 22.92" LocationFloat="967.25, 79.19" StyleName="PageInfo" Name="pageInfo1" Font="Times New Roman, 9pt" Ref="3">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="361.46, 22.92" LocationFloat="605.73, 79.19" TextAlignment="MiddleRight" Text="label12" Name="label12" Padding="2,0,0,0,100" Ref="5">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Created by: {0}" Ref="4" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="493.75, 22.92" LocationFloat="606.25, 102.09" TextAlignment="TopRight" Text="label13" Name="label13" Padding="2,0,0,0,100" Ref="7">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.DateRange" FormatString="Date Range: {0}" Ref="6" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item4>
      </Controls>
    </Item2>
    <Item3 ControlType="GroupHeaderBand" Level="1" HeightF="39.58" Name="groupHeaderBand1" Ref="14">
      <GroupFields>
        <Item1 FieldName="EquipmentNumber" Ref="9" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="411.46, 25" LocationFloat="140.63, 12.5" TextAlignment="MiddleLeft" StyleName="DataField" Name="label2" Font="Times New Roman, 10pt, style=Bold" Ref="11">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="CurrentOdometer.EquipmentNumber" Ref="10" />
          </DataBindings>
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLabel" SizeF="135.42, 25" LocationFloat="5.21, 12.5" TextAlignment="MiddleLeft" Text="Equipment Number:" StyleName="FieldCaption" Name="label1" Ref="12">
          <StylePriority UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLine" SizeF="1094.79, 2.08" LocationFloat="5.21, 37.5" Name="line1" BorderColor="255,89,89,89" Ref="13">
          <StylePriority UseBorderColor="false" />
        </Item3>
      </Controls>
    </Item3>
    <Item4 ControlType="GroupHeaderBand" StyleName="FieldCaption" HeightF="29.17" Name="groupHeaderBand2" Ref="24">
      <Controls>
        <Item1 ControlType="XRTable" Font="Times New Roman, 9pt, style=Bold" SizeF="1082.29, 25" LocationFloat="17.71, 4.17" Name="table1" BackColor="0,0,0,0" BorderColor="DarkGray" Borders="All" Ref="23">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow1" Ref="22">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.6412750292064797" TextAlignment="MiddleCenter" Text="Equipment Make" Name="tableCell1" BackColor="255,194,194,194" BorderColor="DarkGray" Padding="5,0,0,0,100" Borders="All" Ref="15">
                  <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.6402618802737883" TextAlignment="MiddleCenter" Text="Equipment Model" Name="tableCell4" BackColor="255,194,194,194" Padding="5,0,0,0,100" Ref="16">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.7286953085415794" TextAlignment="MiddleCenter" Text="Equipment Type" Name="tableCell3" BackColor="255,194,194,194" BorderColor="DarkGray" Ref="17">
                  <StylePriority UseBackColor="false" UseBorderColor="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.6533363260242363" TextAlignment="MiddleCenter" Name="tableCell5" BackColor="255,194,194,194" Padding="5,0,0,0,100" Ref="19">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="UserInfo.MileOrKm" FormatString="Odometer in {0}" Ref="18" />
                  </DataBindings>
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="1.0553152263664267" TextAlignment="MiddleCenter" Text="Last GPS Time" Name="tableCell2" BackColor="255,194,194,194" Padding="5,0,0,0,100" Ref="20">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item5>
                <Item6 ControlType="XRTableCell" Weight="1.502644602743381" TextAlignment="MiddleCenter" Text="Last Location" Name="tableCell13" BackColor="255,194,194,194" Ref="21">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item6>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UseFont="false" />
        </Item1>
      </Controls>
    </Item4>
    <Item5 ControlType="DetailBand" StyleName="DataField" HeightF="16.67" Name="detailBand1" Ref="39">
      <Controls>
        <Item1 ControlType="XRTable" Font="Times New Roman, 9pt" SizeF="1082.3, 16.67" LocationFloat="17.78, 0" EvenStyleName="xrControlStyle1" Name="table2" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="38">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1.0081079024263615" Name="tableRow3" Ref="37">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.36728035007574966" TextAlignment="MiddleCenter" Name="tableCell9" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="26">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="CurrentOdometer.EquipmentMake" Ref="25" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.3678615336603771" TextAlignment="MiddleCenter" Text="tableCell10" Name="tableCell10" Borders="Left, Right, Bottom" Ref="28">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="CurrentOdometer.EquipmentModel" Ref="27" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.4180093743910875" TextAlignment="MiddleCenter" Text="tableCell6" Name="tableCell6" Ref="30">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="CurrentOdometer.EquipmentType" Ref="29" />
                  </DataBindings>
                  <StylePriority UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.3719021433439773" TextAlignment="MiddleCenter" Text="tableCell29" Name="tableCell29" Borders="Left, Right, Bottom" Ref="32">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="CurrentOdometer.Odometer" FormatString="{0} Mi" Ref="31" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseTextAlignment="false" />
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="0.6111283769401475" TextAlignment="MiddleCenter" Text="tableCell28" Name="tableCell28" Borders="Left, Right, Bottom" Ref="34">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="CurrentOdometer.GpsTimeStamp" Ref="33" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseTextAlignment="false" />
                </Item5>
                <Item6 ControlType="XRTableCell" Weight="0.8591277151233135" TextAlignment="MiddleCenter" Text="tableCell30" Name="tableCell30" Ref="36">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="CurrentOdometer.LastLocation" Ref="35" />
                  </DataBindings>
                  <StylePriority UseTextAlignment="false" />
                </Item6>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" />
        </Item1>
      </Controls>
    </Item5>
    <Item6 ControlType="PageFooterBand" HeightF="47.17" Name="pageFooterBand1" Ref="41">
      <Controls>
        <Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="313, 23" LocationFloat="787.5, 12.24" StyleName="PageInfo" Name="pageInfo2" Font="Times New Roman, 9pt" Ref="40">
          <StylePriority UseFont="false" />
        </Item1>
      </Controls>
    </Item6>
    <Item7 ControlType="BottomMarginBand" HeightF="0" Name="BottomMargin1" Ref="42" />
  </Bands>
  <StyleSheet>
    <Item1 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="Title" Font="Times New Roman, 24pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="43" />
    <Item2 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="FieldCaption" Font="Times New Roman, 10pt, style=Bold" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="44" />
    <Item3 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="PageInfo" Font="Times New Roman, 8pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="45" />
    <Item4 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="DataField" Font="Times New Roman, 8pt" Padding="2,2,0,0,100" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="46" />
    <Item5 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="xrControlStyle1" Font="Times New Roman, 9pt" BackColor="0,245,245,245" BorderColor="DarkGray" Sides="None" Ref="47" />
  </StyleSheet>
  <ObjectStorage>
    <Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;Current_x0020_Odometer_x0020_Report&gt;&lt;xs:schema id=&quot;Current_x0020_Odometer_x0020_Report&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;Current_x0020_Odometer_x0020_Report&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;CurrentOdometer&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;GpsTimeStamp&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Odometer&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;City&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;State&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;LastLocation&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EquipmentVIN&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EquipmentType&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EquipmentCategory&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Description&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EmployeeNumber&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;SerialNumber&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EquipmentNumber&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EquipmentMake&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EquipmentModel&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/Current_x0020_Odometer_x0020_Report&gt;" Type="System.Data.DataSet" Ref="48" />
    <Item2 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;Current_x0020_Odometer_x0020_Report&gt;&lt;xs:schema id=&quot;Current_x0020_Odometer_x0020_Report&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;Current_x0020_Odometer_x0020_Report&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;MileOrKm&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;CurrentOdometer&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;GpsTimeStamp&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Odometer&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;City&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;State&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;LastLocation&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EquipmentVIN&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EquipmentType&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EquipmentCategory&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Description&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EmployeeNumber&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;SerialNumber&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EquipmentNumber&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EquipmentMake&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EquipmentModel&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/Current_x0020_Odometer_x0020_Report&gt;" Type="System.Data.DataSet" Ref="49" />
  </ObjectStorage>
  <Extensions>
    <Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="50" />
  </Extensions>
</XtraReportsLayoutSerializer>', '7647a1c7-2b6c-4ecd-b8cc-1032a438cf69', '8b799cdc-1d57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('812664ab-d149-4831-9d37-abe5d110340b', N'TMS Loads Per Driver Report', 'be7768b5-6924-11e3-a678-a0b3cc4a6a82', N'TMS Loads Per Driver Report', 0, NULL, 1, 'f85a4b2f-ed82-4436-8943-96548b2f0af5', '9b63598e-019d-11e4-80c8-00155db47804', '2016-08-23 02:00:21.870', '2017-02-28 04:25:14.783', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
	<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" Name="TMS Loads Per Driver Report" Margins="63, 100, 98, 100" DisplayName="TMS Loads Per Driver Report" PageWidth="850" PageHeight="1100" DataMember="TMSLoadPerDriverReport" DataSource="#Ref-54">
	  <Bands>
		<Item1 ControlType="TopMarginBand" HeightF="98" Name="TopMargin1" Padding="0,5,0,0,100" Ref="0">
		  <StylePriority UsePadding="false" />
		</Item1>
		<Item2 ControlType="ReportHeaderBand" HeightF="136.88" Name="reportHeaderBand1" Padding="2,0,0,0,100" Ref="7">
		  <StylePriority UsePadding="false" />
		  <Controls>
			<Item1 ControlType="XRLabel" SizeF="638, 39" LocationFloat="6, 29.17" TextAlignment="TopCenter" Text="TMS Loads Per Driver Report" StyleName="Title" Name="label11" Font="Arial Black, 25pt, style=Bold" Ref="1">
			  <StylePriority UseFont="false" UseTextAlignment="false" />
			</Item1>
			<Item2 ControlType="XRPageInfo" TextAlignment="BottomRight" Format="{0: &quot;on &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="177.08, 20.83" LocationFloat="466.67, 103.13" StyleName="PageInfo" Name="pageInfo1" Font="Times New Roman, 9pt" Ref="2">
			  <StylePriority UseFont="false" UseTextAlignment="false" />
			</Item2>
			<Item3 ControlType="XRLabel" SizeF="317.71, 20.83" LocationFloat="196.88, 103.13" TextAlignment="BottomRight" Text="label12" Name="label12" Padding="2,0,0,0,100" Ref="4">
			  <DataBindings>
				<Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Generated by {0}" Ref="3" />
			  </DataBindings>
			  <StylePriority UsePadding="false" UseTextAlignment="false" />
			</Item3>
			<Item4 ControlType="XRLabel" SizeF="493.75, 22.92" LocationFloat="150, 78.13" TextAlignment="TopRight" Text="label13" Name="label13" Padding="2,0,0,0,100" Ref="6">
			  <DataBindings>
				<Item1 PropertyName="Text" DataMember="UserInfo.DateRange" FormatString="Date Range: {0}" Ref="5" />
			  </DataBindings>
			  <StylePriority UsePadding="false" UseTextAlignment="false" />
			</Item4>
		  </Controls>
		</Item2>
		<Item3 ControlType="GroupHeaderBand" Level="2" HeightF="3.13" Name="groupHeaderBand1" Ref="8" />
		<Item4 ControlType="GroupHeaderBand" Level="1" HeightF="34.38" Name="groupHeaderBand2" Ref="15">
		  <GroupFields>
			<Item1 FieldName="Driver" Ref="9" />
		  </GroupFields>
		  <Controls>
			<Item1 ControlType="XRLabel" SizeF="263.54, 25" LocationFloat="5.99, 2.07" TextAlignment="MiddleLeft" StyleName="DataField" Name="label2" Font="Times New Roman, 11pt, style=Bold" Ref="11">
			  <DataBindings>
				<Item1 PropertyName="Text" DataMember="TMSLoadPerDriverReport.Driver" FormatString="{0:dddd MM/dd/yyyy}" Ref="10" />
			  </DataBindings>
			  <StylePriority UseFont="false" UseTextAlignment="false" />
			</Item1>
			<Item2 ControlType="XRLabel" SizeF="290.63, 22.92" LocationFloat="353.38, 2.07" TextAlignment="MiddleRight" Text="label1" StyleName="DataField" Name="label1" Font="Times New Roman, 11pt, style=Bold" Ref="13">
			  <DataBindings>
				<Item1 PropertyName="Text" DataMember="TMSLoadPerDriverReport.TotalByDriver" FormatString="Total Load Count : {0}" Ref="12" />
			  </DataBindings>
			  <StylePriority UseFont="false" UseTextAlignment="false" />
			</Item2>
			<Item3 ControlType="XRLine" ForeColor="255,82,82,82" SizeF="638.54, 2.08" LocationFloat="5.21, 29.69" Name="line1" Ref="14">
			  <StylePriority UseForeColor="false" />
			</Item3>
		  </Controls>
		</Item4>
		<Item5 ControlType="GroupHeaderBand" StyleName="FieldCaption" HeightF="59.17" Name="groupHeaderBand3" Padding="0,5,0,0,100" Ref="29">
		  <GroupFields>
			<Item1 FieldName="Status" Ref="16" />
		  </GroupFields>
		  <StylePriority UsePadding="false" />
		  <Controls>
			<Item1 ControlType="XRTable" SizeF="614.17, 34.38" LocationFloat="30.73, 24.79" Name="table1" BorderColor="DarkGray" Borders="All" Ref="24">
			  <Rows>
				<Item1 ControlType="XRTableRow" Weight="0.9822857142857143" Name="tableRow1" Ref="23">
				  <Cells>
					<Item1 ControlType="XRTableCell" Weight="0.3468416374868192" TextAlignment="MiddleCenter" Text="Order #" Name="tableCell1" BackColor="255,194,194,194" Ref="17">
					  <StylePriority UseBackColor="false" UseTextAlignment="false" />
					</Item1>
					<Item2 ControlType="XRTableCell" Weight="0.5336025192104911" TextAlignment="MiddleCenter" Text="Customer" Name="tableCell2" BackColor="255,194,194,194" Ref="18">
					  <StylePriority UseBackColor="false" UseTextAlignment="false" />
					</Item2>
					<Item3 ControlType="XRTableCell" Weight="0.5336025192104911" TextAlignment="MiddleCenter" Text="Description" Name="tableCell3" BackColor="255,194,194,194" Ref="19">
					  <StylePriority UseBackColor="false" UseTextAlignment="false" />
					</Item3>
					<Item4 ControlType="XRTableCell" Weight="0.32016151152629463" TextAlignment="MiddleCenter" Text="Quantity" Name="tableCell4" BackColor="255,194,194,194" Ref="20">
					  <StylePriority UseBackColor="false" UseTextAlignment="false" />
					</Item4>
					<Item5 ControlType="XRTableCell" Weight="0.6892543740641915" TextAlignment="MiddleCenter" Text="Scheduled Delivery" Name="tableCell6" BackColor="255,194,194,194" Ref="21">
					  <StylePriority UseBackColor="false" UseTextAlignment="false" />
					</Item5>
					<Item6 ControlType="XRTableCell" Weight="0.8537640307367856" TextAlignment="MiddleCenter" Text="Actual Time" Name="tableCell13" BackColor="255,194,194,194" Ref="22">
					  <StylePriority UseBackColor="false" UseTextAlignment="false" />
					</Item6>
				  </Cells>
				</Item1>
			  </Rows>
			  <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" />
			</Item1>
			<Item2 ControlType="XRLabel" SizeF="131.25, 25" LocationFloat="30.99, 0" TextAlignment="MiddleLeft" StyleName="DataField" Name="label4" Font="Times New Roman, 10pt, style=Bold" Ref="26">
			  <DataBindings>
				<Item1 PropertyName="Text" DataMember="TMSLoadPerDriverReport.Status" Ref="25" />
			  </DataBindings>
			  <StylePriority UseFont="false" UseTextAlignment="false" />
			</Item2>
			<Item3 ControlType="XRLabel" SizeF="301.04, 25" LocationFloat="342.95, 0" TextAlignment="MiddleRight" Text="label3" Name="label3" Padding="2,2,0,0,100" Font="Times New Roman, 9pt, style=Bold" Ref="28">
			  <DataBindings>
				<Item1 PropertyName="Text" DataMember="TMSLoadPerDriverReport.TotalByDriverStatus" FormatString="{0}" Ref="27" />
			  </DataBindings>
			  <StylePriority UseFont="false" UseTextAlignment="false" />
			</Item3>
		  </Controls>
		</Item5>
		<Item6 ControlType="DetailBand" StyleName="DataField" HeightF="60" Name="detailBand1" Ref="44">
		  <Controls>
			<Item1 ControlType="XRTable" SizeF="614, 59.38" LocationFloat="31.25, 0" EvenStyleName="xrControlStyle1" Name="table2" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="43">
			  <Rows>
				<Item1 ControlType="XRTableRow" Weight="1.1401689708141323" Name="tableRow2" Ref="42">
				  <Cells>
					<Item1 ControlType="XRTableCell" Weight="0.30332910144451025" TextAlignment="MiddleLeft" Name="tableCell7" Padding="5,0,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="31">
					  <DataBindings>
						<Item1 PropertyName="Text" DataMember="TMSLoadPerDriverReport.OrderNumber" Ref="30" />
					  </DataBindings>
					  <StylePriority UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
					</Item1>
					<Item2 ControlType="XRTableCell" Weight="0.4702776766581555" TextAlignment="MiddleLeft" Name="tableCell8" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="33">
					  <DataBindings>
						<Item1 PropertyName="Text" DataMember="TMSLoadPerDriverReport.Customer" FormatString="{0}" Ref="32" />
					  </DataBindings>
					  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
					</Item2>
					<Item3 ControlType="XRTableCell" Weight="0.4702776766581554" TextAlignment="MiddleLeft" Name="tableCell9" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="35">
					  <DataBindings>
						<Item1 PropertyName="Text" DataMember="TMSLoadPerDriverReport.Description" FormatString="{0}" Ref="34" />
					  </DataBindings>
					  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
					</Item3>
					<Item4 ControlType="XRTableCell" Weight="0.28216660599489324" TextAlignment="MiddleLeft" Name="tableCell10" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="37">
					  <DataBindings>
						<Item1 PropertyName="Text" DataMember="TMSLoadPerDriverReport.Quantity" FormatString="{0}" Ref="36" />
					  </DataBindings>
					  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
					</Item4>
					<Item5 ControlType="XRTableCell" Weight="0.6113609796556021" TextAlignment="MiddleLeft" Text="tableCell12" Name="tableCell12" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="39">
					  <DataBindings>
						<Item1 PropertyName="Text" DataMember="TMSLoadPerDriverReport.ScheduledDelivery" FormatString="{0:MM/dd/yyyy hh:mm tt}" Ref="38" />
					  </DataBindings>
					  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
					</Item5>
					<Item6 ControlType="XRTableCell" Weight="0.7500928942697579" TextAlignment="MiddleLeft" Text="tableCell14" Name="tableCell14" Borders="Left, Right, Bottom" Ref="41">
					  <DataBindings>
						<Item1 PropertyName="Text" DataMember="TMSLoadPerDriverReport.DeliveryCompleteOn" FormatString="{0:MM/dd/yyyy hh:mm tt}" Ref="40" />
					  </DataBindings>
					  <StylePriority UseBorders="false" UseTextAlignment="false" />
					</Item6>
				  </Cells>
				</Item1>
			  </Rows>
			  <StylePriority UseBorderColor="false" UseBorders="false" />
			</Item1>
		  </Controls>
		</Item6>
		<Item7 ControlType="GroupFooterBand" HeightF="24.38" Name="GroupFooter1" Ref="45" />
		<Item8 ControlType="PageFooterBand" HeightF="48.96" Name="pageFooterBand1" Ref="47">
		  <Controls>
			<Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="313, 23" LocationFloat="331, 6" StyleName="PageInfo" Name="pageInfo2" Padding="0,5,0,0,100" Font="Times New Roman, 9pt" Ref="46">
			  <StylePriority UseFont="false" UsePadding="false" />
			</Item1>
		  </Controls>
		</Item8>
		<Item9 ControlType="BottomMarginBand" Name="BottomMargin1" Padding="0,10,0,0,100" Ref="48">
		  <StylePriority UsePadding="false" />
		</Item9>
	  </Bands>
	  <StyleSheet>
		<Item1 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="Title" Font="Times New Roman, 24pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="49" />
		<Item2 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="FieldCaption" Font="Times New Roman, 10pt, style=Bold" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="50" />
		<Item3 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="PageInfo" Font="Times New Roman, 8pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="51" />
		<Item4 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="DataField" Font="Times New Roman, 8pt" Padding="2,2,0,0,100" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="52" />
		<Item5 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="xrControlStyle1" Font="Times New Roman, 9pt" BackColor="WhiteSmoke" BorderColor="DarkGray" Sides="None" BorderWidthSerializable="1" Ref="53" />
	  </StyleSheet>
	  <ObjectStorage>
		<Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;TMS_x0020_Loads_x0020_Per_x0020_Driver_x0020_Report&gt;&lt;xs:schema id=&quot;TMS_x0020_Loads_x0020_Per_x0020_Driver_x0020_Report&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;TMS_x0020_Loads_x0020_Per_x0020_Driver_x0020_Report&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;TMSLoadPerDriverReport&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;ScheduledTime&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Driver&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Status&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;OrderNumber&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Customer&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Description&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Quantity&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;ScheduledDelivery&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DeliveryCompleteOn&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TotalByDriver&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TotalByDriverStatus&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/TMS_x0020_Loads_x0020_Per_x0020_Driver_x0020_Report&gt;" Type="System.Data.DataSet" Ref="54" />
	  </ObjectStorage>
	  <Extensions>
		<Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="55" />
	  </Extensions>
	</XtraReportsLayoutSerializer>', '97fa49db-7673-45d4-a179-b4a16fd2f758', 'c7aed3f5-1c57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('429af997-45d1-4954-b055-b7d4a024bc7b', N'Dispatch Log Report', 'd226c6d5-6924-11e3-a678-a0b3cc4a6a82', NULL, 1, NULL, 1, 'f85a4b2f-ed82-4436-8943-96548b2f0af5', 'f85a4b2f-ed82-4436-8943-96548b2f0af5', '2016-03-16 09:31:13.053', '2016-03-17 09:35:09.930', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" Name="Dispatch Log Report" Margins="98, 59, 98, 100" DisplayName="Dispatch Log Report" PageWidth="850" PageHeight="1100" DataMember="DispatchLogReport" DataSource="#Ref-60">
  <Bands>
    <Item1 ControlType="TopMarginBand" HeightF="98" Name="TopMargin1" Padding="0,5,0,0,100" Ref="0">
      <StylePriority UsePadding="false" />
    </Item1>
    <Item2 ControlType="ReportHeaderBand" HeightF="125" Name="reportHeaderBand1" Padding="2,0,0,0,100" Ref="7">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="638, 39" LocationFloat="6, 29.17" TextAlignment="TopCenter" Text="Dispatch Log Report" StyleName="Title" Name="label11" Font="Arial Black, 25pt, style=Bold" Ref="1">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRPageInfo" TextAlignment="MiddleRight" Format="{0: &quot;at &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="133, 22.92" LocationFloat="511, 79.17" StyleName="PageInfo" Name="pageInfo1" Font="Times New Roman, 9pt" Ref="2">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="361.46, 22.92" LocationFloat="150, 79.17" TextAlignment="MiddleRight" Text="label12" Name="label12" Padding="2,0,0,0,100" Ref="4">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Created by: {0}" Ref="3" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="493.75, 22.92" LocationFloat="150, 102.08" TextAlignment="TopRight" Text="label13" Name="label13" Padding="2,0,0,0,100" Ref="6">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.DateRange" FormatString="Date Range: {0}" Ref="5" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item4>
      </Controls>
    </Item2>
    <Item3 ControlType="GroupHeaderBand" Level="2" HeightF="45.83" Name="groupHeaderBand1" Ref="15">
      <GroupFields>
        <Item1 FieldName="CustomerName" Ref="8" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="326.04, 25" LocationFloat="72.92, 16.67" TextAlignment="MiddleLeft" StyleName="DataField" Name="label2" Font="Times New Roman, 10pt" Ref="10">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="DispatchLogReport.CustomerName" Ref="9" />
          </DataBindings>
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLabel" SizeF="67.83, 25" LocationFloat="5.21, 16.67" TextAlignment="MiddleLeft" Text="Customer :" StyleName="FieldCaption" Name="label1" Font="Times New Roman, 10pt, style=Bold" Ref="11">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLine" ForeColor="255,82,82,82" SizeF="639, 2.08" LocationFloat="5.21, 43.75" Name="line1" Ref="12">
          <StylePriority UseForeColor="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="240.63, 26.04" LocationFloat="401.04, 16.67" TextAlignment="MiddleRight" Name="label5" Padding="2,2,0,0,100" Ref="14">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="DispatchLogReport.OrderNumber" FormatString="Total orders : {0}" Ref="13" />
          </DataBindings>
          <Summary FormatString="Total orders : {0}" Running="Group" Func="Count" />
          <StylePriority UseTextAlignment="false" />
        </Item4>
      </Controls>
    </Item3>
    <Item4 ControlType="GroupHeaderBand" Level="1" HeightF="38.54" Name="groupHeaderBand2" Ref="23">
      <GroupFields>
        <Item1 FieldName="OrderNumber" Ref="16" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="164.58, 23.96" LocationFloat="108.33, 12.5" TextAlignment="MiddleLeft" StyleName="DataField" Name="label4" Font="Times New Roman, 9pt" Ref="18">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="DispatchLogReport.OrderNumber" Ref="17" />
          </DataBindings>
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLabel" SizeF="89.58, 25" LocationFloat="16.67, 11.46" TextAlignment="MiddleLeft" Text="Order Number :" StyleName="FieldCaption" Name="label3" Font="Times New Roman, 9pt, style=Bold" Ref="19">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLine" ForeColor="255,82,82,82" SizeF="621.88, 2.08" LocationFloat="20.83, 36.46" Name="line2" Ref="20">
          <StylePriority UseForeColor="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="363.54, 22.92" LocationFloat="278.13, 13.54" TextAlignment="MiddleRight" Name="label8" Padding="2,2,0,0,100" Ref="22">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="DispatchLogReport.Requester" FormatString="Requester : {0}" Ref="21" />
          </DataBindings>
          <StylePriority UseTextAlignment="false" />
        </Item4>
      </Controls>
    </Item4>
    <Item5 ControlType="GroupHeaderBand" StyleName="FieldCaption" HeightF="40.42" Name="groupHeaderBand3" Padding="0,5,0,0,100" Ref="30">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRTable" SizeF="615.63, 35.42" LocationFloat="25.5, 5" Name="table1" BorderColor="DarkGray" Borders="All" Ref="29">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1.012" Name="tableRow1" Ref="28">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.5059667179286859" TextAlignment="MiddleCenter" Text="Freight Item Desc (Qty)" Name="tableCell1" BackColor="255,194,194,194" Ref="24">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.8590808903711159" TextAlignment="MiddleCenter" Text="Origin Name &amp; Address" Name="tableCell2" BackColor="255,194,194,194" Ref="25">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.8749176486422836" TextAlignment="MiddleCenter" Text="Destination Name &amp; Adress" Name="tableCell3" BackColor="255,194,194,194" Ref="26">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.8749176486422837" TextAlignment="MiddleCenter" Text="Completed Date ( Duration)" Name="tableCell4" BackColor="255,194,194,194" Ref="27">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item4>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item5>
    <Item6 ControlType="DetailBand" StyleName="DataField" HeightF="63.54" Name="detailBand1" Ref="50">
      <Controls>
        <Item1 ControlType="XRTable" SizeF="614.58, 63.54" LocationFloat="25, 0" EvenStyleName="xrControlStyle1" Name="table2" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="49">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow2" Ref="48">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.48136233326621075" TextAlignment="MiddleCenter" Name="tableCell7" Padding="5,0,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="32">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DispatchLogReport.FreightAndQty" Ref="31" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.8173051056526993" TextAlignment="MiddleCenter" Name="tableCell8" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="37">
                  <Controls>
                    <Item1 ControlType="XRLabel" SizeF="168, 34.38" LocationFloat="0, 0" TextAlignment="MiddleLeft" Text="label6" Name="label6" Padding="2,2,0,0,100" Borders="None" Ref="34">
                      <DataBindings>
                        <Item1 PropertyName="Text" DataMember="DispatchLogReport.Origin Name" FormatString="{0} -" Ref="33" />
                      </DataBindings>
                      <StylePriority UseBorders="false" UseTextAlignment="false" />
                    </Item1>
                    <Item2 ControlType="XRLabel" SizeF="167.71, 22.92" LocationFloat="0, 35.42" TextAlignment="TopLeft" Name="label7" Padding="2,2,0,0,100" Borders="None" Ref="36">
                      <DataBindings>
                        <Item1 PropertyName="Text" DataMember="DispatchLogReport.OriginLocation" Ref="35" />
                      </DataBindings>
                      <StylePriority UseBorders="false" UseTextAlignment="false" />
                    </Item2>
                  </Controls>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.8273655784179634" TextAlignment="MiddleCenter" Text="label7" Name="tableCell9" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="42">
                  <Controls>
                    <Item1 ControlType="XRLabel" SizeF="169.79, 33.33" LocationFloat="0, 0" TextAlignment="MiddleLeft" Text="label14" Name="label14" Padding="2,2,0,0,100" Borders="None" Ref="39">
                      <DataBindings>
                        <Item1 PropertyName="Text" DataMember="DispatchLogReport.Destination Name" FormatString="{0} -" Ref="38" />
                      </DataBindings>
                      <StylePriority UseBorders="false" UseTextAlignment="false" />
                    </Item1>
                    <Item2 ControlType="XRLabel" SizeF="169.79, 22.92" LocationFloat="0, 35.42" TextAlignment="TopLeft" Text="label15" Name="label15" Padding="2,2,0,0,100" Borders="None" Ref="41">
                      <DataBindings>
                        <Item1 PropertyName="Text" DataMember="DispatchLogReport.Destination Location" FormatString="{0}" Ref="40" />
                      </DataBindings>
                      <StylePriority UseBorders="false" UseTextAlignment="false" />
                    </Item2>
                  </Controls>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.8323717466839317" TextAlignment="MiddleLeft" Name="tableCell10" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="47">
                  <Controls>
                    <Item1 ControlType="XRLabel" SizeF="170, 33.33" LocationFloat="0, 0" Text="label16" Name="label16" BorderColor="DarkGray" Padding="2,2,0,0,100" Borders="None" Ref="44">
                      <DataBindings>
                        <Item1 PropertyName="Text" DataMember="DispatchLogReport.DispatchCompleted" Ref="43" />
                      </DataBindings>
                      <StylePriority UseBorderColor="false" UseBorders="false" />
                    </Item1>
                    <Item2 ControlType="XRLabel" SizeF="168.75, 23.96" LocationFloat="0, 35.42" TextAlignment="TopLeft" Text="label17" Name="label17" BorderColor="DarkGray" Padding="2,2,0,0,100" Borders="None" Ref="46">
                      <DataBindings>
                        <Item1 PropertyName="Text" DataMember="DispatchLogReport.Duration" FormatString="({0})" Ref="45" />
                      </DataBindings>
                      <StylePriority UseBorderColor="false" UseBorders="false" UseTextAlignment="false" />
                    </Item2>
                  </Controls>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item4>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item6>
    <Item7 ControlType="GroupFooterBand" HeightF="21.88" Name="GroupFooter1" Ref="51" />
    <Item8 ControlType="PageFooterBand" HeightF="48.96" Name="pageFooterBand1" Ref="53">
      <Controls>
        <Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="313, 23" LocationFloat="331, 6" StyleName="PageInfo" Name="pageInfo2" Padding="0,5,0,0,100" Font="Times New Roman, 9pt" Ref="52">
          <StylePriority UseFont="false" UsePadding="false" />
        </Item1>
      </Controls>
    </Item8>
    <Item9 ControlType="BottomMarginBand" Name="BottomMargin1" Padding="0,10,0,0,100" Ref="54">
      <StylePriority UsePadding="false" />
    </Item9>
  </Bands>
  <StyleSheet>
    <Item1 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="Title" Font="Times New Roman, 24pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="55" />
    <Item2 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="FieldCaption" Font="Times New Roman, 10pt, style=Bold" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="56" />
    <Item3 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="PageInfo" Font="Times New Roman, 8pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="57" />
    <Item4 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="DataField" Font="Times New Roman, 8pt" Padding="2,2,0,0,100" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="58" />
    <Item5 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="xrControlStyle1" Font="Times New Roman, 9pt" BackColor="WhiteSmoke" BorderColor="DarkGray" Sides="None" BorderWidthSerializable="1" Ref="59" />
  </StyleSheet>
  <ObjectStorage>
    <Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;Dispatch_x0020_Log_x0020_Report&gt;&lt;xs:schema id=&quot;Dispatch_x0020_Log_x0020_Report&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;Dispatch_x0020_Log_x0020_Report&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;DispatchLogReport&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;Qty&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Order_x0020_Created&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DispatchCompleted&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;PickupScheduled&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DeliveryScheduled&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Actual_x0020_At_x0020_Delivery&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateOutForPickup&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Duration&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;OrderNumber&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;CustomerName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Origin_x0020_Name&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;OriginLocation&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Destination_x0020_Name&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Destination_x0020_Location&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FreightAndQty&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Requester&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Freight_x0020_Item_x0020_Description&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;OrderItemNumber&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/Dispatch_x0020_Log_x0020_Report&gt;" Type="System.Data.DataSet" Ref="60" />
  </ObjectStorage>
  <Extensions>
    <Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="61" />
  </Extensions>
</XtraReportsLayoutSerializer>', 'b571d01a-d326-4b2f-833d-00a78f3cd36b', 'c7aed3f5-1c57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('cfda7798-ebc1-462d-a4d5-bbbf7d4b6a6e', N'Fuel Purchases Report', '05884549-8764-11e4-b90a-ac68328aed23', N'Fuel Purchases Report', 1, NULL, 1, '91e29695-0d94-11e6-80f6-00155db47809', '91e29695-0d94-11e6-80f6-00155db47809', '2017-03-02 07:06:46.353', '2017-03-02 07:44:13.640', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" PaperKind="A4Rotated" Name="Fuel Purchases Report" Margins="30, 19, 0, 0" DisplayName="Fuel Purchases Report" PageWidth="1169" PageHeight="827" DataMember="FuelPurchasesReport" DataSource="#Ref-52">
  <Watermark Font="Times New Roman, 9pt" />
  <Bands>
    <Item1 ControlType="TopMarginBand" HeightF="0" Name="TopMargin1" Ref="0" />
    <Item2 ControlType="ReportHeaderBand" HeightF="156.33" Name="reportHeaderBand1" Padding="2,0,0,0,100" Ref="9">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="637.5, 53.13" LocationFloat="232.29, 14.58" TextAlignment="TopCenter" Text="Fuel Purchases Report" StyleName="Title" Name="label11" Font="Arial Black, 25pt, style=Bold" Ref="1">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRPageInfo" TextAlignment="MiddleRight" Format="{0: &quot;at &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="133, 22.92" LocationFloat="967.25, 79.19" StyleName="PageInfo" Name="pageInfo1" Font="Times New Roman, 9pt" Ref="2">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="361.46, 22.92" LocationFloat="605.73, 79.19" TextAlignment="MiddleRight" Text="label12" Name="label12" Padding="2,0,0,0,100" Ref="4">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Created by: {0}" Ref="3" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="493.75, 22.92" LocationFloat="606.25, 102.09" TextAlignment="TopRight" Text="label13" Name="label13" Padding="2,0,0,0,100" Ref="6">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.DateRange" FormatString="Date Range: {0}" Ref="5" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item4>
        <Item5 ControlType="XRLabel" SizeF="100, 23" LocationFloat="5.21, 126.04" Text="label1" Name="label1" Padding="2,2,0,0,100" Ref="8">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="FuelPurchasesReport.Unit No" Ref="7" />
          </DataBindings>
          <Summary FormatString="Total : {0} records" Running="Report" Func="Count" />
        </Item5>
      </Controls>
    </Item2>
    <Item3 ControlType="GroupHeaderBand" Level="1" HeightF="48.96" Name="groupHeaderBand1" Ref="19">
      <GroupFields>
        <Item1 FieldName="Employee Name" SortOrder="Descending" Ref="10" />
        <Item2 Ref="11" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLine" SizeF="1094.79, 2.08" LocationFloat="5.21, 44.79" Name="line1" BorderColor="255,89,89,89" Ref="12">
          <StylePriority UseBorderColor="false" />
        </Item1>
        <Item2 ControlType="XRTable" SizeF="820.84, 25" LocationFloat="6.25, 12.5" Name="table3" Ref="18">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow2" Ref="17">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="2.4896000000000003" Text="tableCell1" Name="tableCell1" Font="Times New Roman, 10pt, style=Bold" CanShrink="true" Ref="14">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="FuelPurchasesReport.Employee Name" FormatString="Employee Name : {0}" Ref="13" />
                  </DataBindings>
                  <StylePriority UseFont="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="5.7188" Text="tableCell2" Name="tableCell2" Font="Times New Roman, 10pt, style=Bold" CanShrink="true" Ref="16">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="FuelPurchasesReport.Employee No" FormatString="Employee # {0}" Ref="15" />
                  </DataBindings>
                  <StylePriority UseFont="false" />
                </Item2>
              </Cells>
            </Item1>
          </Rows>
        </Item2>
      </Controls>
    </Item3>
    <Item4 ControlType="GroupHeaderBand" StyleName="FieldCaption" HeightF="29.17" Name="groupHeaderBand2" Ref="28">
      <Controls>
        <Item1 ControlType="XRTable" Font="Times New Roman, 9pt, style=Bold" SizeF="1081.25, 25" LocationFloat="17.71, 4.17" Name="table1" BackColor="0,0,0,0" BorderColor="DarkGray" Borders="All" Ref="27">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow1" Ref="26">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.8342557782905846" TextAlignment="MiddleCenter" Text="Unit #" Name="tableCell5" BackColor="255,194,194,194" Padding="5,0,0,0,100" Font="Times New Roman, 10pt, style=Bold" Ref="20">
                  <StylePriority UseBackColor="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="1.050345972077511" TextAlignment="MiddleCenter" Text="Date" Name="tableCell13" BackColor="255,194,194,194" Font="Times New Roman, 10pt, style=Bold" Ref="21">
                  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="1.2061296817756544" TextAlignment="MiddleCenter" Text="Station/Vendor" Name="tableCell7" BackColor="255,194,194,194" Font="Times New Roman, 10pt, style=Bold" Ref="22">
                  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.80912003572238" TextAlignment="MiddleCenter" Text="City,State" Name="tableCell11" BackColor="255,194,194,194" Borders="All" Font="Times New Roman, 9pt, style=Bold" Ref="23">
                  <StylePriority UseBackColor="false" UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="0.8241725341509402" TextAlignment="MiddleCenter" Text="Invoice #" Name="tableCell14" BackColor="255,194,194,194" Font="Times New Roman, 10pt, style=Bold" Ref="24">
                  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
                </Item5>
                <Item6 ControlType="XRTableCell" Weight="0.4924868716626352" TextAlignment="MiddleCenter" Text="Gallons" Name="tableCell16" BackColor="255,194,194,194" Font="Times New Roman, 10pt, style=Bold" Ref="25">
                  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
                </Item6>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UseFont="false" />
        </Item1>
      </Controls>
    </Item4>
    <Item5 ControlType="DetailBand" StyleName="DataField" HeightF="19.79" Name="detailBand1" Ref="43">
      <Controls>
        <Item1 ControlType="XRTable" Font="Times New Roman, 9pt" SizeF="1081.25, 19.67" LocationFloat="17.78, 0" EvenStyleName="xrControlStyle1" Name="table2" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="42">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1.1895310402355448" Name="tableRow3" Ref="41">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.47856316882750843" TextAlignment="MiddleCenter" Text="tableCell29" Name="tableCell29" Borders="Left, Right, Bottom" Ref="30">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="FuelPurchasesReport.Unit No" Ref="29" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.6025213248059037" TextAlignment="MiddleCenter" Text="tableCell30" Name="tableCell30" Ref="32">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="FuelPurchasesReport.Purchased Date" Ref="31" />
                  </DataBindings>
                  <StylePriority UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.6918852197945704" TextAlignment="MiddleCenter" Text="tableCell8" Name="tableCell8" Borders="Left, Right, Bottom" Ref="34">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="FuelPurchasesReport.Name of Vendor" Ref="33" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.4641442808469896" TextAlignment="MiddleCenter" Text="tableCell12" Name="tableCell12" Borders="Left, Right, Bottom" Ref="36">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="FuelPurchasesReport.CityandState" Ref="35" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseTextAlignment="false" />
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="0.47277900839002607" TextAlignment="MiddleCenter" Text="tableCell15" Name="tableCell15" Borders="Left, Right, Bottom" Ref="38">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="FuelPurchasesReport.Invoice" Ref="37" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseTextAlignment="false" />
                </Item5>
                <Item6 ControlType="XRTableCell" Weight="0.28251057294651905" TextAlignment="MiddleCenter" Text="tableCell17" Name="tableCell17" Borders="Left, Right, Bottom" Ref="40">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="FuelPurchasesReport.Gallons Purchased" Ref="39" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseTextAlignment="false" />
                </Item6>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" />
        </Item1>
      </Controls>
    </Item5>
    <Item6 ControlType="PageFooterBand" HeightF="47.17" Name="pageFooterBand1" Expanded="false" Ref="45">
      <Controls>
        <Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="313, 23" LocationFloat="787.5, 12.24" StyleName="PageInfo" Name="pageInfo2" Font="Times New Roman, 9pt" Ref="44">
          <StylePriority UseFont="false" />
        </Item1>
      </Controls>
    </Item6>
    <Item7 ControlType="BottomMarginBand" HeightF="0" Name="BottomMargin1" Ref="46" />
  </Bands>
  <StyleSheet>
    <Item1 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="Title" Font="Times New Roman, 24pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="47" />
    <Item2 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="FieldCaption" Font="Times New Roman, 10pt, style=Bold" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="48" />
    <Item3 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="PageInfo" Font="Times New Roman, 8pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="49" />
    <Item4 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="DataField" Font="Times New Roman, 8pt" Padding="2,2,0,0,100" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="50" />
    <Item5 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="xrControlStyle1" Font="Times New Roman, 9pt" BackColor="0,245,245,245" BorderColor="DarkGray" Sides="None" Ref="51" />
  </StyleSheet>
  <ObjectStorage>
    <Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;Fuel_x0020_Purchases_x0020_Report&gt;&lt;xs:schema id=&quot;Fuel_x0020_Purchases_x0020_Report&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;Fuel_x0020_Purchases_x0020_Report&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;FuelPurchasesReport&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;Purchased_x0020_Date&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Gallons_x0020_Purchased&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Gallon_x0020_Cost&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Purchase_x0020_Cost&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Odometer&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Invoice&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Name_x0020_of_x0020_Vendor&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Fuel_x0020_Type&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Employee_x0020_Name&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Employee_x0020_No&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Unit_x0020_No&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;City&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;State&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;CityandState&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/Fuel_x0020_Purchases_x0020_Report&gt;" Type="System.Data.DataSet" Ref="52" />
  </ObjectStorage>
  <Extensions>
    <Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="53" />
  </Extensions>
</XtraReportsLayoutSerializer>', '0a18bad3-10ec-4639-a4d5-f07c7b936bf3', '59c4bfb5-1d57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('59d2f79a-6249-46e5-ad0d-d89a17764eca', N'TMS Loads Completed by Driver Report', 'be7768b5-6924-11e3-a678-a0b3cc4a6a82', NULL, 0, NULL, 1, '6493dea0-1c9d-11e6-80f6-00155db47809', '9b63598e-019d-11e4-80c8-00155db47804', '2017-12-19 02:00:20.670', '2017-12-19 02:00:20.670', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" PaperKind="LetterExtra" Name="TMS Loads Completed by Driver Report" Margins="8, 10, 98, 22" DisplayName="TMS Loads Completed by Driver Report" PageWidth="927" PageHeight="1200" DataMember="TMSLoadsCompletedbyDriverReport" DataSource="#Ref-49">
  <Bands>
    <Item1 ControlType="TopMarginBand" HeightF="98" Name="TopMargin1" Ref="0" />
    <Item2 ControlType="ReportHeaderBand" HeightF="136.46" Name="reportHeaderBand1" Ref="7">
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="633.33, 31.25" LocationFloat="134.38, 1.99" TextAlignment="TopCenter" Text="TMS Loads Completed by Driver Report" Name="label3" Padding="2,2,0,0,100" Font="Times New Roman, 20pt, style=Bold" Ref="1">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLabel" SizeF="270.83, 22.92" LocationFloat="484.38, 98.96" TextAlignment="TopRight" Name="label4" Padding="2,2,0,0,100" Ref="3">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Generated by {0}" Ref="2" />
          </DataBindings>
          <StylePriority UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRPageInfo" Format="{0:&quot;on&quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="146.88, 22.92" LocationFloat="755.21, 98.96" Name="pageInfo1" Padding="2,2,0,0,100" Ref="4" />
        <Item4 ControlType="XRLabel" SizeF="404.17, 22.92" LocationFloat="497.92, 75" TextAlignment="TopRight" Text="label5" Name="label5" Padding="2,2,0,0,100" Ref="6">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.DateRange" FormatString="Date Range: {0}" Ref="5" />
          </DataBindings>
          <StylePriority UseTextAlignment="false" />
        </Item4>
      </Controls>
    </Item2>
    <Item3 ControlType="PageHeaderBand" HeightF="0" Name="pageHeaderBand1" Ref="8" />
    <Item4 ControlType="GroupHeaderBand" StyleName="DataField" HeightF="75" Name="groupHeaderBand1" Ref="25">
      <GroupFields>
        <Item1 FieldName="DriverID" Ref="9" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="455.21, 16.67" LocationFloat="5.21, 14.58" Text="Generated by" Name="label10" Ref="11">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="TMSLoadsCompletedbyDriverReport.DriverName" Ref="10" />
          </DataBindings>
        </Item1>
        <Item2 ControlType="XRLine" SizeF="895.83, 2.08" LocationFloat="5.21, 32.29" Name="line2" Ref="12" />
        <Item3 ControlType="XRTable" SizeF="892.71, 17.71" LocationFloat="5.21, 57.29" Name="table1" BackColor="255,227,225,225" Borders="All" Ref="21">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow1" Ref="20">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.5417000000000001" Text="Order #" Name="tableCell1" Ref="13" />
                <Item2 ControlType="XRTableCell" Weight="0.9686999999999998" Text="Freight #" Name="tableCell2" Ref="14" />
                <Item3 ControlType="XRTableCell" Weight="2.0208999999999997" Text="Customer" Name="tableCell3" Ref="15" />
                <Item4 ControlType="XRTableCell" Weight="1.4791999999999996" Text="Freight Description" Name="tableCell5" Ref="16" />
                <Item5 ControlType="XRTableCell" Weight="1.5727999999999998" Text="Completed Date" Name="tableCell6" Ref="17" />
                <Item6 ControlType="XRTableCell" Weight="1.1979" Text="Total Drive Time" Name="tableCell4" Ref="18" />
                <Item7 ControlType="XRTableCell" Weight="1.1459" Text="Total Distance" Name="tableCell7" BackColor="255,227,225,225" Ref="19">
                  <StylePriority UseBackColor="false" />
                </Item7>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBackColor="false" UseBorders="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="29.17, 16.67" LocationFloat="860.42, 14.58" Name="label1" Padding="2,2,0,0,100" Ref="23">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="TMSLoadsCompletedbyDriverReport.OrderItemNumber" Ref="22" />
          </DataBindings>
          <Summary Running="Group" Func="Count" />
        </Item4>
        <Item5 ControlType="XRLabel" SizeF="191.67, 16.67" LocationFloat="667.71, 14.58" TextAlignment="TopRight" Text="Total Load Count :" Name="label2" Padding="2,2,0,0,100" Ref="24">
          <StylePriority UseTextAlignment="false" />
        </Item5>
      </Controls>
    </Item4>
    <Item5 ControlType="DetailBand" StyleName="DataField" HeightF="17.71" Name="detailBand1" Ref="42">
      <Controls>
        <Item1 ControlType="XRTable" SizeF="892.71, 17.71" LocationFloat="5.22, 0" Name="table2" Borders="Left, Right, Bottom" Ref="41">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow1" Ref="40">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.5417000000000001" Name="tableCell1" Ref="27">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMSLoadsCompletedbyDriverReport.OrderNumber" Ref="26" />
                  </DataBindings>
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.9686999999999998" Name="tableCell2" Ref="29">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMSLoadsCompletedbyDriverReport.OrderItemNumber" Ref="28" />
                  </DataBindings>
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="2.0208999999999997" Name="tableCell3" Ref="31">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMSLoadsCompletedbyDriverReport.CustomerName" Ref="30" />
                  </DataBindings>
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="1.4791999999999996" Name="tableCell5" Ref="33">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMSLoadsCompletedbyDriverReport.FreightDescription" Ref="32" />
                  </DataBindings>
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="1.5727999999999998" Name="tableCell6" Borders="Left, Right, Bottom" Ref="35">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMSLoadsCompletedbyDriverReport.CompletedDate" Ref="34" />
                  </DataBindings>
                  <StylePriority UseBorders="false" />
                </Item5>
                <Item6 ControlType="XRTableCell" Weight="1.1979" Name="tableCell4" Borders="Left, Right, Bottom" Ref="37">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMSLoadsCompletedbyDriverReport.TotalDriveInSeconds" Ref="36" />
                  </DataBindings>
                  <Summary Func="Custom" />
                  <StylePriority UseBorders="false" />
                </Item6>
                <Item7 ControlType="XRTableCell" Weight="1.1459" Name="tableCell7" Borders="Left, Right, Bottom" Ref="39">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMSLoadsCompletedbyDriverReport.TotalDistanceDriven" FormatString="{0} miles" Ref="38" />
                  </DataBindings>
                  <StylePriority UseBorders="false" />
                </Item7>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBorders="false" />
        </Item1>
      </Controls>
    </Item5>
    <Item6 ControlType="PageFooterBand" HeightF="29" Name="pageFooterBand1" Ref="43" />
    <Item7 ControlType="BottomMarginBand" HeightF="22" Name="BottomMargin1" Ref="44" />
  </Bands>
  <StyleSheet>
    <Item1 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="Title" Font="Times New Roman, 20pt, style=Bold" ForeColor="Maroon" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="45" />
    <Item2 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="FieldCaption" Font="Arial, 10pt, style=Bold" ForeColor="Maroon" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="46" />
    <Item3 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="PageInfo" Font="Times New Roman, 10pt, style=Bold" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="47" />
    <Item4 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="DataField" Font="Times New Roman, 10pt" Padding="2,2,0,0,100" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="48" />
  </StyleSheet>
  <ObjectStorage>
    <Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;TMS_x0020_Loads_x0020_Completed_x0020_by_x0020_Driver_x0020_Report&gt;&lt;xs:schema id=&quot;TMS_x0020_Loads_x0020_Completed_x0020_by_x0020_Driver_x0020_Report&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;TMS_x0020_Loads_x0020_Completed_x0020_by_x0020_Driver_x0020_Report&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;TMSLoadsCompletedbyDriverReport&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;DateCreated&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;OrderNumber&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;OrderItemNumber&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;CustomerName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FreightDescription&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;CompletedDate&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TotalDriveInSeconds&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TotalDistanceDriven&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DriverName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DriverID&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/TMS_x0020_Loads_x0020_Completed_x0020_by_x0020_Driver_x0020_Report&gt;" Type="System.Data.DataSet" Ref="49" />
  </ObjectStorage>
  <Extensions>
    <Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="50" />
  </Extensions>
</XtraReportsLayoutSerializer>', '56290b65-e1e3-46c8-8752-4b60958dcfa0', 'c7aed3f5-1c57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('652ffff7-c07c-48b6-be7c-de7c04494c7f', N'TMS Scheduled Hauls Report', 'be7768b5-6924-11e3-a678-a0b3cc4a6a82', N'TMS Scheduled Hauls Report', 0, NULL, 1, 'f85a4b2f-ed82-4436-8943-96548b2f0af5', '9b63598e-019d-11e4-80c8-00155db47804', '2016-08-23 02:00:21.870', '2025-01-10 14:56:19.680', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" Name="TMS Scheduled Hauls Report" Margins="63, 33, 98, 100" DisplayName="TMS Scheduled Hauls Report" ScriptsSource="private void tableCell8_BeforePrint(object sender, System.EventArgs e) {&#xD;&#xA;    (sender as XRTableCell).Text = GetCurrentColumnValue(&quot;CustomerName&quot;) + Environment.NewLine&#xD;&#xA;                             + GetCurrentColumnValue(&quot;Make&quot;) +&quot;/&quot; + GetCurrentColumnValue(&quot;Model&quot;) + Environment.NewLine&#xD;&#xA;                             + GetCurrentColumnValue(&quot;StockNumber&quot;) + &quot;/&quot; + GetCurrentColumnValue(&quot;Pin&quot;) + Environment.NewLine&#xD;&#xA;                             + GetCurrentColumnValue(&quot;FreightDescription&quot;);&#xD;&#xA;}" PageWidth="850" PageHeight="1100" DataMember="TMSScheduled" DataSource="#Ref-65">
  <Bands>
    <Item1 ControlType="TopMarginBand" HeightF="98" Name="TopMargin1" Padding="0,5,0,0,100" Ref="0">
      <StylePriority UsePadding="false" />
    </Item1>
    <Item2 ControlType="ReportHeaderBand" HeightF="136.88" Name="reportHeaderBand1" Padding="2,0,0,0,100" Ref="7">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="737.5, 38.54" LocationFloat="5.21, 29.17" TextAlignment="TopCenter" Text="Scheduled Hauls Report" StyleName="Title" Name="label11" Font="Arial Black, 25pt, style=Bold" Ref="1">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRPageInfo" TextAlignment="MiddleRight" Format="{0: &quot;at &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="133, 22.92" LocationFloat="604.75, 79.17" StyleName="PageInfo" Name="pageInfo1" Font="Times New Roman, 9pt" Ref="2">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="361.46, 22.92" LocationFloat="243.75, 79.17" TextAlignment="MiddleRight" Text="label12" Name="label12" Padding="2,0,0,0,100" Ref="4">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Created by: {0}" Ref="3" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="493.75, 22.92" LocationFloat="243.75, 102.08" TextAlignment="TopRight" Text="label13" Name="label13" Padding="2,0,0,0,100" Ref="6">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.DateRange" FormatString="Date Range: {0}" Ref="5" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item4>
      </Controls>
    </Item2>
    <Item3 ControlType="GroupHeaderBand" Level="2" HeightF="35.83" Name="groupHeaderBand1" Ref="12">
      <GroupFields>
        <Item1 FieldName="ScheduledTime" Ref="8" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="261.46, 25" LocationFloat="0, 6.25" TextAlignment="MiddleLeft" StyleName="DataField" Name="label2" Font="Times New Roman, 11pt, style=Bold" Ref="10">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="TMSScheduled.ScheduledTime" FormatString="{0:dddd MM/dd/yyyy}" Ref="9" />
          </DataBindings>
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLine" ForeColor="255,82,82,82" SizeF="729.17, 2.08" LocationFloat="4.17, 31.25" Name="line1" Ref="11">
          <StylePriority UseForeColor="false" />
        </Item2>
      </Controls>
    </Item3>
    <Item4 ControlType="GroupHeaderBand" Level="1" HeightF="27.08" Name="groupHeaderBand2" Ref="23">
      <GroupFields>
        <Item1 FieldName="Driver" Ref="13" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="131.25, 25" LocationFloat="5.21, 0" TextAlignment="MiddleLeft" StyleName="DataField" Name="label4" Font="Times New Roman, 10pt, style=Bold" Ref="15">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="TMSScheduled.Driver" Ref="14" />
          </DataBindings>
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLine" ForeColor="255,82,82,82" SizeF="730.21, 2.08" LocationFloat="4.17, 25" Name="line2" Ref="16">
          <StylePriority UseForeColor="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="242.71, 25" LocationFloat="136.46, 0" TextAlignment="MiddleLeft" Name="label1" Padding="2,2,0,0,100" Font="Times New Roman, 9pt, style=Bold" Ref="18">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="TMSScheduled.HOS" FormatString="Current Weekly Reset HOS:{0}" Ref="17" />
          </DataBindings>
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="150, 25" LocationFloat="474.21, 0" TextAlignment="MiddleLeft" Text="label3" Name="label3" Padding="2,2,0,0,100" Font="Times New Roman, 9pt, style=Bold" Ref="20">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="TMSScheduled.EstimatedTripDistanceInMiles" FormatString="Est. Total: {0} Miles," Ref="19" />
          </DataBindings>
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item4>
        <Item5 ControlType="XRLabel" SizeF="113.54, 25" LocationFloat="624.21, 0" TextAlignment="MiddleLeft" Text="label5" Name="label5" Padding="2,2,0,0,100" Font="Times New Roman, 9pt, style=Bold" Ref="22">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="TMSScheduled.EstimatedTripDurationInMin" Ref="21" />
          </DataBindings>
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item5>
      </Controls>
    </Item4>
    <Item5 ControlType="GroupHeaderBand" StyleName="FieldCaption" HeightF="39.38" Name="groupHeaderBand3" Padding="0,5,0,0,100" Ref="32">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRTable" SizeF="736.46, 34.38" LocationFloat="3.65, 5" Name="table1" BorderColor="DarkGray" Borders="All" Ref="31">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="0.9822857142857143" Name="tableRow1" Ref="30">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.2943365017958814" TextAlignment="MiddleCenter" Text="Order #" Name="tableCell1" BackColor="255,194,194,194" Ref="24">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.3144775281330565" TextAlignment="MiddleCenter" Text="Org" Name="tableCell6" BackColor="255,194,194,194" Ref="25">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.503693850716123" TextAlignment="MiddleCenter" Text="Description" Name="tableCell2" BackColor="255,194,194,194" Ref="26">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.48620185289511075" TextAlignment="MiddleCenter" Text="Pickup" Name="tableCell3" BackColor="255,194,194,194" Ref="27">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="0.5737879862152279" TextAlignment="MiddleCenter" Text="Delivery" Name="tableCell4" BackColor="255,194,194,194" Ref="28">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item5>
                <Item6 ControlType="XRTableCell" Weight="0.9241745675673827" TextAlignment="MiddleCenter" Text="Notes" Name="tableCell5" BackColor="255,194,194,194" Ref="29">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item6>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item5>
    <Item6 ControlType="DetailBand" StyleName="DataField" HeightF="60" Name="detailBand1" Ref="55">
      <SortFields>
        <Item1 FieldName="PickupPromiseTime" Ref="33" />
        <Item2 FieldName="DeliveryPromiseTime" Ref="34" />
      </SortFields>
      <Controls>
        <Item1 ControlType="XRTable" SizeF="736.46, 59.38" LocationFloat="4.17, 0" EvenStyleName="xrControlStyle1" Name="table2" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="54">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1.1401689708141323" Name="tableRow2" Ref="53">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.3291943736607088" TextAlignment="MiddleCenter" Name="tableCell7" Padding="5,0,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="36">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMSScheduled.OrderNumber" Ref="35" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.3517206743726343" TextAlignment="MiddleCenter" Text="tableCell12" Name="tableCell12" Ref="38">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMSScheduled.Orgranization" Ref="37" />
                  </DataBindings>
                  <StylePriority UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.563345628868804" TextAlignment="MiddleCenter" Multiline="true" Name="tableCell8" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="40">
                  <Scripts OnBeforePrint="tableCell8_BeforePrint" />
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMSScheduled.FreightDescription" Ref="39" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.543782077519825" TextAlignment="MiddleCenter" Name="tableCell9" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="45">
                  <Controls>
                    <Item1 ControlType="XRLabel" SizeF="99, 22.92" LocationFloat="0, 0" TextAlignment="MiddleLeft" Text="label6" Name="label6" Padding="2,2,0,0,100" Borders="None" Ref="42">
                      <DataBindings>
                        <Item1 PropertyName="Text" DataMember="TMSScheduled.OriginLocation" Ref="41" />
                      </DataBindings>
                      <StylePriority UseBorders="false" UseBorderWidth="false" UseTextAlignment="false" />
                    </Item1>
                    <Item2 ControlType="XRLabel" SizeF="98.96, 22.92" LocationFloat="0, 22.92" TextAlignment="MiddleLeft" Text="label7" Name="label7" Padding="2,2,0,0,100" Borders="None" Ref="44">
                      <DataBindings>
                        <Item1 PropertyName="Text" DataMember="TMSScheduled.PickupPromiseTime" FormatString="{0:t}" Ref="43" />
                      </DataBindings>
                      <StylePriority UseBorders="false" UseBorderWidth="false" UseTextAlignment="false" />
                    </Item2>
                  </Controls>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="0.6417409175677187" TextAlignment="MiddleLeft" Name="tableCell10" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="50">
                  <Controls>
                    <Item1 ControlType="XRLabel" SizeF="129.17, 22.92" LocationFloat="0, 0" Text="label8" Name="label8" Padding="2,2,0,0,100" Borders="None" BorderWidth="0" Ref="47">
                      <DataBindings>
                        <Item1 PropertyName="Text" DataMember="TMSScheduled.DestinationLocation" Ref="46" />
                      </DataBindings>
                      <StylePriority UseBorders="false" UseBorderWidth="false" />
                    </Item1>
                    <Item2 ControlType="XRLabel" SizeF="130.21, 22.92" LocationFloat="0, 22.92" Text="label9" Name="label9" Padding="2,2,0,0,100" Borders="None" Ref="49">
                      <DataBindings>
                        <Item1 PropertyName="Text" DataMember="TMSScheduled.DeliveryPromiseTime" FormatString="{0:t}" Ref="48" />
                      </DataBindings>
                      <StylePriority UseBorders="false" UseBorderWidth="false" />
                    </Item2>
                  </Controls>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item5>
                <Item6 ControlType="XRTableCell" Weight="1.03362330552696" TextAlignment="MiddleCenter" Name="tableCell11" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="52">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="TMSScheduled.Notes" Ref="51" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item6>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item6>
    <Item7 ControlType="GroupFooterBand" HeightF="24.38" Name="GroupFooter1" Ref="56" />
    <Item8 ControlType="PageFooterBand" HeightF="48.96" Name="pageFooterBand1" Ref="58">
      <Controls>
        <Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="400, 22.92" LocationFloat="330.21, 5.21" StyleName="PageInfo" Name="pageInfo2" Padding="0,5,0,0,100" Font="Times New Roman, 9pt" Ref="57">
          <StylePriority UseFont="false" UsePadding="false" />
        </Item1>
      </Controls>
    </Item8>
    <Item9 ControlType="BottomMarginBand" Name="BottomMargin1" Padding="0,10,0,0,100" Ref="59">
      <StylePriority UsePadding="false" />
    </Item9>
  </Bands>
  <StyleSheet>
    <Item1 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="Title" Font="Times New Roman, 24pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="60" />
    <Item2 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="FieldCaption" Font="Times New Roman, 10pt, style=Bold" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="61" />
    <Item3 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="PageInfo" Font="Times New Roman, 8pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="62" />
    <Item4 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="DataField" Font="Times New Roman, 8pt" Padding="2,2,0,0,100" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="63" />
    <Item5 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="xrControlStyle1" Font="Times New Roman, 9pt" BackColor="WhiteSmoke" BorderColor="DarkGray" Sides="None" BorderWidthSerializable="1" Ref="64" />
  </StyleSheet>
  <ObjectStorage>
    <Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;TMS_x0020_Scheduled_x0020_Hauls_x0020_Report&gt;&lt;xs:schema id=&quot;TMS_x0020_Scheduled_x0020_Hauls_x0020_Report&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;TMS_x0020_Scheduled_x0020_Hauls_x0020_Report&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;MileOrKm&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;TMSScheduled&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;ScheduledTime&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Driver&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;OrderNumber&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;OrderItemNumber&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;HOS&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;OriginLocation&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;PickupPromiseTime&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DestinationLocation&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DeliveryPromiseTime&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;StockNumber&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FreightDescription&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Notes&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EstimatedTripDistanceInMiles&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EstimatedTripDurationInMin&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;CustomerName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EquipmentNumber&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Make&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Model&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Machine&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Pin&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Orgranization&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/TMS_x0020_Scheduled_x0020_Hauls_x0020_Report&gt;" Type="System.Data.DataSet" Ref="65" />
  </ObjectStorage>
  <Extensions>
    <Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="66" />
  </Extensions>
</XtraReportsLayoutSerializer>', '71064554-a612-473a-b2ce-aba398c4de51', 'c7aed3f5-1c57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('4a16026a-6b70-44e0-b987-e90144b0b555', N'Vehicles Report', 'd226c6d5-6924-11e3-a678-a0b3cc4a6a82', N'Vehicles Report', 1, NULL, 1, '91e29695-0d94-11e6-80f6-00155db47809', '91e29695-0d94-11e6-80f6-00155db47809', '2017-01-17 04:37:13.657', '2017-01-17 04:51:19.220', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" PaperKind="A4Rotated" Name="Vehicles Report" Margins="38, 19, 0, 0" DisplayName="Vehicles Report" PageWidth="1169" PageHeight="827" DataMember="VehiclesReport" DataSource="#Ref-43">
  <Watermark Font="Times New Roman, 9pt" />
  <Bands>
    <Item1 ControlType="TopMarginBand" HeightF="0" Name="TopMargin1" Ref="0" />
    <Item2 ControlType="ReportHeaderBand" HeightF="132.29" Name="reportHeaderBand1" Padding="2,0,0,0,100" Ref="7">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="637.5, 53.13" LocationFloat="232.29, 14.58" TextAlignment="TopCenter" Text="Vehicles Report" StyleName="Title" Name="label11" Font="Arial Black, 25pt, style=Bold" Ref="1">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRPageInfo" TextAlignment="MiddleRight" Format="{0: &quot;at &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="133, 22.92" LocationFloat="967.25, 79.19" StyleName="PageInfo" Name="pageInfo1" Font="Times New Roman, 9pt" Ref="2">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="361.46, 22.92" LocationFloat="605.73, 79.19" TextAlignment="MiddleRight" Text="label12" Name="label12" Padding="2,0,0,0,100" Ref="4">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Created by: {0}" Ref="3" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="493.75, 22.92" LocationFloat="606.25, 102.09" TextAlignment="TopRight" Text="label13" Name="label13" Padding="2,0,0,0,100" Ref="6">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.DateRange" FormatString="Date Range: {0}" Ref="5" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item4>
      </Controls>
    </Item2>
    <Item3 ControlType="GroupHeaderBand" Level="1" HeightF="39.58" Name="groupHeaderBand1" Expanded="false" Ref="10">
      <GroupFields>
        <Item1 FieldName="EquipmentNumber" Ref="8" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLine" SizeF="1094.79, 2.08" LocationFloat="5.21, 37.5" Name="line1" BorderColor="255,89,89,89" Ref="9">
          <StylePriority UseBorderColor="false" />
        </Item1>
      </Controls>
    </Item3>
    <Item4 ControlType="GroupHeaderBand" StyleName="FieldCaption" HeightF="29.17" Name="groupHeaderBand2" Ref="19">
      <Controls>
        <Item1 ControlType="XRTable" Font="Times New Roman, 9pt, style=Bold" SizeF="1082.29, 25" LocationFloat="17.71, 4.17" Name="table1" BackColor="0,0,0,0" BorderColor="DarkGray" Borders="All" Ref="18">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow1" Ref="17">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.7538310511097838" TextAlignment="MiddleCenter" Text="Unit #" Name="tableCell1" BackColor="255,194,194,194" BorderColor="DarkGray" Padding="5,0,0,0,100" Borders="All" Ref="11">
                  <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.5025701158022794" TextAlignment="MiddleCenter" Text="Plate #" Name="tableCell4" BackColor="255,194,194,194" Padding="5,0,0,0,100" Ref="12">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.8041025362461931" TextAlignment="MiddleCenter" Text="Employee Name" Name="tableCell3" BackColor="255,194,194,194" BorderColor="DarkGray" Ref="13">
                  <StylePriority UseBackColor="false" UseBorderColor="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.738730307493953" TextAlignment="MiddleCenter" Text="Employee #" Name="tableCell5" BackColor="255,194,194,194" Padding="5,0,0,0,100" Ref="14">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="1.5126796016957544" TextAlignment="MiddleCenter" Text="Last Position" Name="tableCell2" BackColor="255,194,194,194" Padding="5,0,0,0,100" Ref="15">
                  <StylePriority UseBackColor="false" UsePadding="false" UseTextAlignment="false" />
                </Item5>
                <Item6 ControlType="XRTableCell" Weight="0.9096147608079274" TextAlignment="MiddleCenter" Text="Last Position Time" Name="tableCell13" BackColor="255,194,194,194" Ref="16">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item6>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UseFont="false" />
        </Item1>
      </Controls>
    </Item4>
    <Item5 ControlType="DetailBand" StyleName="DataField" HeightF="16.67" Name="detailBand1" Ref="34">
      <Controls>
        <Item1 ControlType="XRTable" Font="Times New Roman, 9pt" SizeF="1082.29, 16.67" LocationFloat="17.78, 0" EvenStyleName="xrControlStyle1" Name="table2" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="33">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1.0081079024263615" Name="tableRow3" Ref="32">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.4324282623716064" TextAlignment="MiddleCenter" Name="tableCell9" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="21">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="VehiclesReport.Unit Number" Ref="20" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.2911729758983469" TextAlignment="MiddleCenter" Text="tableCell10" Name="tableCell10" Borders="Left, Right, Bottom" Ref="23">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="VehiclesReport.Plate Number" Ref="22" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.45838779581829875" TextAlignment="MiddleCenter" Text="tableCell6" Name="tableCell6" Ref="25">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="VehiclesReport.Employee Name" Ref="24" />
                  </DataBindings>
                  <StylePriority UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.4208876169054331" TextAlignment="MiddleCenter" Text="tableCell29" Name="tableCell29" Borders="Left, Right, Bottom" Ref="27">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="VehiclesReport.Employee Number" Ref="26" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseTextAlignment="false" />
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="0.8734912522862488" TextAlignment="MiddleCenter" Text="tableCell28" Name="tableCell28" Borders="Left, Right, Bottom" Ref="29">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="VehiclesReport.LastLocation" Ref="28" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseTextAlignment="false" />
                </Item5>
                <Item6 ControlType="XRTableCell" Weight="0.5189139148459277" TextAlignment="MiddleCenter" Text="tableCell30" Name="tableCell30" Ref="31">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="VehiclesReport.GpsTimeStamp" Ref="30" />
                  </DataBindings>
                  <StylePriority UseTextAlignment="false" />
                </Item6>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBorderColor="false" UseBorders="false" UseFont="false" />
        </Item1>
      </Controls>
    </Item5>
    <Item6 ControlType="PageFooterBand" HeightF="47.17" Name="pageFooterBand1" Ref="36">
      <Controls>
        <Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="313, 23" LocationFloat="787.5, 12.24" StyleName="PageInfo" Name="pageInfo2" Font="Times New Roman, 9pt" Ref="35">
          <StylePriority UseFont="false" />
        </Item1>
      </Controls>
    </Item6>
    <Item7 ControlType="BottomMarginBand" HeightF="0" Name="BottomMargin1" Ref="37" />
  </Bands>
  <StyleSheet>
    <Item1 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="Title" Font="Times New Roman, 24pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="38" />
    <Item2 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="FieldCaption" Font="Times New Roman, 10pt, style=Bold" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="39" />
    <Item3 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="PageInfo" Font="Times New Roman, 8pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="40" />
    <Item4 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="DataField" Font="Times New Roman, 8pt" Padding="2,2,0,0,100" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="41" />
    <Item5 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="xrControlStyle1" Font="Times New Roman, 9pt" BackColor="0,245,245,245" BorderColor="DarkGray" Sides="None" Ref="42" />
  </StyleSheet>
  <ObjectStorage>
    <Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;Vehicles_x0020_Report&gt;&lt;xs:schema id=&quot;Vehicles_x0020_Report&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;Vehicles_x0020_Report&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;VehiclesReport&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;GpsTimeStamp&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Odometer&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;City&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;State&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;LastLocation&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Unit_x0020_Number&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Plate_x0020_Number&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EquipmentMake&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EquipmentModel&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EquipmentVIN&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EquipmentType&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EquipmentCategory&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Description&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Employee_x0020_Number&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Employee_x0020_Name&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;SerialNumber&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/Vehicles_x0020_Report&gt;" Type="System.Data.DataSet" Ref="43" />
  </ObjectStorage>
  <Extensions>
    <Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="44" />
  </Extensions>
</XtraReportsLayoutSerializer>', 'b7019c3d-00a2-41d7-b65a-0d86dcf33be5', '8b799cdc-1d57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('28b8ae9a-a640-41b4-a638-e9e61b9bbc83', N'Geofence Duration Report', 'd226c6d5-6924-11e3-a678-a0b3cc4a6a82', NULL, 1, NULL, 1, 'f85a4b2f-ed82-4436-8943-96548b2f0af5', 'e7b72a6c-c9e8-11e3-80c2-00155db47804', '2016-03-07 10:26:31.907', '2017-05-04 21:41:51.677', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" Name="Geofence Duration Report" DisplayName="Geofence Duration Report" PageWidth="850" PageHeight="1100" DataMember="GeofenceDurationReport" DataSource="#Ref-46">
  <Bands>
    <Item1 ControlType="TopMarginBand" Name="TopMargin1" Ref="0" />
    <Item2 ControlType="ReportHeaderBand" HeightF="109.9" Name="reportHeaderBand1" Ref="7">
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="638, 39" LocationFloat="6, 6" TextAlignment="MiddleCenter" Text="Geofence Duration Report" StyleName="Title" Name="label15" Font="Arial Black, 25pt, style=Bold" Ref="1">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLabel" SizeF="231.25, 22.92" LocationFloat="409.38, 78.13" TextAlignment="MiddleRight" Text="label16" Name="label16" Padding="2,2,0,0,100" Ref="3">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.DateRange" FormatString="Date Range: {0}" Ref="2" />
          </DataBindings>
          <StylePriority UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="473.96, 22.92" LocationFloat="11.46, 54.17" TextAlignment="MiddleRight" Text="label17" Name="label17" Padding="2,2,0,0,100" Ref="5">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Created by : {0}" Ref="4" />
          </DataBindings>
          <StylePriority UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRPageInfo" TextAlignment="MiddleRight" Format="{0: &quot;at &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="154.17, 22.92" LocationFloat="485.42, 54.17" Name="pageInfo1" Padding="2,2,0,0,100" Ref="6">
          <StylePriority UseTextAlignment="false" />
        </Item4>
      </Controls>
    </Item2>
    <Item3 ControlType="GroupHeaderBand" Level="2" HeightF="32.82" Name="groupHeaderBand1" Ref="13">
      <GroupFields>
        <Item1 FieldName="GeofenceName" Ref="8" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="514.58, 29.17" LocationFloat="110.42, 0" TextAlignment="MiddleLeft" StyleName="DataField" Name="label2" Ref="10">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="GeofenceDurationReport.GeofenceName" Ref="9" />
          </DataBindings>
          <StylePriority UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLabel" SizeF="104.17, 29.17" LocationFloat="5.21, 0" TextAlignment="MiddleLeft" Text="Geofence Name :" StyleName="FieldCaption" Name="label1" Ref="11">
          <StylePriority UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLine" LineWidth="2" SizeF="630.73, 4.17" LocationFloat="5.21, 28.65" Name="line3" Ref="12" />
      </Controls>
    </Item3>
    <Item4 ControlType="GroupHeaderBand" Level="1" HeightF="32.29" Name="groupHeaderBand2" Ref="18">
      <GroupFields>
        <Item1 FieldName="EquipmentNumber" Ref="14" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="464.58, 26.04" LocationFloat="163.54, 6.25" TextAlignment="MiddleLeft" StyleName="DataField" Name="label4" Ref="16">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="GeofenceDurationReport.EquipmentNumber" Ref="15" />
          </DataBindings>
          <StylePriority UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLabel" SizeF="130.21, 26.04" LocationFloat="27.08, 6.25" TextAlignment="MiddleLeft" Text="Equipment Number :" StyleName="FieldCaption" Name="label3" Ref="17">
          <StylePriority UseTextAlignment="false" />
        </Item2>
      </Controls>
    </Item4>
    <Item5 ControlType="GroupHeaderBand" StyleName="FieldCaption" HeightF="21.88" Name="groupHeaderBand3" Ref="24">
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="136.46, 18" LocationFloat="9.38, 3.85" TextAlignment="MiddleLeft" Text="Device Serial Number" Name="label5" BackColor="DarkGray" BorderColor="DarkGray" Borders="Left, Top, Bottom" Ref="19">
          <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLabel" SizeF="120, 18" LocationFloat="145.83, 3.85" TextAlignment="MiddleLeft" Text="Employee Name" Name="label6" BackColor="DarkGray" BorderColor="DarkGray" Borders="All" Ref="20">
          <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="137.416656, 18" LocationFloat="265.82, 3.85" TextAlignment="MiddleLeft" Text="Enter Time" Name="label7" BackColor="DarkGray" BorderColor="DarkGray" Borders="Top, Right, Bottom" Ref="21">
          <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="137.5, 17.71" LocationFloat="403.13, 4.17" TextAlignment="MiddleLeft" Text="Exit Time" Name="label8" BackColor="DarkGray" BorderColor="DarkGray" Borders="Top, Right, Bottom" Ref="22">
          <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UseTextAlignment="false" />
        </Item4>
        <Item5 ControlType="XRLabel" SizeF="100, 18.23" LocationFloat="540.1, 3.62" TextAlignment="MiddleLeft" Text="Duration" Name="label9" BackColor="DarkGray" BorderColor="DarkGray" Borders="Top, Right, Bottom" Ref="23">
          <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" UseTextAlignment="false" />
        </Item5>
      </Controls>
    </Item5>
    <Item6 ControlType="DetailBand" StyleName="DataField" HeightF="17.71" Name="detailBand1" Ref="38">
      <SortFields>
        <Item1 FieldName="StartTime" Ref="25" />
      </SortFields>
      <Controls>
        <Item1 ControlType="XRTable" SizeF="630.44, 17.71" LocationFloat="9.38, 0" Name="table1" Ref="37">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow1" Ref="36">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="1.3594" TextAlignment="MiddleLeft" Name="tableCell1" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="27">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="GeofenceDurationReport.DeviceSerialNumber" Ref="26" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="1.21" TextAlignment="MiddleLeft" Name="tableCell2" BorderColor="DarkGray" Borders="Right, Bottom" Ref="29">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="GeofenceDurationReport.EmployeeName" Ref="28" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="1.375" TextAlignment="MiddleLeft" Name="tableCell5" BorderColor="DarkGray" Borders="Right, Bottom" Ref="31">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="GeofenceDurationReport.StartTime" Ref="30" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="1.37" TextAlignment="MiddleLeft" Name="tableCell3" BorderColor="DarkGray" Borders="Right, Bottom" Ref="33">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="GeofenceDurationReport.EndTime" Ref="32" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UseTextAlignment="false" />
                </Item4>
                <Item5 ControlType="XRTableCell" Weight="0.9899999999999999" TextAlignment="MiddleCenter" Name="tableCell4" BorderColor="DarkGray" Borders="Right, Bottom" Ref="35">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="GeofenceDurationReport.Duration" Ref="34" />
                  </DataBindings>
                  <StylePriority UseBorderColor="false" UseBorders="false" UseTextAlignment="false" />
                </Item5>
              </Cells>
            </Item1>
          </Rows>
        </Item1>
      </Controls>
    </Item6>
    <Item7 ControlType="PageFooterBand" HeightF="29" Name="pageFooterBand1" Ref="40">
      <Controls>
        <Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="313, 23" LocationFloat="331, 6" StyleName="PageInfo" Name="pageInfo2" Ref="39" />
      </Controls>
    </Item7>
    <Item8 ControlType="BottomMarginBand" Name="BottomMargin1" Ref="41" />
  </Bands>
  <StyleSheet>
    <Item1 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="Title" Font="Times New Roman, 24pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="42" />
    <Item2 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="FieldCaption" Font="Times New Roman, 10pt, style=Bold" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="43" />
    <Item3 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="PageInfo" Font="Times New Roman, 8pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="44" />
    <Item4 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="DataField" Font="Times New Roman, 8pt" Padding="2,2,0,0,100" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="45" />
  </StyleSheet>
  <ObjectStorage>
    <Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;Geofence_x0020_Duration_x0020_Report&gt;&lt;xs:schema id=&quot;Geofence_x0020_Duration_x0020_Report&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;Geofence_x0020_Duration_x0020_Report&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;GeofenceDurationReport&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;StartTime&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EndTime&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Duration&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;GeofenceName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EquipmentNumber&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DeviceSerialNumber&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;EmployeeName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/Geofence_x0020_Duration_x0020_Report&gt;" Type="System.Data.DataSet" Ref="46" />
  </ObjectStorage>
  <Extensions>
    <Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="47" />
  </Extensions>
</XtraReportsLayoutSerializer>', '2110eac4-76a1-4a8b-b49a-dbcc52447de5', '8b799cdc-1d57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('5d2263f4-0985-4e6c-a488-f02c55e329f0', N'TMS Open Orders', 'be7768b5-6924-11e3-a678-a0b3cc4a6a82', N'TMS Open Orders', 0, NULL, 1, 'f85a4b2f-ed82-4436-8943-96548b2f0af5', '91e29695-0d94-11e6-80f6-00155db47809', '2016-08-23 02:00:21.870', '2016-09-01 01:48:02.157', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
		<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" Name="TMS Open Orders" Margins="63, 100, 98, 100" DisplayName="TMS Open Orders" PageWidth="850" PageHeight="1100" DataMember="TMS Open Orders" DataSource="#Ref-45">
		  <Watermark Font="Times New Roman, 9pt" />
		  <Bands>
			<Item1 ControlType="TopMarginBand" HeightF="98" Name="TopMargin1" Padding="0,5,0,0,100" Ref="0">
			  <StylePriority UsePadding="false" />
			</Item1>
			<Item2 ControlType="ReportHeaderBand" HeightF="103.13" Name="reportHeaderBand1" Padding="2,0,0,0,100" Ref="5">
			  <StylePriority UsePadding="false" />
			  <Controls>
				<Item1 ControlType="XRLabel" SizeF="638, 39" LocationFloat="5.99, 29.16" TextAlignment="TopCenter" Text="TMS Open Orders" StyleName="Title" Name="label11" Font="Arial Black, 20pt, style=Bold" Ref="1">
				  <StylePriority UseFont="false" UseTextAlignment="false" />
				</Item1>
				<Item2 ControlType="XRPageInfo" TextAlignment="MiddleRight" Format="{0: &quot;at &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="133, 22.92" LocationFloat="511, 79.17" StyleName="PageInfo" Name="pageInfo1" Font="Times New Roman, 9pt" Ref="2">
				  <StylePriority UseFont="false" UseTextAlignment="false" />
				</Item2>
				<Item3 ControlType="XRLabel" SizeF="361.46, 22.92" LocationFloat="150, 79.17" TextAlignment="MiddleRight" Text="label12" Name="label12" Padding="2,0,0,0,100" Ref="4">
				  <DataBindings>
					<Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Created by: {0}" Ref="3" />
				  </DataBindings>
				  <StylePriority UsePadding="false" UseTextAlignment="false" />
				</Item3>
			  </Controls>
			</Item2>
			<Item3 ControlType="GroupHeaderBand" StyleName="FieldCaption" HeightF="39.38" Name="groupHeaderBand3" Padding="0,5,0,0,100" Ref="16">
			  <StylePriority UsePadding="false" />
			  <Controls>
				<Item1 ControlType="XRTable" SizeF="683, 34.38" LocationFloat="3.65, 5" Name="table1" BorderColor="DarkGray" Borders="All" Ref="15">
				  <Rows>
					<Item1 ControlType="XRTableRow" Weight="0.9822857142857143" Name="tableRow1" Ref="14">
					  <Cells>
						<Item1 ControlType="XRTableCell" Weight="0.25612920922103566" TextAlignment="MiddleCenter" Text="Order #" Name="tableCell1" BackColor="255,194,194,194" Font="Times New Roman, 9pt, style=Bold" Ref="6">
						  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
						</Item1>
						<Item2 ControlType="XRTableCell" Weight="0.4002018894078682" TextAlignment="MiddleCenter" Text="Status" Name="tableCell2" BackColor="255,194,194,194" Font="Times New Roman, 9pt, style=Bold" Ref="7">
						  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
						</Item2>
						<Item3 ControlType="XRTableCell" Weight="0.4002018894078682" TextAlignment="MiddleCenter" Text="Customer" Name="tableCell3" BackColor="255,194,194,194" Font="Times New Roman, 9pt, style=Bold" Ref="8">
						  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
						</Item3>
						<Item4 ControlType="XRTableCell" Weight="0.4268820153683928" TextAlignment="MiddleCenter" Text="Description" Name="tableCell4" BackColor="255,194,194,194" Font="Times New Roman, 9pt, style=Bold" Ref="9">
						  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
						</Item4>
						<Item5 ControlType="XRTableCell" Weight="0.6936832749736382" TextAlignment="MiddleCenter" Text="Pickup" Name="tableCell13" BackColor="255,194,194,194" Font="Times New Roman, 9pt, style=Bold" Ref="10">
						  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
						</Item5>
						<Item6 ControlType="XRTableCell" Weight="0.6670031490131137" TextAlignment="MiddleCenter" Text="Delivery" Name="tableCell17" BackColor="255,194,194,194" Font="Times New Roman, 9pt, style=Bold" Ref="11">
						  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
						</Item6>
						<Item7 ControlType="XRTableCell" Weight="0.4268820153683928" TextAlignment="MiddleCenter" Text="Scheduled Delivery" Name="tableCell18" BackColor="255,194,194,194" Font="Times New Roman, 9pt, style=Bold" Ref="12">
						  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
						</Item7>
						<Item8 ControlType="XRTableCell" Weight="0.3735217634473437" TextAlignment="MiddleCenter" Text="Requester" Name="tableCell5" BackColor="255,194,194,194" Font="Times New Roman, 9pt, style=Bold" Ref="13">
						  <StylePriority UseBackColor="false" UseFont="false" UseTextAlignment="false" />
						</Item8>
					  </Cells>
					</Item1>
				  </Rows>
				  <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" />
				</Item1>
			  </Controls>
			</Item3>
			<Item4 ControlType="DetailBand" StyleName="DataField" HeightF="60" Name="detailBand1" Ref="35">
			  <Controls>
				<Item1 ControlType="XRTable" SizeF="682.5, 59.38" LocationFloat="4.17, 0" EvenStyleName="xrControlStyle1" Name="table2" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="34">
				  <Rows>
					<Item1 ControlType="XRTableRow" Weight="1.1401689708141323" Name="tableRow2" Ref="33">
					  <Cells>
						<Item1 ControlType="XRTableCell" Weight="0.2257332847959146" TextAlignment="MiddleCenter" Multiline="true" Name="tableCell7" Padding="5,0,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="18">
						  <DataBindings>
							<Item1 PropertyName="Text" DataMember="TMS Open Orders.OrderNumber" Ref="17" />
						  </DataBindings>
						  <StylePriority UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
						</Item1>
						<Item2 ControlType="XRTableCell" Weight="0.3527082574936167" TextAlignment="MiddleCenter" Multiline="true" Name="tableCell8" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="20">
						  <DataBindings>
							<Item1 PropertyName="Text" DataMember="TMS Open Orders.Status" Ref="19" />
						  </DataBindings>
						  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
						</Item2>
						<Item3 ControlType="XRTableCell" Weight="0.3527082574936166" TextAlignment="MiddleCenter" Multiline="true" Name="tableCell9" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="22">
						  <DataBindings>
							<Item1 PropertyName="Text" DataMember="TMS Open Orders.Customer" Ref="21" />
						  </DataBindings>
						  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
						</Item3>
						<Item4 ControlType="XRTableCell" Weight="0.3762221413265244" TextAlignment="MiddleLeft" Multiline="true" Name="tableCell10" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="24">
						  <DataBindings>
							<Item1 PropertyName="Text" DataMember="TMS Open Orders.Description" Ref="23" />
						  </DataBindings>
						  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
						</Item4>
						<Item5 ControlType="XRTableCell" Weight="0.611360979655602" TextAlignment="MiddleCenter" Text="tableCell14" Multiline="true" Name="tableCell14" Ref="26">
						  <DataBindings>
							<Item1 PropertyName="Text" DataMember="TMS Open Orders.PickupSite" Ref="25" />
						  </DataBindings>
						  <StylePriority UseTextAlignment="false" />
						</Item5>
						<Item6 ControlType="XRTableCell" Weight="0.5854957074394036" TextAlignment="MiddleCenter" Text="tableCell15" Multiline="true" Name="tableCell15" Borders="Left, Right, Bottom" Ref="28">
						  <DataBindings>
							<Item1 PropertyName="Text" DataMember="TMS Open Orders.DeliverySite" Ref="27" />
						  </DataBindings>
						  <StylePriority UseBorders="false" UseTextAlignment="false" />
						</Item6>
						<Item7 ControlType="XRTableCell" Weight="0.3762221413265244" TextAlignment="MiddleCenter" Text="tableCell16" Multiline="true" Name="tableCell16" Borders="Left, Right, Bottom" Ref="30">
						  <DataBindings>
							<Item1 PropertyName="Text" DataMember="TMS Open Orders.ScheduledDelivery" FormatString="{0:MM/dd/yyyy hh:mm tt}" Ref="29" />
						  </DataBindings>
						  <StylePriority UseBorders="false" UseTextAlignment="false" />
						</Item7>
						<Item8 ControlType="XRTableCell" Weight="0.32919437366070897" TextAlignment="MiddleCenter" Multiline="true" Name="tableCell11" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="32">
						  <DataBindings>
							<Item1 PropertyName="Text" DataMember="TMS Open Orders.RequesterName" Ref="31" />
						  </DataBindings>
						  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
						</Item8>
					  </Cells>
					</Item1>
				  </Rows>
				  <StylePriority UseBorderColor="false" UseBorders="false" />
				</Item1>
			  </Controls>
			</Item4>
			<Item5 ControlType="GroupFooterBand" HeightF="24.38" Name="GroupFooter1" Ref="36" />
			<Item6 ControlType="PageFooterBand" HeightF="48.96" Name="pageFooterBand1" Ref="38">
			  <Controls>
				<Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="313, 23" LocationFloat="331, 6" StyleName="PageInfo" Name="pageInfo2" Padding="0,5,0,0,100" Font="Times New Roman, 9pt" Ref="37">
				  <StylePriority UseFont="false" UsePadding="false" />
				</Item1>
			  </Controls>
			</Item6>
			<Item7 ControlType="BottomMarginBand" Name="BottomMargin1" Padding="0,10,0,0,100" Ref="39">
			  <StylePriority UsePadding="false" />
			</Item7>
		  </Bands>
		  <StyleSheet>
			<Item1 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="Title" Font="Times New Roman, 24pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="40" />
			<Item2 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="FieldCaption" Font="Times New Roman, 10pt, style=Bold" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="41" />
			<Item3 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="PageInfo" Font="Times New Roman, 8pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="42" />
			<Item4 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="DataField" Font="Times New Roman, 8pt" Padding="2,2,0,0,100" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="43" />
			<Item5 BorderStyle="Inset" StringFormat="Near;Near;0;None;Character;Default" Name="xrControlStyle1" Font="Times New Roman, 9pt" BackColor="WhiteSmoke" BorderColor="DarkGray" Sides="None" BorderWidthSerializable="1" Ref="44" />
		  </StyleSheet>
		  <ObjectStorage>
			<Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;TMS_x0020_Open_x0020_Orders&gt;&lt;xs:schema id=&quot;TMS_x0020_Open_x0020_Orders&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;TMS_x0020_Open_x0020_Orders&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;TMS_x0020_Open_x0020_Orders&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;ScheduledDelivery&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;OrderNumber&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Status&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Customer&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Description&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Quantity&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;PickupSite&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DeliverySite&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;RequesterName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/TMS_x0020_Open_x0020_Orders&gt;" Type="System.Data.DataSet" Ref="45" />
		  </ObjectStorage>
		  <Extensions>
			<Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="46" />
		  </Extensions>
		</XtraReportsLayoutSerializer>', '46715b76-e6a8-4bfa-9069-db203b78ff91', 'c7aed3f5-1c57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('e8482b32-a6d9-4064-8ff4-f5a3f43b771c', N'Speed Report', 'd226c6d5-6924-11e3-a678-a0b3cc4a6a82', N'Speed Report for GPS Event', 1, NULL, 1, '91e29695-0d94-11e6-80f6-00155db47809', '91e29695-0d94-11e6-80f6-00155db47809', '2016-05-20 10:38:53.177', '2016-05-23 03:15:20.177', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" Name="Speed Report" Margins="100, 98, 98, 100" DisplayName="Speed Report" PageWidth="850" PageHeight="1100" DataMember="SpeedReport" DataSource="#Ref-47">
  <Bands>
    <Item1 ControlType="TopMarginBand" HeightF="98" Name="TopMargin1" Padding="0,5,0,0,100" Ref="0">
      <StylePriority UsePadding="false" />
    </Item1>
    <Item2 ControlType="ReportHeaderBand" HeightF="125" Name="reportHeaderBand1" Padding="2,0,0,0,100" Ref="7">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="638, 39" LocationFloat="6, 29.17" TextAlignment="TopCenter" Text="Speed Report" StyleName="Title" Name="label11" Font="Arial Black, 25pt, style=Bold" Ref="1">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRPageInfo" TextAlignment="MiddleRight" Format="{0: &quot;at &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="133, 22.92" LocationFloat="511, 79.17" StyleName="PageInfo" Name="pageInfo1" Font="Times New Roman, 9pt" Ref="2">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLabel" SizeF="361.46, 22.92" LocationFloat="150, 79.17" TextAlignment="MiddleRight" Text="label12" Name="label12" Padding="2,0,0,0,100" Ref="4">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Created by: {0}" Ref="3" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="493.75, 22.92" LocationFloat="150, 102.08" TextAlignment="TopRight" Text="label13" Name="label13" Padding="2,0,0,0,100" Ref="6">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.DateRange" FormatString="Date Range: {0}" Ref="5" />
          </DataBindings>
          <StylePriority UsePadding="false" UseTextAlignment="false" />
        </Item4>
      </Controls>
    </Item2>
    <Item3 ControlType="GroupHeaderBand" Level="2" HeightF="59.38" Name="groupHeaderBand1" Ref="13">
      <GroupFields>
        <Item1 FieldName="Equipment" Ref="8" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="281.25, 25" LocationFloat="72.92, 30.21" TextAlignment="MiddleLeft" StyleName="DataField" Name="label2" Font="Times New Roman, 10pt" Ref="10">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="SpeedReport.Equipment" Ref="9" />
          </DataBindings>
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLabel" SizeF="67.83, 25" LocationFloat="5.21, 30.21" TextAlignment="MiddleLeft" Text="Equipment" StyleName="FieldCaption" Name="label1" Font="Times New Roman, 10pt, style=Bold" Ref="11">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLine" ForeColor="255,82,82,82" SizeF="639, 2.08" LocationFloat="5.21, 57.29" Name="line1" Ref="12">
          <StylePriority UseForeColor="false" />
        </Item3>
      </Controls>
    </Item3>
    <Item4 ControlType="GroupHeaderBand" Level="1" HeightF="27.08" Name="groupHeaderBand2" Ref="19">
      <GroupFields>
        <Item1 FieldName="Driver" Ref="14" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="264.58, 23.96" LocationFloat="91.67, 0" TextAlignment="MiddleLeft" StyleName="DataField" Name="label4" Font="Times New Roman, 9pt" Ref="16">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="SpeedReport.Driver" Ref="15" />
          </DataBindings>
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLabel" SizeF="65.63, 25" LocationFloat="26.04, 0" TextAlignment="MiddleLeft" Text="Driver" StyleName="FieldCaption" Name="label3" Font="Times New Roman, 9pt, style=Bold" Ref="17">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRLine" ForeColor="255,82,82,82" SizeF="617, 2.08" LocationFloat="26.04, 25" Name="line2" Ref="18">
          <StylePriority UseForeColor="false" />
        </Item3>
      </Controls>
    </Item4>
    <Item5 ControlType="GroupHeaderBand" StyleName="FieldCaption" HeightF="40.42" Name="groupHeaderBand3" Padding="0,5,0,0,100" Ref="26">
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRTable" SizeF="615.63, 35.42" LocationFloat="25.5, 5" Name="table1" BorderColor="DarkGray" Borders="All" Ref="25">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1.012" Name="tableRow1" Ref="24">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.7168030492895693" TextAlignment="MiddleCenter" Text="Driver" Name="tableCell1" BackColor="255,194,194,194" Ref="20">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.5164908256616025" TextAlignment="MiddleCenter" Text="Velocity in MPH" Name="tableCell2" BackColor="255,194,194,194" Ref="21">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="1.1279010076066265" TextAlignment="MiddleCenter" Text="Location" Name="tableCell3" BackColor="255,194,194,194" Ref="22">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.7536880230265708" TextAlignment="MiddleCenter" Text="Event Timestamp" Name="tableCell4" BackColor="255,194,194,194" Ref="23">
                  <StylePriority UseBackColor="false" UseTextAlignment="false" />
                </Item4>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBackColor="false" UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item5>
    <Item6 ControlType="DetailBand" StyleName="DataField" HeightF="25" Name="detailBand1" Ref="37">
      <Controls>
        <Item1 ControlType="XRTable" SizeF="614.59, 25" LocationFloat="25.5, 0" EvenStyleName="xrControlStyle1" Name="table2" BorderColor="DarkGray" Borders="Left, Right, Bottom" Ref="36">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow2" Ref="35">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.6819349215878097" TextAlignment="MiddleLeft" Name="tableCell7" Padding="5,0,0,0,100" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="28">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="SpeedReport.Driver" Ref="27" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.4913666746360107" TextAlignment="MiddleCenter" Name="tableCell8" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="30">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="SpeedReport.Velocity" Ref="29" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="1.073035453662417" TextAlignment="MiddleLeft" Name="tableCell9" Borders="Left, Right, Bottom" Font="Times New Roman, 9pt" Ref="32">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="SpeedReport.Address" FormatString="{0: MM/dd/yyyy}" Ref="31" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.7120195779012409" TextAlignment="MiddleCenter" Name="tableCell10" Borders="Left,Right,Bottom" Font="Times New Roman, 9pt" Ref="34">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="SpeedReport.Event Timestamp" FormatString="{0:MM/dd/yyyy HH:mm}" Ref="33" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UseFont="false" UseTextAlignment="false" />
                </Item4>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item6>
    <Item7 ControlType="GroupFooterBand" HeightF="28.13" Name="GroupFooter1" Ref="38" />
    <Item8 ControlType="PageFooterBand" HeightF="48.96" Name="pageFooterBand1" Ref="40">
      <Controls>
        <Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="313, 23" LocationFloat="331, 6" StyleName="PageInfo" Name="pageInfo2" Padding="0,5,0,0,100" Font="Times New Roman, 9pt" Ref="39">
          <StylePriority UseFont="false" UsePadding="false" />
        </Item1>
      </Controls>
    </Item8>
    <Item9 ControlType="BottomMarginBand" Name="BottomMargin1" Padding="0,10,0,0,100" Ref="41">
      <StylePriority UsePadding="false" />
    </Item9>
  </Bands>
  <StyleSheet>
    <Item1 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="Title" Font="Times New Roman, 24pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="42" />
    <Item2 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="FieldCaption" Font="Times New Roman, 10pt, style=Bold" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="43" />
    <Item3 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="PageInfo" Font="Times New Roman, 8pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="44" />
    <Item4 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="DataField" Font="Times New Roman, 8pt" Padding="2,2,0,0,100" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="45" />
    <Item5 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="xrControlStyle1" Font="Times New Roman, 9pt" BackColor="WhiteSmoke" BorderColor="DarkGray" Sides="None" BorderWidthSerializable="1" Ref="46" />
  </StyleSheet>
  <ObjectStorage>
    <Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;Speed_x0020_Report&gt;&lt;xs:schema id=&quot;Speed_x0020_Report&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;Speed_x0020_Report&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;SpeedReport&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;Equipment&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Driver&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Velocity&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Event_x0020_Timestamp&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;City&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;State&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/Speed_x0020_Report&gt;" Type="System.Data.DataSet" Ref="47" />
  </ObjectStorage>
  <Extensions>
    <Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="48" />
  </Extensions>
</XtraReportsLayoutSerializer>', '32b5b983-4698-4e00-aa3b-0164f0139436', '8b799cdc-1d57-e311-a331-00155dbb4a2d')
INSERT INTO [dbo].[RPT2_Report] ([ID], [Name], [CategoryKeyword], [Description], [IsSystem], [IsUsedQuarter], [IsActive], [CreatedBy], [ModifiedBy], [DateCreated], [DateModified], [Account_LoginID], [UserGroupID], [ReportSetting], [ReportDataSourceID], [ModuleID]) VALUES ('bd030267-c107-4960-b513-ff9bf9d41aa1', N'Distance Travelled by State with highway status', 'd226c6d5-6924-11e3-a678-a0b3cc4a6a82', N'The Distance Travelled by State with highway status will help users calculate how many miles they’ve travelled per state. This information is valuable to the user when they are filling out IFTA forms', 1, NULL, 1, 'f85a4b2f-ed82-4436-8943-96548b2f0af5', 'f85a4b2f-ed82-4436-8943-96548b2f0af5', '2015-11-10 09:15:27.017', '2015-11-19 08:19:24.133', NULL, NULL, N'﻿<?xml version="1.0" encoding="utf-8"?>
<XtraReportsLayoutSerializer SerializerVersion="15.1.5.0" ControlType="DevExpress.XtraReports.UI.XtraReport, DevExpress.XtraReports.v15.1, Version=15.1.5.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a" Version="15.1" Padding="5,0,0,0,100" Name="Distance Travelled by State with highway status" Margins="79, 96, 96, 96" ReportUnit="Pixels" SnapGridSize="12" Dpi="96" DisplayName="Distance Travelled by State with highway status" PageWidth="816" PageHeight="1056" DataMember="DataMember" FilterString="[Total Miles] &gt; 0.05" DataSource="#Ref-54">
  <Bands>
    <Item1 ControlType="TopMarginBand" HeightF="96" Name="TopMargin1" Dpi="96" Ref="0" />
    <Item2 ControlType="ReportHeaderBand" HeightF="123" Name="reportHeaderBand1" Dpi="96" Ref="7">
      <Controls>
        <Item1 ControlType="XRLabel" SizeF="612.48, 37.44" LocationFloat="5.76, 8.78" Dpi="96" TextAlignment="MiddleCenter" Text="Distance Travelled by State with Highway Status" StyleName="Title" Name="label13" Font="Times New Roman, 21pt" Ref="1">
          <StylePriority UseFont="false" UseTextAlignment="false" />
        </Item1>
        <Item2 ControlType="XRLabel" SizeF="355, 22" LocationFloat="144, 66" Dpi="96" TextAlignment="MiddleRight" Text="label6" Name="label6" Padding="2,2,0,0,100" Ref="3">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.FullName" FormatString="Created by: {0}" Ref="2" />
          </DataBindings>
          <Summary FormatString="Created by : {0}" />
          <StylePriority UseTextAlignment="false" />
        </Item2>
        <Item3 ControlType="XRPageInfo" TextAlignment="MiddleRight" Format="{0: &quot;at &quot; MM/dd/yyyy hh:mm tt}" PageInfo="DateTime" SizeF="124, 22" LocationFloat="500, 66" Dpi="96" Name="pageInfo1" Padding="2,2,0,0,100" Ref="4">
          <StylePriority UseTextAlignment="false" />
        </Item3>
        <Item4 ControlType="XRLabel" SizeF="479, 22" LocationFloat="145, 88" Dpi="96" TextAlignment="MiddleRight" Text="label7" Name="label7" Padding="2,2,0,0,100" Ref="6">
          <DataBindings>
            <Item1 PropertyName="Text" DataMember="UserInfo.DateRange" FormatString="Date Range: {0}" Ref="5" />
          </DataBindings>
          <StylePriority UseTextAlignment="false" />
        </Item4>
      </Controls>
    </Item2>
    <Item3 ControlType="GroupHeaderBand" Level="2" HeightF="116" Name="groupHeaderBand1" Dpi="96" Padding="5,0,0,0,100" Ref="32">
      <GroupFields>
        <Item1 FieldName="State" Ref="8" />
      </GroupFields>
      <StylePriority UsePadding="false" />
      <Controls>
        <Item1 ControlType="XRTable" ForeColor="255,8,7,7" SizeF="609.6, 24" LocationFloat="14.67, 92" Dpi="96" Name="table1" BackColor="255,194,194,194" BorderColor="DarkGray" Ref="14">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow1" Ref="13">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.8017481253242363" TextAlignment="MiddleLeft" Text="Equipment Number" Name="tableCell1" Padding="5,0,0,0,100" Borders="All" Ref="9">
                  <StylePriority UseBorders="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.7310056436779802" TextAlignment="MiddleRight" Text="Total On Highway Miles" Name="tableCell2" Padding="1,5,0,0,100" Borders="Top, Right, Bottom" Ref="10">
                  <StylePriority UseBorders="false" UsePadding="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.7310056436779802" TextAlignment="MiddleRight" Text="Total Off Highway Miles" Name="tableCell3" Padding="0,5,0,0,100" Borders="Top, Right, Bottom" Ref="11">
                  <StylePriority UseBorders="false" UsePadding="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.73100564367798" TextAlignment="MiddleRight" Text="Total Miles (On + Off)" Name="tableCell4" Padding="0,5,0,0,100" Borders="Top, Right, Bottom" Ref="12">
                  <StylePriority UseBorders="false" UsePadding="false" UseTextAlignment="false" />
                </Item4>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBackColor="false" UseBorderColor="false" UseForeColor="false" />
        </Item1>
        <Item2 ControlType="XRTable" Font="Times New Roman, 9pt, style=Bold" ForeColor="Black" SizeF="618, 24" LocationFloat="5, 29" Dpi="96" Name="table3" BackColor="33,255,241,46" BorderColor="255,102,101,97" Ref="20">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow3" Ref="19">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.854312685891769" TextAlignment="MiddleLeft" Text="State" Name="tableCell9" Padding="5,0,0,0,100" Borders="None" Ref="15">
                  <StylePriority UseBorders="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.7499885000596409" TextAlignment="MiddleRight" Text="Total On Highway Miles" Name="tableCell17" Padding="0,5,0,0,100" Ref="16">
                  <StylePriority UsePadding="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.7301495874901301" TextAlignment="MiddleRight" Text="Total Off Highway Miles" Name="tableCell12" Padding="0,5,0,0,100" Ref="17">
                  <StylePriority UsePadding="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.7350574675744024" TextAlignment="MiddleRight" Text="Total Miles (On + Off)" Name="tableCell11" Padding="0,5,0,0,100" Ref="18">
                  <StylePriority UsePadding="false" UseTextAlignment="false" />
                </Item4>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBackColor="false" UseBorderColor="false" UseFont="false" UseForeColor="false" />
        </Item2>
        <Item3 ControlType="XRLine" SizeF="616, 1.92" LocationFloat="5.75, 53" Dpi="96" Name="line1" Ref="21" />
        <Item4 ControlType="XRTable" SizeF="616.5, 24" LocationFloat="6, 55" Dpi="96" Name="table4" Borders="Bottom" Ref="31">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow4" Ref="30">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.8346793199886877" TextAlignment="MiddleLeft" Name="tableCell13" Ref="23">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DataMember.State" Ref="22" />
                  </DataBindings>
                  <StylePriority UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.7316406372749263" TextAlignment="MiddleRight" Text="tableCell14" Name="tableCell14" Padding="0,5,0,0,100" Ref="25">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DataMember.Total On Highway Miles" Ref="24" />
                  </DataBindings>
                  <Summary FormatString="{0:#,##0.0}" Running="Group" />
                  <StylePriority UsePadding="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.7315935015554786" TextAlignment="MiddleRight" Text="tableCell15" Name="tableCell15" Padding="5,5,0,0,100" Ref="27">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DataMember.Total Off Highway Miles" Ref="26" />
                  </DataBindings>
                  <Summary FormatString="{0:#,##0.0}" Running="Group" />
                  <StylePriority UsePadding="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.7217421361908056" TextAlignment="MiddleRight" Text="tableCell16" Name="tableCell16" Padding="5,5,0,0,100" Ref="29">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DataMember.Total Miles" Ref="28" />
                  </DataBindings>
                  <Summary FormatString="{0:#,##0.0}" Running="Group" />
                  <StylePriority UsePadding="false" UseTextAlignment="false" />
                </Item4>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBorders="false" />
        </Item4>
      </Controls>
    </Item3>
    <Item4 ControlType="GroupHeaderBand" Level="1" HeightF="24" Name="groupHeaderBand2" Dpi="96" Ref="44">
      <GroupFields>
        <Item1 FieldName="Equipment Number" Ref="33" />
      </GroupFields>
      <Controls>
        <Item1 ControlType="XRTable" SizeF="609.6, 24" LocationFloat="14.67, 0" Dpi="96" Name="table2" BorderColor="DarkGray" Borders="None" Ref="43">
          <Rows>
            <Item1 ControlType="XRTableRow" Weight="1" Name="tableRow2" Ref="42">
              <Cells>
                <Item1 ControlType="XRTableCell" Weight="0.822771439552038" TextAlignment="MiddleLeft" Text="tableCell5" Name="tableCell5" Padding="5,0,0,0,100" Borders="Left, Right, Bottom" Ref="35">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DataMember.Equipment Number" Ref="34" />
                  </DataBindings>
                  <StylePriority UseBorders="false" UsePadding="false" UseTextAlignment="false" />
                </Item1>
                <Item2 ControlType="XRTableCell" Weight="0.7501739595915641" TextAlignment="MiddleRight" Text="tableCell6" Name="tableCell6" Padding="0,5,0,0,100" Borders="Right, Bottom" Ref="37">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DataMember.Total On Highway Miles" Ref="36" />
                  </DataBindings>
                  <Summary FormatString="{0:#,##0.0}" Running="Group" />
                  <StylePriority UseBorders="false" UsePadding="false" UseTextAlignment="false" />
                </Item2>
                <Item3 ControlType="XRTableCell" Weight="0.750173959591564" TextAlignment="MiddleRight" Text="tableCell7" Name="tableCell7" Padding="5,5,0,0,100" Borders="Right, Bottom" Ref="39">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DataMember.Total Off Highway Miles" Ref="38" />
                  </DataBindings>
                  <Summary FormatString="{0:#,##0.0}" Running="Group" />
                  <StylePriority UseBorders="false" UsePadding="false" UseTextAlignment="false" />
                </Item3>
                <Item4 ControlType="XRTableCell" Weight="0.7501739595915642" TextAlignment="MiddleRight" Text="tableCell8" Name="tableCell8" Padding="5,5,0,0,100" Borders="Right, Bottom" Ref="41">
                  <DataBindings>
                    <Item1 PropertyName="Text" DataMember="DataMember.Total Miles" Ref="40" />
                  </DataBindings>
                  <Summary FormatString="{0:#,##0.0}" Running="Group" />
                  <StylePriority UseBorders="false" UsePadding="false" UseTextAlignment="false" />
                </Item4>
              </Cells>
            </Item1>
          </Rows>
          <StylePriority UseBorderColor="false" UseBorders="false" />
        </Item1>
      </Controls>
    </Item4>
    <Item5 ControlType="GroupHeaderBand" StyleName="FieldCaption" HeightF="0" Name="groupHeaderBand3" Dpi="96" Ref="45" />
    <Item6 ControlType="DetailBand" StyleName="DataField" HeightF="0" Name="detailBand1" Dpi="96" Ref="46" />
    <Item7 ControlType="PageFooterBand" HeightF="27.84" Name="pageFooterBand1" Dpi="96" Ref="48">
      <Controls>
        <Item1 ControlType="XRPageInfo" TextAlignment="TopRight" Format="Page {0} of {1}" SizeF="300.48, 22.08" LocationFloat="317.76, 5.76" Dpi="96" StyleName="PageInfo" Name="pageInfo2" Ref="47" />
      </Controls>
    </Item7>
    <Item8 ControlType="BottomMarginBand" HeightF="96" Name="BottomMargin1" Dpi="96" Padding="5,0,0,0,100" Ref="49">
      <StylePriority UsePadding="false" />
    </Item8>
  </Bands>
  <StyleSheet>
    <Item1 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="Title" Font="Times New Roman, 24pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="50" />
    <Item2 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="FieldCaption" Font="Times New Roman, 10pt, style=Bold" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="51" />
    <Item3 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="PageInfo" Font="Times New Roman, 8pt" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="52" />
    <Item4 StringFormat="Near;Near;0;None;Character;Default" BorderStyle="Inset" Name="DataField" Font="Times New Roman, 8pt" Padding="2,2,0,0,100" ForeColor="Black" BackColor="Transparent" BorderColor="Black" Sides="None" BorderWidthSerializable="1" Ref="53" />
  </StyleSheet>
  <ObjectStorage>
    <Item1 ObjectType="DevExpress.XtraReports.Serialization.ObjectStorageInfo, DevExpress.XtraReports.v15.1" Content="&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-16&quot;?&gt;&lt;DataSource&gt;&lt;xs:schema id=&quot;DataSource&quot; xmlns=&quot;&quot; xmlns:xs=&quot;http://www.w3.org/2001/XMLSchema&quot; xmlns:msdata=&quot;urn:schemas-microsoft-com:xml-msdata&quot;&gt;&lt;xs:element name=&quot;DataSource&quot; msdata:IsDataSet=&quot;true&quot; msdata:UseCurrentLocale=&quot;true&quot;&gt;&lt;xs:complexType&gt;&lt;xs:choice minOccurs=&quot;0&quot; maxOccurs=&quot;unbounded&quot;&gt;&lt;xs:element name=&quot;UserInfo&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;UserName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;FullName&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Phone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;TimeZone&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;DateRange&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Address&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;xs:element name=&quot;DataMember&quot;&gt;&lt;xs:complexType&gt;&lt;xs:sequence&gt;&lt;xs:element name=&quot;State&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Equipment_x0020_Number&quot; type=&quot;xs:string&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Date&quot; type=&quot;xs:dateTime&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Total_x0020_Miles&quot; type=&quot;xs:decimal&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Total_x0020_Off_x0020_Highway_x0020_Miles&quot; type=&quot;xs:decimal&quot; minOccurs=&quot;0&quot; /&gt;&lt;xs:element name=&quot;Total_x0020_On_x0020_Highway_x0020_Miles&quot; type=&quot;xs:decimal&quot; minOccurs=&quot;0&quot; /&gt;&lt;/xs:sequence&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:choice&gt;&lt;/xs:complexType&gt;&lt;/xs:element&gt;&lt;/xs:schema&gt;&lt;/DataSource&gt;" Type="System.Data.DataSet" Ref="54" />
  </ObjectStorage>
  <Extensions>
    <Item1 Key="DataSerializationExtension" Value="CustomUntypedDataSetSerializer" Ref="55" />
  </Extensions>
</XtraReportsLayoutSerializer>', 'b36a4b6b-8658-481a-ae51-f6d7230852d3', '8b799cdc-1d57-e311-a331-00155dbb4a2d')
