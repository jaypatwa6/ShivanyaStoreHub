INSERT INTO [dbo].[TMS_CustomForm_Template] ([ID], [DateCreated], [CreatedBy], [DateModified], [ModifiedBy], [TMS_CustomFormID], [XMLTemplate], [LanguageCode], [CombinedHTML]) VALUES ('6a8a45de-9cbe-48e2-b5db-6688ea7484b5', '2015-05-28 01:01:01.000', '00000000-0000-0000-0000-000000000000', '2015-05-28 01:01:01.000', '00000000-0000-0000-0000-000000000000', '0242125a-416a-4d68-a09b-ec2e8c1b67b8', N'<testXML></testXML>', N'EN', N'
<div class="columns" >
	<div class="four-columns">
		<div class="columns">
			<!--row 1-->
			<div class="six-columns margin-bottom" style="max-height: 60px">
				<label class="float-left">Shipping Status: </label>
				<div class="new-row columns">
					<div class="full-width" id="freight-item-edit-shiping-status" dx-select-box="{
						dataSource: model.shippingStatus.dataSource,
						valueExpr: ''valueText'',
						displayExpr: ''displayText'',
						searchEnabled: true,
						pagingEnabled: true,
						width: ''100%'',
						heigh: 28,
						openOnFieldClick: true,
						value: model.shippingStatus.selectedValue,
						bindingOptions:{
							dataSource: ''model.shippingStatus.dataSource'',
							value: ''model.shippingStatus.selectedValue''
						}
					}"></div>
				</div>
			</div>
			<div class="six-columns margin-bottom" style="max-height: 60px">
				<label class="float-left">Stock Number: </label>
				<div class="new-row columns">
					<div id="freight-item-edit-stock-number" class="full-width" data-property="stockNumber" data-referenceName="stockNumber"
						data-change-mapping="{&quot;machine.selectedValue&quot;:{&quot;valueProp&quot;:&quot;machine&quot;,&quot;dataSourceProp&quot;:&quot;machine.dataSource&quot;},&quot;make&quot;:&quot;make&quot;,&quot;model&quot;:&quot;model&quot;,&quot;description&quot;:&quot;description&quot;}" 
						data-selecteditem-prop="stockNumber.selectedItem"
						dx-select-box="{
						dataSource: model.stockNumber.dataSource,
						valueExpr: ''stockNumber'',
						displayExpr: ''displayText'',
						searchEnabled: true,
						searchExpr:[''displayText'', ''make'',''model'',''machine''],
						searchTimeout: 800,
						pagingEnabled: true,
						width: ''100%'',
						heigh: 28,
						openOnFieldClick: true,
						value: model.stockNumber.selectedValue,
						selectedItem: model.stockNumber.selectedItem,
						onSelectionChanged: onChanged,
						onOpened: onOpened,
						bindingOptions:{
							dataSource: ''model.stockNumber.dataSource'',
							value: ''model.stockNumber.selectedValue'',
							selectedItem: ''model.stockNumber.selectedItem'',
						}
					}">
						<div class="columns no-padding" data-options="dxTemplate:{ name: ''item''}">
							{{stockNumber && stockNumber || ''''}},{{model && model || ''''}},{{make && make || ''''}},{{machine && machine || ''''}}
						</div>
					</div>
				</div>
			</div>
			<!--row 2-->
			<div class="six-columns" style="max-height: 60px">
				<label class="float-left">Machine Id: </label>
				<div class="new-row columns">
					<div class="full-width" data-referenceName="machine" id="freight-item-edit-machine"
						data-change-mapping="{&quot;stockNumber.selectedValue&quot;:{&quot;valueProp&quot;:&quot;stockNumber&quot;,&quot;dataSourceProp&quot;:&quot;stockNumber.dataSource&quot;},&quot;make&quot;:&quot;make&quot;,&quot;model&quot;:&quot;model&quot;,&quot;description&quot;:&quot;description&quot;}" 
						data-selecteditem-prop="machine.selectedItem"
						dx-select-box="{
						dataSource: model.machine.dataSource,
						valueExpr: ''machine'',
						displayExpr: ''displayText'',
						searchEnabled: true,
						searchExpr:[''displayText'', ''make'',''model'',''machine''],
						searchTimeout: 800,
						pagingEnabled: true,
						width: ''100%'',
						heigh: 28,
						openOnFieldClick: true,
						value: model.machine.selectedValue,
						selectedItem: model.machine.selectedItem,
						onSelectionChanged: onChanged,	
						onOpened: onOpened,
						bindingOptions:{
							dataSource: ''model.machine.dataSource'',
							value: ''model.machine.selectedValue'',
							selectedItem: ''model.machine.selectedItem'',
						}
					}">
						<div class="columns no-padding" data-options="dxTemplate:{ name: ''item''}">
							{{stockNumber && stockNumber || ''''}},{{model && model || ''''}},{{make && make || ''''}},{{machine && machine || ''''}}
						</div>
					</div>
				</div>
			</div>
			<div class="six-columns margin-bottom" style="max-height: 60px">
				<label class="float-left">Make: </label>
				<div class="new-row columns">
					<div id="freight-item-edit-make" dx-text-box="{
						value: model.make,
						height: 34,
						width: ''100%'',
						bindingOptions:{
							value: ''model.make''
						}
					}"></div>
				</div>
			</div>
			<!--row 3-->
			<div class="six-columns margin-bottom style="max-height: 60px">
				<label class="float-left">Model: </label>
				<div class="new-row columns">
					<div id="freight-item-edit-model" dx-text-box="{
						value: model.model,
						height: 34,
						width: ''100%'',
						bindingOptions:{
							value: ''model.model''
						}
					}"></div>
				</div>
			</div>
			<div class="six-columns" id="meter-area" style="display: none">
				<label class="float-left">Meter: </label>
				<div class="new-row columns">
					<div id="freight-item-edit-meter" dx-number-box="{
						height: 34,
						width: ''100%'',
						showSpinButtons: false,
						step: 1,
						bindingOptions:{
							value: ''model.meter''
						}
					}"></div>
				</div>
			</div>
			<div class="six-columns margin-bottom" style="max-height: 60px">
				<label class="float-left">Work Order #: </label>
				<div class="new-row columns">
					<div id="freight-item-edit-work-order-number" dx-text-box="{
						height: 34,
						width: ''100%'',
						showSpinButtons: false,
						step: 1,
						bindingOptions:{
							value: ''model.workOrder''
						}
					}"></div>
				</div>
			</div>
			<!--row 4-->
			<div class="six-columns margin-bottom" style="max-height: 60px">
				<label class="float-left">Description <span class="asterisk-style">(*)</span>: </label>
				<div class="new-row columns">
					<div id="freight-item-edit-description" dx-text-box="{
						value: model.description,
						height: 34,
						width: ''100%'',
						bindingOptions:{
							value: ''model.description''
						}
					}"></div>
				</div>
			</div>
			<div class="six-columns margin-bottom" style="max-height: 60px">
				<label class="float-left">PIN: </label>
				<div class="new-row columns">
					<div id="freight-item-edit-pin" dx-text-box="{
						value: model.pin,
						height: 34,
						width: ''100%'',
						bindingOptions:{
							value: ''model.pin''
						}
					}"></div>
				</div>
			</div>
			<!--row 5-->
			<div class="six-columns margin-bottom" style="max-height: 60px">
				<label class="float-left">Qty Ordered <span class="asterisk-style">(*)</span>: </label>
				<div class="new-row columns">
					<div id="freight-item-edit-quantity-ordered" dx-number-box="{
						height: 34,
						width: ''100%'',
						showSpinButtons: false,
						step: 1,
						bindingOptions:{
							value: ''model.qtyOrdered''
						}
					}"></div>
				</div>
			</div>
			<div class="six-columns margin-bottom" style="max-height: 60px">
				<label class="float-left">Packing Type: </label>
				<div class="new-row columns">
					<div id="freight-item-edit-packing-type" class="full-width" dx-select-box="{
						dataSource: model.packingType.dataSource,
						valueExpr: ''valueText'',
						displayExpr: ''displayText'',
						searchEnabled: true,
						pagingEnabled: true,
						width: ''100%'',
						heigh: 28,
						openOnFieldClick: true,
						value: model.packingType.selectedValue,
						bindingOptions:{
							dataSource: ''model.packingType.dataSource'',
							value: ''model.packingType.selectedValue''
						}
					}"></div>
				</div>
			</div>
			<!--row 6-->
			
			<div class="six-columns" id="shipped-area" style="display: none">
				<label class="float-left">Shipped: </label>
				<div class="new-row columns">
					<div id="freight-item-edit-shipped" dx-number-box="{
						height: 34,
						width: ''100%'',
						showSpinButtons: false,
						step: 1,
						bindingOptions:{
							value: ''model.qtyShipped''
						}
					}"></div>
				</div>
			</div>
			<!--row 7-->
			<div class="six-columns margin-bottom" id="deliveried-area" style="display: none">
				<label class="float-left">Deliveried: </label>
				<div class="new-row columns">
					<div id="freight-item-edit-delivery" dx-number-box="{
						height: 34,
						width: ''100%'',
						showSpinButtons: false,
						step: 1,
						bindingOptions:{
							value: ''model.qtyDelivered''
						}
					}"></div>
				</div>
			</div>
			<div class="six-columns" id="shippedby-area" style="display: none">
				<label class="float-left">Shipped By: </label>
				<div class="new-row columns">
					<div id="freight-item-edit-shipped-by" dx-text-box="{
						value: model.shippedBy,
						height: 34,
						width: ''100%'',
						bindingOptions:{
							value: ''model.shippedBy''
						}
					}"></div>
				</div>
			</div>
			<!--row 8-->
			<div class="six-columns margin-bottom" id="receivedby-area" style="display: none">
				<label class="float-left">Received By: </label>
				<div class="new-row columns">
					<div id="freight-item-edit-received-by" dx-text-box="{
						value: model.receivedBy,
						height: 34,
						width: ''100%'',
						bindingOptions:{
							value: ''model.receivedBy''
						}
					}"></div>
				</div>
			</div>
		</div>
	</div>
	<div class="five-columns">
		<div class="columns">
			<!--row 1-->
			<div class="new-row four-columns large-margin-bottom" id="freight-item-edit-item-dimension">
				<label class="float-left">Item Dimension(L x W x H <span ng-size-unit-picker></span>): </label>
				<div class="columns">
					<div class="four-columns">
						<div class="new-row columns">
							<div dx-number-box="{
								height: 34,
								width: ''100%'',
								showSpinButtons: false,
								step: 1,
								bindingOptions:{
									value: ''model.unitLengthInM''
								}
							}"></div>
						</div>
					</div>
					<div class="four-columns">
						<div class="new-row columns">
							<div dx-number-box="{
								height: 34,
								width: ''100%'',
								showSpinButtons: false,
								step: 1,
								bindingOptions:{
									value: ''model.unitWidthInM''
								}
							}"></div>
						</div></div>
					<div class="four-columns">
						<div class="new-row columns">
							<div dx-number-box="{
								height: 34,
								width: ''100%'',
								showSpinButtons: false,
								step: 1,
								bindingOptions:{
									value: ''model.unitHeightInM''
								}
							}"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="four-columns" id="freight-item-edit-item-weight">
				<label class="float-left">Item Weight(<span ng-weight-unit-picker></span>): </label>
				<div class="new-row columns">
					<div dx-number-box="{
						height: 34,
						width: ''100%'',
						showSpinButtons: false,
						step: 1,
						bindingOptions:{
							value: ''model.itemWeight''
						}
					}"></div>
				</div>
			</div>
			<div class="four-columns">
				<label class="float-left">Total Item Weight: </label>
				<div class="new-row columns with-mid-padding">
					{{(model.qtyOrdered && model.itemWeight) && model.qtyOrdered * model.itemWeight || 0}}
				</div>
			</div>
			<!--row 2-->
			<div class="new-row four-columns large-margin-bottom margin-top" id="freight-item-edit-ship-dimension" style="display: none">
				<label class="float-left">Ship Dimension(L x W x H <span ng-size-ship-picker></span>): </label>
				<div class="columns">
					<div class="four-columns">
						<div class="new-row columns">
							<div dx-number-box="{
								height: 34,
								width: ''100%'',
								showSpinButtons: false,
								step: 1,
								bindingOptions:{
									value: ''model.shipLengthInM''
								}
							}"></div>
						</div>
					</div>
					<div class="four-columns">
						<div class="new-row columns">
							<div dx-number-box="{
								height: 34,
								width: ''100%'',
								showSpinButtons: false,
								step: 1,
								bindingOptions:{
									value: ''model.shipWidthInM''
								}
							}"></div>
						</div>
					</div>
					<div class="four-columns">
						<div class="new-row columns">
							<div dx-number-box="{
								height: 34,
								width: ''100%'',
								showSpinButtons: false,
								step: 1,
								bindingOptions:{
									value: ''model.shipHeightInM''
								}
							}"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="four-columns margin-top" id="freight-item-edit-ship-weight" style="display: none">
				<label class="float-left">Ship Weight(<span ng-weight-ship-picker></span>): </label>
				<div class="new-row columns">
					<div dx-number-box="{
						height: 34,
						width: ''100%'',
						showSpinButtons: false,
						step: 1,
						bindingOptions:{
							value: ''model.shipWeight''
						}
					}"></div>
				</div>
			</div>
			<div class="four-columns margin-top" style="display: none">
				<label class="float-left">Ship Item Weight: </label>
				<div class="new-row columns with-mid-padding">
					{{(model.qtyOrdered && model.shipWeight) && model.qtyOrdered * model.shipWeight || 0}}
				</div>
			</div>
			<!--row 3-->
			<div class="twelve-columns"  style=''padding-top: 10px;''>
				<label class="float-left">Item Notes: </label>
				<div class="new-row columns">
					<div id="freight-item-edit-item-note" dx-text-area="{
						value: model.itemNotes,
						height: 60,
						width: ''100%'',
						bindingOptions:{
							value: ''model.itemNotes''
						}
					}"></div>
				</div>
			</div><!--Reference control-->
			<div class="new-row twelve-columns grey-bg" id="freight-item-edit-billing-information" style=''margin-top: 20px''>
				<form class="full-width">
					<fieldset>
						<legend align="left">Billing Information</legend>
						<div class="columns with-mid-padding">
							<!--row 1-->
							<div class="new-row two-columns">
								<label class="float-right">Billing Type: </label>
							</div>
							<div class="four-columns">
								<div class="new-row columns">
									<div id="freight-item-edit-billing-type" class="full-width" dx-select-box="{
										dataSource: model.billingType.dataSource,
										valueExpr: ''valueText'',
										displayExpr: ''displayText'',
										searchEnabled: true,
										pagingEnabled: true,
										width: ''100%'',
										heigh: 28,
										openOnFieldClick: true,
										value: model.billingType.selectedValue,
										bindingOptions:{
											dataSource: ''model.billingType.dataSource'',
											value: ''model.billingType.selectedValue''
										}
									}"></div>
								</div>
							</div>
							<div class="two-columns float-right">
								<label class="float-right">Authorization No: </label>
							</div>
							<div class="four-columns">
								<div class="new-row columns">
									<div id="freight-item-edit-authorization-number" dx-text-box="{
										value: model.authorizationNo,
										height: 34,
										width: ''100%'',
										bindingOptions:{
											value: ''model.authorizationNo''
										}
									}"></div>
								</div>
							</div>
							<!--row 2-->
							<div class="new-row two-columns float-right">
								<label class="float-right">Account Number: </label>
							</div>
							<div class="four-columns">
								<div class="new-row columns">
									<div class="full-width" id="freight-item-edit-account-number" dx-select-box="{
										dataSource: model.accountNumber.dataSource,
										valueExpr: ''valueText'',
										displayExpr: ''displayText'',
										searchEnabled: true,
										pagingEnabled: true,
										width: ''100%'',
										heigh: 28,
										openOnFieldClick: true,
										value: model.accountNumber.selectedValue,
										bindingOptions:{
											dataSource: ''model.accountNumber.dataSource'',
											value: ''model.accountNumber.selectedValue''
										}
									}"></div>
								</div>
							</div>
							<div class="two-columns float-right">
								<label class="float-right">Charge Value: </label>
							</div>
							<div class="four-columns">
								<div class="new-row columns">
									<div id="freight-item-edit-charge-value" dx-number-box="{
										height: 34,
										width: ''100%'',
										showSpinButtons: false,
										step: 1,
										bindingOptions:{
											value: ''model.chargeValue''
										}
									}"></div>
								</div>
							</div>
						</div>
					</fieldset>
				</form>
			</div>
		</div>
	</div>
	<div class="three-columns">
		<div class="columns">
			<!--row 1-->
			<div class="twelve-columns float-left">
				<input type="checkbox" class="float-left" ng-model="model.isStackable"/><label class="float-left"> Stackable</label>
			</div>
			<!--row 2-->
			<div class="twelve-columns grey-bg" id=''assignmentsBox''>
				<form class="full-width">
					<fieldset>
						<legend align="left">Assignments</legend>
						<div class="columns with-mid-padding">
							<div class="new-row two-columns large-margin-bottom">
								<label class="float-right mid-margin-top">Driver: </label>
							</div>
							<div class="ten-columns">
								<div class="new-row columns">
									<div class="full-width" id="freight-item-edit-assignment-driver" dx-select-box="{
										dataSource: model.driver.dataSource,
										displayExpr: ''displayText'',
										searchEnabled: true,
										searchExpr:[''number'', ''firstName'', ''lastName''],
										pagingEnabled: true,
										width: ''auto'',
										heigh: 20,
										openOnFieldClick: true,
										value: model.driver.selectedValue,
										selectedItem: model.driver.selectedItem,
										bindingOptions:{
											dataSource: ''model.driver.dataSource'',
											value: ''model.driver.selectedValue'',
											selectedItem: ''model.driver.selectedItem''
										}
									}">
										<div class="columns no-padding" data-options="dxTemplate:{ name: ''item''}">
											<div class="three-columns" style="white-space:nowrap;overflow:hidden;">{{ number }}</div>
											<div class="one-column"></div>
											<div class="three-columns" style="white-space:nowrap;overflow:hidden;">{{ firstName }}</div>
											<div class="one-column"></div>
											<div class="four-columns" style="white-space:nowrap;overflow:hidden;">{{ lastName }}</div>
										</div>
									</div>
								</div>
							</div>
							<div class="new-row two-columns large-margin-bottom">
								<label class="float-right mid-margin-top">Truck: </label>
							</div>
							<div class="ten-columns">
								<div class="new-row columns">
									<div class="full-width" id="freight-item-edit-assignment-truck" dx-select-box="{
										dataSource: model.truck.dataSource,
										valueExpr: ''valueText'',
										displayExpr: ''displayText'',
										searchEnabled: true,
										pagingEnabled: true,
										width: ''auto'',
										heigh: 28,
										openOnFieldClick: true,
										value: model.truck.selectedValue,
										selectedItem: model.truck.selectedItem,
										bindingOptions:{
											dataSource: ''model.truck.dataSource'',
											value: ''model.truck.selectedValue'',
											selectedItem: ''model.truck.selectedItem''
										}
									}">
										<div class="columns no-padding" data-options="dxTemplate:{ name: ''item''}">
											<div class="three-columns" style="white-space:nowrap;overflow:hidden;">{{ number }}</div>
											<div class="one-column"></div>
											<div class="three-columns" style="white-space:nowrap;overflow:hidden;">{{ model }}</div>
											<div class="one-column"></div>
											<div class="four-columns" style="white-space:nowrap;overflow:hidden;">{{ make }}</div>
										</div>
									</div>
								</div>
							</div>
							<div class="new-row two-columns large-margin-bottom">
								<label class="float-right mid-margin-top">Trailer: </label>
							</div>
							<div class="ten-columns">
								<div class="new-row columns">
									<div class="full-width" id="freight-item-edit-assignment-trailer" dx-select-box="{
										dataSource: model.trailer.dataSource,
										displayExpr: ''displayText'',
										searchEnabled: true,
										searchExpr:[''number'', ''model'', ''make''],
										pagingEnabled: true,
										width: ''auto'',
										heigh: 25,
										openOnFieldClick: true,
										value: model.trailer.selectedValue,
										selectedItem: model.trailer.selectedItem,
										bindingOptions:{
											dataSource: ''model.trailer.dataSource'',
											value: ''model.trailer.selectedValue'',
											selectedItem: ''model.trailer.selectedItem''
										}
									}">
										<div class="columns no-padding" data-options="dxTemplate:{ name: ''item''}">
											<div class="three-columns" style="white-space:nowrap;overflow:hidden;">{{ number }}</div>
											<div class="one-column"></div>
											<div class="three-columns" style="white-space:nowrap;overflow:hidden;">{{ model }}</div>
											<div class="one-column"></div>
											<div class="four-columns" style="white-space:nowrap;overflow:hidden;">{{ make }}</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</fieldset>
				</form>
			</div>
		</div>
	</div>
</div>')
INSERT INTO [dbo].[TMS_CustomForm_Template] ([ID], [DateCreated], [CreatedBy], [DateModified], [ModifiedBy], [TMS_CustomFormID], [XMLTemplate], [LanguageCode], [CombinedHTML]) VALUES ('1814ce36-8eab-4a1b-9357-724eec77d734', '2015-06-02 01:01:01.000', '00000000-0000-0000-0000-000000000000', '2015-06-02 01:01:01.000', '00000000-0000-0000-0000-000000000000', '046fb6d3-5d65-44fc-8295-856b99a4b70f', N'<testXML></testXML>', N'EN', N'<div class="columns align-left">
						<div class="four-columns">
							<div class="columns">
								<div class="new-row twelve-columns"><h4 class="fire-edit-mode no-margin-bottom" ng-repeat="item in model.shippingStatus.dataSource | filter: {valueText: model.shippingStatus.selectedValue}" ng-style="{''color'':item.color}">{{item.displayText}}</h4></div>
								<div class="new-row twelve-columns">Stock Number: <b class="fire-edit-mode" ng-repeat="item in model.stockNumber.dataSource | filter: {valueText: model.stockNumber.selectedValue}">{{item.stockNumber}}</b></div>
								<div class="new-row twelve-columns">Machine ID: <b class="fire-edit-mode" ng-repeat="item in model.machine.dataSource | filter: {valueText: model.machine.selectedValue}">{{item.displayText}}</b></div>
								<div class="new-row twelve-columns">Make: <b class="fire-edit-mode">{{model.make}}</b></div>
								<div class="new-row twelve-columns">Model: <b class="fire-edit-mode">{{model.model}}</b></div>
								<div class="new-row twelve-columns">Freight Description: <b class="fire-edit-mode">{{model.description}}</b></div>
								<div class="new-row twelve-columns">PIN: <b class="fire-edit-mode">{{model.pin}}</b></div>
								<div class="new-row twelve-columns" style="display:none">Meter: <b class="fire-edit-mode">{{model.meter}}</b></div>
								<div class="new-row twelve-columns">Qty Ordered: <b class="fire-edit-mode">{{model.qtyOrdered}}</b> <span style="font-style:italic; display: none">(Shipped: {{model.qtyShipped}}, Delivered: {{model.qtyDelivered}})</span></div>
								<div class="new-row twelve-columns">WO#: <b class="fire-edit-mode">{{model.workOrder}}</b></div>
								<div class="new-row twelve-columns">Packing Type: <b class="fire-edit-mode" ng-repeat="item in model.packingType.dataSource | filter: {valueText: model.packingType.selectedValue}">{{item.displayText}}</b></div>
								<div class="new-row twelve-columns">Integration App: <b class="fire-edit-mode">{{model.integrationApplication}}</b></div>
							</div>
						</div>
						<div class="five-columns">
							<div class="columns">
								<!--row 1-->
								<div class="new-row four-columns large-margin-bottom">
									<label class="float-left">Item Dimension(L x W x H <span ng-size-unit-picker></span>): </label>
									<div class="columns">
										<div class="three-columns">
											<div class="new-row columns align-center value">
												{{model.unitLengthInM == null && 0 || model.unitLengthInM}}
											</div>
										</div>
										<div class="one-column">
											<div class="new-row columns">
												<i style="margin: auto 5px;" class="icon-cross"></i>
											</div>
										</div>
										<div class="three-columns">
											<div class="new-row columns align-center">
												{{model.unitWidthInM == null && 0 || model.unitWidthInM}}
											</div>
										</div>
										<div class="one-column">
											<div class="new-row columns">
												<i style="margin: auto 5px;" class="icon-cross"></i>
											</div>
										</div>
										<div class="four-columns">
											<div class="new-row columns align-center">
												{{model.unitHeightInM == null && 0 || model.unitHeightInM}}
											</div>
										</div>
									</div>
								</div>
								<div class="four-columns">
									<label class="float-left">Item Weight(<span ng-weight-unit-picker></span>): </label>
									<div class="new-row columns">
										{{model.itemWeight == null && 0 || model.itemWeight}} lb
									</div>
								</div>
								<div class="four-columns">
									<label class="float-left">Total Item Weight: </label>
									<div class="new-row columns">
										{{calculateTotalUnitWeight()}} lb
									</div>
								</div>
								<!--row 2-->
								<div class="new-row four-columns large-margin-bottom margin-top" style="display: none">
									<label class="float-left">Ship Dimension(L x W x H <span ng-size-ship-picker></span>): </label>
									<div class="columns">
										<div class="three-columns">
											<div class="new-row columns align-center value">
												{{model.shipLengthInM == null && 0 || model.shipLengthInM}}
											</div>
										</div>
										<div class="one-column">
											<div class="new-row columns">
												<i style="margin: auto 5px;" class="icon-cross"></i>
											</div>
										</div>
										<div class="three-columns">
											<div class="new-row columns align-center">
												{{model.shipWidthInM == null && 0 || model.shipWidthInM}}
											</div>
										</div>
										<div class="one-column">
											<div class="new-row columns">
												<i style="margin: auto 5px;" class="icon-cross"></i>
											</div>
										</div>
										<div class="four-columns">
											<div class="new-row columns align-center">
												{{model.shipHeightInM == null && 0 || model.shipHeightInM}}
											</div>
										</div>
									</div>
								</div>
								<div class="four-columns margin-top" style="display: none">
									<label class="float-left">Ship Weight(<span ng-weight-ship-picker></span>): </label>
									<div class="new-row columns">
										{{model.shipWeight == null && 0 || model.shipWeight}} lb
									</div>
								</div>
								<div class="four-columns margin-top" style="display: none">
									<label class="float-left">Ship Item Weight: </label>
									<div class="new-row columns">
										{{calculateTotalShipWeight()}} lb
									</div>
								</div>
								<!--row 3-->
								<div class="twelve-columns">
									<label class="float-left">Item Notes: </label>
									<textarea class="full-width input-clear input" readonly="true" style="height:60px">{{model.itemNotes}}</textarea>
								</div>
							
								<!--Reference control-->
								<div class="new-row twelve-columns align-left">
									<div class="columns with-mid-padding">
										<div class="new-row six-columns">Billing Type: <b class="fire-edit-mode" ng-repeat="item in model.billingType.dataSource | filter: {valueText: model.billingType.selectedValue}">{{item.displayText}}</b></div>
										<div class="six-columns">Authorization No:  <b class="fire-edit-mode">{{model.authorizationNo}}</b></div>
										<div class="new-row six-columns">Account Number: <b class="fire-edit-mode" ng-repeat="item in model.accountNumber.dataSource | filter: {valueText: model.accountNumber.selectedValue}">{{item.displayText}}</b></div>
										<div class="six-columns">Charge Value: <b class="fire-edit-mode">{{model.chargeValue}}</b></div>
									</div>
								</div>
							</div>
						</div>
						<div class="three-columns">
							<div class="columns">
								<!--row 1-->
								<div class="twelve-columns float-left">
									<input type="checkbox" class="float-left" ng-model="model.isStackable" disabled/><label class="float-left"> Stackable</label>
								</div>
								<!--row 2-->
								<div class="twelve-columns">
									<div class="columns boxed with-border with-mid-padding" id="assignmentsBox">
										<div class="new-row twelve-columns mid-margin-bottom"><b>Assignments</b></div>
										<div class="new-row twelve-columns mid-margin-left">Driver: <b class="fire-edit-mode" ng-repeat="item in model.driver.dataSource | filter: {valueText: model.driver.selectedValue}">{{item.displayText}}</b></div>
										<div class="new-row twelve-columns mid-margin-left">Truck: <b class="fire-edit-mode" ng-repeat="item in model.truck.dataSource | filter: {valueText: model.truck.selectedValue}">{{item.displayText}}</b></div>
										<div class="new-row twelve-columns mid-margin-left">Trailer: <b class="fire-edit-mode" ng-repeat="item in model.trailer.dataSource | filter: {valueText: model.trailer.selectedValue}">{{item.displayText}}</b></div>
									</div>
								</div>
							</div>
						</div>
					</div>')
