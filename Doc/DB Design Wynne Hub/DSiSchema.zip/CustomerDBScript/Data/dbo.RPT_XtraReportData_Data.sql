INSERT INTO [dbo].[RPT_XtraReportData] ([ID], [ReportName], [XtraReportLayout], [LookupQuery], [CreatedBy], [DateCreated], [DateModified], [ModifiedBy], [IsDsiMasterDb], [IsActive]) VALUES ('e3e8fdfd-920a-e511-9d6b-001e670bc654', N'Orders', NULL, N'select DATEADD(hour, @timeoffset, GETUTCDATE()) DateCreated, Account.Id,  account.AccountName,accountlogin.Phone,
			isnull(accountlogin.FirstName,'''') + '' '' + isnull(accountlogin.LastName,'''') as Name, 
			isnull(ad.Address1,'''')  + '' '' + isnull(ad.City,'''') +'' ''+isnull('','' +ad.State,'''')+'' ''+isnull(ad.PostalCode,'''') as Address
			from [dbo].[Account] as account
			join [dbo].[Account_Address] as ad on account.Id=ad.AccountID
			join [dbo].[Account_Login] as accountlogin on account.id = accountlogin.AccountId
			where accountlogin.Id =@userid', 'f85a4b2f-ed82-4436-8943-96548b2f0af5', '2015-03-03 00:00:00.000', '2015-03-03 00:00:00.000', 'f85a4b2f-ed82-4436-8943-96548b2f0af5', 1, 1)
INSERT INTO [dbo].[RPT_XtraReportData] ([ID], [ReportName], [XtraReportLayout], [LookupQuery], [CreatedBy], [DateCreated], [DateModified], [ModifiedBy], [IsDsiMasterDb], [IsActive]) VALUES ('a33a73d6-920a-e511-9d6b-001e670bc654', N'Orders', NULL, N'select                 [customer].Name as ''Name of Customer ''     
,isnull([contact].FirstName,'''') + '' '' + isnull([contact].LastName,'''') as ''Customer Contact Name''   
,isnull([phone].PhoneNumber,'''')+'' ''+isnull(''ext ''+[phone].Extension,'''') as ''Customer Contact Number''       
,[order].OrderNumber as ''Order Number''                ,[orderItem].QuantityOrdered as ''Total quantity ordered''        
,[orderItem].Notes as ''Additional notes of the item''                ,isnull([orderItem].UnitLengthInM,0) * 3.28084  as ''Length of item''      
,isnull([orderItem].UnitWidthInM,0) * 3.28084 as ''Width of item''    
,[jsPickup].Name ''Origin Name''  
,isnull([jsPickup].Address,'''')  + '' '' + isnull([jsPickup].City,'''') +'' ''+ +isnull('','' +[jsPickup].State,'''')     
+ '' '' +isnull([jsPickup].PostalCode,'''')  as ''Origin Location''       
,isnull([jsPickup].ContactName,'''') + '' '' +isnull([jsPickup].ContactPhone,'''') + '' '' + isnull(''ext ''+[jsPickup].ContactExtension,'''') as ''Origin ContactPhone''        
,[order].[OriginJobsiteNotes] as ''Origin Note''                ,[jsDelivery].Name as ''Destination Name''         
,isnull([jsDelivery].Address,'''')  + '' '' + isnull([jsDelivery].City,'''') +'' ''+ +isnull('','' +[jsDelivery].State,'''')           
+ '' '' +isnull([jsDelivery].PostalCode,'''')  as ''Destination Location''        
,isnull([jsDelivery].ContactName,'''')  + '' '' ++isnull([jsDelivery].ContactPhone,'''') + '' '' + isnull(''ext ''+[jsDelivery].ContactExtension,'''') as ''Destination ContactPhone''  
,[order].[DestinationJobsiteNotes] as ''Destination Note''    
--,[taskEvent].DateCreated as ''Request Completed Date'' 
,[orderItem].[FreightDescription]     
,[customdata].StockNumber as Stock            
--,[equipmentmachine].Number as MachineId           
,[customdata].Machine EquipmentLicense        
,[customdata].Make                
,[customdata].Model      
,[customdata].PIN
,orderItem.Notes                ,orderItem.QuantityOrdered      
,isnull([orderItem].UnitWeightInKG,0) * 2.2046   as ''Weight of item''      
,isnull([orderItem].UnitWeightInKG,0) * isnull([orderItem].QuantityOrdered,0) * 2.2046  as ''Total Weight''    
,DATEADD(hour, @timeoffset,[orderItem].DateCreated) as ''Scheduled Dispatched''        
,orderItem.OrderItemNumber       ,[status].Name as OTCurrentStatus        
,(select top 1 DATEADD(hour, @timeoffset, OIT.ScheduledTime)              
from TMS_Order_Item_Task OIT inner join System_CommonList_Item CI on OIT.CommonList_TMSOrderItemTaskTypeId = CI.ID      
where OIT.TMS_Order_ItemID = [orderItem].ID and ci.Keyword = ''TMS_Order_Type_Pickup'' ) as ''Scheduled Pickup''     
,(select DATEADD(hour, @timeoffset, OIT.ScheduledTime)        
from TMS_Order_Item_Task OIT inner join System_CommonList_Item CI on OIT.CommonList_TMSOrderItemTaskTypeId = CI.ID        
where  OIT.TMS_Order_ItemID = [orderItem].ID and ci.Keyword = ''TMS_Order_Type_Delivery'') as ''Scheduled Delivery''  
,(select top 1 DATEADD(hour, @timeoffset, OITE.DateCreated)        
from TMS_Order_Event_Summary OITE inner join System_CommonList_Item CI on OITE.CommonList_TMSOrder_Item_StatusId = CI.ID                
inner join TMS_Order_Item_Task OIT  on OITE.TMS_Order_Item_TaskID = OIT.ID       
where  OIT.TMS_Order_ItemID = [orderItem].ID and ci.Keyword = ''TMS_OrderItemStatus_Dispatched''  
order by OITE.DateCreated desc ) as ''Actual Dispatched''       
,(select top 1 DATEADD(hour, @timeoffset, OITE.DateCreated)       
from TMS_Order_Event_Summary OITE inner join System_CommonList_Item CI on OITE.CommonList_TMSOrder_Item_StatusId = CI.ID  
inner join TMS_Order_Item_Task OIT  on OITE.TMS_Order_Item_TaskID = OIT.ID            
where  OIT.TMS_Order_ItemID = [orderItem].ID and ci.Keyword = ''TMS_OrderItemStatus_OutForPickup''    
order by OITE.DateCreated desc) as ''Actual Out Pickup''                ,(select top 1 DATEADD(hour, @timeoffset, OITE.DateCreated)            
from TMS_Order_Event_Summary OITE inner join System_CommonList_Item CI on OITE.CommonList_TMSOrder_Item_StatusId = CI.ID                  
inner join TMS_Order_Item_Task OIT  on OITE.TMS_Order_Item_TaskID = OIT.ID            
where OIT.TMS_Order_ItemID = [orderItem].ID and ci.Keyword = ''TMS_OrderItemStatus_AtPickup''   
order by OITE.DateCreated desc) as ''Actual At Pickup''           
,(select top 1 DATEADD(hour, @timeoffset, OITE.DateCreated)               
from TMS_Order_Event_Summary OITE inner join System_CommonList_Item CI on OITE.CommonList_TMSOrder_Item_StatusId = CI.ID        
inner join TMS_Order_Item_Task OIT  on OITE.TMS_Order_Item_TaskID = OIT.ID             
where OIT.TMS_Order_ItemID = [orderItem].ID and ci.Keyword = ''TMS_OrderItemStatus_OutForDelivery''    
order by OITE.DateCreated desc) as ''Actual Out For Delivery''       
,(select top 1 DATEADD(hour, @timeoffset, OITE.DateCreated) 
from TMS_Order_Event_Summary OITE inner join System_CommonList_Item CI on OITE.CommonList_TMSOrder_Item_StatusId = CI.ID    
inner join TMS_Order_Item_Task OIT  on OITE.TMS_Order_Item_TaskID = OIT.ID        
where OIT.TMS_Order_ItemID = [orderItem].ID and ci.Keyword = ''TMS_OrderItemStatus_AtDelivery''   
order by OITE.DateCreated desc) as ''Actual At Delivery''        ,(select top 1 DATEADD(hour, @timeoffset, OITE.DateCreated)           
from TMS_Order_Event_Summary OITE inner join System_CommonList_Item CI on OITE.CommonList_TMSOrder_Item_StatusId = CI.ID         
inner join TMS_Order_Item_Task OIT  on OITE.TMS_Order_Item_TaskID = OIT.ID            
where OIT.TMS_Order_ItemID = [orderItem].ID and ci.Keyword = ''TMS_OrderItemStatus_DeliveryComplete''  
order by OITE.DateCreated desc) as ''Actual DeliveryCompleted''                
,(SELECT        TOP (1) E.Number                           
FROM    
dbo.TMS_Order_Item_Task AS OIT INNER JOIN                   
dbo.System_CommonList_Item AS CI ON OIT.CommonList_TMSOrderItemTaskTypeId = CI.ID INNER JOIN                                 
dbo.HR_Employee AS E ON OIT.Driver_HR_EmployeeID = E.ID                         
WHERE    OIT.TMS_Order_ItemID = [orderItem].ID and    CI.Keyword = ''TMS_Order_Type_Pickup''  ) as ''DriverNumber Pickup''             
,(SELECT        TOP (1) E.Number                                    FROM            dbo.TMS_Order_Item_Task AS OIT INNER JOIN                    
dbo.System_CommonList_Item AS CI ON OIT.CommonList_TMSOrderItemTaskTypeId = CI.ID INNER JOIN                       
dbo.HR_Employee AS E ON OIT.Driver_HR_EmployeeID = E.ID               
WHERE    OIT.TMS_Order_ItemID = [orderItem].ID and    CI.Keyword = ''TMS_Order_Type_Delivery''  ) as ''DriverNumber Delivery''       ,(SELECT        TOP (1) E.Number             
FROM            dbo.TMS_Order_Item_Task AS OIT INNER JOIN                                                 
dbo.System_CommonList_Item AS CI ON OIT.CommonList_TMSOrderItemTaskTypeId = CI.ID INNER JOIN            
dbo.FMS_Equipment AS E ON OIT.Truck_FMS_EquipmentID = E.ID                  
WHERE    OIT.TMS_Order_ItemID = [orderItem].ID and    CI.Keyword = ''TMS_Order_Type_Pickup''  ) as ''EquipmentNumber Pickup''       ,(SELECT        TOP (1) E.Number        
FROM            dbo.TMS_Order_Item_Task AS OIT INNER JOIN                                            
dbo.System_CommonList_Item AS CI ON OIT.CommonList_TMSOrderItemTaskTypeId = CI.ID INNER JOIN      
dbo.FMS_Equipment AS E ON OIT.Truck_FMS_EquipmentID = E.ID     
WHERE    OIT.TMS_Order_ItemID = [orderItem].ID and    CI.Keyword = ''TMS_Order_Type_Delivery''  ) as ''EquipmentNumber Delivery''           ,    
CASE            WHEN [pickupTimeType].Keyword in (''TMS_Order_TimeType_After'',''TMS_Order_TimeType_At'',''TMS_Order_TimeType_Before'',''TMS_Order_TimeType_Blank'')     
THEN CONCAT([pickupTimeType].Name,'' '',FORMAT(DATEADD(hour, @timeoffset, [order].PickupRequestedTimeToRange), ''MM/dd/yyyy hh:mm tt''))   
WHEN [pickupTimeType].Keyword =''TMS_Order_TimeType_Between''             THEN CONCAT([pickupTimeType].Name,'' '',      
FORMAT(DATEADD(hour, @timeoffset, [order].PickupRequestedTimeFromRange),''MM/dd/yyyy hh:mm tt'')           ,'' - '', FORMAT(DATEADD(hour, @timeoffset, [order].PickupRequestedTimeToRange),''MM/dd/yyyy hh:mm tt''))       
ELSE FORMAT(DATEADD(hour, @timeoffset, [order].PickupRequestedTimeToRange),''MM/dd/yyyy hh:mm tt'')           END as ''pTimeType''           ,       
CASE            WHEN [deliveryTimeType].Keyword in (''TMS_Order_TimeType_After'',''TMS_Order_TimeType_At'',''TMS_Order_TimeType_Before'',''TMS_Order_TimeType_Blank'')         
THEN CONCAT([deliveryTimeType].Name,'' '',           FORMAT(DATEADD(hour, @timeoffset, [order].DeliveryRequestedTimeToRange), ''MM/dd/yyyy hh:mm tt''))     
WHEN [deliveryTimeType].Keyword =''TMS_Order_TimeType_Between''             THEN CONCAT([deliveryTimeType].Name,'' '',   
FORMAT(DATEADD(hour, @timeoffset, [order].DeliveryRequestedTimeFromRange),''MM/dd/yyyy hh:mm tt''),            '' - '',   
FORMAT(DATEADD(hour, @timeoffset, [order].DeliveryRequestedTimeToRange),''MM/dd/yyyy hh:mm tt''))    
ELSE FORMAT(DATEADD(hour, @timeoffset, [order].DeliveryRequestedTimeToRange),''MM/dd/yyyy hh:mm tt'')     
END as ''dTimeType''                from  TMS_Order [order]            
join TMS_Order_Item [orderItem]  on [order].ID = [orderItem].TMS_OrderID      
--very inportance for filter status of OrderItem          
join System_CommonList_Item as [status] on [orderItem].CommonList_TMSOrderItemStatusID = [status].ID        
join CRM_Jobsite [jsPickup] on [order].Origin_CRM_JobsiteID = [jsPickup].Id                
join CRM_Jobsite [jsDelivery] on [order].Destination_CRM_JobsiteID = [jsDelivery].Id       
left join [dbo].[TMS_Order_Item_CustomData] [customdata] on [orderItem].ID = [customdata].TMS_Order_ItemID     
left join System_CommonList_Item [pickupTimeType] on [order].Pickup_CommonList_TimeTypeID = [pickupTimeType].Id    
left join System_CommonList_Item [deliveryTimeType] on [order].Delivery_CommonList_TimeTypeID = [deliveryTimeType].Id               
--left join [dbo].[FMS_Equipment] [equipmentstock] on [equipmentstock].ID =[customdata].StockNumber             
--left join [dbo].[FMS_Equipment] [equipmentmachine] on [equipmentmachine].ID =[customdata].Machine   
left join CRM_Customer [customer] on [customer].ID = [order].CRM_CustomerID       
left join CRM_Customer_Contact [contact] on [contact].ID = [order].CRM_Customer_ContactID    
left join CRM_Customer_Contact_Phone [phone] on [phone].CRM_Customer_ContactID = [contact].Id and [phone].IsPrimary= 1          
where [order].ID = @orderId       
--where [order].OrderNumber = ''15429''  
group by [customer].Name ,[contact].FirstName,[contact].LastName,[phone].PhoneNumber,[phone].Extension ,
[order].OrderNumber ,[orderItem].QuantityOrdered  ,[orderItem].Notes        
,[orderItem].UnitLengthInM,[orderItem].UnitWidthInM,[jsPickup].Name ,[jsPickup].Address,
[jsPickup].City,[jsPickup].State,[jsPickup].PostalCode,        
[jsPickup].ContactName,[jsPickup].ContactPhone,[jsPickup].ContactExtension,
[jsPickup].Note ,[jsDelivery].Name ,[jsDelivery].Address,[jsDelivery].City,    
[jsDelivery].State,[jsDelivery].PostalCode,[jsDelivery].ContactName,      
[jsDelivery].ContactPhone,[jsDelivery].ContactExtension, [jsDelivery].Note ,[orderItem].[FreightDescription]       
,[customdata].StockNumber       ,[customdata].Machine                ,[customdata].Make 
,[customdata].PIN 
,[customdata].Model                ,orderItem.Notes                ,orderItem.QuantityOrdered     
,[orderItem].UnitWeightInKG                ,[orderItem].UnitWeightInKG,[orderItem].QuantityOrdered     
,[orderItem].DateCreated        ,orderItem.OrderItemNumber       ,[status].Name    
,[orderItem].ID       ,[order].OriginJobsiteNotes       ,[order].DestinationJobsiteNotes    
,[pickupTimeType].Keyword       ,[pickupTimeType].Name       ,[order].PickupRequestedTimeToRange   
,[order].PickupRequestedTimeFromRange       ,[deliveryTimeType].Keyword    
,[deliveryTimeType].Name   															 
,[order].DeliveryRequestedTimeToRange     
,[order].DeliveryRequestedTimeFromRange  order by [orderItem].DateCreated', 'f85a4b2f-ed82-4436-8943-96548b2f0af5', '2015-03-03 00:00:00.000', '2015-03-03 00:00:00.000', 'f85a4b2f-ed82-4436-8943-96548b2f0af5', 0, 1)
