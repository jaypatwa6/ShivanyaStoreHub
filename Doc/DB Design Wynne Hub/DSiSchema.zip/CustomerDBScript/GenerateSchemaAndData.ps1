$InFileName = $args[0]
$OutFileName = $args[1]

$FileOriginal = Get-Content $InFileName

Set-Content -Path $OutFileName  -Encoding UTF8 -Value "use [DatabaseName]
GO
CREATE LOGIN DatabaseAdministratorName WITH PASSWORD = 'DatabaseAdministratorPassword';

GO
CREATE USER DatabaseAdministratorName FOR LOGIN DatabaseAdministratorName;

GO
EXEC sp_addrolemember N'db_owner', N'DatabaseAdministratorName'
GO

"

Add-Content -Path $OutFileName  -Encoding UTF8 -Value $FileOriginal

