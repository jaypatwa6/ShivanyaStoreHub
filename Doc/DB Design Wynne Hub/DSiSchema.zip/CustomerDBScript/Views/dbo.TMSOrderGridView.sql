SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE VIEW [dbo].[TMSOrderGridView]
AS
SELECT 
	_order.ID AS OrderID, 
	ISNULL(_orderItem.ID, NEWID()) AS OrderItemID, 
	ISNULL(_orderItem.CreatedBy, _order.CreatedBy) AS CreatedBy, 
	_order.Requester,
	CAST(ISNULL((SELECT FirstName + ' ' + LastName AS Expr1 FROM dbo.HR_Employee AS employee WHERE (ID = _order.Requester)), ISNULL((SELECT FirstName + ' ' + LastName AS Expr1 FROM [Master_Account_Login] WHERE (ID = _order.Requester)), (SELECT FirstName + ' ' + LastName AS Expr1 FROM  [Master_Account_Login] WHERE (ID = _orderItem.CreatedBy)))) AS NVARCHAR(250)) AS RequesterName, 
	CAST(ISNULL((SELECT FirstName + ' ' + LastName AS Expr1 FROM dbo.HR_Employee AS employee WHERE (ID = _orderItem.CreatedBy)), ISNULL((SELECT FirstName + ' ' + LastName AS Expr1 FROM [Master_Account_Login] WHERE (ID = _order.CreatedBy)), (SELECT FirstName + ' ' + LastName AS Expr1 FROM  [Master_Account_Login] WHERE (ID = _orderItem.CreatedBy)))) AS NVARCHAR(250)) AS CreatedByName, 
	ISNULL(_order.DateCreated, GETUTCDATE()) AS CreatedDate, 
	_orderItem.FreightDescription, 
	_order.OrderNumber, 
	ISNULL(_orderItem.QuantityOrdered, 0) AS Quantity, 
	dbo.CRM_Customer.Name AS CustomerName,
	_orderItem.ReferenceOrderItemDocumentNumbers AS ReferenceNo, 
	ISNULL(_orderItem.DateModified, GETUTCDATE()) AS ModifiedDate,
	ISNULL(_orderItem.CommonList_TMSOrderItemStatusID, (SELECT ID FROM dbo.System_CommonList_Item WHERE (Keyword = 'TMS_OrderItemStatus_Pending'))) AS TMSOrderItemStatusID, 
	OrderItemStatus.Name AS [Status], 
	OrderItemStatusColor.Color AS StatusTextColor, 
	PickupJobsite.Name AS PSite,
	COALESCE (NULLIF (PickupJobsite.City, ''), '') + ', ' + COALESCE (NULLIF (PickupJobsite.State, ''), '') AS PLocation, 
	PickupJobsite.[Address] AS PLocationAddress, 
	PickupJobsite.Latitude AS PLatitude,
	PickupJobsite.Longitude AS PLongitude, 
	PickupTimeType.Keyword AS PickupTimeTypeName, 
	_order.PickupRequestedTimeFromRange, 
	_order.PickupRequestedTimeToRange,
	PickupTask.ScheduledTime AS PScheduledTime,
	(SELECT FirstName + ' ' + LastName AS EmployeeName FROM dbo.HR_Employee WHERE (ID = PickupTask.Driver_HR_EmployeeID)) AS PDriverName,
	(SELECT ID FROM dbo.HR_Employee AS HR_Employee_3 WHERE (ID = PickupTask.Driver_HR_EmployeeID)) AS PDriverID,
	(SELECT Name FROM dbo.FMS_Equipment WHERE (ID = PickupTask.Truck_FMS_EquipmentID)) AS PTruckName,
	(SELECT Number FROM dbo.FMS_Equipment AS FMS_Equipment_9 WHERE (ID = PickupTask.Truck_FMS_EquipmentID)) AS PTruckNumber,
	(SELECT Name FROM dbo.FMS_Equipment AS FMS_Equipment_8 WHERE (ID = PickupTask.Trailer_FMS_EquipmentID)) AS PTrailerName,
	(SELECT Number FROM dbo.FMS_Equipment AS FMS_Equipment_7 WHERE (ID = PickupTask.Trailer_FMS_EquipmentID)) AS PTrailerNumber,
	(SELECT ID FROM dbo.FMS_Equipment AS FMS_Equipment_6 WHERE (ID = PickupTask.Truck_FMS_EquipmentID)) AS PTruckID, 
	DeliveryJobsite.Name AS DSite, 
	COALESCE (NULLIF (DeliveryJobsite.City, ''), '') + ', ' + COALESCE (NULLIF (DeliveryJobsite.State, ''), '') AS DLocation, 
	DeliveryJobsite.[Address] AS DLocationAddress, 
	DeliveryJobsite.Latitude AS DLatitude, 
	DeliveryJobsite.Longitude AS DLongitude, 
	DeliveryTimeType.Keyword AS DeliveryTimeTypeName,
	_order.DeliveryRequestedTimeFromRange, 
	_order.DeliveryRequestedTimeToRange,
	DeliveryTask.ScheduledTime AS DScheduledTime,
	(SELECT FirstName + ' ' + LastName AS Expr1 FROM dbo.HR_Employee AS HR_Employee_1 WHERE (ID = DeliveryTask.Driver_HR_EmployeeID)) AS DDriverName,
	(SELECT ID FROM dbo.HR_Employee AS HR_Employee_2 WHERE (ID = DeliveryTask.Driver_HR_EmployeeID)) AS DDriverID,
	(SELECT Name FROM dbo.FMS_Equipment AS FMS_Equipment_5 WHERE (ID = DeliveryTask.Truck_FMS_EquipmentID)) AS DTruckName,
	(SELECT Number FROM dbo.FMS_Equipment AS FMS_Equipment_4 WHERE (ID = DeliveryTask.Truck_FMS_EquipmentID)) AS DTruckNumber,
	(SELECT Name FROM dbo.FMS_Equipment AS FMS_Equipment_3 WHERE (ID = DeliveryTask.Trailer_FMS_EquipmentID)) AS DTrailerName,
	(SELECT Number FROM dbo.FMS_Equipment AS FMS_Equipment_2 WHERE (ID = DeliveryTask.Trailer_FMS_EquipmentID)) AS DTrailerNumber,
	(SELECT ID FROM dbo.FMS_Equipment AS FMS_Equipment_1 WHERE (ID = DeliveryTask.Truck_FMS_EquipmentID)) AS DTruckID,
	(SELECT TOP 1 DateCreated FROM TMS_Order_Event_Summary WHERE TMS_Order_Item_TaskID = PickupTask.ID AND CommonList_TMSOrderItemStatusID = (SELECT ID FROM dbo.System_CommonList_Item WHERE Keyword = 'TMS_OrderItemStatus_AtPickup') ORDER BY TMS_Order_Event_Summary.DateCreated DESC) AS PActualTime,
	(SELECT TOP 1 DateCreated FROM TMS_Order_Event_Summary WHERE TMS_Order_Item_TaskID = DeliveryTask.ID AND CommonList_TMSOrderItemStatusID = (SELECT ID FROM dbo.System_CommonList_Item WHERE Keyword = 'TMS_OrderItemStatus_AtDelivery') ORDER BY TMS_Order_Event_Summary.DateCreated DESC) AS DActualTime,
	(SELECT TOP 1 DateCreated FROM TMS_Order_Event_Summary WHERE TMS_Order_Item_TaskID = PickupTask.ID AND CommonList_TMSOrderItemStatusID = (SELECT ID FROM dbo.System_CommonList_Item WHERE Keyword = 'TMS_OrderItemStatus_Dispatched') ORDER BY TMS_Order_Event_Summary.DateCreated DESC) AS DispatchedTime,
	ItemCustomData.StockNumber,
	ItemCustomData.Machine, 
	ItemCustomData.Make, 
	ItemCustomData.Model, 
	ItemCustomData.Meter, 
	ItemCustomData.Integration_WorkOrderNo, 
	ItemCustomData.ShippedBy, 
	ItemCustomData.ReceivedBy,
	_orderItem.Notes AS FreightNote
FROM dbo.TMS_Order AS _order
	LEFT OUTER JOIN dbo.TMS_Order_Item as _orderItem ON _order.ID = _orderItem.TMS_OrderID 
	LEFT OUTER JOIN dbo.TMS_Order_Item_CustomData AS ItemCustomData ON ItemCustomData.TMS_Order_ItemID = _orderItem.ID 
	LEFT OUTER JOIN dbo.CRM_Jobsite AS PickupJobsite ON _order.Origin_CRM_JobsiteID = PickupJobsite.ID 
	LEFT OUTER JOIN dbo.CRM_Jobsite AS DeliveryJobsite ON _order.Destination_CRM_JobsiteID = DeliveryJobsite.ID 
	LEFT OUTER JOIN dbo.System_CommonList_Item AS PickupTimeType ON _order.Pickup_CommonList_TimeTypeID = PickupTimeType.ID 
	LEFT OUTER JOIN dbo.System_CommonList_Item AS DeliveryTimeType ON _order.Delivery_CommonList_TimeTypeID = DeliveryTimeType.ID 
	LEFT OUTER JOIN dbo.CRM_Customer ON _order.CRM_CustomerID = dbo.CRM_Customer.ID 
	LEFT OUTER JOIN dbo.System_CommonList_Item AS OrderItemStatus ON OrderItemStatus.ID = _orderItem.CommonList_TMSOrderItemStatusID 
	LEFT OUTER JOIN dbo.TMS_Order_Event_StatusMapping AS OrderItemStatusColor ON OrderItemStatusColor.CommonList_TMS_Order_Item_StatusId = _orderItem.CommonList_TMSOrderItemStatusID 
	LEFT OUTER JOIN dbo.TMS_Order_Item_Task AS PickupTask ON _orderItem.ID = PickupTask.TMS_Order_ItemID AND PickupTask.CommonList_TMSOrderItemTaskTypeId IN (SELECT ID FROM dbo.System_CommonList_Item WHERE (Keyword = 'TMS_Order_Type_Pickup')) 
	LEFT OUTER JOIN dbo.TMS_Order_Item_Task AS DeliveryTask ON _orderItem.ID = DeliveryTask.TMS_Order_ItemID AND DeliveryTask.CommonList_TMSOrderItemTaskTypeId IN (SELECT ID FROM dbo.System_CommonList_Item WHERE (Keyword = 'TMS_Order_Type_Delivery'))
WHERE _order.IsDelete=0 AND _orderItem.IsDelete=0

GO
