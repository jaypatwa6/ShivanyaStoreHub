SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE VIEW [dbo].[OPSAttachmentViewCustom]
AS
SELECT _attachment.ID, _attachment.DateCreated,  _attachment.DateModified, _attachment.CreatedBy, _attachment.ModifiedBy, _attachment.IsDelete,
_attachment.DisplayName, _attachment.FileName, _attachment.FileType, _attachment.FileSize, _attachment.DCM_PhysicalDocID as DCMPhysicalDocID, _attachment.Note, _attachment.StaticURL,
_attachment.CloudURL, _attachment.CloudThumbnailURL, _attachment.StorageSource, _attachment.IsShared, _attachment.ReferenceTable, _attachment.ReferenceForeignKeyID,
_attachment.DateSynchronized, _attachment.ReceivedBy, _attachment.ExtendedData, 

_attachment.CommonList_DocumentTypeID, DocumentType.Keyword as DocumentTypeKeyword, DocumentType.Sequence as DocumentTypeSequence, _attachment.CommonList_AttachmentTypeID, AttachmentType.Keyword as AttachmentTypeKeyword, 

COALESCE(_order.OrderNumber, _order1.OrderNumber, _workOrder.OrderNumber) AS ReferenceOrderNumber, COALESCE(_orderItem.OrderItemNumber, _orderItem1.OrderItemNumber) AS ReferenceOrderItemNumber,
_tristopTask.IsDeleted IsTaskDeleted, _tristopTask.DocumentNumbers TaskDocumentNumbers, _tristopTask.RefDoc_LoadNumber TaskLoadNumber, _tristopTask.RefDoc_OrderNumber TaskOrderNumber

FROM dbo.OPS_Attachment AS _attachment WITH (nolock) LEFT OUTER JOIN
		-- Common List
        dbo.System_CommonList_Item AS DocumentType WITH (nolock) ON _attachment.CommonList_DocumentTypeID = DocumentType.ID LEFT OUTER JOIN
		dbo.System_CommonList_Item AS AttachmentType WITH (nolock) ON _attachment.CommonList_AttachmentTypeID = AttachmentType.ID LEFT OUTER JOIN
		
		-- TMS
		dbo.TMS_Order_Item AS _orderItem WITH (nolock) 
			ON _attachment.ReferenceTable = 'TMS_Order_Item' AND _attachment.ReferenceForeignKeyID = _orderItem.ID LEFT OUTER JOIN
		dbo.TMS_Order AS _order WITH (nolock) ON _orderItem.TMS_OrderID = _order.ID LEFT OUTER JOIN

		-- MCS
		dbo.MCS_Trip_Stop_Task AS _tristopTask WITH (nolock) 
			ON _attachment.ReferenceTable = 'MCS_Trip_Stop_Task' AND _attachment.ReferenceForeignKeyID = _tristopTask.ID LEFT OUTER JOIN
		dbo.TMS_Order_Item_Task AS _orderItemTask1 WITH (nolock) ON _tristopTask.ID = _orderItemTask1.MCS_Trip_Stop_TaskID LEFT OUTER JOIN
		dbo.TMS_Order_Item AS _orderItem1 WITH (nolock) ON _orderItemTask1.TMS_Order_ItemID = _orderItem1.ID LEFT OUTER JOIN
		dbo.TMS_Order AS _order1 WITH (nolock) ON _orderItem1.TMS_OrderID = _order1.ID LEFT OUTER JOIN

		-- WSS
		dbo.OPS_WorkOrder_Task AS _woTask WITH (nolock)
			ON _attachment.ReferenceTable = 'OPS_WorkOrder_Task' AND _attachment.ReferenceForeignKeyID = _woTask.ID LEFT OUTER JOIN
		dbo.OPS_WorkOrder AS _workOrder WITH (nolock) ON _woTask.OPS_WorkOrderID = _workOrder.ID LEFT OUTER JOIN

		-- Employee
		dbo.HR_Employee AS _employee WITH (nolock) ON _attachment.ReferenceTable = 'HR_Employee' AND _attachment.ReferenceForeignKeyID = _employee.ID
WHERE  (_attachment.IsDelete <> 1)

GO
