SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE VIEW [dbo].[TMSSchedulerGridView]
AS
select 
emp.ID as EmployeeId,
emp.DriverStartLocation,
(SELECT emp.FirstName + ' ' + emp.LastName) as Driver,
emp.IsActive as IsDriverActive,
[order].ID as OrderId,
orderItem.ID as OrderItemId,
task.ID as TaskId,
task.ScheduledTime as TaskScheduledTime,
task.TaskLocation_CRM_JobsiteID as TaskLocationCRMJobsiteID,
jobSite.City as TaskLocationCRMJobsiteCity,
task.CommonList_TMSOrderItemTaskTypeId as TaskTypeId,
comTaskType.Keyword as TaskTypeKeyword,
(ISNULL(task.StopDuration, (select value from [dbo].[System_Setting] where Keyword='TMS.Scheduler.DefaultStopDuration'))) as StopDuration,
comOrderItemStatus.Name as OrderItemStatus,
crmJobsite.Longitude as JobsiteLongitude,
crmJobsite.Latitude as JobsiteLatitude

from [dbo].[HR_Employee] emp
join [dbo].[System_CommonList_Item] comEmployeeType on emp.CommonList_EmployeeTypeID = comEmployeeType.ID
left join [dbo].[TMS_Order_Item_Task] task on emp.ID = task.Driver_HR_EmployeeID
left join [dbo].[TMS_Order_Item] orderItem on task.TMS_Order_ItemID = orderItem.ID
left join [dbo].[TMS_Order] [order] on orderItem.TMS_OrderID = [order].ID
left join [dbo].[CRM_Jobsite] jobSite on task.TaskLocation_CRM_JobsiteID = jobSite.ID
left join [dbo].[System_CommonList_Item] comTaskType on task.CommonList_TMSOrderItemTaskTypeId = comTaskType.ID
left join [dbo].[System_CommonList_Item] comOrderItemStatus on orderItem.CommonList_TMSOrderItemStatusID = comOrderItemStatus.ID
left join [dbo].[CRM_Jobsite] crmJobsite on task.TaskLocation_CRM_JobsiteID = crmJobsite.ID
where comEmployeeType.Keyword='HR_EmployeeType_Driver'
and task.IsDelete=0 and orderItem.IsDelete=0 and [order].IsDelete=0
GO
