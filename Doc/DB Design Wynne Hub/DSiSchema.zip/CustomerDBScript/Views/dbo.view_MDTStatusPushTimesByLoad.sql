SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE VIEW [dbo].[view_MDTStatusPushTimesByLoad]
AS

SELECT [Order].Id AS TMS_OrderID
	, [OrderItem].Id AS TMS_Order_ItemID
	, [order].OrderNumber
	, [OrderItem].OrderItemNumber AS OrderItemNumber
	, ISNULL(emp.FirstName,'')  + ' ' + ISNULL(emp.LastName,'') AS DriverName
	, emp.ID AS DriverID
	, [OrderItem].CommonList_TMSOrderItemStatusID
	, [Order].CRM_CustomerID
	, ( 
		SELECT Count(*)
		FROM TMS_Order_Event_Summary [taskEvent]
		WHERE TMS_Order_ItemId = [OrderItem].ID
	) AS Key5Buttons
	, (
		SELECT tt.ScheduledTime
		FROM TMS_Order_Item_Task tt
			INNER JOIN System_CommonList_Item ss on ss.Id = tt.CommonList_TMSOrderItemTaskTypeId
		WHERE tt.TMS_Order_ItemID = [OrderItem].Id and ss.Keyword = 'TMS_Order_Type_Pickup'
	) AS [PickupSchedule]
	, (
		SELECT tt.ScheduledTime
		FROM TMS_Order_Item_Task tt
			INNER JOIN System_CommonList_Item ss on ss.Id = tt.CommonList_TMSOrderItemTaskTypeId
		WHERE tt.TMS_Order_ItemID = [OrderItem].Id and ss.Keyword = 'TMS_Order_Type_Delivery'
	) AS [DeliverySchedule]
	,(
		SELECT MAX([taskEvent].DATECREATED)
		FROM TMS_Order_Event_Summary [taskEvent]
			INNER JOIN System_CommonList_Item ss on ss.Id = [taskEvent].CommonList_TMSOrder_Item_Task_StatusId
		WHERE TMS_Order_ItemId = [OrderItem].ID and ss.Keyword = 'TMS_OrderItemStatus_OutForPickup'
	) AS [OutForPickup]
	,(
		SELECT MAX([taskEvent].DATECREATED)
		FROM TMS_Order_Event_Summary [taskEvent]
			INNER JOIN System_CommonList_Item ss on ss.Id = [taskEvent].CommonList_TMSOrder_Item_Task_StatusId
		WHERE TMS_Order_ItemId = [OrderItem].ID and ss.Keyword = 'TMS_OrderItemStatus_AtPickup'
	) AS [AtPickup]
	,(
		SELECT MAX([taskEvent].DATECREATED)
		FROM TMS_Order_Event_Summary [taskEvent]
			INNER JOIN System_CommonList_Item ss on ss.Id = [taskEvent].CommonList_TMSOrder_Item_Task_StatusId
		WHERE TMS_Order_ItemId = [OrderItem].ID and ss.Keyword = 'TMS_OrderItemStatus_PickupComplete'
	) AS [PickupComplete]
	,(
		SELECT MAX([taskEvent].DATECREATED)
		FROM TMS_Order_Event_Summary [taskEvent]
			INNER JOIN System_CommonList_Item ss on ss.Id = [taskEvent].CommonList_TMSOrder_Item_Task_StatusId
		WHERE TMS_Order_ItemId = [OrderItem].ID and ss.Keyword = 'TMS_OrderItemStatus_AtDelivery'
	) AS [AtDelivery]
	,(
		SELECT MAX([taskEvent].DATECREATED)
		FROM TMS_Order_Event_Summary [taskEvent]
			INNER JOIN System_CommonList_Item ss on ss.Id = [taskEvent].CommonList_TMSOrder_Item_Task_StatusId
		WHERE TMS_Order_ItemId = [OrderItem].ID and ss.Keyword = 'TMS_OrderItemStatus_OutForDelivery'
	) AS [OutForDelivery]
	,(
		SELECT MAX([taskEvent].DATECREATED)
		FROM TMS_Order_Event_Summary [taskEvent]
			INNER JOIN System_CommonList_Item ss on ss.Id = [taskEvent].CommonList_TMSOrder_Item_Task_StatusId
		WHERE TMS_Order_ItemId = [OrderItem].ID and ss.Keyword = 'TMS_OrderItemStatus_DeliveryComplete'
	) AS [DeliveryComplete]
FROM TMS_Order_Item [OrderItem]
	INNER JOIN TMS_Order [Order] on [Order].ID = [OrderItem].TMS_OrderID
	INNER JOIN dbo.TMS_Order_Item_Task AS task ON task.TMS_Order_ItemID = [OrderItem].ID
	INNER JOIN HR_Employee AS emp on emp.ID = task.Driver_HR_EmployeeID
	INNER JOIN dbo.System_CommonList_Item AS comEmployeeType ON emp.CommonList_EmployeeTypeID = comEmployeeType.ID 
																AND comEmployeeType.Keyword in ('HR_EmployeeType_Driver','HR_EmployeeType_SubHauler')
	INNER JOIN dbo.System_Organization Org on emp.System_OrganizationID = org.Id AND org.[Name] like '%Rent%'
WHERE	[Order].IsDelete = 0
		AND [OrderItem].IsDelete = 0 
GROUP BY
	[Order].ID,
	[Order].OrderNumber,
	[OrderItem].Id,		
	[OrderItem].OrderItemNumber,
	[OrderItem].CommonList_TMSOrderItemStatusID,
	[Order].CRM_CustomerID,
	emp.Id,
	emp.FirstName,
	emp.LastName


GO
