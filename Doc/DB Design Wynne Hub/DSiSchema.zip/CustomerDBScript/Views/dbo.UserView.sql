SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE VIEW [dbo].[UserView]
AS
SELECT
	a.ID AS AccountId, 
	a.AccountName,
	u.Id AS UserId,
	u.UserName,
	u.[Password], 
	u.Hashkey,
	 u.FirstName AS UserFirstName, 
	 u.LastName AS UserLastName, 
	 u.Email AS UserEmail, 
	 u.[Address] AS UserAddress1, 
	 u.Address2 AS UserAddress2, 
	 u.City AS UserCity, 
	 u.[State] AS UserState, 
     u.PostalCode AS UserPostalCode, 
	 u.Phone AS UserPhone ,
	 u.CellPhone AS UserCellPhone, 
	u.Note AS UserNote, 
	u.TimeZone AS UserTimeZone,
	u.IsPrimary AS UserIsPrimary,
	e.Id AS EmployeeId,
	e.Number AS EmployeeNumber,
	e.FirstName AS EmployeeFirstName,
	e.LastName AS EmployeeLastName,
	ce.ID AS EmployeeTypeId,
	ce.Name AS EmployeeTypeName
FROM Master_Account_Login AS u 
	JOIN Master_Account AS a  ON a.ID = u.AccountID
	LEFT JOIN dbo.HR_Employee AS e  ON e.Account_LoginID = u.ID
	LEFT JOIN dbo.System_CommonList_Item ce ON ce.ID = e.CommonList_EmployeeTypeID
WHERE 
	a.ID = SUBSTRING(SUBSTRING(SUBSTRING(DB_NAME(), CHARINDEX('_', DB_NAME()) + 1, LEN(DB_NAME())), CHARINDEX('_', SUBSTRING(DB_NAME(), CHARINDEX('_', DB_NAME()) + 1, LEN(DB_NAME()))) + 1, LEN(SUBSTRING(DB_NAME(), CHARINDEX('_', DB_NAME()) + 1, LEN(DB_NAME())))), 0, CHARINDEX('_', SUBSTRING(SUBSTRING(DB_NAME(), CHARINDEX('_', DB_NAME()) + 1, LEN(DB_NAME())), CHARINDEX('_', SUBSTRING(DB_NAME(), CHARINDEX('_', DB_NAME()) + 1, LEN(DB_NAME()))) + 1, LEN(SUBSTRING(DB_NAME(), CHARINDEX('_', DB_NAME()) + 1, LEN(DB_NAME())))))) 
	AND u.AccountID = SUBSTRING(SUBSTRING(SUBSTRING(DB_NAME(), CHARINDEX('_', DB_NAME()) + 1, LEN(DB_NAME())), CHARINDEX('_', SUBSTRING(DB_NAME(), CHARINDEX('_', DB_NAME()) + 1, LEN(DB_NAME()))) + 1, LEN(SUBSTRING(DB_NAME(), CHARINDEX('_', DB_NAME()) + 1, LEN(DB_NAME())))), 0, CHARINDEX('_', SUBSTRING(SUBSTRING(DB_NAME(), CHARINDEX('_', DB_NAME()) + 1, LEN(DB_NAME())), CHARINDEX('_', SUBSTRING(DB_NAME(), CHARINDEX('_', DB_NAME()) + 1, LEN(DB_NAME()))) + 1, LEN(SUBSTRING(DB_NAME(), CHARINDEX('_', DB_NAME()) + 1, LEN(DB_NAME()))))))
GO
