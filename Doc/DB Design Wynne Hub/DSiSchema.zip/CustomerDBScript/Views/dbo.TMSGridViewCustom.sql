SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE VIEW [dbo].[TMSGridViewCustom]
AS
SELECT _order.ID AS OrderID, _orderItem.ID, _orderItem.CreatedBy, _order.Requester, CAST(ISNULL
                      ((SELECT FirstName + ' ' + LastName AS Expr1
                        FROM      dbo.HR_Employee AS employee
                        WHERE   (ID = _order.Requester)), ISNULL
                      ((SELECT FirstName + ' ' + LastName AS Expr1
                        FROM      dbo.Master_Account_Login
                        WHERE   (ID = _order.Requester)),
                      (SELECT FirstName + ' ' + LastName AS Expr1
                       FROM      dbo.Master_Account_Login AS Master_Account_Login_3
                       WHERE   (ID = _orderItem.CreatedBy)))) AS NVARCHAR(250)) AS RequesterName, CAST(ISNULL
                      ((SELECT FirstName + ' ' + LastName AS Expr1
                        FROM      dbo.HR_Employee AS employee
                        WHERE   (ID = _orderItem.CreatedBy)), ISNULL
                      ((SELECT FirstName + ' ' + LastName AS Expr1
                        FROM      dbo.Master_Account_Login AS Master_Account_Login_2
                        WHERE   (ID = _order.CreatedBy)),
                      (SELECT FirstName + ' ' + LastName AS Expr1
                       FROM      dbo.Master_Account_Login AS Master_Account_Login_1
                       WHERE   (ID = _orderItem.CreatedBy)))) AS NVARCHAR(250)) AS CreatedByName, _orderItem.DateCreated, _orderItem.FreightDescription, _order.OrderNumber, dbo.CRM_Customer.Name AS CustomerName, dbo.CRM_Customer.Number AS CustomerNumber,_orderItem.DateModified, 
                  PickupJobsite.Name AS PSite, PickupJobsite.Address AS PLocationAddress, _order.PickupRequestedTimeFromRange, _order.PickupRequestedTimeToRange, PickupTask.ScheduledTime AS PScheduledTime,
                      (SELECT FirstName + ' ' + LastName AS EmployeeName
                       FROM      dbo.HR_Employee
                       WHERE   (ID = PickupTask.Driver_HR_EmployeeID)) AS PDriverName, PickupTask.Driver_HR_EmployeeID AS PDriverID,
                      (SELECT Number
                       FROM      dbo.FMS_Equipment AS FMS_Equipment_9
                       WHERE   (ID = PickupTask.Truck_FMS_EquipmentID)) AS PTruckNumber,
                      (SELECT Number
                       FROM      dbo.FMS_Equipment AS FMS_Equipment_7
                       WHERE   (ID = PickupTask.Trailer_FMS_EquipmentID)) AS PTrailerNumber, PickupTask.Truck_FMS_EquipmentID AS PTruckID, DeliveryJobsite.Name AS DSite, DeliveryJobsite.Address AS DLocationAddress, 
                  _order.DeliveryRequestedTimeFromRange, _order.DeliveryRequestedTimeToRange, DeliveryTask.ScheduledTime AS DScheduledTime,
                      (SELECT FirstName + ' ' + LastName AS Expr1
                       FROM      dbo.HR_Employee AS HR_Employee_1
                       WHERE   (ID = DeliveryTask.Driver_HR_EmployeeID)) AS DDriverName, DeliveryTask.Driver_HR_EmployeeID AS DDriverID,
                      (SELECT Number
                       FROM      dbo.FMS_Equipment AS FMS_Equipment_4
                       WHERE   (ID = DeliveryTask.Truck_FMS_EquipmentID)) AS DTruckNumber,
                      (SELECT Number
                       FROM      dbo.FMS_Equipment AS FMS_Equipment_2
                       WHERE   (ID = DeliveryTask.Trailer_FMS_EquipmentID)) AS DTrailerNumber, ItemCustomData.StockNumber, ItemCustomData.Machine, ItemCustomData.Make, ItemCustomData.Model, ItemCustomData.Integration_WorkOrderNo, ItemCustomData.EstimatedInMin, 
                  ItemCustomData.PIN, _orderItem.Notes AS FreightNote, _order.CommonList_TMSOrderTypeID, ItemCustomData.Type, _order.CRM_CustomerID, PickupTask.ID AS PID, DeliveryTask.ID AS DID, _order.System_OrganizationID, 
                  _orderItem.CommonList_TMSOrderItemStatusID, _order.CommonList_TMSOrderStatusID, _order.CommonListItem_PriorityStatusID, _orderItem.OrderItemNumber, ISNULL(dbo.CRM_Customer.Tags, N'') AS CustomerTags, 
                  ISNULL(DeliveryJobsite.Tags, N'') AS DTags, ISNULL(PickupJobsite.Tags, N'') AS PTags, ItemCustomData.Integration_Application, _order.Dispatcher,
					  (SELECT FirstName + ' ' + LastName AS Expr1
                       FROM      dbo.HR_Employee AS employee
                       WHERE   (ID = _order.Dispatcher)) AS DispatcherName, ISNULL(_orderItem.QuantityOrdered, 0) AS QuantityOrdered, 
                  dbo.System_Organization.Name AS OrgName, _order.DateCreated AS OrderDateCreated, _order.Pickup_CommonList_TimeTypeID, _order.Delivery_CommonList_TimeTypeID, dbo.TMS_Order_CustomData.CustomerJobNo, 
                  dbo.TMS_Order_CustomData.Integration_WorkOrderNo AS Order_Integration_WorkOrderNo, dbo.TMS_Order_CustomData.Integration_Application AS Order_Integration_Application, _order.PurchaseOrder, _order.BillOfLading, 
                  _order.InvoicedDate, _order.InvoicedNumber, _orderItem.TotalTripDurationInMin, _orderItem.TotalTripDistanceInKM, OrderType.Name AS OrderTypeName, OrderItemStatus.Name AS OrderItemStatusName, _order.CommonList_TMSDispatchWindowTypeID, OrderDispatchWindowType.Name AS OrderDispatchWindowTypeName,
                  PickupTask.Trailer_FMS_EquipmentID AS PTrailerID, DeliveryTask.Trailer_FMS_EquipmentID AS DTrailerID, DeliveryTask.Truck_FMS_EquipmentID AS DTruckID,
                      (SELECT Number
                       FROM      dbo.HR_Employee AS HR_Employee_4
                       WHERE   (ID = PickupTask.Driver_HR_EmployeeID)) AS PDriverNumber,
                      (SELECT Number
                       FROM      dbo.HR_Employee AS HR_Employee_5
                       WHERE   (ID = DeliveryTask.Driver_HR_EmployeeID)) AS DDriverNumber, DeliveryJobsite.ID AS DSiteID, PickupJobsite.City AS PLocationCity, PickupJobsite.State AS PLocationState, PickupJobsite.PostalCode AS PLocationPostalCode, 
                  PickupJobsite.ID AS PSiteID, DeliveryJobsite.City AS DLocationCity, DeliveryJobsite.State AS DLocationState, DeliveryJobsite.PostalCode AS DLocationPostalCode, _orderItem.ModifiedBy, _orderItem.ShipWeightInPound AS ShipWeightInKG, 
                  DeliveryJobsite.Longitude AS DLongitude, DeliveryJobsite.Latitude AS DLatitude, PickupJobsite.Longitude AS PLongitude, PickupJobsite.Latitude AS PLatitude
FROM     dbo.TMS_Order AS _order WITH (nolock) INNER JOIN
                  dbo.TMS_Order_Item AS _orderItem WITH (nolock) ON _order.ID = _orderItem.TMS_OrderID LEFT OUTER JOIN
                  dbo.TMS_Order_Item_CustomData AS ItemCustomData WITH (nolock) ON ItemCustomData.TMS_Order_ItemID = _orderItem.ID LEFT OUTER JOIN
                  dbo.TMS_Order_CustomData WITH (nolock) ON _order.ID = dbo.TMS_Order_CustomData.TMS_OrderID LEFT OUTER JOIN
                  dbo.System_Organization WITH (nolock) ON _order.System_OrganizationID = dbo.System_Organization.ID LEFT OUTER JOIN
                  dbo.CRM_Customer WITH (nolock) ON _order.CRM_CustomerID = dbo.CRM_Customer.ID LEFT OUTER JOIN
                  dbo.System_CommonList_Item AS OrderType WITH (nolock) ON _order.CommonList_TMSOrderTypeID = OrderType.ID LEFT OUTER JOIN
				  dbo.System_CommonList_Item AS OrderItemStatus WITH (nolock) ON _orderItem.CommonList_TMSOrderItemStatusID = OrderItemStatus.ID LEFT OUTER JOIN
				  dbo.System_CommonList_Item AS OrderDispatchWindowType WITH (nolock) ON _order.CommonList_TMSDispatchWindowTypeID = OrderDispatchWindowType.ID LEFT OUTER JOIN
                  dbo.TMS_Order_Item_Task AS PickupTask WITH (nolock) ON _orderItem.ID = PickupTask.TMS_Order_ItemID AND PickupTask.CommonList_TMSOrderItemTaskTypeId IN
                      (SELECT ID
                       FROM      dbo.System_CommonList_Item
                       WHERE   (Keyword = 'TMS_Order_Type_Pickup')) LEFT OUTER JOIN
                  dbo.TMS_Order_Item_Task AS DeliveryTask WITH (nolock) ON _orderItem.ID = DeliveryTask.TMS_Order_ItemID AND DeliveryTask.CommonList_TMSOrderItemTaskTypeId IN
                      (SELECT ID
                       FROM      dbo.System_CommonList_Item
                       WHERE   (Keyword = 'TMS_Order_Type_Delivery')) LEFT OUTER JOIN
                  dbo.CRM_Jobsite AS DeliveryJobsite WITH (nolock) ON DeliveryTask.TaskLocation_CRM_JobsiteID = DeliveryJobsite.ID LEFT OUTER JOIN
                  dbo.CRM_Jobsite AS PickupJobsite WITH (nolock) ON PickupTask.TaskLocation_CRM_JobsiteID = PickupJobsite.ID
WHERE  (_order.IsDelete <> 1) AND (_orderItem.IsDelete <> 1)

GO
