SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE VIEW [dbo].[v_elog_DailyReportDetail]  
AS  
SELECT        scli.Keyword, fedrd.ID, fedrd.StartTime, fedrd.StartTimeKey, fedrd.EndTime, fedrd.HR_EmployeeID, fedrd.Is16HourRuleException, fedrd.IsAdverseDriving, fedrd.IsOversizedLoad, fedrd.MCS_EventSummaryID, fedrd.DistanceInKM, 
                         fedrd.IsInterstateLoad, fedrd.FMS_Elog_CoDriversID, fedrd.FMS_Elog_DailyReportID, fedrd.IsApproved
FROM            dbo.FMS_Elog_DailyReport_Detail AS fedrd INNER JOIN
                         dbo.System_CommonList_Item AS scli ON scli.ID = fedrd.CommonList_ElogStatusTypeID
WHERE        (fedrd.ELD_EventRecordStatus = 1)
GO
