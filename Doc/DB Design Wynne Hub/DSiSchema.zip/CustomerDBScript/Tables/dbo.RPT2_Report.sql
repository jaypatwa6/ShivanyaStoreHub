CREATE TABLE [dbo].[RPT2_Report]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_RW2_Cus_Report_Id] DEFAULT (newsequentialid()),
[Name] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CategoryKeyword] [uniqueidentifier] NULL,
[Description] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsSystem] [bit] NOT NULL,
[IsUsedQuarter] [bit] NULL,
[IsActive] [bit] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL,
[DateModified] [datetime] NOT NULL,
[Account_LoginID] [uniqueidentifier] NULL,
[UserGroupID] [bigint] NULL,
[ReportSetting] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ReportDataSourceID] [uniqueidentifier] NOT NULL,
[ModuleID] [uniqueidentifier] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[RPT2_Report] ADD CONSTRAINT [PK_RPT2_Report] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
