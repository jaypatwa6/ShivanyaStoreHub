CREATE TABLE [dbo].[SFE_UserProcess]
(
[CurrentStep] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CurrentOutput] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsCompleted] [bit] NOT NULL CONSTRAINT [DF_SFE_UserProcess_IsCompleted] DEFAULT ((0)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_SFE_UserProcess_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_SFE_UserProcess_DateModified] DEFAULT (getutcdate()),
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__SFE_UserProc__ID__075714DC] DEFAULT (newsequentialid()),
[BussinessProcessID] [uniqueidentifier] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[SFE_UserProcess] ADD CONSTRAINT [PK_SFE_UserProcess] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[SFE_UserProcess] ADD CONSTRAINT [FK_SFE_UserProcess__BussinessProcessID_X_SFE_BussinessProcess__ID] FOREIGN KEY ([BussinessProcessID]) REFERENCES [dbo].[SFE_BussinessProcess] ([ID]) ON DELETE CASCADE
GO
