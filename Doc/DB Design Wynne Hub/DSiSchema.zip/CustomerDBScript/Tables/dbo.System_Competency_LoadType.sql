CREATE TABLE [dbo].[System_Competency_LoadType]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__System_Competency_LoadType__ID] DEFAULT (newsequentialid()),
[System_CompetencyID] [uniqueidentifier] NOT NULL,
[CommonList_LoadTypeID] [uniqueidentifier] NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_System_Competency_LoadType_IsActive] DEFAULT ((1)),
[IsDelete] [bit] NULL CONSTRAINT [DF_System_Competency_LoadType_IsDelete] DEFAULT ((0)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_System_Competency_LoadType_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_System_Competency_LoadType_DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Competency_LoadType] ADD CONSTRAINT [PK__System_Competency_LoadType] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Competency_LoadType] WITH NOCHECK ADD CONSTRAINT [FK__System_Competency_LoadType__CommonList_LoadTypeID__X__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_LoadTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[System_Competency_LoadType] WITH NOCHECK ADD CONSTRAINT [FK__System_Competency_LoadType__System_CompetencyID__X__System_Competency__ID] FOREIGN KEY ([System_CompetencyID]) REFERENCES [dbo].[System_Competency] ([ID])
GO
