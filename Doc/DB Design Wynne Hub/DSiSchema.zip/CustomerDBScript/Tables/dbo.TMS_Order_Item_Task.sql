CREATE TABLE [dbo].[TMS_Order_Item_Task]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__TMS_Order_Item_Task__ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__TMS_Order_Item_Task__DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__TMS_Order_Item_Task__DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[TMS_Order_ItemID] [uniqueidentifier] NOT NULL,
[PredecessorOrderItemTaskID] [uniqueidentifier] NULL,
[Driver_HR_EmployeeID] [uniqueidentifier] NULL,
[Truck_FMS_EquipmentID] [uniqueidentifier] NULL,
[Trailer_FMS_EquipmentID] [uniqueidentifier] NULL,
[Accessory_FMS_EquipmentID] [uniqueidentifier] NULL,
[Freight_FMS_EquipmentID] [uniqueidentifier] NULL,
[ScheduledTime] [datetime] NULL,
[QuantityScheduled] [decimal] (18, 2) NULL,
[QuantityCompleted] [decimal] (18, 2) NULL,
[CommonList_TMSFreigthUnitID] [uniqueidentifier] NULL,
[MCS_Trip_Stop_TaskID] [uniqueidentifier] NULL,
[ReferenceOrderItemTaskDocumentNumbers] [xml] NULL,
[TaskLocation_CRM_JobsiteID] [uniqueidentifier] NULL,
[CommonList_TMSOrderItemTaskTypeId] [uniqueidentifier] NULL,
[ShipWeightInKG] [decimal] (18, 2) NULL,
[ShipHeightInM] [decimal] (18, 2) NULL,
[ShipWidthInM] [decimal] (18, 2) NULL,
[ShipLengthInM] [decimal] (18, 2) NULL,
[StopDuration] [decimal] (18, 2) NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__TMS_Order_Item_Task__IsDelete] DEFAULT ((0)),
[IsAssignOnly] [bit] NOT NULL CONSTRAINT [DF__TMS_Order__IsAss__63112973] DEFAULT ((0)),
[DateTimeDriverEnroute] [datetime] NULL,
[DateTimeDriverArrived] [datetime] NULL,
[DateTimeDriverCompleted] [datetime] NULL,
[CommonList_TMSOrderItemTaskStatusID] [uniqueidentifier] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_Order_Item_Task] ADD CONSTRAINT [PK__TMS_Order_Item_Task] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Item_Task__Accessory_FMS_EquipmentID] ON [dbo].[TMS_Order_Item_Task] ([Accessory_FMS_EquipmentID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Item_Task__DateCreated] ON [dbo].[TMS_Order_Item_Task] ([DateCreated]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Item_Task__Driver_HR_EmployeeID] ON [dbo].[TMS_Order_Item_Task] ([Driver_HR_EmployeeID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Item_Task__Freight_FMS_EquipmentID] ON [dbo].[TMS_Order_Item_Task] ([Freight_FMS_EquipmentID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Item_Task__IsDelete_X_DriveR_HR_EmployeeID_X_TMS_OLrder_ItemID] ON [dbo].[TMS_Order_Item_Task] ([IsDelete], [Driver_HR_EmployeeID], [TMS_Order_ItemID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Item_Task__MCS_Trip_Stop_TaskID] ON [dbo].[TMS_Order_Item_Task] ([MCS_Trip_Stop_TaskID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Item_Task__ScheduledTime_X_Driver_HR_EmployeeID_X_IsDelete_X_TMS_OrdeR_ItemID] ON [dbo].[TMS_Order_Item_Task] ([ScheduledTime], [Driver_HR_EmployeeID], [IsDelete], [TMS_Order_ItemID]) INCLUDE ([Truck_FMS_EquipmentID], [IsAssignOnly]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Item_Task__TaskLocation_CRM_JobsiteID] ON [dbo].[TMS_Order_Item_Task] ([TaskLocation_CRM_JobsiteID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Item_Task__TMS_Order_ItemID] ON [dbo].[TMS_Order_Item_Task] ([TMS_Order_ItemID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_TMS_Order_Item_Task_FullCover] ON [dbo].[TMS_Order_Item_Task] ([TMS_Order_ItemID], [ScheduledTime], [CommonList_TMSOrderItemTaskTypeId]) INCLUDE ([TaskLocation_CRM_JobsiteID], [Driver_HR_EmployeeID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Item_Task__TMS_OrderItemID_X_ScheduledTime_X_Truck_FMS_EquipmentID] ON [dbo].[TMS_Order_Item_Task] ([TMS_Order_ItemID], [ScheduledTime], [Truck_FMS_EquipmentID]) INCLUDE ([CommonList_TMSOrderItemTaskTypeId]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Item_Task__TMS_Order_ItemID_X_Truck_FMS_EquipmentID] ON [dbo].[TMS_Order_Item_Task] ([TMS_Order_ItemID], [Truck_FMS_EquipmentID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Item_Task__Trailer_FMS_EquipmentID] ON [dbo].[TMS_Order_Item_Task] ([Trailer_FMS_EquipmentID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Item_Task__Truck_FMS_EquipmentID] ON [dbo].[TMS_Order_Item_Task] ([Truck_FMS_EquipmentID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_Order_Item_Task] ADD CONSTRAINT [FK__TMS_Order_Item_Task__Accessory_FMS_EquipmentID__x__FMS_Equipment__ID] FOREIGN KEY ([Accessory_FMS_EquipmentID]) REFERENCES [dbo].[FMS_Equipment] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order_Item_Task] ADD CONSTRAINT [FK__TMS_Order_Item_Task__CommonList_TMSFreigthUnitID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_TMSFreigthUnitID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order_Item_Task] ADD CONSTRAINT [FK__TMS_Order_Item_Task__CommonList_TMSOrderItemTaskTypeId__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_TMSOrderItemTaskTypeId]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order_Item_Task] ADD CONSTRAINT [FK__TMS_Order_Item_Task__Driver_HR_EmployeeID__x__HR_Employee__ID] FOREIGN KEY ([Driver_HR_EmployeeID]) REFERENCES [dbo].[HR_Employee] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order_Item_Task] ADD CONSTRAINT [FK__TMS_Order_Item_Task__Freight_FMS_EquipmentID__x__FMS_Equipment__ID] FOREIGN KEY ([Freight_FMS_EquipmentID]) REFERENCES [dbo].[FMS_Equipment] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order_Item_Task] ADD CONSTRAINT [FK__TMS_Order_Item_Task__MCS_Trip_Stop_TaskID__x__MCS_Trip_Stop_Task__ID] FOREIGN KEY ([MCS_Trip_Stop_TaskID]) REFERENCES [dbo].[MCS_Trip_Stop_Task] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order_Item_Task] ADD CONSTRAINT [FK__TMS_Order_Item_Task__TaskLocation_CRM_JobsiteID__x__CRM_Jobsite__ID] FOREIGN KEY ([TaskLocation_CRM_JobsiteID]) REFERENCES [dbo].[CRM_Jobsite] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order_Item_Task] ADD CONSTRAINT [FK__TMS_Order_Item_Task__TMS_Order_ItemID__x__TMS_Order_Item__ID] FOREIGN KEY ([TMS_Order_ItemID]) REFERENCES [dbo].[TMS_Order_Item] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order_Item_Task] ADD CONSTRAINT [FK__TMS_Order_Item_Task__Trailer_FMS_EquipmentID__x__FMS_Equipment__ID] FOREIGN KEY ([Trailer_FMS_EquipmentID]) REFERENCES [dbo].[FMS_Equipment] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order_Item_Task] ADD CONSTRAINT [FK__TMS_Order_Item_Task__Truck_FMS_EquipmentID__x__FMS_Equipment__ID] FOREIGN KEY ([Truck_FMS_EquipmentID]) REFERENCES [dbo].[FMS_Equipment] ([ID])
GO
