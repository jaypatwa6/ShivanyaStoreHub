CREATE TABLE [dbo].[System_CommonList_Item]
(
[IsActive] [bit] NOT NULL CONSTRAINT [DF_System_CommonList_Items_IsActive] DEFAULT ((1)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_System_CommonList_Items_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_System_CommonList_Items_DateModified] DEFAULT (getutcdate()),
[Name] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Keyword] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Description] [nvarchar] (400) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ExtendedData] [nvarchar] (400) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Sequence] [int] NULL,
[IsSystemItem] [bit] NOT NULL CONSTRAINT [DF_System_CommonListItems_IsSystemItem] DEFAULT ((1)),
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__System_Commo__ID__7ED7A8CB] DEFAULT (newsequentialid()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[System_CommonListID] [uniqueidentifier] NOT NULL,
[TranslationKeyword] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_CommonList_Item] ADD CONSTRAINT [PK_System_CommonList_Item] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__System_CommonList_Item__Keyword] ON [dbo].[System_CommonList_Item] ([Keyword]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_CommonList_Item] ADD CONSTRAINT [UQ_System_CommonList_Item__Keyword__System_CommonListID] UNIQUE NONCLUSTERED  ([Keyword], [System_CommonListID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_CommonList_Item] ADD CONSTRAINT [UQ_System_CommonList_Item__Name__System_CommonListID] UNIQUE NONCLUSTERED  ([Keyword], [System_CommonListID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_CommonList_Item] WITH NOCHECK ADD CONSTRAINT [FK_System_CommonList_Item_System_CommonListID_X_System_CommonList_ID] FOREIGN KEY ([System_CommonListID]) REFERENCES [dbo].[System_CommonList] ([ID])
GO
