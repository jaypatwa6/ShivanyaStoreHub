CREATE TABLE [dbo].[FMS_Equipment_Deficiency]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__FMS_Equipment_Deficiency__ID] DEFAULT (newsequentialid()),
[FMS_EquipmentID] [uniqueidentifier] NOT NULL,
[Description] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Note] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[EstimatedHours] [decimal] (10, 2) NULL,
[CommonList_DeficiencyStatusID] [uniqueidentifier] NOT NULL,
[CompletedBy] [uniqueidentifier] NULL,
[DateCompleted] [datetime] NULL,
[Completed_OPS_WorkOrder_TaskID] [uniqueidentifier] NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__FMS_Equipment_Deficiency__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__FMS_Equipment_Deficiency__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__FMS_Equipment_Deficiency__IsDelete] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Equipment_Deficiency] ADD CONSTRAINT [PK__FMS_Equipment_Deficiency] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Equipment_Deficiency] ADD CONSTRAINT [FK__FMS_Equipment_Deficiency__CommonList_DeficiencyStatusID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_DeficiencyStatusID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_Equipment_Deficiency] ADD CONSTRAINT [FK__FMS_Equipment_Deficiency__Completed_OPS_WorkOrder_TaskID__x__OPS_WorkOrder_Task__ID] FOREIGN KEY ([Completed_OPS_WorkOrder_TaskID]) REFERENCES [dbo].[OPS_WorkOrder_Task] ([ID])
GO
