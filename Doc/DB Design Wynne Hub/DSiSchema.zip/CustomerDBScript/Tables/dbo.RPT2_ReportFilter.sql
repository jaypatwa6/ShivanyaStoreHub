CREATE TABLE [dbo].[RPT2_ReportFilter]
(
[ID] [uniqueidentifier] NOT NULL,
[Name] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[RPT2_ReportID] [uniqueidentifier] NOT NULL,
[FilterExp] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[IsDefault] [bit] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NULL,
[DateCreated] [datetime] NOT NULL,
[DateModified] [datetime] NULL,
[DateFrom] [datetime] NULL,
[DateTo] [datetime] NULL,
[DataRangeMode] [int] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[RPT2_ReportFilter] ADD CONSTRAINT [PK_RPT2_ReportFilter] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[RPT2_ReportFilter] WITH NOCHECK ADD CONSTRAINT [FK_RPT2_ReportFilter_RPT2_Report] FOREIGN KEY ([RPT2_ReportID]) REFERENCES [dbo].[RPT2_Report] ([ID])
GO
ALTER TABLE [dbo].[RPT2_ReportFilter] NOCHECK CONSTRAINT [FK_RPT2_ReportFilter_RPT2_Report]
GO
