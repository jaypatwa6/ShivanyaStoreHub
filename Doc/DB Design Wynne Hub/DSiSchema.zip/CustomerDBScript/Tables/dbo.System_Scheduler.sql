CREATE TABLE [dbo].[System_Scheduler]
(
[Id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_RW_ScheduleEvent_Id] DEFAULT (newsequentialid()),
[EventName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Color] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Description] [nvarchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsAllDay] [bit] NOT NULL,
[IsAnnual] [bit] NOT NULL,
[IsActive] [bit] NOT NULL,
[EventLocation] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DisplayMode] [int] NOT NULL,
[EventCategories] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[StickerIconName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[EventScheduler] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[AttachedFiles] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Actions] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[UserName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[StartDate] [datetime] NOT NULL,
[EndDate] [datetime] NOT NULL,
[RemindFriendUserNames] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[RepeatIntervalRange] [int] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL,
[DateModified] [datetime] NOT NULL,
[DataKey] [uniqueidentifier] NOT NULL,
[Extension] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DateLastRun] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Scheduler] ADD CONSTRAINT [PK_RW_ScheduleEvent] PRIMARY KEY CLUSTERED  ([Id]) ON [PRIMARY]
GO
