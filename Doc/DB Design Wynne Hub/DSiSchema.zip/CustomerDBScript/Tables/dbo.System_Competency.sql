CREATE TABLE [dbo].[System_Competency]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__System_Competency__ID] DEFAULT (newsequentialid()),
[Code] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Name] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CommonList_CompetencyTypeID] [uniqueidentifier] NOT NULL,
[CommonList_ProficiencyID] [uniqueidentifier] NOT NULL,
[IsProficiencyMinimum] [bit] NOT NULL,
[ValidityPeriodInYear] [decimal] (18, 2) NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_System_Competency_IsActive] DEFAULT ((1)),
[IsDelete] [bit] NULL CONSTRAINT [DF_System_Competency_IsDelete] DEFAULT ((0)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_System_Competency_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_System_Competency_DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Competency] ADD CONSTRAINT [PK__System_Competency] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Competency] WITH NOCHECK ADD CONSTRAINT [FK__System_Competency__CommonList_CompetencyTypeID__X__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_CompetencyTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[System_Competency] WITH NOCHECK ADD CONSTRAINT [FK__System_Competency__CommonList_ProficiencyID__X__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_ProficiencyID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
