CREATE TABLE [dbo].[ATS_RuleEngine]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__ATS_RuleEngine__ID] DEFAULT (newsequentialid()),
[Name] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[IsDefault] [bit] NOT NULL CONSTRAINT [DF__ATS_RuleEngine__IsDefault] DEFAULT ((0)),
[RuleSetting] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__ATS_RuleEngine__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__ATS_RuleEngine__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__ATS_RuleEngine__IsDelete] DEFAULT ((0)),
[IsActive] [bit] NOT NULL CONSTRAINT [DF__ATS_RuleEngine__IsActive] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[ATS_RuleEngine] ADD CONSTRAINT [PK__ATS_RuleEngine] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
