CREATE TABLE [dbo].[System_CustomPayload_Setting]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_System_CustomPayload_Setting_ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_System_CustomPayload_Setting_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_System_CustomPayload_Setting_DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[System_CustomPayload_PropertyID] [uniqueidentifier] NOT NULL,
[DisplayName] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Enabled] [bit] NOT NULL CONSTRAINT [DF_System_CustomPayload_Setting_Enabled] DEFAULT ((1)),
[Sequence] [int] NOT NULL CONSTRAINT [DF_System_CustomPayload_Setting_Sequence] DEFAULT ((0)),
[ShowOnTaskList] [bit] NOT NULL CONSTRAINT [DF__System_Cu__ShowO__1B68FA81] DEFAULT ((0)),
[InterfaceType] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_CustomPayload_Setting] ADD CONSTRAINT [PK_System_CustomPayload_Setting] PRIMARY KEY CLUSTERED ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_CustomPayload_Setting] ADD CONSTRAINT [FK_System_CustomPayload_Setting___System_CustomPayload_PropertyID_x_System_CustomPayload_Property__ID] FOREIGN KEY ([System_CustomPayload_PropertyID]) REFERENCES [dbo].[System_CustomPayload_Property] ([ID])
GO
