CREATE TABLE [dbo].[FMS_EmployeeEquipmentPairing]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_FMS_EmployeeEquipmentPairing_ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_FMS_EmployeeEquipmentPairing_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_FMS_EmployeeEquipmentPairing_DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsPrimary] [bit] NOT NULL CONSTRAINT [DF_FMS_EmployeeEquipmentPairing_IsActive] DEFAULT ((1)),
[IsDeleted] [bit] NOT NULL CONSTRAINT [DF_FMS_EmployeeEquipmentPairing_IsDeleted] DEFAULT ((0)),
[FMS_EquipmentID] [uniqueidentifier] NOT NULL,
[HR_EmployeeID] [uniqueidentifier] NOT NULL,
[CommonList_PairingTypeID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_EmployeeEquipmentPairing] ADD CONSTRAINT [PK_FMS_EmployeeEquipmentPairing] PRIMARY KEY CLUSTERED ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_EmployeeEquipmentPairing] ADD CONSTRAINT [FK_FMS_EmployeeEquipmentPairing___FMS_EquipmentID_x_FMS_Equipment__ID] FOREIGN KEY ([FMS_EquipmentID]) REFERENCES [dbo].[FMS_Equipment] ([ID])
GO
ALTER TABLE [dbo].[FMS_EmployeeEquipmentPairing] ADD CONSTRAINT [FK_FMS_EmployeeEquipmentPairing___HR_EmployeeID_x_HR_Employee__ID] FOREIGN KEY ([HR_EmployeeID]) REFERENCES [dbo].[HR_Employee] ([ID])
GO
