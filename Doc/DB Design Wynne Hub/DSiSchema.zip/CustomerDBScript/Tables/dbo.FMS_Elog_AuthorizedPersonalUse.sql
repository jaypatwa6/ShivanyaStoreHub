CREATE TABLE [dbo].[FMS_Elog_AuthorizedPersonalUse]
(
[ID] [uniqueidentifier] NOT NULL,
[HR_EmployeeID] [uniqueidentifier] NULL,
[System_CommonList_ItemID] [uniqueidentifier] NULL,
[IsActive] [nchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_FMS_Elog_AuthorizedPersonalUse_DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_FMS_Elog_AuthorizedPersonalUse_DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_AuthorizedPersonalUse] ADD CONSTRAINT [PK_FMS_Elog_AuthorizedPersonalUse] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
