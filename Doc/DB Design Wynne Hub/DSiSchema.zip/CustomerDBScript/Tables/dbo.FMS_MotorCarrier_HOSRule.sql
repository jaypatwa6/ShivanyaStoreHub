CREATE TABLE [dbo].[FMS_MotorCarrier_HOSRule]
(
[FMS_Elog_HOSRuleID] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_FMS_MotorCarrier_HOSRule_DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_FMS_MotorCarrier_HOSRule_DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_FMS_MotorCarrier_HOSRule_IsActive] DEFAULT ((1))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_MotorCarrier_HOSRule] ADD CONSTRAINT [PK_FMS_MotorCarrier_HOSRule] PRIMARY KEY CLUSTERED  ([FMS_Elog_HOSRuleID]) ON [PRIMARY]
GO
