CREATE TABLE [dbo].[TMS_Order]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__TMS_Order__ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__TMS_Order__DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__TMS_Order__DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[OrderNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CommonList_TMSOrderStatusID] [uniqueidentifier] NOT NULL,
[CRM_CustomerID] [uniqueidentifier] NOT NULL,
[CRM_Customer_ContactID] [uniqueidentifier] NULL,
[CustomerPONumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ReferenceOrderDocumentNumbers] [xml] NULL,
[Origin_LocationType] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Origin_CRM_JobsiteID] [uniqueidentifier] NULL,
[Origin_FMS_EquipmentID] [uniqueidentifier] NULL,
[OriginJobsiteNotes] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[OriginJobsiteTimeZone] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[OriginJobsiteTimeZoneOffset] [decimal] (3, 1) NULL,
[Destination_CRM_JobsiteID] [uniqueidentifier] NULL,
[DestinationJobsiteNotes] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DestinationTimezone] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DestinationTimezoneOffset] [decimal] (3, 1) NULL,
[DeliveryPromiseTime] [datetime] NULL,
[PickupPromiseTime] [datetime] NULL,
[CommonList_TMSOrderTypeID] [uniqueidentifier] NULL,
[EstimatedTripDurationInMin] [decimal] (18, 2) NULL,
[EstimatedTripDistanceInKM] [decimal] (18, 2) NULL,
[Requester] [uniqueidentifier] NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__TMS_Order__IsDelete] DEFAULT ((0)),
[RequesterName] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Dispatcher] [uniqueidentifier] NULL,
[CustomerAdditionalNotes] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Pickup_CommonList_TimeTypeID] [uniqueidentifier] NULL,
[PickupRequestedTimeFromRange] [datetime] NULL,
[PickupRequestedTimeToRange] [datetime] NULL,
[Delivery_CommonList_TimeTypeID] [uniqueidentifier] NULL,
[DeliveryRequestedTimeFromRange] [datetime] NULL,
[DeliveryRequestedTimeToRange] [datetime] NULL,
[CommonListItem_PriorityStatusID] [uniqueidentifier] NULL,
[PurchaseOrder] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[BillOfLading] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[System_OrganizationID] [uniqueidentifier] NULL,
[IsDelivery] [bit] NULL,
[InvoicedDate] [datetime] NULL,
[InvoicedNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CommonList_TMSBillTypeID] [uniqueidentifier] NULL,
[CommonList_TMSDispatchWindowTypeID] [uniqueidentifier] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_Order] ADD CONSTRAINT [PK__TMS_Order] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order__CommonList_TMSOrderStatusID] ON [dbo].[TMS_Order] ([CommonList_TMSOrderStatusID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order__TMSOrderTypeID_IsDelete_ID] ON [dbo].[TMS_Order] ([CommonList_TMSOrderTypeID], [IsDelete], [ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order__CRM_Customer_ContactID] ON [dbo].[TMS_Order] ([CRM_Customer_ContactID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order__CRM_CustomerID] ON [dbo].[TMS_Order] ([CRM_CustomerID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order__DateCreated] ON [dbo].[TMS_Order] ([DateCreated]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_TMS_Order_Active] ON [dbo].[TMS_Order] ([DateCreated] DESC, [ID]) WHERE ([IsDelete]=(0)) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_TMS_Order_Paging] ON [dbo].[TMS_Order] ([DateCreated] DESC, [ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order__DateModified] ON [dbo].[TMS_Order] ([DateModified]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order__Destination_CRM_JobsiteID] ON [dbo].[TMS_Order] ([Destination_CRM_JobsiteID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_IsDelete] ON [dbo].[TMS_Order] ([IsDelete]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order__OrderNumber] ON [dbo].[TMS_Order] ([OrderNumber]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order__Origin_CRM_JobsiteID] ON [dbo].[TMS_Order] ([Origin_CRM_JobsiteID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order__Origin_FMS_EquipmentID] ON [dbo].[TMS_Order] ([Origin_FMS_EquipmentID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_Order] ADD CONSTRAINT [FK__TMS_Order__CommonList_TMSBillTypeIID_System_CommonList_ItemID] FOREIGN KEY ([CommonList_TMSBillTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order] ADD CONSTRAINT [FK__TMS_Order__CommonList_TMSDispatchWindowTypeID_System_CommonList_ItemID] FOREIGN KEY ([CommonList_TMSDispatchWindowTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order] ADD CONSTRAINT [FK__TMS_Order__CommonList_TMSOrderStatusID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_TMSOrderStatusID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order] ADD CONSTRAINT [FK__TMS_Order__CommonList_TMSOrderTypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_TMSOrderTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order] ADD CONSTRAINT [FK__TMS_Order__CommonListItem_PriorityStatusID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonListItem_PriorityStatusID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order] ADD CONSTRAINT [FK__TMS_Order__CRM_Customer_ContactID__x__CRM_Customer_Contact__ID] FOREIGN KEY ([CRM_Customer_ContactID]) REFERENCES [dbo].[CRM_Customer_Contact] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order] ADD CONSTRAINT [FK__TMS_Order__CRM_CustomerID__x__CRM_Customer__ID] FOREIGN KEY ([CRM_CustomerID]) REFERENCES [dbo].[CRM_Customer] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order] ADD CONSTRAINT [FK__TMS_Order__Delivery_CommonList_TimeTypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([Delivery_CommonList_TimeTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order] ADD CONSTRAINT [FK__TMS_Order__Destination_CRM_JobsiteID__x__CRM_Jobsite__ID] FOREIGN KEY ([Destination_CRM_JobsiteID]) REFERENCES [dbo].[CRM_Jobsite] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order] ADD CONSTRAINT [FK__TMS_Order__Origin_CRM_JobsiteID__x__CRM_Jobsite__ID] FOREIGN KEY ([Origin_CRM_JobsiteID]) REFERENCES [dbo].[CRM_Jobsite] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order] ADD CONSTRAINT [FK__TMS_Order__Origin_FMS_EquipmentID__x__FMS_Equipment__ID] FOREIGN KEY ([Origin_FMS_EquipmentID]) REFERENCES [dbo].[FMS_Equipment] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order] ADD CONSTRAINT [FK__TMS_Order__Pickup_CommonList_TimeTypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([Pickup_CommonList_TimeTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order] ADD CONSTRAINT [FK_TMS_Order_System_Organization] FOREIGN KEY ([System_OrganizationID]) REFERENCES [dbo].[System_Organization] ([ID])
GO
