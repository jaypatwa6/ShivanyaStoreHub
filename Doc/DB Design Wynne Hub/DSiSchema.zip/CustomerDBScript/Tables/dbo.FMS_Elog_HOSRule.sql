CREATE TABLE [dbo].[FMS_Elog_HOSRule]
(
[Name] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[InterstateMaxDriveHours] [int] NOT NULL,
[InterstateMaxOnDutyHours] [int] NOT NULL,
[InterstateMultiDayHours1] [int] NOT NULL,
[InterstateMultiDayDays1] [int] NOT NULL,
[InterstateMultiDayHours2] [int] NOT NULL,
[InterstateMultiDayDays2] [int] NOT NULL,
[InterstateDailyResetHours] [int] NOT NULL,
[InterstateWeeklyResetHours] [int] NOT NULL,
[InterstateSleeperHours1] [int] NOT NULL,
[InterstateSleeperHours2] [int] NOT NULL,
[IntrastateMaxDriveHours] [int] NOT NULL,
[IntrastateMaxOnDutyHours] [int] NOT NULL,
[IntrastateMultiDayHours1] [int] NOT NULL,
[IntrastateMultiDayDays1] [int] NOT NULL,
[IntrastateMultiDayHours2] [int] NOT NULL,
[IntrastateMultiDayDays2] [int] NOT NULL,
[IntrastateDailyResetHours] [int] NOT NULL,
[IntrastateWeeklyResetHours] [int] NOT NULL,
[IntrastateSleeperHours1] [int] NOT NULL,
[IntrastateSleeperHours2] [int] NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_ELog_StandardSettingsDefinition_IsActive] DEFAULT ((1)),
[InterstateMaxExemptionHours] [int] NOT NULL,
[IntrastateMaxExemptionHours] [int] NOT NULL,
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__ELog_Standar__ID__3DFE09A7] DEFAULT (newsequentialid()),
[CommonList_ElogRuleTypeID] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_FMS_Elog_HOSRule_DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_FMS_Elog_HOSRule_DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DateEffective] [datetime] NULL,
[IsDefault] [bit] NOT NULL CONSTRAINT [DF_FMS_Elog_HOSRule_IsDefault] DEFAULT ((1)),
[IsCanadianELD] [bit] NULL CONSTRAINT [DF_FMS_Elog_HOSRule_IsCanadianELD] DEFAULT ((0)),
[Canada_CommonList_ZoneID] [uniqueidentifier] SPARSE NULL,
[Canada_CommonList_CycleID] [uniqueidentifier] SPARSE NULL,
[Canada_DailyOnDutyLimitHours] [smallint] SPARSE NULL,
[Canada_DailyDrivingLimitHours] [smallint] SPARSE NULL,
[Canada_DailyMaxOnDutyLimitHours] [smallint] SPARSE NULL,
[Canada_DailyConsecutiveOffDutyHours] [smallint] SPARSE NULL,
[Canada_DailyInShiftOffDutyHours] [smallint] SPARSE NULL,
[Canada_CycleDays] [smallint] SPARSE NULL,
[Canada_CycleOnDutyLimitHours] [smallint] SPARSE NULL,
[Canada_Cycle2Week1OnDutyLimitHours] [smallint] SPARSE NULL,
[Canada_Cycle2Week1ResetHours] [smallint] SPARSE NULL,
[Canada_CycleResetHours] [smallint] SPARSE NULL,
[Canada_MinSplitSleeperSingleDriverHours] [smallint] SPARSE NULL,
[Canada_MinSplitSleeperTeamDriverHours] [smallint] SPARSE NULL,
[Canada_WorkShiftElapsedTimeLimitHours] [smallint] SPARSE NULL,
[Canada_WorkShiftElapsedTimeSplitSleeperBerthLimitHours] [smallint] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_HOSRule] ADD CONSTRAINT [PK_FMS_Elog_HOSRule] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_HOSRule] ADD CONSTRAINT [FK_FMS_Elog_HOSRule__CommonList_ElogRuleTypeID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_ElogRuleTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_Elog_HOSRule] ADD CONSTRAINT [FK_FMS_Elog_HOSRule_CycleID_System_CommonList_Item] FOREIGN KEY ([Canada_CommonList_CycleID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_Elog_HOSRule] ADD CONSTRAINT [FK_FMS_Elog_HOSRule_ZoneID_System_CommonList_Item] FOREIGN KEY ([Canada_CommonList_ZoneID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
