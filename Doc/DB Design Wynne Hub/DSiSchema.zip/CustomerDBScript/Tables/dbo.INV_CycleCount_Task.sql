CREATE TABLE [dbo].[INV_CycleCount_Task]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__INV_CycleCount_Task__ID] DEFAULT (newsequentialid()),
[INV_CycleCountID] [uniqueidentifier] NOT NULL,
[System_OrganizationID] [uniqueidentifier] NOT NULL,
[CommonList_INV_TaskStatusID] [uniqueidentifier] NOT NULL,
[Day] [int] NOT NULL,
[TaskNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__INV_CycleCount_Task__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__INV_CycleCount_Task__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsDeleted] [bit] NOT NULL CONSTRAINT [DF_INV_CycleCount_Task_IsDeleted] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[INV_CycleCount_Task] ADD CONSTRAINT [PK__CycleCount_Task] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[INV_CycleCount_Task] ADD CONSTRAINT [FK__INV_CycleCount_Task__CommonList_INV_TaskStatusID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_INV_TaskStatusID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[INV_CycleCount_Task] ADD CONSTRAINT [FK__INV_CycleCount_Task__INV_CycleCountID__x__INV_CycleCount__ID] FOREIGN KEY ([INV_CycleCountID]) REFERENCES [dbo].[INV_CycleCount] ([ID])
GO
ALTER TABLE [dbo].[INV_CycleCount_Task] ADD CONSTRAINT [FK__INV_CycleCount_Task__System_OrganizationID__x__System_Organization__ID] FOREIGN KEY ([System_OrganizationID]) REFERENCES [dbo].[System_Organization] ([ID])
GO
