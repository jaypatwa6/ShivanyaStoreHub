CREATE TABLE [dbo].[FMS_MaintenacePlanCollection_Item]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_FMS_MaintenacePlanCollection_Item_ID] DEFAULT (newsequentialid()),
[FMS_MaintenanccePlanCollectionID] [uniqueidentifier] NOT NULL,
[FMS_MaintenancePlanTemplateID] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__FMS_MaintenacePlanCollection_Item__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__FMS_MaintenacePlanCollection_Item__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL CONSTRAINT [DF__FMS_MaintenacePlanCollection_Item__CreatedBy] DEFAULT ('00000000-0000-0000-0000-000000000000'),
[ModifiedBy] [uniqueidentifier] NOT NULL CONSTRAINT [DF__FMS_MaintenacePlanCollection_Item__ModifiedBy] DEFAULT ('00000000-0000-0000-0000-000000000000'),
[IsActive] [bit] NOT NULL CONSTRAINT [DF__FMS_MaintenacePlanCollection_Item__IsActive] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_MaintenacePlanCollection_Item] ADD CONSTRAINT [PK_FMS_MaintenacePlanCollection_Item] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_MaintenacePlanCollection_Item] ADD CONSTRAINT [FK_FMS_MaintenacePlanCollection_Item__FMS_MaintenanccePlanCollectionID_X_FMS_MaintenancePlanCollection__ID] FOREIGN KEY ([FMS_MaintenanccePlanCollectionID]) REFERENCES [dbo].[FMS_MaintenancePlanCollection] ([ID])
GO
ALTER TABLE [dbo].[FMS_MaintenacePlanCollection_Item] ADD CONSTRAINT [FK_FMS_MaintenacePlanCollection_Item__FMS_MaintenancePlanTemplateID_X_FMS_MaintenancePlanTemplate__ID] FOREIGN KEY ([FMS_MaintenancePlanTemplateID]) REFERENCES [dbo].[FMS_MaintenancePlanTemplate] ([ID])
GO
