CREATE TABLE [dbo].[MCS_Driver_Status]
(
[ID] [uniqueidentifier] NOT NULL,
[CommonList_DriverStatusID] [uniqueidentifier] NOT NULL,
[HR_EmployeeID] [uniqueidentifier] NOT NULL,
[MCS_Device_CommEventID] [uniqueidentifier] NULL,
[DateCreated] [datetime] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[Note] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[MCS_Device_EventSummaryID] [uniqueidentifier] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Driver_Status] ADD CONSTRAINT [PK_MCS_Driver_Status] PRIMARY KEY NONCLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_MCS_Driver_Status__DateCreated] ON [dbo].[MCS_Driver_Status] ([DateCreated] DESC) INCLUDE ([CommonList_DriverStatusID], [HR_EmployeeID]) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [_dta_index_MCS_Driver_Status_c_22_354100302__K7] ON [dbo].[MCS_Driver_Status] ([DateModified]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Driver_Status__DateModified] ON [dbo].[MCS_Driver_Status] ([DateModified] DESC) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Driver_Status] ADD CONSTRAINT [FK_MCS_Driver_Status_HR_Employee] FOREIGN KEY ([HR_EmployeeID]) REFERENCES [dbo].[HR_Employee] ([ID])
GO
ALTER TABLE [dbo].[MCS_Driver_Status] ADD CONSTRAINT [FK_MCS_Driver_Status_System_CommonList_Item] FOREIGN KEY ([CommonList_DriverStatusID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
