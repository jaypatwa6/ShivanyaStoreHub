CREATE TABLE [dbo].[MCS_Fleet]
(
[Name] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[IsPublic] [bit] NOT NULL CONSTRAINT [DF_Mobile_GPS_Fleet_IsPublic] DEFAULT ((0)),
[IsActive] [bit] NOT NULL CONSTRAINT [DF_Mobile_GPS_Fleet_IsActive] DEFAULT ((1)),
[Description] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Mobile_GPS_Fleet_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_Mobile_GPS_Fleet_DateModified] DEFAULT (getutcdate()),
[SortOrder] [int] NULL,
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__MCS_Fleet__ID__10216507] DEFAULT (newsequentialid()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[Account_LoginID] [uniqueidentifier] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Fleet] ADD CONSTRAINT [PK_dbo.MCS_Fleet] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
