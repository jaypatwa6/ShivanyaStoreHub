CREATE TABLE [dbo].[SFE_Custom_ValidationRule]
(
[ValidationName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[MinValue] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[MaxValue] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[StringLength] [int] NULL,
[RegularExpressionText] [nvarchar] (150) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ValidateType] [nvarchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ErrorMessage] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_SFE_Custom_ValidationRule_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_SFE_Custom_ValidationRule_DateModified] DEFAULT (getutcdate()),
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__SFE_Custom_V__ID__00AA174D] DEFAULT (newsequentialid()),
[FieldID] [uniqueidentifier] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[SFE_Custom_ValidationRule] ADD CONSTRAINT [PK_SFE_Custom_ValidationRule] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[SFE_Custom_ValidationRule] ADD CONSTRAINT [FK_SFE_Custom_ValidationRule__FieldID_X_SFE_Custom_FieldTable__ID] FOREIGN KEY ([FieldID]) REFERENCES [dbo].[SFE_Custom_FieldTable] ([ID]) ON DELETE CASCADE
GO
