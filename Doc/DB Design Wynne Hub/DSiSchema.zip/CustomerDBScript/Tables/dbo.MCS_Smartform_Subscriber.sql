CREATE TABLE [dbo].[MCS_Smartform_Subscriber]
(
[Id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_MCS_Smartform_Subscriber_Id] DEFAULT (newsequentialid()),
[MCS_SmartformId] [uniqueidentifier] NOT NULL,
[AccountId] [bigint] NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF__MCS_Smart__IsAct__129EAA56] DEFAULT ((1)),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL,
[ModifiedBy] [uniqueidentifier] NULL,
[DateModified] [datetime] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Smartform_Subscriber] ADD CONSTRAINT [PK_MCS_Smartform_Subscriber] PRIMARY KEY CLUSTERED  ([Id]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Smartform_Subscriber] ADD CONSTRAINT [FK_MCS_Smartform_Subscriber__MCS_SMartformId_x_MCS_Smartform__Id] FOREIGN KEY ([MCS_SmartformId]) REFERENCES [dbo].[MCS_Smartform] ([ID])
GO
