CREATE TABLE [dbo].[MCS_Geofence_UserOptOut]
(
[DateCreated] [datetime] NOT NULL,
[DateModified] [datetime] NOT NULL,
[ID] [uniqueidentifier] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[Account_LoginID] [uniqueidentifier] NULL,
[MCS_GeofenceID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Geofence_UserOptOut] ADD CONSTRAINT [PK_MCS_Geofence_UserOptOut] PRIMARY KEY NONCLUSTERED  ([ID]) ON [PRIMARY]
GO
