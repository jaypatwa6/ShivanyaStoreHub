CREATE TABLE [dbo].[System_UserSetting_MapOverrides]
(
[Value] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Mobile_GPS_UserFleetSettingOverride_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_Mobile_GPS_UserFleetSettingOverride_DateModified] DEFAULT (getutcdate()),
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__Mobile_GPS_U__ID__6517D6C8] DEFAULT (newsequentialid()),
[System_SettingID] [uniqueidentifier] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[Account_LoginID] [uniqueidentifier] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_UserSetting_MapOverrides] ADD CONSTRAINT [PK_Mobile_GPS_UserFleetSettingOverride] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_UserSetting_MapOverrides] ADD CONSTRAINT [UQ_Mobile_GPS_UserFleetSettingOverride_SettingID_Account_LoginID] UNIQUE NONCLUSTERED  ([System_SettingID], [Account_LoginID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_UserSetting_MapOverrides] WITH NOCHECK ADD CONSTRAINT [FK_System_UserSettings_MapOverrides_System_Setting] FOREIGN KEY ([System_SettingID]) REFERENCES [dbo].[System_Setting] ([ID])
GO
