CREATE TABLE [dbo].[RPT_XtraReportData]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_RPT_ReportData_ID] DEFAULT (newsequentialid()),
[ReportName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[XtraReportLayout] [xml] NULL,
[LookupQuery] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL,
[DateModified] [datetime] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsDsiMasterDb] [bit] NOT NULL,
[IsActive] [bit] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[RPT_XtraReportData] ADD CONSTRAINT [PK_RPT_ReportData] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
