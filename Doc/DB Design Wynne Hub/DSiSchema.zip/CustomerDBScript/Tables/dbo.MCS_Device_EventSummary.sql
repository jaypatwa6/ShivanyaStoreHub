CREATE TABLE [dbo].[MCS_Device_EventSummary]
(
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL,
[DateModified] [datetime] NOT NULL,
[FirmwareVersion] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS SPARSE NULL,
[TimeZone] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[TimeZoneOffset] [decimal] (3, 1) NULL,
[GpsTimeStamp] [datetime] NOT NULL,
[ReceivedTime] [datetime] NULL,
[StartedMovingTime] [datetime] NULL,
[StoppedMovingTime] [datetime] NULL,
[IgnitionOnTime] [datetime] NULL,
[IgnitionOffTime] [datetime] NULL,
[IsIgnitionOn] [bit] NULL,
[Latitude] [decimal] (9, 6) NULL,
[Longitude] [decimal] (9, 6) NULL,
[Heading] [smallint] NULL,
[OdometerInKM] [decimal] (9, 2) NULL,
[OdometerReset] [bit] NOT NULL,
[VelocityInKPH] [smallint] NULL,
[SpeedLimitInKPH] [smallint] NULL,
[Satellites] [tinyint] NULL,
[CellSignalStrength] [tinyint] NULL,
[FuelLevel] [smallint] NULL,
[FuelUsed] [decimal] (9, 2) NULL,
[Address] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[City] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[State] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PostalCode1] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[EventData] [xml] SPARSE NULL,
[PollingPort] [int] SPARSE NULL,
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__MCS_Device_E__ID__673F4B05] DEFAULT (newsequentialid()),
[System_List_CountryID] [uniqueidentifier] NULL,
[System_OrganizationID] [uniqueidentifier] NULL,
[HR_EmployeeID] [uniqueidentifier] NULL,
[FMS_EquipmentID] [uniqueidentifier] NULL,
[CommonList_DeviceSummaryEventID] [uniqueidentifier] NOT NULL,
[MCS_DeviceID] [uniqueidentifier] NULL,
[GPSRawTimestamp] [datetime] NULL,
[DistanceTraveledInKM] [decimal] (11, 2) NULL,
[DurationInSecond] [int] NULL,
[DistanceTraveledByState] [decimal] (9, 2) NULL,
[MCS_OriginalDeviceID] [uniqueidentifier] SPARSE NULL,
[MCS_BlackboxDeviceID] [uniqueidentifier] SPARSE NULL,
[IsOffHighway] [bit] NULL CONSTRAINT [DF_MCS_Device_EventSummary__IsOffHighway] DEFAULT ((0)),
[IsMoving] [bit] NOT NULL CONSTRAINT [DF__MCS_Devic__IsMov__1269A02C] DEFAULT ((0)),
[GpsTimeStampDateKey] [int] NULL,
[GpsTimeStampTimeKey] [int] NULL,
[BatteryLevel] [tinyint] SPARSE NULL,
[ELD_SequenceID] [int] SPARSE NULL,
[ELD_Origin] [tinyint] SPARSE NULL,
[ELD_Annotation] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS SPARSE NULL,
[MCS_Device_ELDEventCodeID] [uniqueidentifier] SPARSE NULL,
[MCS_Device_CommEventID] [uniqueidentifier] SPARSE NULL,
[MalfunctionCode] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS SPARSE NULL,
[MalfunctionStartSequenceID] [int] SPARSE NULL,
[MalfunctionEndSequenceID] [int] SPARSE NULL,
[ExtendData] [xml] SPARSE NULL,
[EngineHours] [decimal] (10, 1) SPARSE NULL,
[HOSCertifiedDate] [date] SPARSE NULL,
[CheckSum] [smallint] SPARSE NULL,
[ELD_EventRecordStatus] [tinyint] NOT NULL CONSTRAINT [DF_MCS_Device_EventSummary_ELD_EventRecordStatus] DEFAULT ((1)),
[MainVoltage] [decimal] (3, 1) SPARSE NULL,
[RTCTime] [datetime] SPARSE NULL,
[GPSSignalHDOP] [smallint] SPARSE NULL,
[OSVersion] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS SPARSE NULL,
[SoftwareVersion] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS SPARSE NULL,
[FuelLevelGallons] [smallint] SPARSE NULL,
[RPM] [int] SPARSE NULL,
[FuelRate] [decimal] (9, 2) SPARSE NULL,
[EngineCoolantTemperature] [int] SPARSE NULL,
[InstantaneousFuelEconomy] [decimal] (9, 2) SPARSE NULL,
[EngineLoad] [tinyint] SPARSE NULL,
[AcceleratorPedalPosition] [decimal] (5, 2) SPARSE NULL,
[ECUProtocol] [nvarchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DistanceFromGeolocationInKM] [decimal] (11, 2) NULL,
[DistanceTraveledBetweenPingsInKM] [decimal] (11, 2) NULL,
[DirectionFromGeolocation] [varchar] (3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DurationBetweenPingsInSecond] [int] NULL,
[ElapsedEngineHours] [decimal] (11, 2) NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Device_EventSummary] ADD CONSTRAINT [PK_MCS_Device_EventSummary] PRIMARY KEY NONCLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Device_EventSummary__DateModified__DateCreated__HR_EmployeeID] ON [dbo].[MCS_Device_EventSummary] ([DateModified], [DateCreated], [HR_EmployeeID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Device_EventSummary__ELD_SequenceID] ON [dbo].[MCS_Device_EventSummary] ([ELD_SequenceID] DESC) INCLUDE ([MCS_DeviceID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Device_EventSummary__FMS_EquipmentID] ON [dbo].[MCS_Device_EventSummary] ([FMS_EquipmentID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Device_EventSummary__GPSTimestamp] ON [dbo].[MCS_Device_EventSummary] ([GpsTimeStamp]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Device_EventSummary__HR_EmployeeID__FMS_EquipmentID__GPSTimeStamp] ON [dbo].[MCS_Device_EventSummary] ([HR_EmployeeID], [FMS_EquipmentID], [GpsTimeStamp]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Device_EventSummary__HR_EmployeeID__MCS_Device_ELDEventCodeID__DateModified_DateCreated__CommonList_DeviceSummaryEventID] ON [dbo].[MCS_Device_EventSummary] ([HR_EmployeeID], [MCS_Device_ELDEventCodeID], [DateModified], [DateCreated], [CommonList_DeviceSummaryEventID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Device_EventSummary__MCS_DeviceID] ON [dbo].[MCS_Device_EventSummary] ([MCS_DeviceID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Device_EventSummary] WITH NOCHECK ADD CONSTRAINT [FK_MCS_Device_EventSummary__CommonList_DeviceSummaryEventID_x_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_DeviceSummaryEventID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[MCS_Device_EventSummary] WITH NOCHECK ADD CONSTRAINT [FK_MCS_Device_EventSummary_MCS_Device_ELDEventCode] FOREIGN KEY ([MCS_Device_ELDEventCodeID]) REFERENCES [dbo].[MCS_Device_ELDEventCode] ([ID])
GO
ALTER TABLE [dbo].[MCS_Device_EventSummary] WITH NOCHECK ADD CONSTRAINT [FK_MCS_Device_EventSummary_MCS_Device_Original] FOREIGN KEY ([MCS_OriginalDeviceID]) REFERENCES [dbo].[MCS_Device] ([ID])
GO
EXEC sp_addextendedproperty N'MS_Description', N'The status code of the record.', 'SCHEMA', N'dbo', 'TABLE', N'MCS_Device_EventSummary', 'COLUMN', N'ELD_EventRecordStatus'
GO
