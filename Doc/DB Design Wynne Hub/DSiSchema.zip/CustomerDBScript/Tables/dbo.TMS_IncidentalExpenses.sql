CREATE TABLE [dbo].[TMS_IncidentalExpenses]
(
[Id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_TMS_IncidentalExpenses_Id] DEFAULT (newsequentialid()),
[TMS_OrderID] [uniqueidentifier] NOT NULL,
[ExpenseName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[AccountNumber] [nvarchar] (65) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Qty] [decimal] (18, 2) NULL CONSTRAINT [DF_TMS_IncidentalExpenses_Qty] DEFAULT ((1)),
[Rate] [decimal] (18, 2) NULL,
[Taxable] [bit] NULL,
[IsActive] [bit] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL,
[Integration_Number] [nvarchar] (36) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Cost] [decimal] (18, 2) NULL,
[Description] [nvarchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_IncidentalExpenses] ADD CONSTRAINT [PK_TMS_IncidentalExpenses] PRIMARY KEY CLUSTERED ([Id]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_IncidentalExpenses] ADD CONSTRAINT [FK_TMS_IncidentalExpenses_TMS_Order] FOREIGN KEY ([TMS_OrderID]) REFERENCES [dbo].[TMS_Order] ([ID]) ON DELETE CASCADE
GO
