CREATE TABLE [dbo].[FMS_MaintenancePlan_MaintenanceHistory]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_FMS_MaintenancePlan_MaintenanceHistory_ID] DEFAULT (newsequentialid()),
[FMS_MaintenancePlanID] [uniqueidentifier] NOT NULL,
[ForecastedEventDate] [datetime] NULL,
[ForecastedEventRemindAtDate] [datetime] NULL,
[CommonList_ServiceIntervalUOMTypeID] [uniqueidentifier] NOT NULL,
[ActualEventDate] [datetime] NULL,
[ActualEventBeganAtDate] [datetime] NULL,
[System_Form_ID] [uniqueidentifier] NULL,
[System_Form_SubmissionID] [uniqueidentifier] NULL,
[IsComplete] [bit] NOT NULL CONSTRAINT [DF_FMS_MaintenancePlan_MaintenanceHistory_IsComplete] DEFAULT ((0)),
[IsSkipped] [bit] NOT NULL CONSTRAINT [DF_FMS_MaintenancePlan_MaintenanceHistory_IsSkipped] DEFAULT ((0)),
[ServiceNotes] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PartsCost] [money] NULL,
[LaborCost] [money] NULL,
[ServicePerformedBy] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__FMS_MaintenancePlan_MaintenanceHistory__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__FMS_MaintenancePlan_MaintenanceHistory__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL CONSTRAINT [DF__FMS_MaintenancePlan_MaintenanceHistory__CreatedBy] DEFAULT ('00000000-0000-0000-0000-000000000000'),
[ModifiedBy] [uniqueidentifier] NOT NULL CONSTRAINT [DF__FMS_MaintenancePlan_MaintenanceHistory__ModifiedBy] DEFAULT ('00000000-0000-0000-0000-000000000000'),
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__FMS_MaintenancePlan_MaintenanceHistory__IsDelete] DEFAULT ((0)),
[CommonList_MaintenanceHistoryStatusID] [uniqueidentifier] NULL,
[CommonList_MaintenanceHistoryEventStatusID] [uniqueidentifier] NULL,
[Parent_FMS_MaintenancePlan_MaintenanceHistoryID] [uniqueidentifier] NULL,
[ReferenceTable] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ReferenceForeignKeyID] [uniqueidentifier] NULL,
[CommonList_MaintenanceHistoryDueStatusID] [uniqueidentifier] NULL,
[ExtendedData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_MaintenancePlan_MaintenanceHistory] ADD CONSTRAINT [PK_FMS_MaintenancePlan_MaintenanceHistory] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_MaintenancePlan_MaintenanceHistory__ReferenceTable_ReferenceForeignKeyID] ON [dbo].[FMS_MaintenancePlan_MaintenanceHistory] ([ReferenceTable], [ReferenceForeignKeyID], [IsDelete]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_MaintenancePlan_MaintenanceHistory] ADD CONSTRAINT [FK__FMS_MaintenancePlan_MaintenanceHistory__CommonList_MaintenanceHistoryDueStatusID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_MaintenanceHistoryDueStatusID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_MaintenancePlan_MaintenanceHistory] ADD CONSTRAINT [FK__FMS_MaintenancePlan_MaintenanceHistory__CommonList_MaintenanceHistoryEventStatusID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_MaintenanceHistoryEventStatusID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_MaintenancePlan_MaintenanceHistory] ADD CONSTRAINT [FK__FMS_MaintenancePlan_MaintenanceHistory__CommonList_MaintenanceHistoryStatusID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_MaintenanceHistoryStatusID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_MaintenancePlan_MaintenanceHistory] ADD CONSTRAINT [FK__FMS_MaintenancePlan_MaintenanceHistory__Parent_FMS_MaintenancePlan_MaintenanceHistoryID__x__ID] FOREIGN KEY ([Parent_FMS_MaintenancePlan_MaintenanceHistoryID]) REFERENCES [dbo].[FMS_MaintenancePlan_MaintenanceHistory] ([ID])
GO
ALTER TABLE [dbo].[FMS_MaintenancePlan_MaintenanceHistory] ADD CONSTRAINT [FK_FMS_MaintenancePlan_MaintenanceHistory__CommonList_ServiceIntervalUOMTypeID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_ServiceIntervalUOMTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_MaintenancePlan_MaintenanceHistory] ADD CONSTRAINT [FK_FMS_MaintenancePlan_MaintenanceHistory__FMS_MaintenancePlanID_X_FMS_MaintenancePlan__ID] FOREIGN KEY ([FMS_MaintenancePlanID]) REFERENCES [dbo].[FMS_MaintenancePlan] ([ID])
GO
ALTER TABLE [dbo].[FMS_MaintenancePlan_MaintenanceHistory] ADD CONSTRAINT [FK_FMS_MaintenancePlan_MaintenanceHistory__System_Form_ID_x_MCS_Smartform__ID] FOREIGN KEY ([System_Form_ID]) REFERENCES [dbo].[MCS_Smartform] ([ID])
GO
ALTER TABLE [dbo].[FMS_MaintenancePlan_MaintenanceHistory] ADD CONSTRAINT [FK_FMS_MaintenancePlan_MaintenanceHistory__System_Form_SubmissionID_x_MCS_Smartform_Submission__ID] FOREIGN KEY ([System_Form_SubmissionID]) REFERENCES [dbo].[MCS_Smartform_Submission] ([ID])
GO
