CREATE TABLE [dbo].[ElogModifiedReportItem_tracking]
(
[Id] [bigint] NOT NULL IDENTITY(1, 1),
[UpdateKey] [timestamp] NOT NULL,
[ObjectKey] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsTombstone] [bit] NULL,
[DateModified] [datetime] NULL,
[MetaData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[ElogModifiedReportItem_tracking] ADD CONSTRAINT [PK_ElogModifiedReportItem_tracking] PRIMARY KEY CLUSTERED  ([Id]) ON [PRIMARY]
GO
