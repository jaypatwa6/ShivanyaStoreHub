CREATE TABLE [dbo].[MCS_Smartform]
(
[IsActive] [bit] NOT NULL CONSTRAINT [DF_Mobile_Smartforms_IsActive] DEFAULT ((1)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Mobile_Smartforms_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_Mobile_Smartforms_DateModified] DEFAULT (getutcdate()),
[Name] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ShortName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsSystemForm] [bit] NOT NULL CONSTRAINT [DF_Mobile_Smartforms_IsSystemForm] DEFAULT ((0)),
[Keyword] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__Mobile_Smart__ID__4B5804C5] DEFAULT (newsequentialid()),
[CommonList_SmartformCategoryID] [uniqueidentifier] NOT NULL,
[CommonList_SmartformTypeID] [uniqueidentifier] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__MCS_Smart__IsDel__408F9238] DEFAULT ((0)),
[PromptMessage] [nvarchar] (300) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Smartform] ADD CONSTRAINT [PK_MCS_Smartform] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Smartform] WITH NOCHECK ADD CONSTRAINT [FK_MCS_Smartform__CommonList_SmartformCategoryID_X_System_CommonList_Item_ID] FOREIGN KEY ([CommonList_SmartformCategoryID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[MCS_Smartform] WITH NOCHECK ADD CONSTRAINT [FK_MCS_Smartform__CommonList_SmartformTypeID_X_System_CommonList_Item_ID] FOREIGN KEY ([CommonList_SmartformTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
