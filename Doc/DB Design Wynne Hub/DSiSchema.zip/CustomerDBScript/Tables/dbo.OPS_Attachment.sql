CREATE TABLE [dbo].[OPS_Attachment]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__OPS_Attachment__ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__OPS_Attachment__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__OPS_Attachment__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__OPS_Attachment__IsDelete] DEFAULT ((0)),
[DisplayName] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[FileName] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[FileType] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[FileSize] [bigint] NULL,
[DCM_PhysicalDocID] [int] NULL,
[ReferenceTable] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ReferenceForeignKeyID] [uniqueidentifier] NULL,
[Note] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[StaticURL] [nvarchar] (2048) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CloudURL] [nvarchar] (2048) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CloudThumbnailURL] [nvarchar] (2048) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[StorageSource] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsShared] [bit] NOT NULL CONSTRAINT [DF__OPS_Attac__IsSha__2779CBAB] DEFAULT ((0)),
[CommonList_DocumentTypeID] [uniqueidentifier] NOT NULL,
[DateSynchronized] [datetime] NULL,
[ReceivedBy] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ExtendedData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CommonList_AttachmentTypeID] [uniqueidentifier] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_Attachment] ADD CONSTRAINT [PK__OPS_Attachment] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_CreatedBy_DCM_PhysicalDocID_ReferenceTable] ON [dbo].[OPS_Attachment] ([CreatedBy], [DCM_PhysicalDocID], [ReferenceTable]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_OPS_Attachment_FileName_DCM_PhysicalDocID_ReferenceTable] ON [dbo].[OPS_Attachment] ([FileName], [DCM_PhysicalDocID], [ReferenceTable]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_OPS_ReferenceTable_ReferenceForeignKeyID_DateCreated] ON [dbo].[OPS_Attachment] ([ReferenceTable], [ReferenceForeignKeyID], [DateCreated]) INCLUDE ([IsDelete]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__OPS_Attachment__ReferenceTable_ReferenceForeignKeyID_IsDelete] ON [dbo].[OPS_Attachment] ([ReferenceTable], [ReferenceForeignKeyID], [IsDelete]) INCLUDE ([CloudURL]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_Attachment] ADD CONSTRAINT [FK__OPS_Attachment__CommonList_AttachmentTypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_AttachmentTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_Attachment] ADD CONSTRAINT [FK__OPS_Attachment__CommonList_DocumentTypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_DocumentTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
