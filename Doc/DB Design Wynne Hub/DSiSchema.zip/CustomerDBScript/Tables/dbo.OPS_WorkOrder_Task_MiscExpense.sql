CREATE TABLE [dbo].[OPS_WorkOrder_Task_MiscExpense]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__OPS_WorkOrder_Task_MiscExpense__ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__OPS_WorkOrder_Task_MiscExpense__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__OPS_WorkOrder_Task_MiscExpense__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__OPS_WorkOrder_Task_MiscExpense__IsDelete] DEFAULT ((0)),
[OPS_WorkOrder_TaskID] [uniqueidentifier] NOT NULL,
[PurchaseOrder] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PurchaseOrderDescription] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[InvoiceDescription] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Cost] [decimal] (18, 2) NULL,
[Sell] [decimal] (18, 2) NULL,
[CommonList_SupplierID] [uniqueidentifier] NULL,
[VendorName] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[BillableAmount] [decimal] (18, 2) NULL,
[ExtendedData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Integration_ReferenceID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Integration_CommonList_ApplicationID] [uniqueidentifier] NULL,
[CommonList_TypeID] [uniqueidentifier] NOT NULL,
[Mileage] [decimal] (18, 2) NULL,
[RatePerMile] [decimal] (18, 2) NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_MiscExpense] ADD CONSTRAINT [PK__OPS_WorkOrder_Task_MiscExpense] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_MiscExpense] ADD CONSTRAINT [FK__OPS_WorkOrder_Task_MiscExpense__CommonList_SupplierID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_SupplierID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_MiscExpense] ADD CONSTRAINT [FK__OPS_WorkOrder_Task_MiscExpense__CommonList_TypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_TypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_MiscExpense] ADD CONSTRAINT [FK__OPS_WorkOrder_Task_MiscExpense__Integration_CommonList_ApplicationID__x__System_CommonList_Item__ID] FOREIGN KEY ([Integration_CommonList_ApplicationID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_MiscExpense] ADD CONSTRAINT [FK__OPS_WorkOrder_Task_MiscExpense__OPS_WorkOrder_TaskID__x__OPS_WorkOrder_Task__ID] FOREIGN KEY ([OPS_WorkOrder_TaskID]) REFERENCES [dbo].[OPS_WorkOrder_Task] ([ID])
GO
