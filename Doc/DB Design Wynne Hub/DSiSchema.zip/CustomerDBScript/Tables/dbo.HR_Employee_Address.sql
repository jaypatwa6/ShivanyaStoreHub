CREATE TABLE [dbo].[HR_Employee_Address]
(
[Address1] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Address2] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[City] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[State] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PostalCode] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_HR_Employee_Address_IsActive] DEFAULT ((1)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_HR_Employee_Address_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_HR_Employee_Address_DateModified] DEFAULT (getutcdate()),
[IsPrimary] [bit] NOT NULL CONSTRAINT [DF_HR_Employee_Address_IsPrimary] DEFAULT ((0)),
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__HR_Employee___ID__7849DB76] DEFAULT (newsequentialid()),
[CommonList_AddressTypeID] [uniqueidentifier] NOT NULL,
[System_List_CountryID] [uniqueidentifier] NOT NULL,
[HR_EmployeeID] [uniqueidentifier] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[Longitude] [decimal] (9, 6) NULL,
[Latitude] [decimal] (9, 6) NULL,
[IsStartingLocation] [bit] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[HR_Employee_Address] ADD CONSTRAINT [PK_HR_Employee_Address] PRIMARY KEY NONCLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [IX__HR_Employee_Address__HR_EmployeeID] ON [dbo].[HR_Employee_Address] ([HR_EmployeeID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__HR_Employee_Address__IsActive] ON [dbo].[HR_Employee_Address] ([IsActive]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[HR_Employee_Address] ADD CONSTRAINT [FK_HR_Employee_Address__CommonList_AddressTypeID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_AddressTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[HR_Employee_Address] ADD CONSTRAINT [FK_HR_Employee_Address__HR_EmployeeID_X_HR_Employee__ID] FOREIGN KEY ([HR_EmployeeID]) REFERENCES [dbo].[HR_Employee] ([ID]) ON DELETE CASCADE
GO
ALTER TABLE [dbo].[HR_Employee_Address] ADD CONSTRAINT [FK_HR_Employee_Address__System_List_CountryID_X_System_List_Countries__ID] FOREIGN KEY ([System_List_CountryID]) REFERENCES [dbo].[System_List_Country] ([ID])
GO
