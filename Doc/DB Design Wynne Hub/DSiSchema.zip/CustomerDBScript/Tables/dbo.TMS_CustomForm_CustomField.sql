CREATE TABLE [dbo].[TMS_CustomForm_CustomField]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__TMS_CustomForm_CustomField__ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__TMS_CustomForm_CustomField__DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__TMS_CustomForm_CustomField__DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[TMS_CustomFormID] [uniqueidentifier] NOT NULL,
[TMS_CustomField_PropertiesID] [uniqueidentifier] NOT NULL,
[VersionFrom] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[VersionTo] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ControlGroup] [int] NULL,
[ControlOrder] [int] NULL,
[SnapToObject] [int] NULL,
[SnapToObjectLabel] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_CustomForm_CustomField] ADD CONSTRAINT [PK__TMS_CustomForm_CustomField] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_CustomForm_CustomField] ADD CONSTRAINT [FK__TMS_CustomForm_CustomField__TMS_CustomField_PropertiesID__x__TMS_CustomField_Properties__ID] FOREIGN KEY ([TMS_CustomField_PropertiesID]) REFERENCES [dbo].[TMS_CustomField_Properties] ([ID])
GO
ALTER TABLE [dbo].[TMS_CustomForm_CustomField] ADD CONSTRAINT [FK__TMS_CustomForm_CustomField__TMS_CustomFormID__x__TMS_CustomForm__ID] FOREIGN KEY ([TMS_CustomFormID]) REFERENCES [dbo].[TMS_CustomForm] ([ID])
GO
