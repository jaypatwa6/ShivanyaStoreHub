CREATE TABLE [dbo].[HR_Employee_Phone]
(
[PhoneNumber] [nvarchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_HR_Employee_Phone_IsActive] DEFAULT ((1)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_HR_Employee_Phone_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_HR_Employee_Phone_DateModified] DEFAULT (getutcdate()),
[Extension] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsPrimary] [bit] NOT NULL CONSTRAINT [DF_HR_Employee_Phone_IsPrimary] DEFAULT ((0)),
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__HR_Employee___ID__478773E1] DEFAULT (newsequentialid()),
[CommonList_PhoneTypeID] [uniqueidentifier] NOT NULL,
[HR_EmployeeID] [uniqueidentifier] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[HR_Employee_Phone] ADD CONSTRAINT [PK_HR_Employee_Phone] PRIMARY KEY NONCLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [IX__HR_Employee_Phone__HR_EmployeeID] ON [dbo].[HR_Employee_Phone] ([HR_EmployeeID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__HR_Employee_Phone__IsActive] ON [dbo].[HR_Employee_Phone] ([IsActive]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[HR_Employee_Phone] WITH NOCHECK ADD CONSTRAINT [FK_HR_Employee_Phone__CommonList_PhoneTypeID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_PhoneTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[HR_Employee_Phone] ADD CONSTRAINT [FK_HR_Employee_Phone__HR_EmployeeID_X_HR_Employee__ID] FOREIGN KEY ([HR_EmployeeID]) REFERENCES [dbo].[HR_Employee] ([ID]) ON DELETE CASCADE
GO
