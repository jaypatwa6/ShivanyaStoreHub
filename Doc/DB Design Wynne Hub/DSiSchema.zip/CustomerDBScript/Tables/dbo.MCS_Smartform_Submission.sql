CREATE TABLE [dbo].[MCS_Smartform_Submission]
(
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Mobile_Smartforms_Submissions_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_Mobile_Smartforms_Submissions_DateModified] DEFAULT (getutcdate()),
[DateRecorded] [datetime] NOT NULL CONSTRAINT [DF_Mobile_Smartforms_Submissions_DateRecorded] DEFAULT (getdate()),
[Metadata] [nvarchar] (400) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Latitude] [decimal] (9, 6) NULL,
[Longitude] [decimal] (9, 6) NULL,
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__Mobile_Smart__ID__7CEF6059] DEFAULT (newsequentialid()),
[HR_EmployeeID] [uniqueidentifier] NULL,
[FMS_EquipmentID] [uniqueidentifier] NULL,
[MCS_DeviceID] [uniqueidentifier] NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[MCS_SmartformID] [uniqueidentifier] NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_MCS_Smartform_Submission_IsActive] DEFAULT ((1)),
[CommonList_SubmissionStatusId] [uniqueidentifier] NULL,
[Integration_Application] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Integration_RowId] [nvarchar] (36) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Integration_WorkOrderNo] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Application_Source] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Smartform_Submission] ADD CONSTRAINT [PK_MCS_Smartform_Submission] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Smartform_Submission__ISActive] ON [dbo].[MCS_Smartform_Submission] ([IsActive]) INCLUDE ([Integration_WorkOrderNo]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Smartform_Submission__MCS_SmartformID] ON [dbo].[MCS_Smartform_Submission] ([MCS_SmartformID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Smartform_Submission] ADD CONSTRAINT [FK_MCS_Smartform_Submission__FMS_EquipmentID_X_FMS_Equipment__ID] FOREIGN KEY ([FMS_EquipmentID]) REFERENCES [dbo].[FMS_Equipment] ([ID])
GO
ALTER TABLE [dbo].[MCS_Smartform_Submission] ADD CONSTRAINT [FK_MCS_Smartform_Submission__HR_EmployeeID_X_HR_Employee__ID] FOREIGN KEY ([HR_EmployeeID]) REFERENCES [dbo].[HR_Employee] ([ID])
GO
ALTER TABLE [dbo].[MCS_Smartform_Submission] WITH NOCHECK ADD CONSTRAINT [FK_MCS_Smartform_Submission_MCS_SmartformID_X_MCS_Smartforms_ID] FOREIGN KEY ([MCS_SmartformID]) REFERENCES [dbo].[MCS_Smartform] ([ID])
GO
ALTER TABLE [dbo].[MCS_Smartform_Submission] ADD CONSTRAINT [FK_MCS_Smartform_Submission_System__CommonList_SubmissionStatusId_x_CommonList_Item__Id] FOREIGN KEY ([CommonList_SubmissionStatusId]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
