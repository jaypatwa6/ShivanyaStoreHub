CREATE TABLE [dbo].[OPS_Labor]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__OPS_Labor__ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__OPS_Labor__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__OPS_Labor__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__OPS_Labor__IsDelete] DEFAULT ((0)),
[HR_EmployeeID] [uniqueidentifier] NOT NULL,
[ActualStartTime] [datetime] NULL,
[ActualEndTime] [datetime] NULL,
[ActualTotalTimeInMin] [decimal] (18, 2) NULL,
[RatePerHour] [decimal] (18, 2) NULL,
[TotalCost] [decimal] (18, 2) NULL,
[LaborCode] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ReferenceTable] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ReferenceForeignKeyID] [uniqueidentifier] NULL,
[Created_CommonList_ApplicationID] [uniqueidentifier] NULL,
[Integration_CommonList_ApplicationID] [uniqueidentifier] NULL,
[Integration_ReferenceID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CommonList_OPS_Labor_StatusID] [uniqueidentifier] NULL,
[CommonList_OPS_Labor_CodeID] [uniqueidentifier] NULL,
[ExtendedData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_Labor] ADD CONSTRAINT [PK__OPS_Labor] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__OPS_Labor__ReferenceForeignKeyID_X_IsDelete_X_ActualStartTime] ON [dbo].[OPS_Labor] ([ReferenceForeignKeyID], [IsDelete], [ActualStartTime]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_Labor] ADD CONSTRAINT [FK__OPS_Labor__CommonList_OPS_Labor_CodeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPS_Labor_CodeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_Labor] ADD CONSTRAINT [FK__OPS_Labor__CommonList_OPS_Labor_StatusID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPS_Labor_StatusID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_Labor] ADD CONSTRAINT [FK__OPS_Labor__Created_CommonList_ApplicationID__x__System_CommonList_Item__ID] FOREIGN KEY ([Created_CommonList_ApplicationID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_Labor] ADD CONSTRAINT [FK__OPS_Labor__HR_EmployeeID__x__HR_Employee__ID] FOREIGN KEY ([HR_EmployeeID]) REFERENCES [dbo].[HR_Employee] ([ID])
GO
ALTER TABLE [dbo].[OPS_Labor] ADD CONSTRAINT [FK__OPS_Labor__Integration_CommonList_ApplicationID__x__System_CommonList_Item__ID] FOREIGN KEY ([Integration_CommonList_ApplicationID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
