CREATE TABLE [dbo].[OPS_WorkOrderTaskStageMapping]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__OPS_WorkOrderTaskStageMapping__ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__OPS_WorkOrderTaskStageMapping__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__OPS_WorkOrderTaskStageMapping__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF__OPS_WorkOrderTaskStageMapping__IsActive] DEFAULT ((1)),
[Sequence] [int] NOT NULL CONSTRAINT [DF__OPS_WorkOrderTaskStageMapping__Sequence] DEFAULT ((0)),
[CommonList_OPS_Integration_Task_StageID] [uniqueidentifier] NOT NULL,
[CommonList_OPSWorkOrder_Task_StageID] [uniqueidentifier] NOT NULL,
[LockWorkOrder] [bit] NOT NULL,
[AllowToSync] [bit] NOT NULL,
[IsAllowToDelete] [bit] NOT NULL CONSTRAINT [DF__OPS_WorkOrderTaskStageMapping__IsAllowToDelete] DEFAULT ((0)),
[IsOpenStatus] [bit] NOT NULL CONSTRAINT [DF__OPS_WorkOrderTaskStageMapping__IsOpenStatus] DEFAULT ((1))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_WorkOrderTaskStageMapping] ADD CONSTRAINT [PK_OPS_WorkOrderTaskStageMapping] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_WorkOrderTaskStageMapping] ADD CONSTRAINT [FK__OPS_WorkOrderTaskStageMapping__CommonList_OPS_Integration_Task_StageID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPS_Integration_Task_StageID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrderTaskStageMapping] ADD CONSTRAINT [FK__OPS_WorkOrderTaskStageMapping__CommonList_OPSWorkOrder_Task_StageID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPSWorkOrder_Task_StageID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
