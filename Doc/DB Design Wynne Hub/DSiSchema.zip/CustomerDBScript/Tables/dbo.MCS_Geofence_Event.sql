CREATE TABLE [dbo].[MCS_Geofence_Event]
(
[DateofGeofenceEntry] [datetime] NOT NULL,
[GeofenceEntryGMTOffset] [int] NOT NULL,
[DateOfGeofenceExit] [datetime] NULL,
[GeofenceExitGMTOffset] [int] NULL,
[SecondsInGeofence] [bigint] NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Mobile_GPS_GeofenceEvents_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_Mobile_GPS_GeofenceEvents_DateModified] DEFAULT (getutcdate()),
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__MCS_Geofence__ID__1C873BEC] DEFAULT (newsequentialid()),
[MCS_DeviceID] [uniqueidentifier] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[MCS_GeofenceID] [uniqueidentifier] NOT NULL,
[Exit_MCS_Device_CommEventID] [uniqueidentifier] NULL,
[Enter_MCS_Device_CommEventID] [uniqueidentifier] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Geofence_Event] ADD CONSTRAINT [PK_MCS_Geofence_Event] PRIMARY KEY NONCLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [IX__MCS_Geofence_Event__MCS_DeviceID__MCS_GeofenceID__ID] ON [dbo].[MCS_Geofence_Event] ([ID], [MCS_DeviceID], [MCS_GeofenceID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Geofence_Event__MCS_DeviceID__MCS_GeofenceID__DateOfGeofenceExit] ON [dbo].[MCS_Geofence_Event] ([MCS_DeviceID], [MCS_GeofenceID], [DateOfGeofenceExit]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Geofence_Event__MCS_GeofenceID__MCS_DeviceID__Date] ON [dbo].[MCS_Geofence_Event] ([MCS_GeofenceID], [MCS_DeviceID], [DateOfGeofenceExit]) INCLUDE ([DateofGeofenceEntry], [ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Geofence_Event] ADD CONSTRAINT [FK_MCS_Geofence_Event__MCS_DeviceID_X_MCS_Device__ID] FOREIGN KEY ([MCS_DeviceID]) REFERENCES [dbo].[MCS_Device] ([ID])
GO
ALTER TABLE [dbo].[MCS_Geofence_Event] ADD CONSTRAINT [FK_MCS_Geofence_Event__MCS_GeofenceID_X_MCS_Geofence__ID] FOREIGN KEY ([MCS_GeofenceID]) REFERENCES [dbo].[MCS_Geofence] ([ID])
GO
