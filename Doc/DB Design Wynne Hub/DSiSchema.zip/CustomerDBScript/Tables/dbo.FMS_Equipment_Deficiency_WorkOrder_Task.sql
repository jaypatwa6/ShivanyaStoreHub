CREATE TABLE [dbo].[FMS_Equipment_Deficiency_WorkOrder_Task]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__FMS_Equipment_Deficiency_WorkOrder_Task__ID] DEFAULT (newsequentialid()),
[FMS_Equipment_DeficiencyID] [uniqueidentifier] NOT NULL,
[OPS_WorkOrder_TaskID] [uniqueidentifier] NOT NULL,
[CommonList_DeficiencyStatusID] [uniqueidentifier] NOT NULL,
[ExtendedData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__FMS_Equipment_Deficiency_WorkOrder_Task__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__FMS_Equipment_Deficiency_WorkOrder_Task__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__FMS_Equipment_Deficiency_WorkOrder_Task__IsDelete] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Equipment_Deficiency_WorkOrder_Task] ADD CONSTRAINT [PK__FMS_Equipment_Deficiency_WorkOrder_Task] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Equipment_Deficiency_WorkOrder_Task] ADD CONSTRAINT [FK__FMS_Equipment_Deficiency_WorkOrder_Task__CommonList_DeficiencyStatusID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_DeficiencyStatusID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_Equipment_Deficiency_WorkOrder_Task] ADD CONSTRAINT [FK__FMS_Equipment_Deficiency_WorkOrder_Task__FMS_Equipment_DeficiencyID__x__FMS_Equipment_Deficiency__ID] FOREIGN KEY ([FMS_Equipment_DeficiencyID]) REFERENCES [dbo].[FMS_Equipment_Deficiency] ([ID])
GO
ALTER TABLE [dbo].[FMS_Equipment_Deficiency_WorkOrder_Task] ADD CONSTRAINT [FK__FMS_Equipment_Deficiency_WorkOrder_Task__OPS_WorkOrder_TaskID__x__OPS_WorkOrder_Task__ID] FOREIGN KEY ([OPS_WorkOrder_TaskID]) REFERENCES [dbo].[OPS_WorkOrder_Task] ([ID])
GO
