CREATE TABLE [dbo].[FMS_Equipment_Audit]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__FMS_Equipment_Audit__ID] DEFAULT (newsequentialid()),
[FMS_EquipmentID] [uniqueidentifier] NOT NULL,
[CommonList_EquipmentChangeTypeID] [uniqueidentifier] NOT NULL,
[DataType] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[OriginalValue] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[NewValue] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ActionFrom] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__FMS_Equipment_Audit__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__FMS_Equipment_Audit__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Equipment_Audit] ADD CONSTRAINT [PK__FMS_Equipment_Audit] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Equipment_Audit] ADD CONSTRAINT [FK__FMS_Equipment_Audit__CommonList_EquipmentChangeTypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_EquipmentChangeTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_Equipment_Audit] ADD CONSTRAINT [FK__FMS_Equipment_Audit__FMS_EquipmentID__x__FMS_Equipment__ID] FOREIGN KEY ([FMS_EquipmentID]) REFERENCES [dbo].[FMS_Equipment] ([ID])
GO
