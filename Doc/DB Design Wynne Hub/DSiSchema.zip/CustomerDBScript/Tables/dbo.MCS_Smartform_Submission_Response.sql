CREATE TABLE [dbo].[MCS_Smartform_Submission_Response]
(
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Mobile_Smartforms_SubmissionResponses_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_Mobile_Smartforms_SubmissionResponses_DateModified] DEFAULT (getutcdate()),
[QuestionName] [nvarchar] (400) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Response] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__Mobile_Smart__ID__7B0717E7] DEFAULT (newsequentialid()),
[MCS_Smartform_SubmissionID] [uniqueidentifier] NOT NULL,
[MCS_Smartform_QuestionID] [uniqueidentifier] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[MCS_Smartform_ParentQuestionId] [uniqueidentifier] NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_MCS_Smartform_Submission_Response_IsActive] DEFAULT ((1))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Smartform_Submission_Response] ADD CONSTRAINT [PK_MCS_Smartform_Submission_Response] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Smartform_Submission_Response__MCS_Smartform_QuestionID] ON [dbo].[MCS_Smartform_Submission_Response] ([MCS_Smartform_QuestionID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Smartform_Submission_Response__MCS_Smartform_SubmissionID] ON [dbo].[MCS_Smartform_Submission_Response] ([MCS_Smartform_SubmissionID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Smartform_Submission_Response] WITH NOCHECK ADD CONSTRAINT [FK_MCS_Smartform_Submission_Response_MCS_Smartform_QuestionID_X_MCS_Smartform_Question_ID] FOREIGN KEY ([MCS_Smartform_QuestionID]) REFERENCES [dbo].[MCS_Smartform_Question] ([ID])
GO
ALTER TABLE [dbo].[MCS_Smartform_Submission_Response] ADD CONSTRAINT [FK_MCS_Smartform_Submission_Response_MCS_Smartform_SubmissionID_X_MCS_Smartform_Submission_ID] FOREIGN KEY ([MCS_Smartform_SubmissionID]) REFERENCES [dbo].[MCS_Smartform_Submission] ([ID])
GO
