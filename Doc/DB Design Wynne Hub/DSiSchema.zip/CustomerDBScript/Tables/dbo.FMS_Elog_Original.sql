CREATE TABLE [dbo].[FMS_Elog_Original]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__FMS_Elog_Ori__ID__6AA5C795] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__FMS_Elog___DateC__6B99EBCE] DEFAULT (getutcdate()),
[StartDate] [datetime] NOT NULL,
[EndDate] [datetime] NULL,
[TotalInTicks] [bigint] NULL,
[DistanceTraveledInKM] [decimal] (18, 2) NOT NULL,
[ShippingDocumentNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Note] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsManuallyCreated] [bit] NOT NULL CONSTRAINT [DF__FMS_Elog___IsMan__6C8E1007] DEFAULT ((0)),
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__FMS_Elog___IsDel__6D823440] DEFAULT ((0)),
[DateDeleted] [datetime] NULL,
[IsDailyReset] [bit] NOT NULL CONSTRAINT [DF__FMS_Elog___IsDai__6E765879] DEFAULT ((0)),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__FMS_Elog___DateM__6F6A7CB2] DEFAULT (getutcdate()),
[MaxExemptionHourRequest] [int] NOT NULL,
[CommonList_ElogStatusTypeID] [uniqueidentifier] NOT NULL,
[FMS_Elog_HeaderID] [uniqueidentifier] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ApprovedAccount_LoginID] [uniqueidentifier] NULL,
[DateApproved] [datetime] NULL,
[DateReapproved] [datetime] NULL,
[IsApproved] [bit] NOT NULL CONSTRAINT [DF__FMS_Elog___IsApp__705EA0EB] DEFAULT ((0)),
[IsInterstateLoad] [bit] NULL CONSTRAINT [DF__FMS_Elog___IsInt__7152C524] DEFAULT ((0)),
[DateLastSync] [datetime] NULL,
[MCS_Device_CommEventID] [uniqueidentifier] NULL,
[MCS_Device_EventSummaryID] [uniqueidentifier] NULL,
[SystemRemarks] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_Original] ADD CONSTRAINT [PK_FMS_Elog_Original] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Elog_Original__FMS_Elog_HeaderID] ON [dbo].[FMS_Elog_Original] ([FMS_Elog_HeaderID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_Original] ADD CONSTRAINT [FK_FMS_Elog_Original__CommonList_ElogStatusTypeID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_ElogStatusTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_Elog_Original] ADD CONSTRAINT [FK_FMS_Elog_Original__FMS_Elog_HeaderID_X_FMS_Elog_Header__ID] FOREIGN KEY ([FMS_Elog_HeaderID]) REFERENCES [dbo].[FMS_Elog_Header] ([ID])
GO
