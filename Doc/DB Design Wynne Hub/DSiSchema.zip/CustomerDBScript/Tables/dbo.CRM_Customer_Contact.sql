CREATE TABLE [dbo].[CRM_Customer_Contact]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__CRM_Customer__ID__38453051] DEFAULT (newsequentialid()),
[FirstName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[LastName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Email] [nvarchar] (150) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_CRM_Customer_Contact_IsActive] DEFAULT ((1)),
[Note] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_CRM_Customer_Contact_DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_CRM_Customer_Contact_DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsPrimary] [bit] NOT NULL CONSTRAINT [DF_CRM_Customer_Contact_IsPrimary] DEFAULT ((0)),
[CRM_CustomerID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[CRM_Customer_Contact] ADD CONSTRAINT [PK_CRM_Customer_Contact] PRIMARY KEY NONCLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [IX__CRM_Customer_Contact__CRM_CustomerID] ON [dbo].[CRM_Customer_Contact] ([CRM_CustomerID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[CRM_Customer_Contact] ADD CONSTRAINT [FK_CRM_Customer_Contact__CustomerID_X_CRM_Customer__ID] FOREIGN KEY ([CRM_CustomerID]) REFERENCES [dbo].[CRM_Customer] ([ID]) ON DELETE CASCADE
GO
