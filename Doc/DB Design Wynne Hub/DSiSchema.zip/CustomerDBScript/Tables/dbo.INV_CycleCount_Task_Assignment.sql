CREATE TABLE [dbo].[INV_CycleCount_Task_Assignment]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__INV_CycleCount_Task_Assignment__ID] DEFAULT (newsequentialid()),
[INV_CycleCount_TaskID] [uniqueidentifier] NOT NULL,
[HR_EmployeeID] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__INV_CycleCount_Task_Assignment__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__INV_CycleCount_Task_Assignment__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsDeleted] [bit] NOT NULL CONSTRAINT [DF_INV_CycleCount_Task_Assignment_IsDeleted] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[INV_CycleCount_Task_Assignment] ADD CONSTRAINT [PK__INV_CycleCount_Task_Assignment] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[INV_CycleCount_Task_Assignment] ADD CONSTRAINT [FK__INV_CycleCount_Task_Assignment__HR_EmployeeID__x__HR_Employee__ID] FOREIGN KEY ([HR_EmployeeID]) REFERENCES [dbo].[HR_Employee] ([ID])
GO
ALTER TABLE [dbo].[INV_CycleCount_Task_Assignment] ADD CONSTRAINT [FK__INV_CycleCount_Task_Assignment__INV_CycleCount_TaskID__x__INV_CycleCount_Task__ID] FOREIGN KEY ([INV_CycleCount_TaskID]) REFERENCES [dbo].[INV_CycleCount_Task] ([ID])
GO
