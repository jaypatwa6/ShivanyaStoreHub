CREATE TABLE [dbo].[TMS_Custom_GridView]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__TMS_Custom_GridView__ID] DEFAULT (newsequentialid()),
[Name] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[HtmlFolder] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[JavascriptFolder] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IndexHtml] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IndexJavascript] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_Custom_GridView] ADD CONSTRAINT [PK__TMS_Custom_GridView__ID] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
