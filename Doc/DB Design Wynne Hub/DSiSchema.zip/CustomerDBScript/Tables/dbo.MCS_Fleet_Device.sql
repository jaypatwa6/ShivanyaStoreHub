CREATE TABLE [dbo].[MCS_Fleet_Device]
(
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Mobile_GPS_Fleet_Device_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_Mobile_GPS_Fleet_Device_DateModified] DEFAULT (getutcdate()),
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__MCS_Fleet_De__ID__12FDD1B2] DEFAULT (newsequentialid()),
[MCS_DeviceID] [uniqueidentifier] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[MCS_FleetID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Fleet_Device] ADD CONSTRAINT [PK_MCS_Fleet_Device] PRIMARY KEY NONCLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [IX__MCS_Fleet_Device__MCS_Device__MCS_FleetID__ID] ON [dbo].[MCS_Fleet_Device] ([MCS_FleetID], [MCS_DeviceID], [ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Fleet_Device] ADD CONSTRAINT [FK_MCS_Fleet_Device__MCS_DeviceID_X_MCS_Device_ID] FOREIGN KEY ([MCS_DeviceID]) REFERENCES [dbo].[MCS_Device] ([ID])
GO
ALTER TABLE [dbo].[MCS_Fleet_Device] ADD CONSTRAINT [FK_MCS_Fleet_Device__MCS_FleetID_X_MCS_Fleet__ID] FOREIGN KEY ([MCS_FleetID]) REFERENCES [dbo].[MCS_Fleet] ([ID])
GO
