CREATE TABLE [dbo].[SFE_UsersInvolveInAction]
(
[ActionKey] [nvarchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[IsCompleted] [bit] NOT NULL CONSTRAINT [DF_SFE_UsersInvolveInAction_IsCompleted] DEFAULT ((0)),
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__SFE_UsersInv__ID__093F5D4E] DEFAULT (newsequentialid()),
[Account_LoginID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[SFE_UsersInvolveInAction] ADD CONSTRAINT [PK_SFE_UsersInvolveInAction] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
