CREATE TABLE [dbo].[MCS_Device_CommEvent]
(
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Mobile_GPS_Device_Event_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_Mobile_GPS_Device_Event_DateModified] DEFAULT (getutcdate()),
[FirmwareVersion] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS SPARSE NULL,
[TimeZone] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[TimeZoneOffset] [decimal] (3, 1) NULL,
[GpsTimeStamp] [datetime] NOT NULL CONSTRAINT [DF_MCS_Device_CommEvent_GpsTimeStamp] DEFAULT (getutcdate()),
[ReceivedTime] [datetime] NULL,
[StartedMovingTime] [datetime] NULL,
[StoppedMovingTime] [datetime] NULL,
[IgnitionOnTime] [datetime] NULL,
[IgnitionOffTime] [datetime] NULL,
[IsIgnitionOn] [bit] NULL CONSTRAINT [DF_Mobile_GPS_Device_Event_IsIgnitionOn] DEFAULT ((0)),
[Latitude] [decimal] (9, 6) NULL,
[Longitude] [decimal] (9, 6) NULL,
[Heading] [smallint] NULL,
[OdometerInKM] [decimal] (9, 2) NULL,
[OdometerReset] [bit] NOT NULL CONSTRAINT [DF_Mobile_GPS_Device_Event_OdometerReset] DEFAULT ((0)),
[VelocityInKPH] [smallint] NULL,
[SpeedLimitInKPH] [smallint] NULL,
[Satellites] [tinyint] NULL,
[CellSignalStrength] [tinyint] NULL,
[FuelLevel] [smallint] NULL,
[FuelUsed] [decimal] (9, 2) NULL,
[Address] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[City] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[State] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PostalCode1] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PollingPort] [int] SPARSE NULL,
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__Mobile_GPS_D__ID__623B6A1D] DEFAULT (newsequentialid()),
[System_List_CountryID] [uniqueidentifier] NULL,
[System_OrganizationID] [uniqueidentifier] NULL,
[HR_EmployeeID] [uniqueidentifier] NULL,
[FMS_EquipmentID] [uniqueidentifier] NULL,
[CommonList_DeviceEventTypeID] [uniqueidentifier] NOT NULL,
[MCS_DeviceID] [uniqueidentifier] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[GPSRawTimestamp] [datetime] NULL,
[DistanceTraveledInKM] [decimal] (11, 2) NULL,
[IsMoving] [bit] NOT NULL CONSTRAINT [DF_MCS_Device_CommEvent__IsMoving] DEFAULT ((0)),
[DurationInSecond] [int] NULL,
[DistanceTraveledByState] [decimal] (9, 2) NULL,
[DistanceTraveledBetweenPingsInKM] [decimal] (9, 2) NULL,
[DurationBetweenPingsInSecond] [int] NULL,
[GpsTimeStampDateKey] [int] NULL,
[GpsTimeStampTimeKey] [int] NULL,
[IsOffHighway] [bit] NULL CONSTRAINT [DF_MCS_Device_CommEvent__IsOffHighway] DEFAULT ((0)),
[ExtendData] [xml] SPARSE NULL,
[BatteryLevel] [tinyint] SPARSE NULL,
[ELD_SequenceID] [int] SPARSE NULL,
[ELD_Origin] [tinyint] SPARSE NULL,
[ELD_Annotation] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS SPARSE NULL,
[MCS_Device_ELDEventCodeID] [uniqueidentifier] SPARSE NULL,
[MalfunctionCode] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS SPARSE NULL,
[MCS_OriginalDeviceID] [uniqueidentifier] SPARSE NULL,
[MCS_BlackboxDeviceID] [uniqueidentifier] SPARSE NULL,
[EngineHours] [decimal] (10, 1) SPARSE NULL,
[CheckSum] [smallint] SPARSE NULL,
[MainVoltage] [decimal] (3, 1) SPARSE NULL,
[RTCTime] [datetime] SPARSE NULL,
[GPSSignalHDOP] [smallint] SPARSE NULL,
[ParsedDataID] [uniqueidentifier] SPARSE NULL,
[OSVersion] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS SPARSE NULL,
[SoftwareVersion] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS SPARSE NULL,
[FuelLevelGallons] [smallint] SPARSE NULL,
[RPM] [int] SPARSE NULL,
[FuelRate] [decimal] (9, 2) SPARSE NULL,
[EngineCoolantTemperature] [int] SPARSE NULL,
[InstantaneousFuelEconomy] [decimal] (9, 2) SPARSE NULL,
[EngineLoad] [tinyint] SPARSE NULL,
[AcceleratorPedalPosition] [decimal] (5, 2) SPARSE NULL,
[ECUProtocol] [nvarchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Device_CommEvent] ADD CONSTRAINT [PK_MCS_Device_CommEvent] PRIMARY KEY NONCLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Device_CommEvent__DateCreated] ON [dbo].[MCS_Device_CommEvent] ([DateCreated]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Device_CommEvent__GPSTimestamp] ON [dbo].[MCS_Device_CommEvent] ([GpsTimeStamp]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_MCS_Device_CommEvent__MCS_BlackboxDeviceID] ON [dbo].[MCS_Device_CommEvent] ([MCS_BlackboxDeviceID]) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [IX__MCS_Device_CommEvent__MCS_DeviceID] ON [dbo].[MCS_Device_CommEvent] ([MCS_DeviceID], [ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_MCS_Device_CommEvent__MCS_OriginalDeviceID] ON [dbo].[MCS_Device_CommEvent] ([MCS_OriginalDeviceID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Device_CommEvent] WITH NOCHECK ADD CONSTRAINT [FK_MCS_Device_CommEvent__CommonList_DeviceEventTypeID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_DeviceEventTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[MCS_Device_CommEvent] ADD CONSTRAINT [FK_MCS_Device_CommEvent__FMS_EquipmentID_X_FMS_Equipment__ID] FOREIGN KEY ([FMS_EquipmentID]) REFERENCES [dbo].[FMS_Equipment] ([ID]) ON DELETE SET NULL
GO
ALTER TABLE [dbo].[MCS_Device_CommEvent] ADD CONSTRAINT [FK_MCS_Device_CommEvent__HR_EmployeeID_X_HR_Employee__ID] FOREIGN KEY ([HR_EmployeeID]) REFERENCES [dbo].[HR_Employee] ([ID]) ON DELETE SET NULL
GO
ALTER TABLE [dbo].[MCS_Device_CommEvent] ADD CONSTRAINT [FK_MCS_Device_CommEvent__MCS_DeviceID_X_Mobile_GPS_Device__ID] FOREIGN KEY ([MCS_DeviceID]) REFERENCES [dbo].[MCS_Device] ([ID])
GO
ALTER TABLE [dbo].[MCS_Device_CommEvent] ADD CONSTRAINT [FK_MCS_Device_CommEvent__System_List_CountryID_X_System_List_Country__ID] FOREIGN KEY ([System_List_CountryID]) REFERENCES [dbo].[System_List_Country] ([ID])
GO
ALTER TABLE [dbo].[MCS_Device_CommEvent] ADD CONSTRAINT [FK_MCS_Device_CommEvent__System_OrganizationID_X_System_Organization__ID] FOREIGN KEY ([System_OrganizationID]) REFERENCES [dbo].[System_Organization] ([ID])
GO
ALTER TABLE [dbo].[MCS_Device_CommEvent] WITH NOCHECK ADD CONSTRAINT [FK_MCS_Device_CommEvent_MCS_Device_ELDEventCode] FOREIGN KEY ([MCS_Device_ELDEventCodeID]) REFERENCES [dbo].[MCS_Device_ELDEventCode] ([ID])
GO
ALTER TABLE [dbo].[MCS_Device_CommEvent] ADD CONSTRAINT [FK_MCS_Device_CommEvent_MCS_Device_Original] FOREIGN KEY ([MCS_OriginalDeviceID]) REFERENCES [dbo].[MCS_Device] ([ID])
GO
