CREATE TABLE [dbo].[HR_Employee_Skill]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__HR_Employee___ID__478773E2] DEFAULT (newsequentialid()),
[Notes] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_HR_Employee_Skill_IsActive] DEFAULT ((1)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_HR_Employee_Skill_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_HR_Employee_Skill_DateModified] DEFAULT (getutcdate()),
[IsPrimary] [bit] NOT NULL CONSTRAINT [DF_HR_Employee_Skill_IsPrimary] DEFAULT ((0)),
[CommonList_EmployeeSkillID] [uniqueidentifier] NOT NULL,
[HR_EmployeeID] [uniqueidentifier] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[CommonList_ProficiencyID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__HR_Employ__Commo__6F556E19] DEFAULT ('F42A1D8C-C195-4ABA-8DD1-744F12E82FDA'),
[ExpiryDate] [datetime] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[HR_Employee_Skill] ADD CONSTRAINT [PK_HR_Employee_Skill] PRIMARY KEY NONCLUSTERED ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[HR_Employee_Skill] WITH NOCHECK ADD CONSTRAINT [FK__HR_Employee_Skill__CommonList_ProficiencyID__X__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_ProficiencyID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[HR_Employee_Skill] ADD CONSTRAINT [FK_HR_Employee_Skill__HR_EmployeeID_X_HR_Employee__ID] FOREIGN KEY ([HR_EmployeeID]) REFERENCES [dbo].[HR_Employee] ([ID]) ON DELETE CASCADE
GO
ALTER TABLE [dbo].[HR_Employee_Skill] WITH NOCHECK ADD CONSTRAINT [FK_HR_Employee_Skill_CommonList_EmployeeSkillID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_EmployeeSkillID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
