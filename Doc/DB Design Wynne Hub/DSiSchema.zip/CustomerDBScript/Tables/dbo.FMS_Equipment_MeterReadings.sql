CREATE TABLE [dbo].[FMS_Equipment_MeterReadings]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_FMS_Equipment_MeterReadings_ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_FMS_Equipment_MeterReadings_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_FMS_Equipment_MeterReadings_DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[FMS_EquipmentID] [uniqueidentifier] NOT NULL,
[MeterReadingDate] [datetime] NOT NULL,
[CommonList_MeterReadingTypeID] [uniqueidentifier] NOT NULL,
[Notes] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ReadingValue] [decimal] (12, 2) NOT NULL,
[Sequence] [int] NOT NULL CONSTRAINT [DF__FMS_Equipment_MeterReadings__Sequence] DEFAULT ((1)),
[OPS_WorkOrder_TaskID] [uniqueidentifier] NULL,
[IsNewMeter] [bit] NULL,
[IsUpdateMeter] [bit] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Equipment_MeterReadings] ADD CONSTRAINT [PK_FMS_Equipment_MeterReadings] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Equipment_MeterReadings__CommonList_MeterReadingTypeID] ON [dbo].[FMS_Equipment_MeterReadings] ([CommonList_MeterReadingTypeID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Equipment_MeterReadings__FMS_EquipmentID] ON [dbo].[FMS_Equipment_MeterReadings] ([FMS_EquipmentID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Equipment_MeterReadings] ADD CONSTRAINT [FK__FMS_Equipment_MeterReadings__OPS_WorkOrder_TaskID__x__OPS_WorkOrder_Task__ID] FOREIGN KEY ([OPS_WorkOrder_TaskID]) REFERENCES [dbo].[OPS_WorkOrder_Task] ([ID])
GO
ALTER TABLE [dbo].[FMS_Equipment_MeterReadings] ADD CONSTRAINT [FK_FMS_Equipment_MeterReadings__CommonList_MeterReadingTypeID_x_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_MeterReadingTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_Equipment_MeterReadings] ADD CONSTRAINT [FK_FMS_Equipment_MeterReadings__FMS_EquipmentID_x_FMS_Equipment__ID] FOREIGN KEY ([FMS_EquipmentID]) REFERENCES [dbo].[FMS_Equipment] ([ID])
GO
