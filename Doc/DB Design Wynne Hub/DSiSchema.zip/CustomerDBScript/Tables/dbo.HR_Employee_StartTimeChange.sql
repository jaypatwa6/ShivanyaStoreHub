CREATE TABLE [dbo].[HR_Employee_StartTimeChange]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_HR_Employee_StartTimeChange_ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL,
[DateModified] [datetime] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[StartTime] [smallint] NOT NULL,
[HR_EmployeeID] [uniqueidentifier] NOT NULL,
[DateEffected] [datetime] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[HR_Employee_StartTimeChange] ADD CONSTRAINT [PK_HR_Employee_ZoneCycleChange] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[HR_Employee_StartTimeChange] ADD CONSTRAINT [FK_HR_Employee_StartTimeChange_HR_Employee] FOREIGN KEY ([HR_EmployeeID]) REFERENCES [dbo].[HR_Employee] ([ID])
GO
