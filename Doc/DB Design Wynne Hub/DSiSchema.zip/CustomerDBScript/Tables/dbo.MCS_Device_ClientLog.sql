CREATE TABLE [dbo].[MCS_Device_ClientLog]
(
[ID] [uniqueidentifier] NOT NULL ROWGUIDCOL CONSTRAINT [DF__MCS_Device_ClientLog__ID] DEFAULT (newsequentialid()),
[DeviceID] [uniqueidentifier] NOT NULL,
[DateRequested] [datetime] NOT NULL CONSTRAINT [DF__MCS_Device_ClientLog__DateRequested] DEFAULT (getutcdate()),
[DateUploaded] [datetime] NULL,
[RequestedBy] [uniqueidentifier] NULL,
[UploadedBy] [uniqueidentifier] NULL,
[FileURL] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[RetryTimes] [int] NOT NULL,
[IsDeleted] [bit] NOT NULL CONSTRAINT [DF_MCS_Device_ClientLog_IsDeleted] DEFAULT ((0)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_MCS_Device_ClientLog_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_MCS_Device_ClientLog_DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL CONSTRAINT [DF_MCS_Device_ClientLog_CreatedBy] DEFAULT ('F85A4B2F-ED82-4436-8943-96548B2F0AF5'),
[ModifiedBy] [uniqueidentifier] NOT NULL CONSTRAINT [DF_MCS_Device_ClientLog_ModifiedBy] DEFAULT ('F85A4B2F-ED82-4436-8943-96548B2F0AF5'),
[Note] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[StorageType] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Device_ClientLog] ADD CONSTRAINT [PK_MCS_Device_ClientLog] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Device_ClientLog] ADD CONSTRAINT [FK__MCS_Device_ClientLog__DeviceID__x__MCS_Device__Id] FOREIGN KEY ([DeviceID]) REFERENCES [dbo].[MCS_Device] ([ID])
GO
