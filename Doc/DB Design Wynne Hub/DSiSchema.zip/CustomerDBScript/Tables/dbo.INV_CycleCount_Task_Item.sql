CREATE TABLE [dbo].[INV_CycleCount_Task_Item]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__INV_CycleCount_Task_Item__ID] DEFAULT (newsequentialid()),
[INV_CycleCount_TaskID] [uniqueidentifier] NOT NULL,
[Number] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[StockClass] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[BinLocation] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CountedQuantity] [int] NULL,
[CountedDate] [datetime] NULL,
[CountedBy] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Comment] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ItemDescription] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IntegrationSystemDate] [datetime] NOT NULL,
[IntegrationModifiedDate] [datetime] NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__INV_CycleCount_Task_Item__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__INV_CycleCount_Task_Item__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsDeleted] [bit] NOT NULL CONSTRAINT [DF_INV_CycleCount_Task_Item_IsDeleted] DEFAULT ((0)),
[SerialNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[QuantityOnHand] [int] NOT NULL CONSTRAINT [DF__INV_Cycle__Quant__54A177DD] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[INV_CycleCount_Task_Item] ADD CONSTRAINT [PK__INV_CycleCount_Task_Item] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[INV_CycleCount_Task_Item] ADD CONSTRAINT [FK__INV_CycleCount_Task_Item__INV_CycleCount_TaskID__x__INV_CycleCount_Task__ID] FOREIGN KEY ([INV_CycleCount_TaskID]) REFERENCES [dbo].[INV_CycleCount_Task] ([ID])
GO
