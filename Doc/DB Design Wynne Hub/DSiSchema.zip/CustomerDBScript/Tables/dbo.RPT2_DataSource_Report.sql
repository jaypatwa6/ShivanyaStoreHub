CREATE TABLE [dbo].[RPT2_DataSource_Report]
(
[ID] [uniqueidentifier] NOT NULL,
[DataSourceID] [uniqueidentifier] NOT NULL,
[ReportID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[RPT2_DataSource_Report] ADD CONSTRAINT [PK_RPT2_DataSource_Report] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[RPT2_DataSource_Report] WITH NOCHECK ADD CONSTRAINT [FK_RPT2_DataSource_Report_RPT2_DataSource] FOREIGN KEY ([DataSourceID]) REFERENCES [dbo].[RPT2_DataSource] ([ID])
GO
ALTER TABLE [dbo].[RPT2_DataSource_Report] WITH NOCHECK ADD CONSTRAINT [FK_RPT2_DataSource_Report_RPT2_Report] FOREIGN KEY ([ReportID]) REFERENCES [dbo].[RPT2_Report] ([ID])
GO
ALTER TABLE [dbo].[RPT2_DataSource_Report] NOCHECK CONSTRAINT [FK_RPT2_DataSource_Report_RPT2_DataSource]
GO
ALTER TABLE [dbo].[RPT2_DataSource_Report] NOCHECK CONSTRAINT [FK_RPT2_DataSource_Report_RPT2_Report]
GO
