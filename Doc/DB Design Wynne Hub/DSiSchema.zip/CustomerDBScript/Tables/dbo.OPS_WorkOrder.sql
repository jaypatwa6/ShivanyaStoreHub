CREATE TABLE [dbo].[OPS_WorkOrder]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__Sales_Order__ID__7A12F3AE] DEFAULT (newsequentialid()),
[System_OrganizationID] [uniqueidentifier] NULL,
[CRM_CustomerID] [uniqueidentifier] NULL,
[CRM_Customer_ContactID] [uniqueidentifier] NULL,
[CommonList_OrderPriorityID] [uniqueidentifier] NOT NULL,
[CommonList_OrderTypeID] [uniqueidentifier] NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[AssignedToEmployeeID] [uniqueidentifier] NULL,
[AssignmentTypeKeyword] [nvarchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF_Sales_Order_IsDelete] DEFAULT ((0)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Sales_Order_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_Sales_Order_DateModified] DEFAULT (getutcdate()),
[DriverPhoneNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[OrderNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[EventData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsComplete] [bit] NOT NULL CONSTRAINT [DF__OPS_WorkO__IsCom__6E82DC1F] DEFAULT ((0)),
[StartDate] [datetime] NULL,
[EndDate] [datetime] NULL,
[SiteDescription] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Address] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[City] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[State] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PostalCode] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Longitude] [decimal] (9, 6) NULL,
[Latitude] [decimal] (9, 6) NULL,
[CRM_JobsiteID] [uniqueidentifier] NULL,
[Sequence] [int] NULL,
[Note] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IntegrationID] [nvarchar] (150) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[FMS_EquipmentID] [uniqueidentifier] NULL,
[Current_FMSEquipment_MeterReadingsID] [uniqueidentifier] NULL,
[Previous_FMSEquipment_MeterReadingsID] [uniqueidentifier] NULL,
[EstimatedBy] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CommonList_OPSWorkOrder_StatusID] [uniqueidentifier] NULL,
[CommonList_OPSWorkOrder_DepartmentTypeID] [uniqueidentifier] NULL,
[Created_CommonList_ApplicationID] [uniqueidentifier] NULL,
[Integration_CommonList_ApplicationID] [uniqueidentifier] NULL,
[CommonList_OPSWorkOrder_LocationTypeID] [uniqueidentifier] NULL,
[CommonList_WorkOrderTypeID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__OPS_WorkOrder__CommonList_WorkOrderTypeID] DEFAULT ('AE72FC1B-E3E2-49FC-8F3A-59EE1179F0A2')
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_WorkOrder] ADD CONSTRAINT [PK_Sales_Order] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__OPS_WorkOrder__WorkOrderTypeID_IsDelete_FMSEquipmentID] ON [dbo].[OPS_WorkOrder] ([CommonList_WorkOrderTypeID], [IsDelete], [FMS_EquipmentID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_WorkOrder] ADD CONSTRAINT [FK__OPS_WorkOrder__CommonList_OPSWorkOrder_DepartmentTypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPSWorkOrder_DepartmentTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder] ADD CONSTRAINT [FK__OPS_WorkOrder__CommonList_OPSWorkOrder_LocationTypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPSWorkOrder_LocationTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder] ADD CONSTRAINT [FK__OPS_WorkOrder__CommonList_OPSWorkOrder_StatusID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPSWorkOrder_StatusID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder] ADD CONSTRAINT [FK__OPS_WorkOrder__CommonList_WorkOrderTypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_WorkOrderTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder] ADD CONSTRAINT [FK__OPS_WorkOrder__Created_CommonList_ApplicationID__x__System_CommonList_Item__ID] FOREIGN KEY ([Created_CommonList_ApplicationID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder] ADD CONSTRAINT [FK__OPS_WorkOrder__FMS_EquipmentID__x__FMS_Equipment__ID] FOREIGN KEY ([FMS_EquipmentID]) REFERENCES [dbo].[FMS_Equipment] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder] ADD CONSTRAINT [FK__OPS_WorkOrder__Integration_CommonList_ApplicationID__x__System_CommonList_Item__ID] FOREIGN KEY ([Integration_CommonList_ApplicationID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder] WITH NOCHECK ADD CONSTRAINT [FK_OPS_WorkOrder__CommonList_OrderPriorityID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OrderPriorityID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder] WITH NOCHECK ADD CONSTRAINT [FK_OPS_WorkOrder__CommonList_OrderTypeID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OrderTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder] ADD CONSTRAINT [FK_OPS_WorkOrder__CRM_Customer_ContactID_X_CRM_Customer_Contact__ID] FOREIGN KEY ([CRM_Customer_ContactID]) REFERENCES [dbo].[CRM_Customer_Contact] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder] ADD CONSTRAINT [FK_OPS_WorkOrder__CRM_CustomerID_X_CRM_Customer__ID] FOREIGN KEY ([CRM_CustomerID]) REFERENCES [dbo].[CRM_Customer] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder] ADD CONSTRAINT [FK_OPS_WorkOrder__CRM_JobsiteID_X_CRM_Jobsite__ID] FOREIGN KEY ([CRM_JobsiteID]) REFERENCES [dbo].[CRM_Jobsite] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder] ADD CONSTRAINT [FK_OPS_WorkOrder__System_OrganizationID_X_System_Organizations_ID] FOREIGN KEY ([System_OrganizationID]) REFERENCES [dbo].[System_Organization] ([ID]) ON DELETE SET NULL
GO
