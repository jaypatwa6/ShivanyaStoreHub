CREATE TABLE [dbo].[OPS_TimeClock]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_OPS_TimeClock_ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_OPS_TimeClock_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_OPS_TimeClock_DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF_OPS_TimeClock_IsDelete] DEFAULT ((0)),
[HR_EmployeeID] [uniqueidentifier] NOT NULL,
[StartTime] [datetime] NULL,
[EndTime] [datetime] NULL,
[Note] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_TimeClock] ADD CONSTRAINT [PK_OPS_TimeClock] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_TimeClock] ADD CONSTRAINT [FK__OPS_TimeClock__HR_EmployeeID__x__HR_Employee__ID] FOREIGN KEY ([HR_EmployeeID]) REFERENCES [dbo].[HR_Employee] ([ID])
GO
