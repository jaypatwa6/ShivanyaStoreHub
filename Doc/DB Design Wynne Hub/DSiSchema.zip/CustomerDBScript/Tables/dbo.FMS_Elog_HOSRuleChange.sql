CREATE TABLE [dbo].[FMS_Elog_HOSRuleChange]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_FMS_Elog_ZoneCycleChange_ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL,
[DateModified] [datetime] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[FMS_Elog_HOSRuleID] [uniqueidentifier] NOT NULL,
[HR_EmployeeID] [uniqueidentifier] NOT NULL,
[DateEffected] [datetime] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_HOSRuleChange] ADD CONSTRAINT [PK_FMS_Elog_ZoneCycleChange] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_HOSRuleChange] ADD CONSTRAINT [FK_FMS_Elog_HOSRuleChange_HR_Employee] FOREIGN KEY ([HR_EmployeeID]) REFERENCES [dbo].[HR_Employee] ([ID])
GO
ALTER TABLE [dbo].[FMS_Elog_HOSRuleChange] ADD CONSTRAINT [FK_FMS_Elog_ZoneCycleChange_FMS_Elog_HOSRule] FOREIGN KEY ([FMS_Elog_HOSRuleID]) REFERENCES [dbo].[FMS_Elog_HOSRule] ([ID]) ON DELETE CASCADE
GO
