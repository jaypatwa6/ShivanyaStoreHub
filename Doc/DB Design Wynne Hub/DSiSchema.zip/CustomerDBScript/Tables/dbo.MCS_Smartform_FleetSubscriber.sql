CREATE TABLE [dbo].[MCS_Smartform_FleetSubscriber]
(
[IsActive] [bit] NOT NULL CONSTRAINT [DF_Mobile_Smartforms_Subscribers_IsActive] DEFAULT ((1)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Mobile_Smartforms_Subscribers_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_Mobile_Smartforms_Subscribers_DateModified] DEFAULT (getutcdate()),
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__Mobile_Smart__ID__5F5EFD72] DEFAULT (newsequentialid()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[MCS_SmartformID] [uniqueidentifier] NOT NULL,
[MCS_FleetID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Smartform_FleetSubscriber] ADD CONSTRAINT [PK_MCS_Smartforms_Subscribers] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Smartform_FleetSubscriber__IsActive] ON [dbo].[MCS_Smartform_FleetSubscriber] ([IsActive]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Smartform_FleetSubscriber__MCS_FleetID] ON [dbo].[MCS_Smartform_FleetSubscriber] ([MCS_FleetID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Smartform_FleetSubscriber__MCS_SmartformID] ON [dbo].[MCS_Smartform_FleetSubscriber] ([MCS_SmartformID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Smartform_FleetSubscriber] ADD CONSTRAINT [FK_MCS_Smartform_FleetSubscriber__MCS_FleetID_X_MCS_Fleet__ID] FOREIGN KEY ([MCS_FleetID]) REFERENCES [dbo].[MCS_Fleet] ([ID])
GO
ALTER TABLE [dbo].[MCS_Smartform_FleetSubscriber] WITH NOCHECK ADD CONSTRAINT [FK_MCS_Smartform_FleetSubscriber_MCS_SmartformID_X_MCS_Smartform_ID] FOREIGN KEY ([MCS_SmartformID]) REFERENCES [dbo].[MCS_Smartform] ([ID])
GO
