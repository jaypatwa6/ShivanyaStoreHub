CREATE TABLE [dbo].[TMS_Unsubscribe]
(
[ID] [bigint] NOT NULL IDENTITY(1, 1),
[UserID] [uniqueidentifier] NOT NULL,
[OrderID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_Unsubscribe] ADD CONSTRAINT [PK__TMS_Unsubscribe] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_Unsubscribe] ADD CONSTRAINT [FK__TMS_Unsubscribe__OrderID__x__TMS_Order__ID] FOREIGN KEY ([OrderID]) REFERENCES [dbo].[TMS_Order] ([ID])
GO
