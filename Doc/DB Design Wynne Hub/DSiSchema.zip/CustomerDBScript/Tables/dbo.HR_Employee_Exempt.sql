CREATE TABLE [dbo].[HR_Employee_Exempt]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_HR_Employee_Exempt_ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL,
[DateModified] [datetime] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[Reason] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[HR_EmployeeID] [uniqueidentifier] NOT NULL,
[IsActive] [bit] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[HR_Employee_Exempt] ADD CONSTRAINT [PK_HR_Employee_Exempt] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[HR_Employee_Exempt] ADD CONSTRAINT [FK_HR_Employee_Exempt_HR_Employee] FOREIGN KEY ([HR_EmployeeID]) REFERENCES [dbo].[HR_Employee] ([ID])
GO
