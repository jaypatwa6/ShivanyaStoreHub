CREATE TABLE [dbo].[CRM_Customer]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__CRM_Customer__ID__7FCBCD04] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_CRM_Customer_DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_CRM_Customer_DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[Name] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Number] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_CRM_Customer_IsActive] DEFAULT ((1)),
[Note] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[System_OrganizationID] [uniqueidentifier] NULL,
[CommonList_CustomerTypeID] [uniqueidentifier] NOT NULL,
[ExtendedData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DateOfBirth] [datetime] NULL,
[DriverLicenceState] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Integration_CommonList_ApplicationID] [uniqueidentifier] NULL,
[Integration_ReferenceID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Tags] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[JobNumberRequired] [bit] NOT NULL CONSTRAINT [DF__CRM_Custo__JobNu__4A8DFDBE] DEFAULT ((0)),
[Email] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DriverLicenceNumber] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[RequiredPONumber] [bit] NOT NULL CONSTRAINT [DF__CRM_Custo__Requi__1D5142F3] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[CRM_Customer] ADD CONSTRAINT [PK_CRM_Customer] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[CRM_Customer] ADD CONSTRAINT [UQ_CRM_Customer_Number] UNIQUE NONCLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__CRM_Customer__Integration_ReferenceID] ON [dbo].[CRM_Customer] ([Integration_ReferenceID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__CRM_Customer__IsActive] ON [dbo].[CRM_Customer] ([IsActive]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__CRM_Customer__CustomerName] ON [dbo].[CRM_Customer] ([Name]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__CRM_Customer__Number] ON [dbo].[CRM_Customer] ([Number]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__CRM_Customer__System_OrganizationID] ON [dbo].[CRM_Customer] ([System_OrganizationID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[CRM_Customer] ADD CONSTRAINT [FK__CRM_Customer__Integration_CommonList_ApplicationID__x__System_CommonList_Item__ID] FOREIGN KEY ([Integration_CommonList_ApplicationID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[CRM_Customer] ADD CONSTRAINT [FK_CRM_Customer__CommonList_CustomerTypeID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_CustomerTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[CRM_Customer] ADD CONSTRAINT [FK_CRM_Customer__System_OrganizationID_X_System_Organizations__ID] FOREIGN KEY ([System_OrganizationID]) REFERENCES [dbo].[System_Organization] ([ID]) ON DELETE SET NULL
GO
