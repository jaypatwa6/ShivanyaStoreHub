CREATE TABLE [dbo].[MCS_Watch]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_MCS_Watch_ID] DEFAULT (newsequentialid()),
[Name] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DateCreated] [datetime] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL,
[Description] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Account_LoginID] [uniqueidentifier] NOT NULL,
[ViewMode] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Watch] ADD CONSTRAINT [PK_MCS_Watch] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
