CREATE TABLE [dbo].[MCS_Trip_Stop_Task]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__SDMS_Task__ID__4A63E08C] DEFAULT (newsequentialid()),
[MCS_Trip_StopID] [uniqueidentifier] NOT NULL,
[CommonList_TaskStatusID] [uniqueidentifier] NOT NULL,
[CRM_CustomerID] [uniqueidentifier] NOT NULL,
[CommonList_OrderTypeID] [uniqueidentifier] NOT NULL,
[CommonList_OrderPriorityID] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_StopActivity_DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[TaskNumber] [int] NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_SDMS_Task_DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[Sequence] [int] NOT NULL,
[Note] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DateSynchronized] [datetime] NOT NULL CONSTRAINT [DF__SDMS_Task__DateS__6AEFE058] DEFAULT (getdate()),
[Acknowledge] [bit] NOT NULL CONSTRAINT [DF__SDMS_Task__Ackno__6BE40491] DEFAULT ((1)),
[IsDeleted] [bit] NOT NULL CONSTRAINT [DF__SDMS_Task__IsDel__6CD828CA] DEFAULT ((0)),
[DocumentNumbers] [nvarchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[TruckID] [nvarchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DateAcknowledged] [datetime] NULL CONSTRAINT [DF_MCS_Trip_Stop_Task_DateAcknowledged] DEFAULT (NULL),
[IsDelivery] [bit] NULL,
[ExtendedData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DataSource] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[RefDoc_LoadNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ExtendedData2] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[RefDoc_CustomerBillOfLading] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[RefDoc_CustomerJobNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[RefDoc_CustomerPO] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[RefDoc_LoadBillOfLading] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[RefDoc_TicketNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[RefDoc_OrderNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CommonList_WorkOrderTypeID] [uniqueidentifier] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Trip_Stop_Task] ADD CONSTRAINT [PK_MCS_Trip_Stop_Task] PRIMARY KEY NONCLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Trip_Stop_Task__CommonList_TaskStatusID] ON [dbo].[MCS_Trip_Stop_Task] ([CommonList_TaskStatusID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Trip_Stop_Task__CRM_CustomerID] ON [dbo].[MCS_Trip_Stop_Task] ([CRM_CustomerID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Trip_Stop_Task__IsDeleted__CommonList_TaskStatusID__ID__MCS_TripStopID] ON [dbo].[MCS_Trip_Stop_Task] ([IsDeleted], [CommonList_TaskStatusID], [ID], [MCS_Trip_StopID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Trip_Stop_Task__MCS_Trip_StopID] ON [dbo].[MCS_Trip_Stop_Task] ([MCS_Trip_StopID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Trip_Stop_Task__RefDoc_CustomerBillOfLading_X_IsDeleted] ON [dbo].[MCS_Trip_Stop_Task] ([RefDoc_CustomerBillOfLading], [IsDeleted]) INCLUDE ([ID], [MCS_Trip_StopID], [CommonList_TaskStatusID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Trip_Stop_Task__RefDoc_CustomerJobNumber_X_IsDeleted] ON [dbo].[MCS_Trip_Stop_Task] ([RefDoc_CustomerJobNumber], [IsDeleted]) INCLUDE ([ID], [MCS_Trip_StopID], [CommonList_TaskStatusID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Trip_Stop_Task__RefDoc_CustomerPO_X_IsDeleted] ON [dbo].[MCS_Trip_Stop_Task] ([RefDoc_CustomerPO], [IsDeleted]) INCLUDE ([ID], [MCS_Trip_StopID], [CommonList_TaskStatusID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Trip_Stop_Task__RefDoc_LoadBillOfLading_X_IsDeleted] ON [dbo].[MCS_Trip_Stop_Task] ([RefDoc_LoadBillOfLading], [IsDeleted]) INCLUDE ([ID], [MCS_Trip_StopID], [CommonList_TaskStatusID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Trip_Stop_Task__LoadNumber__IsDeleted] ON [dbo].[MCS_Trip_Stop_Task] ([RefDoc_LoadNumber], [IsDeleted]) INCLUDE ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Trip_Stop_Task__RefDoc_LoadNumber_X_IsDeleted] ON [dbo].[MCS_Trip_Stop_Task] ([RefDoc_LoadNumber], [IsDeleted]) INCLUDE ([ID], [MCS_Trip_StopID], [CommonList_TaskStatusID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Trip_Stop_Task__RefDoc_OrderNumber_X_IsDeleted] ON [dbo].[MCS_Trip_Stop_Task] ([RefDoc_OrderNumber], [IsDeleted]) INCLUDE ([ID], [MCS_Trip_StopID], [CommonList_TaskStatusID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Trip_Stop_Task__RefDoc_TicketNumber_X_IsDeleted] ON [dbo].[MCS_Trip_Stop_Task] ([RefDoc_TicketNumber], [IsDeleted]) INCLUDE ([ID], [MCS_Trip_StopID], [CommonList_TaskStatusID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Trip_Stop_Task] WITH NOCHECK ADD CONSTRAINT [FK__MCS_Trip_Stop_Task__CommonList_WorkOrderTypeID__X__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_WorkOrderTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[MCS_Trip_Stop_Task] ADD CONSTRAINT [FK_MCS_Trip_Stop_Task__CommonList_OrderPriorityID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OrderPriorityID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[MCS_Trip_Stop_Task] WITH NOCHECK ADD CONSTRAINT [FK_MCS_Trip_Stop_Task__CommonList_SalesOrderTaskTypeID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OrderTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[MCS_Trip_Stop_Task] WITH NOCHECK ADD CONSTRAINT [FK_MCS_Trip_Stop_Task__CommonList_TaskStatusID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_TaskStatusID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[MCS_Trip_Stop_Task] ADD CONSTRAINT [FK_MCS_Trip_Stop_Task__CRM_CustomerID_X_CRM_Customer__ID] FOREIGN KEY ([CRM_CustomerID]) REFERENCES [dbo].[CRM_Customer] ([ID])
GO
ALTER TABLE [dbo].[MCS_Trip_Stop_Task] ADD CONSTRAINT [FK_MCS_Trip_Stop_Task__MCS_Dispatch_Trip_StopID_X_MCS_Dispatch_Trip_Stop__ID] FOREIGN KEY ([MCS_Trip_StopID]) REFERENCES [dbo].[MCS_Trip_Stop] ([ID])
GO
