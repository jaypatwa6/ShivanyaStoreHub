CREATE TABLE [dbo].[HR_Employee_Workload]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_HR_Employee_Workload_ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL,
[DateModified] [datetime] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__HR_Employee_Workload__IsDelete] DEFAULT ((0)),
[ContractNumber] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[HR_EmployeeID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[HR_Employee_Workload] ADD CONSTRAINT [PK_HR_HR_Employee_Workload] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_HR_Employee_Workload_ContractNumber] ON [dbo].[HR_Employee_Workload] ([ContractNumber]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[HR_Employee_Workload] ADD CONSTRAINT [FK_HR_Employee_Workload_HR_Employee] FOREIGN KEY ([HR_EmployeeID]) REFERENCES [dbo].[HR_Employee] ([ID])
GO
