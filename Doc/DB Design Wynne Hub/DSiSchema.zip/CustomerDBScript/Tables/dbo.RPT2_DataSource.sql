CREATE TABLE [dbo].[RPT2_DataSource]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_RW2_Cus_ReportDataSource_Id] DEFAULT (newsequentialid()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL,
[DateModified] [datetime] NOT NULL,
[Name] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DataSourceMetadata] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[RawSql] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CommonList_DataSourceTypeID] [uniqueidentifier] NULL,
[Columns] [xml] NULL,
[Description] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF__RPT2_Data__IsAct__6B4FD30B] DEFAULT ((1)),
[ShortName] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[RPT2_DataSource] ADD CONSTRAINT [RW2_Cus_ReportDataSouce_PK] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
