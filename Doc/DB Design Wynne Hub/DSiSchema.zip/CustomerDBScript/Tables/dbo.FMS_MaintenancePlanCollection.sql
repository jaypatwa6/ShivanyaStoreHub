CREATE TABLE [dbo].[FMS_MaintenancePlanCollection]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_FMS_MaintenancePlanCollection_ID] DEFAULT (newsequentialid()),
[Name] [nvarchar] (150) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_FMS_MaintenancePlanCollection_IsActive] DEFAULT ((1)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__FMS_MaintenancePlanCollection__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__FMS_MaintenancePlanCollection__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL CONSTRAINT [DF__FMS_MaintenancePlanCollection__CreatedBy] DEFAULT ('00000000-0000-0000-0000-000000000000'),
[ModifiedBy] [uniqueidentifier] NOT NULL CONSTRAINT [DF__FMS_MaintenancePlanCollection__ModifiedBy] DEFAULT ('00000000-0000-0000-0000-000000000000')
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_MaintenancePlanCollection] ADD CONSTRAINT [PK_FMS_MaintenancePlanCollection] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
