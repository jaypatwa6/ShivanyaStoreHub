CREATE TABLE [dbo].[MCS_Device]
(
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Mobile_GPS_Device_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_Mobile_GPS_Device_DateModified] DEFAULT (getutcdate()),
[IsActive] [bit] NOT NULL CONSTRAINT [DF_Mobile_GPS_Device_IsActive] DEFAULT ((1)),
[FirmwareVersion] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS SPARSE NULL,
[DeviceGUID] [nvarchar] (300) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DeviceModel] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[SerialNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IPAddress] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PhoneNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[TimeZone] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[TimeZoneOffset] [decimal] (3, 1) NULL,
[GpsTimeStamp] [datetime] NOT NULL CONSTRAINT [DF_MCS_Device_GpsTimeStamp] DEFAULT (getutcdate()),
[SentTime] [datetime] NULL,
[ReceivedTime] [datetime] NULL,
[StartedMovingTime] [datetime] NULL,
[StoppedMovingTime] [datetime] NULL,
[IgnitionOnTime] [datetime] NULL,
[IgnitionOffTime] [datetime] NULL,
[IsIgnitionOn] [bit] NULL,
[Latitude] [decimal] (9, 6) NULL,
[Longitude] [decimal] (9, 6) NULL,
[Heading] [smallint] NULL,
[OdometerInKM] [decimal] (9, 2) NULL,
[OdometerReset] [bit] NOT NULL CONSTRAINT [DF_Mobile_GPS_Device_OdometerReset] DEFAULT ((0)),
[VelocityInKPH] [smallint] NULL,
[SpeedLimitInKPH] [smallint] NULL,
[Satellites] [tinyint] NULL,
[CellSignalStrength] [tinyint] NULL,
[GPSSignalHDOP] [tinyint] NULL,
[FuelLevel] [smallint] NULL,
[FuelUsed] [decimal] (9, 2) NULL,
[Address] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[City] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[State] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PostalCode1] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DockIndicator] [bit] NOT NULL CONSTRAINT [DF_Mobile_GPS_Device_DockIndicator] DEFAULT ((0)),
[PollingPort] [int] SPARSE NULL,
[AuditProcessBufferTimestamp] [datetime] NULL,
[AuditDataParserTimestamp] [datetime] NULL,
[AuditMsgQWriteTimestamp] [datetime] NULL,
[AuditMsgQReadTimestamp] [datetime] NULL,
[AuditBizLayerTimestamp] [datetime] NULL,
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__Mobile_GPS_D__ID__496FBC53] DEFAULT (newsequentialid()),
[System_List_CountryID] [uniqueidentifier] NULL,
[System_OrganizationID] [uniqueidentifier] NULL,
[HR_EmployeeID] [uniqueidentifier] NULL,
[FMS_EquipmentID] [uniqueidentifier] NULL,
[CommonList_DeviceEventTypeID] [uniqueidentifier] NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DistanceTraveledInKM] [decimal] (11, 2) NULL,
[DurationInSecond] [int] NULL,
[IsMoving] [bit] NOT NULL CONSTRAINT [DF_MCS_Device__IsMoving] DEFAULT ((0)),
[DistanceTraveledByState] [decimal] (9, 2) NULL,
[DeviceType] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[BatteryLevel] [tinyint] SPARSE NULL,
[MalfunctionCode] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS SPARSE NULL,
[ELD_SequenceID] [int] SPARSE NULL,
[ExtendData] [xml] SPARSE NULL,
[SoftwareVersion] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS SPARSE NULL,
[OSType] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS SPARSE NULL,
[OSVersion] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS SPARSE NULL,
[MCS_Device_ELDEventCodeID] [uniqueidentifier] SPARSE NULL,
[MCS_OriginalDeviceID] [uniqueidentifier] SPARSE NULL,
[MCS_BlackboxDeviceID] [uniqueidentifier] SPARSE NULL,
[EngineHours] [decimal] (10, 1) SPARSE NULL,
[MainVoltage] [decimal] (3, 1) SPARSE NULL,
[RTCTime] [datetime] SPARSE NULL,
[FcmDeviceToken] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ICCID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[FuelLevelGallons] [smallint] SPARSE NULL,
[RPM] [int] SPARSE NULL,
[FuelRate] [decimal] (9, 2) SPARSE NULL,
[EngineCoolantTemperature] [int] SPARSE NULL,
[InstantaneousFuelEconomy] [decimal] (9, 2) SPARSE NULL,
[EngineLoad] [tinyint] SPARSE NULL,
[AcceleratorPedalPosition] [decimal] (5, 2) SPARSE NULL,
[ECUProtocol] [nvarchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Device] ADD CONSTRAINT [PK_MCS_Device] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Device__DateModified] ON [dbo].[MCS_Device] ([DateModified]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Device__FMS_EquipmentID] ON [dbo].[MCS_Device] ([FMS_EquipmentID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Device__HR_EmployeeID] ON [dbo].[MCS_Device] ([HR_EmployeeID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Device__IsActive] ON [dbo].[MCS_Device] ([IsActive]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Device__SerialNumber] ON [dbo].[MCS_Device] ([SerialNumber]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Device__System_OrganizationID] ON [dbo].[MCS_Device] ([System_OrganizationID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Device] WITH NOCHECK ADD CONSTRAINT [FK_MCS_Device__CommonList_DeviceEventTypeID_X_System_CommonList_Item_ID] FOREIGN KEY ([CommonList_DeviceEventTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[MCS_Device] ADD CONSTRAINT [FK_MCS_Device__FMS_EquipmentID_X_FMS_Equipment__ID] FOREIGN KEY ([FMS_EquipmentID]) REFERENCES [dbo].[FMS_Equipment] ([ID])
GO
ALTER TABLE [dbo].[MCS_Device] ADD CONSTRAINT [FK_MCS_Device__HR_EmployeeID_X_HR_Employee_ID] FOREIGN KEY ([HR_EmployeeID]) REFERENCES [dbo].[HR_Employee] ([ID])
GO
ALTER TABLE [dbo].[MCS_Device] ADD CONSTRAINT [FK_MCS_Device__System_List_CountryID_X_System_List_Countries_ID] FOREIGN KEY ([System_List_CountryID]) REFERENCES [dbo].[System_List_Country] ([ID])
GO
ALTER TABLE [dbo].[MCS_Device] ADD CONSTRAINT [FK_MCS_Device__System_OrganizationID_X_System_Organizations__ID] FOREIGN KEY ([System_OrganizationID]) REFERENCES [dbo].[System_Organization] ([ID]) ON DELETE SET NULL
GO
ALTER TABLE [dbo].[MCS_Device] WITH NOCHECK ADD CONSTRAINT [FK_MCS_Device_MCS_Device_ELDEventCode] FOREIGN KEY ([MCS_Device_ELDEventCodeID]) REFERENCES [dbo].[MCS_Device_ELDEventCode] ([ID])
GO
ALTER TABLE [dbo].[MCS_Device] ADD CONSTRAINT [FK_MCS_Device_MCS_Device_Original] FOREIGN KEY ([MCS_OriginalDeviceID]) REFERENCES [dbo].[MCS_Device] ([ID])
GO
EXEC sp_addextendedproperty N'MS_Description', N'FCM Device Token', 'SCHEMA', N'dbo', 'TABLE', N'MCS_Device', 'COLUMN', N'FcmDeviceToken'
GO
