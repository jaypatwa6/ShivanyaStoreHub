CREATE TABLE [dbo].[System_CommonList]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__System_Commo__ID__3568C3A6] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_System_CommonList_DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_System_CommonList_DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[Name] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Keyword] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Description] [nvarchar] (400) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DeveloperNotes] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsSystemList] [bit] NOT NULL CONSTRAINT [DF_System_CommonLists_IsSystemList] DEFAULT ((1)),
[DefaultSortOnItemName] [bit] NOT NULL CONSTRAINT [DF_System_CommonLists_DefaultSortOnItemName] DEFAULT ((0)),
[System_ModuleID] [uniqueidentifier] NOT NULL,
[CategoryName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[IsCanAdd] [bit] NOT NULL CONSTRAINT [DF_System_CommonLists_IsCanAdd] DEFAULT ((0)),
[IsCanEdit] [bit] NOT NULL CONSTRAINT [DF_System_CommonLists_IsCanEdit] DEFAULT ((0)),
[IsActive] [bit] NOT NULL CONSTRAINT [DF_System_CommonList_IsActive] DEFAULT ((1)),
[IsAllowBlankName] [bit] NOT NULL CONSTRAINT [DF_System_CommonList_IsAllowBlankName] DEFAULT ((1)),
[IsCanView] [bit] NOT NULL CONSTRAINT [DF__System_Co__IsCan__3F3159AB] DEFAULT ((1))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_CommonList] ADD CONSTRAINT [PK_System_CommonList] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_CommonList] ADD CONSTRAINT [UQ_System_CommonList_Keyword] UNIQUE NONCLUSTERED  ([Keyword]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_CommonList] ADD CONSTRAINT [FK_System_CommonList_System_ModuleID_X_System_Module_ID] FOREIGN KEY ([System_ModuleID]) REFERENCES [dbo].[System_Module] ([ID])
GO
