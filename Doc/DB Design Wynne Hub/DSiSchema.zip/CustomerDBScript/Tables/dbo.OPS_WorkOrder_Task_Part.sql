CREATE TABLE [dbo].[OPS_WorkOrder_Task_Part]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__OPS_WorkOrder_Task_Part__ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__OPS_WorkOrder_Task_Part__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__OPS_WorkOrder_Task_Part__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__OPS_WorkOrder_Task_Part__IsDelete] DEFAULT ((0)),
[OPS_WorkOrder_TaskID] [uniqueidentifier] NOT NULL,
[Number] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CommonList_OPSWorkOrder_Task_Part_StatusID] [uniqueidentifier] NULL,
[CommonList_OPSWorkOrder_Task_Part_WarehouseID] [uniqueidentifier] NULL,
[CommonList_UnitOfMeasureID] [uniqueidentifier] NULL,
[EstimatedTime] [datetime] NULL,
[Price] [decimal] (18, 3) NULL,
[Quantity] [decimal] (18, 3) NULL,
[TotalCost] [decimal] (18, 3) NULL,
[Integration_CommonList_ApplicationID] [uniqueidentifier] NULL,
[Integration_ReferenceID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ExtendedData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[TruckNumber] [nvarchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[BackOrderQuantity] [decimal] (18, 3) NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_Part] ADD CONSTRAINT [PK__OPS_WorkOrder_Task_Part] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_Part] ADD CONSTRAINT [FK__OPS_WorkOrder_Task_Part__CommonList_OPSWorkOrder_Task_Part_StatusID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPSWorkOrder_Task_Part_StatusID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_Part] ADD CONSTRAINT [FK__OPS_WorkOrder_Task_Part__CommonList_OPSWorkOrder_Task_Part_WarehouseID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPSWorkOrder_Task_Part_WarehouseID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_Part] ADD CONSTRAINT [FK__OPS_WorkOrder_Task_Part__CommonList_UnitOfMeasureID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_UnitOfMeasureID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_Part] ADD CONSTRAINT [FK__OPS_WorkOrder_Task_Part__Integration_CommonList_ApplicationID__x__System_CommonList_Item__ID] FOREIGN KEY ([Integration_CommonList_ApplicationID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_Part] ADD CONSTRAINT [FK__OPS_WorkOrder_Task_Part__OPSWorkOrder_TaskID__x__OPS_WorkOrder_Task__ID] FOREIGN KEY ([OPS_WorkOrder_TaskID]) REFERENCES [dbo].[OPS_WorkOrder_Task] ([ID])
GO
