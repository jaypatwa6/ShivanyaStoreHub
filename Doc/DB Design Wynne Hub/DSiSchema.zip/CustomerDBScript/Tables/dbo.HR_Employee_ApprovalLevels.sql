CREATE TABLE [dbo].[HR_Employee_ApprovalLevels]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_HR_Employee_ApprovalLevels_ID] DEFAULT (newsequentialid()),
[Notes] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_HR_Employee_ApprovalLevels_IsActive] DEFAULT ((1)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_HR_Employee_ApprovalLevels_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_HR_Employee_ApprovalLevels_DateModified] DEFAULT (getutcdate()),
[CommonList_ApprovalLevelID] [uniqueidentifier] NOT NULL,
[HR_EmployeeID] [uniqueidentifier] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[HR_Employee_ApprovalLevels] ADD CONSTRAINT [PK_HR_Employee_ApprovalLevels] PRIMARY KEY NONCLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[HR_Employee_ApprovalLevels] ADD CONSTRAINT [FK_HR_Employee_ApprovalLevels__HR_EmployeeID_X_HR_Employee__ID] FOREIGN KEY ([HR_EmployeeID]) REFERENCES [dbo].[HR_Employee] ([ID]) ON DELETE CASCADE
GO
ALTER TABLE [dbo].[HR_Employee_ApprovalLevels] WITH NOCHECK ADD CONSTRAINT [FK_HR_Employee_ApprovalLevels_CommonList_ApprovalLevelID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_ApprovalLevelID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
