CREATE TABLE [dbo].[System_TimeZone]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_System_TimeZone_ID] DEFAULT (newsequentialid()),
[Name] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DisplayName] [nvarchar] (70) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DaylightName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[StandardName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Bias] [int] NOT NULL,
[StandardBias] [int] NOT NULL,
[DaylightBias] [int] NOT NULL,
[StandardDateMonth] [int] NULL,
[StandardDateHour] [int] NULL,
[StandardDateMinute] [int] NULL,
[StandardDateDayOfWeek] [int] NULL,
[DaylightDateMonth] [int] NULL,
[DaylightDateHour] [int] NULL,
[DaylightDateMinute] [int] NULL,
[DaylightDateDayOfWeek] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_TimeZone] ADD CONSTRAINT [PK_System_TimeZone] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
