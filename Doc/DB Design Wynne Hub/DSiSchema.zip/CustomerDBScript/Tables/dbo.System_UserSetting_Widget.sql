CREATE TABLE [dbo].[System_UserSetting_Widget]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_System_UserSetting_Widget_ID] DEFAULT (newid()),
[Account_LoginID] [uniqueidentifier] NOT NULL,
[WidgetName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[SortOrder] [int] NOT NULL,
[CommonList_WidgetModuleID] [uniqueidentifier] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_UserSetting_Widget] ADD CONSTRAINT [PK_System_UserSetting_Widget] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_UserSetting_Widget] ADD CONSTRAINT [FK_System_UserSetting_Widget__CommonList_WidgetModuleID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_WidgetModuleID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
