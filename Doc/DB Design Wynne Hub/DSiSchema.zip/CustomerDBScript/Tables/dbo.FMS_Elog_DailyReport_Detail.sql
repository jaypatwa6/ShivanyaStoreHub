CREATE TABLE [dbo].[FMS_Elog_DailyReport_Detail]
(
[ID] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[StartTime] [datetime] NOT NULL,
[StartTimeZoneOffset] [decimal] (3, 1) NOT NULL,
[EndTime] [datetime] NULL,
[EndTimeZoneOffset] [decimal] (3, 1) NULL,
[DurationInTicks] [bigint] NULL,
[DistanceInKM] [decimal] (18, 2) NULL,
[ShippingDocNumber] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Note] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsInterstateLoad] [bit] NOT NULL,
[SystemRemarks] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[MCS_EventSummaryID] [uniqueidentifier] NULL,
[ELD_EventRecordStatus] [tinyint] NOT NULL,
[FMS_Elog_CoDriversID] [uniqueidentifier] NULL,
[HR_EmployeeID] [uniqueidentifier] NOT NULL,
[FMS_Elog_DailyReportID] [uniqueidentifier] NOT NULL,
[CommonList_ElogStatusTypeID] [uniqueidentifier] NOT NULL,
[IsManually] [bit] NOT NULL,
[IsDailyReset] [bit] NOT NULL,
[IsApproved] [bit] NOT NULL,
[DateApproved] [datetime] NULL,
[GroupID] [uniqueidentifier] NULL,
[FMS_Elog_ChangesetID] [uniqueidentifier] NULL,
[CanEditDuration] [bit] NOT NULL CONSTRAINT [DF_FMS_Elog_DailyReport_Detail_CanEditDuration] DEFAULT ((1)),
[Is16HourRuleException] [bit] NULL CONSTRAINT [DF_FMS_Elog_DailyReport_Detail_Is16HourRuleException] DEFAULT (NULL),
[IsOversizedLoad] [bit] NOT NULL CONSTRAINT [DF__FMS_Elog___IsOve__4051FD1B] DEFAULT ((0)),
[StartTimeKey] [bigint] NOT NULL CONSTRAINT [DF__FMS_Elog___Start__0313E4B1] DEFAULT ((0)),
[IsAdverseDriving] [bit] NULL CONSTRAINT [DF__FMS_Elog___IsAdv__0D05CC91] DEFAULT ((0)),
[EndTimeKey] [bigint] NULL,
[CommonList_ZoneID] [uniqueidentifier] NULL,
[IsFerry] [bit] NULL,
[IsAdditionalHours] [bit] NULL,
[CommonList_ElogPermitStatusID] [uniqueidentifier] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_DailyReport_Detail] ADD CONSTRAINT [PK_FMS_Elog_DailyReport_Detail] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Elog_DailyReport_Detail__CommonList_ElogStatusTypeID] ON [dbo].[FMS_Elog_DailyReport_Detail] ([CommonList_ElogStatusTypeID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Elog_DailyReport_Detail__DateCreated] ON [dbo].[FMS_Elog_DailyReport_Detail] ([DateCreated]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Elog_DailyReport_Detail__ELD_EventRecordStatus_HR_EmployeeID_StartTime] ON [dbo].[FMS_Elog_DailyReport_Detail] ([ELD_EventRecordStatus], [HR_EmployeeID], [StartTime]) INCLUDE ([CommonList_ElogStatusTypeID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Elog_DailyReport_Detail__FMS_Elog_ChangesetID] ON [dbo].[FMS_Elog_DailyReport_Detail] ([FMS_Elog_ChangesetID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Elog_DailyReport_Detail__FMS_ElogDailyReportID] ON [dbo].[FMS_Elog_DailyReport_Detail] ([FMS_Elog_DailyReportID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Elog_DailyReport_Detail__HR_EmployeeID] ON [dbo].[FMS_Elog_DailyReport_Detail] ([HR_EmployeeID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Elog_DailyReport_Detail__HR_EmployeeID_EndTimeKey] ON [dbo].[FMS_Elog_DailyReport_Detail] ([HR_EmployeeID], [EndTimeKey]) WHERE ([EndTimeKey] IS NOT NULL) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Elog_DailyReport_Detail__HR_EmployeeID_StartTimeKey] ON [dbo].[FMS_Elog_DailyReport_Detail] ([HR_EmployeeID], [StartTimeKey]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Elog_DailyReport_Detail__MCS_Device_CommEventID] ON [dbo].[FMS_Elog_DailyReport_Detail] ([MCS_EventSummaryID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_ELOG_DAILYREPORT__DETAIL_Status_Duration] ON [dbo].[FMS_Elog_DailyReport_Detail] ([StartTime], [EndTime], [CommonList_ElogStatusTypeID], [DurationInTicks]) INCLUDE ([FMS_Elog_DailyReportID], [MCS_EventSummaryID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Elog_DailyReport_Detail__StartTimeKey] ON [dbo].[FMS_Elog_DailyReport_Detail] ([StartTimeKey]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_DailyReport_Detail] ADD CONSTRAINT [FK_FMS_Elog_DailyReport_Detail_FMS_Elog_Changeset] FOREIGN KEY ([FMS_Elog_ChangesetID]) REFERENCES [dbo].[FMS_Elog_Changeset] ([ID])
GO
ALTER TABLE [dbo].[FMS_Elog_DailyReport_Detail] WITH NOCHECK ADD CONSTRAINT [FK_FMS_Elog_DailyReport_Detail_HR_Employee] FOREIGN KEY ([HR_EmployeeID]) REFERENCES [dbo].[HR_Employee] ([ID])
GO
ALTER TABLE [dbo].[FMS_Elog_DailyReport_Detail] ADD CONSTRAINT [FK_FMS_Elog_DailyReport_Detail_System_CommonList_Item] FOREIGN KEY ([CommonList_ElogStatusTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
EXEC sp_addextendedproperty N'MS_Description', N'Allow user edit the starttime and endtime or not', 'SCHEMA', N'dbo', 'TABLE', N'FMS_Elog_DailyReport_Detail', 'COLUMN', N'CanEditDuration'
GO
