CREATE TABLE [dbo].[TMS_CustomForm]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__TMS_CustomForm__ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__TMS_CustomForm__DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__TMS_CustomForm__DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[Title] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF__TMS_CustomForm__IsActive] DEFAULT ((1)),
[TemplatePath] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[JavascriptPath] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_CustomForm] ADD CONSTRAINT [PK__TMS_CustomForm] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
