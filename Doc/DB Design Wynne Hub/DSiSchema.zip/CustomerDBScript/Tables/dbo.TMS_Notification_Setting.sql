CREATE TABLE [dbo].[TMS_Notification_Setting]
(
[Id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_TMS_Notifications_Settings_Id] DEFAULT (newsequentialid()),
[Keyword] [nvarchar] (400) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Name] [nvarchar] (400) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Requester] [bit] NOT NULL,
[Dispatcher] [bit] NOT NULL,
[Jobsite] [bit] NOT NULL CONSTRAINT [TMS_Notifcation_Setting_Jobsite] DEFAULT ((0)),
[Organization] [bit] NOT NULL CONSTRAINT [DF__TMS_Notif__Organ__1B9E04AB] DEFAULT ((0)),
[Customer] [bit] NOT NULL CONSTRAINT [DF__TMS_Notif__Custo__1C9228E4] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_Notification_Setting] ADD CONSTRAINT [PK__TMS_Notifications_Settings] PRIMARY KEY CLUSTERED  ([Id]) ON [PRIMARY]
GO
