CREATE TABLE [dbo].[FMS_Elog_Header]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__FMS_Elog_Hea__ID__5D4BCC77] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__FMS_Elog___DateC__5E3FF0B0] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__FMS_Elog___DateM__5F3414E9] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[CommonList_ElogReportStatusID] [uniqueidentifier] NOT NULL,
[ApprovedAccount_LoginID] [uniqueidentifier] NULL,
[ReapprovedByAccountLoginID] [uniqueidentifier] NULL,
[DateApproved] [datetime] NULL,
[DateReapproved] [datetime] NULL,
[DateStartDailyReset] [datetime] NULL,
[DateEndDailyReset] [datetime] NULL,
[IsApproved] [bit] NOT NULL CONSTRAINT [DF__FMS_Elog___IsApp__60283922] DEFAULT ((0)),
[FMS_Elog_HOSRuleID] [uniqueidentifier] NOT NULL,
[HR_EmployeeID] [uniqueidentifier] NOT NULL,
[DailyOnDuty] [numeric] (18, 2) NULL,
[DailyDriving] [numeric] (18, 2) NULL,
[DailyOffDuty] [numeric] (18, 2) NULL,
[DailySleeper] [numeric] (18, 2) NULL,
[DailyPersonal] [numeric] (18, 2) NULL,
[WeeklyOnduty] [numeric] (18, 2) NULL,
[WeeklyDriving] [numeric] (18, 2) NULL,
[WeeklyOffDuty] [numeric] (18, 2) NULL,
[WeeklySleeper] [numeric] (18, 2) NULL,
[WeeklyPersonal] [numeric] (18, 2) NULL,
[IsWeeklyReset] [bit] NOT NULL,
[IsCalculate] [bit] NOT NULL,
[RestBreakFlag] [bit] NULL,
[RestBreakViolation] [bit] NULL,
[RestBreakViolationTime] [datetime] NULL,
[DrivingViolation] [bit] NULL,
[DrivingViolationTime] [datetime] NULL,
[WeeklyOnDutyViolation] [bit] NULL,
[WeeklyOnDutyViolationTime] [datetime] NULL,
[MostRecentLogStatus] [uniqueidentifier] NOT NULL,
[MostRecentLogTime] [datetime] NULL,
[SevenDayRuleCheckTime] [numeric] (18, 2) NULL,
[HourRemainingWeeklyOnduty] [numeric] (18, 2) NOT NULL,
[HourRemainingInDay] [numeric] (18, 2) NOT NULL,
[MotorCarrierState] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[MotorCarrierID] [uniqueidentifier] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_Header] ADD CONSTRAINT [PK_FMS_Elog_Header] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Elog_Header__CreatedBy__HR_EmployeeID__ID] ON [dbo].[FMS_Elog_Header] ([CreatedBy], [HR_EmployeeID], [ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Elog_Header__CreatedBy_HR_EmployeeID_ID] ON [dbo].[FMS_Elog_Header] ([CreatedBy], [HR_EmployeeID], [ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Elog_Header__DateCreated] ON [dbo].[FMS_Elog_Header] ([DateCreated]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Elog_Header__HR_EmployeeID] ON [dbo].[FMS_Elog_Header] ([HR_EmployeeID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Elog_Header__ID__HR_EmployeeID] ON [dbo].[FMS_Elog_Header] ([ID], [HR_EmployeeID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_Header] ADD CONSTRAINT [FK_FMS_Elog_Header__CommonList_ElogReportStatusID_x_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_ElogReportStatusID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_Elog_Header] ADD CONSTRAINT [FK_FMS_Elog_Header__FMS_Elog_HOSRuleID_x_FMS_Elog_HOSRule__ID] FOREIGN KEY ([FMS_Elog_HOSRuleID]) REFERENCES [dbo].[FMS_Elog_HOSRule] ([ID])
GO
ALTER TABLE [dbo].[FMS_Elog_Header] ADD CONSTRAINT [FK_FMS_Elog_Header__HR_EmployeeID_x_HR_Employee__ID] FOREIGN KEY ([HR_EmployeeID]) REFERENCES [dbo].[HR_Employee] ([ID])
GO
