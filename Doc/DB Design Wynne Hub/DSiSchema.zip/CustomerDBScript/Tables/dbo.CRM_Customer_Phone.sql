CREATE TABLE [dbo].[CRM_Customer_Phone]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__CRM_Customer__ID__3C15C135] DEFAULT (newsequentialid()),
[PhoneNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Extension] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Description] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_CRM_Customer_Phone_IsActive] DEFAULT ((1)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_CRM_Customer_Phone_DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_CRM_Customer_Phone_DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsPrimary] [bit] NULL CONSTRAINT [DF_CRM_Customer_Phone_IsPrimary] DEFAULT ((0)),
[CRM_CustomerID] [uniqueidentifier] NOT NULL,
[CommonList_PhoneTypeID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[CRM_Customer_Phone] ADD CONSTRAINT [PK_CRM_Customer_Phone] PRIMARY KEY NONCLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [IX__CRM_Customer_Phone__CRM_CustomerID] ON [dbo].[CRM_Customer_Phone] ([CRM_CustomerID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[CRM_Customer_Phone] WITH NOCHECK ADD CONSTRAINT [FK_CRM_Customer_Phone__CommonList_PhoneTypeID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_PhoneTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[CRM_Customer_Phone] ADD CONSTRAINT [FK_CRM_Customer_Phone__CustomerID_X_CRM_Customer__ID] FOREIGN KEY ([CRM_CustomerID]) REFERENCES [dbo].[CRM_Customer] ([ID]) ON DELETE CASCADE
GO
