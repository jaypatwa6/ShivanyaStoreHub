CREATE TABLE [dbo].[INV_CycleCount_Task_Equipment]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__INV_CycleCount_Task_Equipment__ID] DEFAULT (newsequentialid()),
[INV_CycleCount_TaskID] [uniqueidentifier] NOT NULL,
[Number] [nvarchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Status] [nvarchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Category] [int] NOT NULL,
[Classification] [int] NOT NULL,
[Make] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Model] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsBulkEquipment] [bit] NOT NULL,
[IsSystemCount] [bit] NOT NULL,
[CountedLocation] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[SerialNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CountedQuantity] [int] NULL,
[CountedDate] [datetime] NULL,
[CountedBy] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Comment] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CatClassDescription] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IntegrationSystemDate] [datetime] NOT NULL,
[IntegrationModifiedDate] [datetime] NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__INV_CycleCount_Task_Equipment__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__INV_CycleCount_Task_Equipment__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsDeleted] [bit] NOT NULL CONSTRAINT [DF_INV_CycleCount_Task_Equipment_IsDeleted] DEFAULT ((0)),
[QuantityOnHand] [int] NOT NULL CONSTRAINT [DF__INV_Cycle__Quant__53AD53A4] DEFAULT ((0)),
[IsDiscrepancy] [bit] NOT NULL CONSTRAINT [DF__INV_Cycle__IsDis__55959C16] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[INV_CycleCount_Task_Equipment] ADD CONSTRAINT [PK__INV_CycleCount_Task_Equipment] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[INV_CycleCount_Task_Equipment] ADD CONSTRAINT [FK__INV_CycleCount_Task_Equipment__INV_CycleCount_TaskID__x__INV_CycleCount_Task__ID] FOREIGN KEY ([INV_CycleCount_TaskID]) REFERENCES [dbo].[INV_CycleCount_Task] ([ID])
GO
