CREATE TABLE [dbo].[System_Audit]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_System_Audit_ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__System_Audit__DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__System_Audit__DateModified] DEFAULT (getutcdate()),
[ReferenceTable] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ReferenceForeignKeyID] [uniqueidentifier] NULL,
[Data] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ActionName] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Audit] ADD CONSTRAINT [PK_System_Audit] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
