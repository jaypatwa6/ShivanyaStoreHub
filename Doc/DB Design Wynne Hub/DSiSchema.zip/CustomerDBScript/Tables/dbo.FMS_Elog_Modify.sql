CREATE TABLE [dbo].[FMS_Elog_Modify]
(
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__FMS_Elog___DateC__62108194] DEFAULT (getutcdate()),
[StartDate] [datetime] NOT NULL,
[EndDate] [datetime] NULL,
[TotalInTicks] [bigint] NULL,
[DistanceTraveledInKM] [decimal] (18, 2) NOT NULL,
[ShippingDocumentNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Note] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsManuallyCreated] [bit] NOT NULL CONSTRAINT [DF__FMS_Elog___IsMan__6304A5CD] DEFAULT ((0)),
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__FMS_Elog___IsDel__63F8CA06] DEFAULT ((0)),
[DateDeleted] [datetime] NULL,
[IsDailyReset] [bit] NOT NULL CONSTRAINT [DF__FMS_Elog___IsDai__64ECEE3F] DEFAULT ((0)),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__FMS_Elog___DateM__65E11278] DEFAULT (getutcdate()),
[MaxExemptionHourRequest] [int] NOT NULL,
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__FMS_Elog_Mod__ID__66D536B1] DEFAULT (newsequentialid()),
[CommonList_ElogStatusTypeID] [uniqueidentifier] NOT NULL,
[FMS_Elog_HeaderID] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[FMS_Elog_OriginalID] [uniqueidentifier] NOT NULL,
[DateApproved] [datetime] NULL,
[DateReapproved] [datetime] NULL,
[IsApproved] [bit] NOT NULL CONSTRAINT [DF__FMS_Elog___IsApp__67C95AEA] DEFAULT ((0)),
[IsInterstateLoad] [bit] NULL CONSTRAINT [DF__FMS_Elog___IsInt__68BD7F23] DEFAULT ((0)),
[ApprovedAccount_LoginID] [uniqueidentifier] NULL,
[DateLastSync] [datetime] NULL,
[MCS_Device_CommEventID] [uniqueidentifier] NULL,
[MCS_Device_EventSummaryID] [uniqueidentifier] NULL,
[SystemRemarks] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_Modify] ADD CONSTRAINT [PK_FMS_Elog_Modify] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Elog_Modify__CreatedBy__DateModified__EndDate__FMS_ElogHeaderID__ID] ON [dbo].[FMS_Elog_Modify] ([CreatedBy], [DateModified], [EndDate], [FMS_Elog_HeaderID], [ID]) INCLUDE ([ApprovedAccount_LoginID], [CommonList_ElogStatusTypeID], [DateApproved], [DateCreated], [DateDeleted], [DateLastSync], [DateReapproved], [DistanceTraveledInKM], [FMS_Elog_OriginalID], [IsApproved], [IsDailyReset], [IsDelete], [IsInterstateLoad], [IsManuallyCreated], [MaxExemptionHourRequest], [MCS_Device_EventSummaryID], [ModifiedBy], [Note], [ShippingDocumentNumber], [StartDate], [SystemRemarks], [TotalInTicks]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Elog_Modify__CreatedBy__EndDate] ON [dbo].[FMS_Elog_Modify] ([CreatedBy], [EndDate]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Elog_Modify__FMS_Elog_HeaderID] ON [dbo].[FMS_Elog_Modify] ([FMS_Elog_HeaderID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Elog_Modify__FMS_Elog_OriginalID] ON [dbo].[FMS_Elog_Modify] ([FMS_Elog_OriginalID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Elog_Modify__IsApproved__FMS_Elog_HeaderID__StartDate] ON [dbo].[FMS_Elog_Modify] ([IsApproved], [FMS_Elog_HeaderID], [StartDate]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_Modify] ADD CONSTRAINT [UQ_FMS_Elog_Modify__StartDate__CreatedBy] UNIQUE NONCLUSTERED  ([StartDate], [CreatedBy]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_Modify] ADD CONSTRAINT [FK_FMS_Elog_Modify__CommonList_ElogStatusTypeID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_ElogStatusTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_Elog_Modify] ADD CONSTRAINT [FK_FMS_Elog_Modify__FMS_Elog_HeaderID_X_FMS_Elog_Header__ID] FOREIGN KEY ([FMS_Elog_HeaderID]) REFERENCES [dbo].[FMS_Elog_Header] ([ID])
GO
ALTER TABLE [dbo].[FMS_Elog_Modify] ADD CONSTRAINT [FK_FMS_Elog_Modify__FMS_Elog_OriginalID_X_FMS_Elog_Original__ID] FOREIGN KEY ([FMS_Elog_OriginalID]) REFERENCES [dbo].[FMS_Elog_Original] ([ID])
GO
