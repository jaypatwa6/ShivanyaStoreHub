CREATE TABLE [dbo].[System_Rate_Organization]
(
[Id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_System_Rate_Organization_Id] DEFAULT (newsequentialid()),
[System_RateID] [uniqueidentifier] NOT NULL,
[System_OrganizationID] [uniqueidentifier] NOT NULL,
[IsActive] [bit] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Rate_Organization] ADD CONSTRAINT [PK_System_Rate_Organization] PRIMARY KEY CLUSTERED  ([Id]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Rate_Organization] ADD CONSTRAINT [FK_System_Rate_OrganizationID_System_Organization_ID] FOREIGN KEY ([System_OrganizationID]) REFERENCES [dbo].[System_Organization] ([ID])
GO
ALTER TABLE [dbo].[System_Rate_Organization] ADD CONSTRAINT [FK_System_Rate_OrganizationId_System_RateId] FOREIGN KEY ([System_RateID]) REFERENCES [dbo].[System_Rate] ([Id])
GO
