CREATE TABLE [dbo].[TMS_Order_Item]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__TMS_Order_Item__ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__TMS_Order_Item__DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__TMS_Order_Item__DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[TMS_OrderID] [uniqueidentifier] NOT NULL,
[FreightDescription] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[QuantityOrdered] [decimal] (18, 2) NOT NULL,
[QuantityShipped] [decimal] (18, 2) NULL,
[QuantityReceived] [decimal] (18, 2) NULL,
[CommonList_TMSFreightUnitID] [uniqueidentifier] NULL,
[UnitWeightInPound] [decimal] (18, 2) NULL,
[UnitLengthInInch] [decimal] (18, 2) NULL,
[UnitWidthInInch] [decimal] (18, 2) NULL,
[UnitHeightInInch] [decimal] (18, 2) NULL,
[IsStackable] [bit] NOT NULL,
[Notes] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ReferenceOrderItemDocumentNumbers] [xml] NULL,
[CommonList_TMSOrderItemStatusID] [uniqueidentifier] NOT NULL,
[OrderItemNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ShipWeightInPound] [decimal] (18, 2) NULL,
[ShipLengthInInch] [decimal] (18, 2) NULL,
[ShipWidthInInch] [decimal] (18, 2) NULL,
[ShipHeightInInch] [decimal] (18, 2) NULL,
[TotalTripDurationInMin] [decimal] (18, 2) NULL,
[TotalTripDistanceInKM] [decimal] (18, 2) NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__TMS_Order_Item__IsDelete] DEFAULT ((0)),
[IsPilot] [bit] NULL,
[IsPermit] [bit] NULL,
[PermitNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Rate] [decimal] (18, 2) NULL,
[Taxable] [bit] NULL,
[CarrierPay] [decimal] (18, 2) NULL,
[DateTimeItemDispatched] [datetime] NULL,
[DateTimeItemOutForPickup] [datetime] NULL,
[DateTimeItemAtPickup] [datetime] NULL,
[DateTimeItemPickupComplete] [datetime] NULL,
[DateTimeItemAtDelivery] [datetime] NULL,
[DateTimeItemOutForDelivery] [datetime] NULL,
[DateTimeItemDeliveryComplete] [datetime] NULL,
[DateTimeItemActivityComplete] [datetime] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_Order_Item] ADD CONSTRAINT [PK__TMS_Order_Item] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Item__CommonList_TMSOrderItemStatusID] ON [dbo].[TMS_Order_Item] ([CommonList_TMSOrderItemStatusID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Item__CommonList_TMS_OrderItemStatusID_X_IsDelete_X_DateCreated_X_TMS_OrderID] ON [dbo].[TMS_Order_Item] ([CommonList_TMSOrderItemStatusID], [IsDelete], [DateCreated], [TMS_OrderID]) INCLUDE ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Item_CommonList_TMSOrderItemStatusID_IsDelete_ID_TMS_OrderID] ON [dbo].[TMS_Order_Item] ([CommonList_TMSOrderItemStatusID], [IsDelete], [ID], [TMS_OrderID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Item__DateCreated] ON [dbo].[TMS_Order_Item] ([DateCreated]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Item__DateModified] ON [dbo].[TMS_Order_Item] ([DateModified]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Item__OrderItemNumber] ON [dbo].[TMS_Order_Item] ([OrderItemNumber]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Item__TMS_OrderID] ON [dbo].[TMS_Order_Item] ([TMS_OrderID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_TMS_Order_Item_Active] ON [dbo].[TMS_Order_Item] ([TMS_OrderID], [DateModified]) INCLUDE ([ID]) WHERE ([IsDelete]=(0)) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Item__OrderID_ID_Date_Delete_Status] ON [dbo].[TMS_Order_Item] ([TMS_OrderID], [ID], [DateCreated], [IsDelete], [CommonList_TMSOrderItemStatusID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_Order_Item] ADD CONSTRAINT [FK__TMS_Order_Item__CommonList_TMSFreightUnitID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_TMSFreightUnitID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order_Item] ADD CONSTRAINT [FK__TMS_Order_Item__CommonList_TMSOrderItemStatusID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_TMSOrderItemStatusID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order_Item] ADD CONSTRAINT [FK__TMS_Order_Item__TMS_OrderID__x__TMS_Order__ID] FOREIGN KEY ([TMS_OrderID]) REFERENCES [dbo].[TMS_Order] ([ID])
GO
