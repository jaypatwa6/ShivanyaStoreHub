CREATE TABLE [dbo].[CRM_Customer_Address]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__CRM_Customer__ID__34749F6D] DEFAULT (newsequentialid()),
[Address1] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Address2] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[City] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[State] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PostalCode1] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PostalCode2] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_CRM_Customer_Address_IsActive] DEFAULT ((1)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_CRM_Customer_Address_DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_CRM_Customer_Address_DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[Longitude] [decimal] (9, 6) NULL,
[Latitude] [decimal] (9, 6) NULL,
[IsPrimary] [bit] NOT NULL CONSTRAINT [DF_CRM_Customer_Address_IsPrimary] DEFAULT ((0)),
[CRM_CustomerID] [uniqueidentifier] NOT NULL,
[System_List_CountryID] [uniqueidentifier] NOT NULL,
[CommonList_AddressTypeID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[CRM_Customer_Address] ADD CONSTRAINT [PK_CRM_Customer_Address] PRIMARY KEY NONCLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [IX__CRM_Customer_Address__CRM_CustomerID] ON [dbo].[CRM_Customer_Address] ([CRM_CustomerID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[CRM_Customer_Address] WITH NOCHECK ADD CONSTRAINT [FK_CRM_Customer_Address__CommonList_AddressTypeID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_AddressTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[CRM_Customer_Address] ADD CONSTRAINT [FK_CRM_Customer_Address__CountryCodeID_X_System_List_Countries__ID] FOREIGN KEY ([System_List_CountryID]) REFERENCES [dbo].[System_List_Country] ([ID])
GO
ALTER TABLE [dbo].[CRM_Customer_Address] ADD CONSTRAINT [FK_CRM_Customer_Address__CustomerID_X_CRM_Customer__ID] FOREIGN KEY ([CRM_CustomerID]) REFERENCES [dbo].[CRM_Customer] ([ID]) ON DELETE CASCADE
GO
