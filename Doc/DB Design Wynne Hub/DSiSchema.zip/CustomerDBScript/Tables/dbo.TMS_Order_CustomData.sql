CREATE TABLE [dbo].[TMS_Order_CustomData]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__TMS_Order_CustomData__ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__TMS_Order_CustomData__DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__TMS_Order_CustomData__DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[TMS_OrderID] [uniqueidentifier] NOT NULL,
[TMS_CustomFormID] [uniqueidentifier] NOT NULL,
[Integration_Application] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Integration_RowId] [nvarchar] (36) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Integration_WorkOrderNo] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CustomerJobNo] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_Order_CustomData] ADD CONSTRAINT [PK__TMS_Order_CustomData] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_CustomData__DateModified] ON [dbo].[TMS_Order_CustomData] ([DateModified]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_CustomData__TMS_OrderID] ON [dbo].[TMS_Order_CustomData] ([TMS_OrderID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_CustomData__Integration_WorkOrderNo] ON [dbo].[TMS_Order_CustomData] ([TMS_OrderID], [Integration_WorkOrderNo]) INCLUDE ([Integration_Application], [CustomerJobNo]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_Order_CustomData] ADD CONSTRAINT [FK__TMS_Order_CustomData__TMS_CustomFormID__x__TMS_CustomForm__ID] FOREIGN KEY ([TMS_CustomFormID]) REFERENCES [dbo].[TMS_CustomForm] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order_CustomData] ADD CONSTRAINT [FK__TMS_Order_CustomData__TMS_OrderID__x__TMS_Order__ID] FOREIGN KEY ([TMS_OrderID]) REFERENCES [dbo].[TMS_Order] ([ID])
GO
