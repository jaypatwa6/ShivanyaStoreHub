CREATE TABLE [dbo].[CRM_Jobsite]
(
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_CRM_Jobsite_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_CRM_Jobsite_DateModified] DEFAULT (getutcdate()),
[Name] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Address] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[City] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[State] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PostalCode] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_SDMS_StopSite_IsActive] DEFAULT ((1)),
[Longitude] [decimal] (9, 6) NULL,
[Latitude] [decimal] (9, 6) NULL,
[ContactName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ContactPhone] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ContactExtension] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Note] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsDeleted] [bit] NOT NULL CONSTRAINT [DF__CRM_Jobsite__IsDel__65370702] DEFAULT ((0)),
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__CRM_Jobsite__ID__59A6241C] DEFAULT (newsequentialid()),
[System_List_CountryID] [uniqueidentifier] NULL,
[System_OrganizationID] [uniqueidentifier] NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsOneTimeJobsite] [bit] NOT NULL CONSTRAINT [DF__CRM_Jobsi__IsOne__07A1F8F6] DEFAULT ((0)),
[ContactEmail] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Geohash] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ExtendedData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[JobNumber] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[JobLocation] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CRM_CustomerID] [uniqueidentifier] NULL,
[Integration_CommonList_ApplicationID] [uniqueidentifier] NULL,
[Tags] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[TaxDistrict] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[CRM_Jobsite] ADD CONSTRAINT [PK_CRM_Jobsite (Clustered)] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_CRM_Jobsite_Search] ON [dbo].[CRM_Jobsite] ([ID]) INCLUDE ([PostalCode], [Name]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__CRM_Jobsite__IsDelete] ON [dbo].[CRM_Jobsite] ([IsDeleted]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[CRM_Jobsite] ADD CONSTRAINT [FK__CRM_Jobsite__CRM_CustomerID__x__CRM_Customer__ID] FOREIGN KEY ([CRM_CustomerID]) REFERENCES [dbo].[CRM_Customer] ([ID])
GO
ALTER TABLE [dbo].[CRM_Jobsite] ADD CONSTRAINT [FK__CRM_Jobsite__Integration_CommonList_ApplicationID__x__System_CommonList_Item__ID] FOREIGN KEY ([Integration_CommonList_ApplicationID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[CRM_Jobsite] ADD CONSTRAINT [FK_CRM_Jobsite__CountryCodeID_X_System_List_Countries__ID] FOREIGN KEY ([System_List_CountryID]) REFERENCES [dbo].[System_List_Country] ([ID])
GO
ALTER TABLE [dbo].[CRM_Jobsite] ADD CONSTRAINT [FK_CRM_Jobsite__System_OrganizationID_X_System_Organizations_ID] FOREIGN KEY ([System_OrganizationID]) REFERENCES [dbo].[System_Organization] ([ID]) ON DELETE SET NULL
GO
