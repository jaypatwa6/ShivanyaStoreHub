CREATE TABLE [dbo].[FMS_Elog_DailyReport_Detail_History]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__FMS_Elog_His__ID__21B6055D] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__FMS_Elog___DateC__22AA2996] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__FMS_Elog___DateM__24927208] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[StartTime] [datetime] NOT NULL,
[StartTimeZoneOffset] [nchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[EndTime] [datetime] NULL,
[EndTimeZoneOffset] [nchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DurationInTicks] [bigint] NULL,
[DistanceInKM] [decimal] (18, 2) NOT NULL,
[ShippingDocNumber] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Note] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsInterstateLoad] [bit] NOT NULL CONSTRAINT [DF__FMS_Elog___IsInt__267ABA7A] DEFAULT ((0)),
[SystemRemarks] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[MCS_EventSummaryID] [uniqueidentifier] NULL,
[FMS_Elog_CoDriversID] [uniqueidentifier] NULL,
[FMS_Elog_DailyReportID] [uniqueidentifier] NULL,
[ELD_EventRecordStatus] [tinyint] NOT NULL,
[HR_EmployeeID] [uniqueidentifier] NOT NULL,
[CommonList_ElogStatusTypeID] [uniqueidentifier] NOT NULL,
[IsManually] [bit] NOT NULL,
[IsDailyReset] [bit] NOT NULL CONSTRAINT [DF__FMS_Elog___IsDai__239E4DCF] DEFAULT ((0)),
[IsApproved] [bit] NOT NULL CONSTRAINT [DF__FMS_Elog___IsApp__25869641] DEFAULT ((0)),
[DateApproved] [datetime] NULL,
[GroupID] [uniqueidentifier] NULL,
[CanEditDuration] [bit] NOT NULL CONSTRAINT [DF_FMS_Elog_DailyReport_Detail_History_CanEditDuration] DEFAULT ((1)),
[IsAdverseDriving] [bit] NULL CONSTRAINT [DF__FMS_Elog___IsAdv__0DF9F0CA] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_DailyReport_Detail_History] ADD CONSTRAINT [PK_FMS_Elog_History] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
EXEC sp_addextendedproperty N'MS_Description', N'Allow user edit the starttime and endtime or not', 'SCHEMA', N'dbo', 'TABLE', N'FMS_Elog_DailyReport_Detail_History', 'COLUMN', N'CanEditDuration'
GO
