CREATE TABLE [dbo].[System_Rate]
(
[Id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_System_Rate_Id] DEFAULT (newsequentialid()),
[Name] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CommonList_RateTypeID] [uniqueidentifier] NOT NULL,
[Description] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[AccountNumber] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[RateAmount] [decimal] (11, 2) NULL CONSTRAINT [DF_System_Rate_RateAmount] DEFAULT ((0)),
[Note] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsActive] [bit] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL,
[Cost] [decimal] (18, 2) NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Rate] ADD CONSTRAINT [PK_System_Rate] PRIMARY KEY CLUSTERED ([Id]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Rate] ADD CONSTRAINT [FK_System_Rate_TypeID_System_CommonList_Item_ID] FOREIGN KEY ([CommonList_RateTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
