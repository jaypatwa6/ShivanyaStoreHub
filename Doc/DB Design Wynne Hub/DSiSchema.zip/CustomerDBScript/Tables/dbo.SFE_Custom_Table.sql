CREATE TABLE [dbo].[SFE_Custom_Table]
(
[TableName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_SFE_Custom_Table_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_SFE_Custom_Table_DateModified] DEFAULT (getutcdate()),
[IsActive] [bit] NOT NULL CONSTRAINT [DF_SFE_Custom_Table_IsActive] DEFAULT ((0)),
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__SFE_Custom_T__ID__79FD19BE] DEFAULT (newsequentialid()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[SFE_Custom_Table] ADD CONSTRAINT [PK_SFE_Custom_Table] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
