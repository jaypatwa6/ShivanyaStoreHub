CREATE TABLE [dbo].[System_Localization_Override]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_System_Localization_Override_ID] DEFAULT (newsequentialid()),
[System_LocalizationID] [uniqueidentifier] NOT NULL,
[Localize_En_US] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Localize_En_GB] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Localize_Fr_FR] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Localize_Fr_CA] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__System_Localization_Override__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__System_Localization_Override__DateModified] DEFAULT (getutcdate())
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Localization_Override] ADD CONSTRAINT [PK_System_Localization_Override] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
