CREATE TABLE [dbo].[System_Setting]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__SystemSettin__Id__34B3CB38] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__SystemSet__DateC__60083D91] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__SystemSet__DateM__60FC61CA] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[Keyword] [nvarchar] (150) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Note] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CommonList_SystemSettingFormatTypeID] [uniqueidentifier] NOT NULL,
[ControlSource] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CommonList_SystemSettingResponseDataTypeID] [uniqueidentifier] NOT NULL,
[DefaultValue] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Value] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PreviousValue] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[System_ModuleID] [uniqueidentifier] NOT NULL,
[Category] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[IsSystemSetting] [bit] NOT NULL CONSTRAINT [DF__SystemSet__IsSys__61F08603] DEFAULT ((1)),
[IsActive] [bit] NOT NULL CONSTRAINT [DF__SystemSet__IsAct__62E4AA3C] DEFAULT ((1)),
[IsRequired] [bit] NOT NULL CONSTRAINT [DF__SystemSet__IsReq__63D8CE75] DEFAULT ((1)),
[DeveloperNotes] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsDeleted] [bit] NOT NULL CONSTRAINT [DF_SystemSetting_IsDeleted] DEFAULT ((0)),
[ControlSourceType] [uniqueidentifier] NULL,
[Name] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsEncryptedValue] [bit] NOT NULL CONSTRAINT [DF__System_Se__IsEnc__2D32A501] DEFAULT ((0)),
[IsEncrypt] [bit] NULL CONSTRAINT [DF__System_Se__IsEnc__5A054B78] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Setting] ADD CONSTRAINT [PK_System_Setting] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Setting] ADD CONSTRAINT [UQ_System_Setting_Keyword] UNIQUE NONCLUSTERED  ([Keyword]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Setting] ADD CONSTRAINT [FK_System_Setting_CommonList_SystemSettingFormatTypeID_X_System_CommonList_Item_ID] FOREIGN KEY ([CommonList_SystemSettingFormatTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[System_Setting] ADD CONSTRAINT [FK_System_Setting_CommonList_SystemSettingResponseDataTypeID_X_System_CommonList_Item_ID] FOREIGN KEY ([CommonList_SystemSettingResponseDataTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[System_Setting] ADD CONSTRAINT [FK_System_Setting_System_ModuleID_X_System_Module_ID] FOREIGN KEY ([System_ModuleID]) REFERENCES [dbo].[System_Module] ([ID])
GO
