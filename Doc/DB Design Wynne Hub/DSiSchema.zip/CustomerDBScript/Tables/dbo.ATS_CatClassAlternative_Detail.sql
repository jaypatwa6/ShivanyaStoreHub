CREATE TABLE [dbo].[ATS_CatClassAlternative_Detail]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__ATS_CatClassAlternative_Detail__ID] DEFAULT (newsequentialid()),
[ATS_CatClassAlternativeID] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__ATS_CatClassAlternative_Detail__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__ATS_CatClassAlternative_Detail__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF__ATS_CatClassAlternative_Detail__IsActive] DEFAULT ((1)),
[CategoryCode] [nvarchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ClassificationCode] [nvarchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[WeekRate] [decimal] (18, 2) NULL,
[Sequence] [int] NOT NULL CONSTRAINT [DF__ATS_CatClassAlternative_Detail__Sequence] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[ATS_CatClassAlternative_Detail] ADD CONSTRAINT [PK_ATS_CatClassAlternative_Detail] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[ATS_CatClassAlternative_Detail] ADD CONSTRAINT [FK__ATS_CatClassAlternative_Detail__ATS_CatClassAlternativeID__x__ATS_CatClassAlternative__ID] FOREIGN KEY ([ATS_CatClassAlternativeID]) REFERENCES [dbo].[ATS_CatClassAlternative] ([ID])
GO
