CREATE TABLE [dbo].[System_UserSetting_GridLayout]
(
[SettingName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ViewName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ControlID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Value] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_System_UserSettings_GridLayout_DateModified] DEFAULT (getutcdate()),
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__System_UserS__ID__5A9A4855] DEFAULT (newsequentialid()),
[Account_LoginID] [uniqueidentifier] NULL,
[ModifiedBy] [uniqueidentifier] NULL,
[Mode] [int] NOT NULL,
[RefreshTime] [int] NOT NULL,
[RowPerPage] [int] NOT NULL,
[DateDisplay] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_System_UserSettings_GridLayout_DateCreated] DEFAULT (getutcdate()),
[IsActive] [bit] NOT NULL CONSTRAINT [DF_System_UserSettings_GridLayout_IsActive] DEFAULT ((1)),
[DefaultValue] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_UserSetting_GridLayout] ADD CONSTRAINT [PK_System_UserSettings_GridLayout] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
