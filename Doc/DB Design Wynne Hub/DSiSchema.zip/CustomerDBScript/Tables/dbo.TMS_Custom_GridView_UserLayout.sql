CREATE TABLE [dbo].[TMS_Custom_GridView_UserLayout]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__TMS_Custom_GridView_UserLayout__ID] DEFAULT (newsequentialid()),
[TMS_Custom_GridViewId] [uniqueidentifier] NULL,
[UserId] [uniqueidentifier] NULL,
[LayoutJson] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[FilterJson] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[UserView] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Description] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsPublic] [bit] NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__TMS_Custom_GridView_UserLayout__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__TMS_Custom_GridView_UserLayout__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL CONSTRAINT [DF__TMS_Custom_GridView_UserLayout__CreatedBy] DEFAULT ('00000000-0000-0000-0000-000000000000'),
[ModifiedBy] [uniqueidentifier] NOT NULL CONSTRAINT [DF__TMS_Custom_GridView_UserLayout__ModifiedBy] DEFAULT ('00000000-0000-0000-0000-000000000000'),
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__TMS_Custom_GridView_UserLayout__IsDelete] DEFAULT ((0)),
[Sequence] [int] NOT NULL CONSTRAINT [DF__TMS_Custom_GridView_UserLayout__Sequence] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_Custom_GridView_UserLayout] ADD CONSTRAINT [PK__TMS_Custom_GridView_UserLayout__ID] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_Custom_GridView_UserLayout] WITH NOCHECK ADD CONSTRAINT [FK__TMS_Custom_GridView_UserLayout__TMS_Custom_GridViewId__x__TMS_Custom_GridView__ID] FOREIGN KEY ([TMS_Custom_GridViewId]) REFERENCES [dbo].[TMS_Custom_GridView] ([ID])
GO
