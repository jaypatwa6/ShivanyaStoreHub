CREATE TABLE [dbo].[System_Rate_UnitOfMeasure]
(
[Id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_System_Rate_UnitOfMeasure_Id] DEFAULT (newsequentialid()),
[System_RateID] [uniqueidentifier] NOT NULL,
[CommonList_UnitOfMeasureID] [uniqueidentifier] NOT NULL,
[IsActive] [bit] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Rate_UnitOfMeasure] ADD CONSTRAINT [PK_System_Rate_UnitOfMeasure] PRIMARY KEY CLUSTERED  ([Id]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Rate_UnitOfMeasure] ADD CONSTRAINT [FK_System_Rate_UnitOfMeasureID_System_CommonList_Item_ID] FOREIGN KEY ([CommonList_UnitOfMeasureID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[System_Rate_UnitOfMeasure] ADD CONSTRAINT [FK_System_Rate_UnitOfMeasureId_System_RateId] FOREIGN KEY ([System_RateID]) REFERENCES [dbo].[System_Rate] ([Id])
GO
