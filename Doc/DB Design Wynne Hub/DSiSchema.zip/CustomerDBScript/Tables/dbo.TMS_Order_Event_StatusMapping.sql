CREATE TABLE [dbo].[TMS_Order_Event_StatusMapping]
(
[Id] [uniqueidentifier] NOT NULL CONSTRAINT [DF__TMS_Order_Event_StatusMapping__ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__TMS_Order_Event_StatusMapping__DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__TMS_Order_Event_StatusMapping__DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[CommonList_TMS_Order_StatusId] [uniqueidentifier] NULL,
[CommonList_TMS_Order_Item_StatusId] [uniqueidentifier] NOT NULL,
[CommonList_TMS_Order_Item_Task_StatusId] [uniqueidentifier] NULL,
[CommonList_TMS_Order_Item_Task_TypeId] [uniqueidentifier] NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF__TMS_Order_Event_StatusMapping__IsActive] DEFAULT ((1)),
[SequenceNumber] [int] NOT NULL,
[Color] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_Order_Event_StatusMapping] ADD CONSTRAINT [PK__TMS_Order_Event_StatusMapping] PRIMARY KEY CLUSTERED  ([Id]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_Order_Event_StatusMapping] ADD CONSTRAINT [FK__TMS_Order_Event_StatusMapping__CommonList_TMS_Order_Item_StatusId__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_TMS_Order_Item_StatusId]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order_Event_StatusMapping] ADD CONSTRAINT [FK__TMS_Order_Event_StatusMapping__CommonList_TMS_Order_Item_Task_StatusId__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_TMS_Order_Item_Task_StatusId]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order_Event_StatusMapping] ADD CONSTRAINT [FK__TMS_Order_Event_StatusMapping__CommonList_TMS_Order_Item_Task_TypeId__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_TMS_Order_Item_Task_TypeId]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order_Event_StatusMapping] ADD CONSTRAINT [FK__TMS_Order_Event_StatusMapping__CommonList_TMS_Order_StatusId__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_TMS_Order_StatusId]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
