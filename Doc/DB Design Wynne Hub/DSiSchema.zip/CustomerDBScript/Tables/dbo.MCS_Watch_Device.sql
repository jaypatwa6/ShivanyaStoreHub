CREATE TABLE [dbo].[MCS_Watch_Device]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_MCS_Watch_Device_ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_MCS_Watch_Device_DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_MCS_Watch_Device_DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[MCS_DeviceID] [uniqueidentifier] NOT NULL,
[MCS_WatchID] [uniqueidentifier] NOT NULL,
[SortOrder] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Watch_Device] ADD CONSTRAINT [PK_MCS_Watch_Device] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Watch_Device] ADD CONSTRAINT [FK_MCS_Watch_Device__MCS_DeviceID_x_MCS_Device__ID] FOREIGN KEY ([MCS_DeviceID]) REFERENCES [dbo].[MCS_Device] ([ID])
GO
ALTER TABLE [dbo].[MCS_Watch_Device] ADD CONSTRAINT [FK_MCS_Watch_Device_MCS_Watch] FOREIGN KEY ([MCS_WatchID]) REFERENCES [dbo].[MCS_Watch] ([ID]) ON DELETE CASCADE
GO
