CREATE TABLE [dbo].[FMS_Equipment_Group]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__FMS_Equipment_Group__ID] DEFAULT (newsequentialid()),
[CommonList_EquipmentCategoryID] [uniqueidentifier] NULL,
[CommonList_EquipmentClassificationID] [uniqueidentifier] NULL,
[CommonList_EquipmentMakeID] [uniqueidentifier] NULL,
[CommonList_EquipmentModelID] [uniqueidentifier] NULL,
[CommonList_Equipment_GroupTypeID] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__FMS_Equipment_Group__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__FMS_Equipment_Group__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__FMS_Equipment_Group__IsDelete] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Equipment_Group] ADD CONSTRAINT [PK__FMS_Equipment_Group] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Equipment_Group] ADD CONSTRAINT [UK__FMS_Equipment_Group__CatClassMakeModel] UNIQUE NONCLUSTERED  ([CommonList_EquipmentCategoryID], [CommonList_EquipmentClassificationID], [CommonList_EquipmentMakeID], [CommonList_EquipmentModelID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Equipment_Group] ADD CONSTRAINT [FK__FMS_Equipment_Group__CommonList_Equipment_GroupTypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_Equipment_GroupTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_Equipment_Group] ADD CONSTRAINT [FK__FMS_Equipment_Group__CommonList_EquipmentCategoryID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_EquipmentCategoryID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_Equipment_Group] ADD CONSTRAINT [FK__FMS_Equipment_Group__CommonList_EquipmentClassificationID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_EquipmentClassificationID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_Equipment_Group] ADD CONSTRAINT [FK__FMS_Equipment_Group__CommonList_EquipmentMakeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_EquipmentMakeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_Equipment_Group] ADD CONSTRAINT [FK__FMS_Equipment_Group__CommonList_EquipmentModelID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_EquipmentModelID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
