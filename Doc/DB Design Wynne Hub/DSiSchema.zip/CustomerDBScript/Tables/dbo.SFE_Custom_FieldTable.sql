CREATE TABLE [dbo].[SFE_Custom_FieldTable]
(
[FieldName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[IsPrimaryKey] [bit] NOT NULL CONSTRAINT [DF_SFE_Custom_FieldTable_IsPrimaryKey] DEFAULT ((0)),
[IsIndexField] [bit] NOT NULL CONSTRAINT [DF_SFE_Custom_FieldTable_IsIndexField] DEFAULT ((0)),
[IsNullable] [bit] NOT NULL CONSTRAINT [DF_SFE_Custom_FieldTable_IsNullable] DEFAULT ((0)),
[FieldType] [int] NOT NULL,
[DataLength] [int] NOT NULL,
[DecimalScale] [int] NOT NULL,
[DecimalPrecision] [int] NOT NULL,
[DefaultValue] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsSystem] [bit] NOT NULL CONSTRAINT [DF_SFE_Custom_FieldTable_IsSystem] DEFAULT ((0)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_SFE_Custom_FieldTable_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_SFE_Custom_FieldTable_DateModified] DEFAULT (getutcdate()),
[ControlDisplay] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__SFE_Custom_F__ID__762C88DA] DEFAULT (newsequentialid()),
[TableID] [uniqueidentifier] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[RelationshipID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[SFE_Custom_FieldTable] ADD CONSTRAINT [PK_SFE_Custom_FieldTable] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[SFE_Custom_FieldTable] ADD CONSTRAINT [FK_SFE_Custom_FieldTable__RelationshipID_x_SFE_Custom_TableRelationship__ID] FOREIGN KEY ([RelationshipID]) REFERENCES [dbo].[SFE_Custom_TableRelationship] ([ID])
GO
ALTER TABLE [dbo].[SFE_Custom_FieldTable] ADD CONSTRAINT [FK_SFE_Custom_FieldTable__TableID_X_SFE_Custom_Table__ID] FOREIGN KEY ([TableID]) REFERENCES [dbo].[SFE_Custom_Table] ([ID]) ON DELETE CASCADE
GO
