CREATE TABLE [dbo].[FMS_Elog_CoDrivers]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__[FMS_Elog_CoDriver__ID__7B1C2684] DEFAULT (newsequentialid()),
[HR_EmployeeID_1] [uniqueidentifier] NOT NULL,
[HR_EmployeeID_2] [uniqueidentifier] NOT NULL,
[StartTimeZoneOffset] [decimal] (3, 1) NULL,
[StartTime] [datetime] NOT NULL,
[EndTimeZoneOffset] [decimal] (3, 1) NULL,
[EndTime] [datetime] NULL,
[FMS_EquipmentID] [uniqueidentifier] NOT NULL,
[Note] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_CoDrivers] ADD CONSTRAINT [PK_ELD_CoDrivers_Tracking] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_CoDrivers] ADD CONSTRAINT [FK_FMS_Elog_CoDrivers_FMS_Equipment] FOREIGN KEY ([FMS_EquipmentID]) REFERENCES [dbo].[FMS_Equipment] ([ID])
GO
ALTER TABLE [dbo].[FMS_Elog_CoDrivers] ADD CONSTRAINT [FK_FMS_Elog_CoDrivers_HR_Employee1] FOREIGN KEY ([HR_EmployeeID_2]) REFERENCES [dbo].[HR_Employee] ([ID])
GO
ALTER TABLE [dbo].[FMS_Elog_CoDrivers] ADD CONSTRAINT [FK_FMS_Elog_CoDrivers_HR_Employee2] FOREIGN KEY ([HR_EmployeeID_1]) REFERENCES [dbo].[HR_Employee] ([ID])
GO
