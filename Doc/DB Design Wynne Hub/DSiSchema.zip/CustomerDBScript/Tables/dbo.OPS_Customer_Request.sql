CREATE TABLE [dbo].[OPS_Customer_Request]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__OPS_Customer_Request__ID] DEFAULT (newsequentialid()),
[CRM_CustomerID] [uniqueidentifier] NOT NULL,
[FMS_EquipmentID] [uniqueidentifier] NULL,
[OPS_WorkOrder_TaskID] [uniqueidentifier] NULL,
[CRM_JobsiteID] [uniqueidentifier] NULL,
[ContractNumber] [nvarchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[RequestNumber] [nvarchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[JobName] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[RequestDate] [datetime] NOT NULL,
[RequestDetail] [nvarchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[RequesterName] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[RequesterEmail] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CommonList_OPSCustomer_Request_StatusID] [uniqueidentifier] NOT NULL,
[CommonList_OPSCustomer_Request_TypeID] [uniqueidentifier] NOT NULL,
[CancelComment] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ExtendedData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__OPS_Customer_Request__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__OPS_Customer_Request__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__OPS_Customer_Request__IsDelete] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_Customer_Request] ADD CONSTRAINT [PK__OPS_Customer_Request] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_Customer_Request] ADD CONSTRAINT [FK__OPS_Customer_Request__CommonList_OPSCustomer_Request_StatusID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPSCustomer_Request_StatusID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_Customer_Request] ADD CONSTRAINT [FK__OPS_Customer_Request__CommonList_OPSCustomer_Request_TypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPSCustomer_Request_TypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_Customer_Request] ADD CONSTRAINT [FK__OPS_Customer_Request__CRM_CustomerID__x__CRM_Customer__ID] FOREIGN KEY ([CRM_CustomerID]) REFERENCES [dbo].[CRM_Customer] ([ID])
GO
ALTER TABLE [dbo].[OPS_Customer_Request] ADD CONSTRAINT [FK__OPS_Customer_Request__CRM_JobsiteID__x__CRM_Jobsite__ID] FOREIGN KEY ([CRM_JobsiteID]) REFERENCES [dbo].[CRM_Jobsite] ([ID])
GO
ALTER TABLE [dbo].[OPS_Customer_Request] ADD CONSTRAINT [FK__OPS_Customer_Request__FMS_EquipmentID__x__FMS_Equipment__ID] FOREIGN KEY ([FMS_EquipmentID]) REFERENCES [dbo].[FMS_Equipment] ([ID])
GO
ALTER TABLE [dbo].[OPS_Customer_Request] ADD CONSTRAINT [FK__OPS_Customer_Request__OPS_WorkOrder_TaskID__x__OPS_WorkOrder_Task__ID] FOREIGN KEY ([OPS_WorkOrder_TaskID]) REFERENCES [dbo].[OPS_WorkOrder_Task] ([ID])
GO
