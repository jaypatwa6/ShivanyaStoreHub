CREATE TABLE [dbo].[System_Organization]
(
[Name] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Address] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Address2] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[City] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[State] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PostalCode] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ContactPhone] [nvarchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ContactName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Note] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Longitude] [decimal] (9, 6) NULL,
[Latitude] [decimal] (9, 6) NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_System_Organizations_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_System_Organizations_DateModified] DEFAULT (getutcdate()),
[IsActive] [bit] NOT NULL CONSTRAINT [DF_System_Organizations_IsActive] DEFAULT ((1)),
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__System_Organ__ID__522FEADD] DEFAULT (newsequentialid()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[System_OrganizationTypeID] [uniqueidentifier] NOT NULL,
[ReportsToID] [uniqueidentifier] NULL,
[Description] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ShortDescription] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ExtendedData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[System_TimeZoneID] [uniqueidentifier] NULL,
[System_List_CountryID] [uniqueidentifier] NULL,
[AccountNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ContactEmail] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Organization] ADD CONSTRAINT [PK_System_Organizations] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Organization] ADD CONSTRAINT [FK__System_Organization__System_TimeZoneID__x__System_TimeZone__ID] FOREIGN KEY ([System_TimeZoneID]) REFERENCES [dbo].[System_TimeZone] ([ID])
GO
ALTER TABLE [dbo].[System_Organization] ADD CONSTRAINT [FK_System_Organization__ReportsToID_x_System_Organization__ID] FOREIGN KEY ([ReportsToID]) REFERENCES [dbo].[System_Organization] ([ID])
GO
ALTER TABLE [dbo].[System_Organization] ADD CONSTRAINT [FK_System_Organization__System_List_CountryID_X_System_List_Countries__ID] FOREIGN KEY ([System_List_CountryID]) REFERENCES [dbo].[System_List_Country] ([ID])
GO
ALTER TABLE [dbo].[System_Organization] ADD CONSTRAINT [FK_System_Organization__System_OrganizationTypeID_X_System_OrganizationType__ID] FOREIGN KEY ([System_OrganizationTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
