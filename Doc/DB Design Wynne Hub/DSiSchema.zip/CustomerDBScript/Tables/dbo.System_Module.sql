CREATE TABLE [dbo].[System_Module]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__System_Modul__ID__753864A1] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_System_Module_DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_System_Module_DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_System_Module_IsActive] DEFAULT ((1)),
[IsPurchased] [bit] NULL,
[Description] [nvarchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Name] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Version] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Module] ADD CONSTRAINT [PK_System_Module] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
