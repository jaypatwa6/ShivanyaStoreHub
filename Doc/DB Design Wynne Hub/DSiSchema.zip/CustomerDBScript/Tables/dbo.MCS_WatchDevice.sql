CREATE TABLE [dbo].[MCS_WatchDevice]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_MCS_WatchDevice_ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_MCS_WatchDevice_DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_MCS_WatchDevice_DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[Name] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[MCS_DeviceID] [uniqueidentifier] NOT NULL,
[Properties] [xml] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_WatchDevice] ADD CONSTRAINT [PK_MCS_WatchDevice] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_WatchDevice__CreatedBy] ON [dbo].[MCS_WatchDevice] ([CreatedBy]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_WatchDevice__MCS_DeviceID] ON [dbo].[MCS_WatchDevice] ([MCS_DeviceID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_WatchDevice__Name] ON [dbo].[MCS_WatchDevice] ([Name]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_WatchDevice] ADD CONSTRAINT [FK_MCS_WatchDevice__MCS_DeviceID_x_MCS_Device__ID] FOREIGN KEY ([MCS_DeviceID]) REFERENCES [dbo].[MCS_Device] ([ID])
GO
