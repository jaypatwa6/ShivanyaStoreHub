CREATE TABLE [dbo].[MCS_Trip]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_MCS_Dispatch_Trip_ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_MCS_Dispatch_Trip_DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_MCS_Dispatch_Trip_DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[TripNumber] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[AssignedToEmployeeID] [uniqueidentifier] NULL,
[CustomData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[AssignedToTruckID] [uniqueidentifier] NULL,
[CommonList_AssignedTypeID] [uniqueidentifier] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Trip] ADD CONSTRAINT [PK_MCS_Trip] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Trip__AssignedToEmployeeID__ID] ON [dbo].[MCS_Trip] ([AssignedToEmployeeID], [ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Trip__DateModified] ON [dbo].[MCS_Trip] ([DateModified] DESC) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Trip] ADD CONSTRAINT [FK_MCS_Trip__AssignedToEmployeeID_X_HR_Employee__ID] FOREIGN KEY ([AssignedToEmployeeID]) REFERENCES [dbo].[HR_Employee] ([ID])
GO
ALTER TABLE [dbo].[MCS_Trip] ADD CONSTRAINT [FK_MCS_Trip_FMS_Equipment] FOREIGN KEY ([AssignedToTruckID]) REFERENCES [dbo].[FMS_Equipment] ([ID])
GO
ALTER TABLE [dbo].[MCS_Trip] ADD CONSTRAINT [FK_MCS_Trip_System_CommonList_Item] FOREIGN KEY ([CommonList_AssignedTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
