CREATE TABLE [dbo].[FMS_Elog_Changeset_History]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_FMS_Elog_Changeset_History_ID_1] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_FMS_Elog_Changeset_History_DateCreated_1] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_FMS_Elog_Changeset_History_DateModified_1] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[StartTime] [datetime] NOT NULL,
[StartTimeZoneOffset] [nchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[EndTime] [datetime] NULL,
[EndTimeZoneOffset] [nchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DurationInTicks] [bigint] NULL,
[DistanceInKM] [decimal] (18, 2) NOT NULL,
[ShippingDocNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Note] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsInterstateLoad] [bit] NOT NULL CONSTRAINT [DF_FMS_Elog_Changeset_History_IsInterstateLoad_1] DEFAULT ((0)),
[SystemRemarks] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[MCS_EventSummaryID] [uniqueidentifier] NULL,
[FMS_Elog_CoDriversID] [uniqueidentifier] NULL,
[FMS_Elog_DailyReportID] [uniqueidentifier] NULL,
[ELD_EventRecordStatus] [tinyint] NOT NULL,
[HR_EmployeeID] [uniqueidentifier] NOT NULL,
[CommonList_ElogStatusTypeID] [uniqueidentifier] NOT NULL,
[IsManually] [bit] NOT NULL,
[IsDailyReset] [bit] NOT NULL CONSTRAINT [DF_FMS_Elog_Changeset_History_IsDailyReset_1] DEFAULT ((0)),
[IsApproved] [bit] NOT NULL CONSTRAINT [DF_FMS_Elog_Changeset_History_IsApproved_1] DEFAULT ((0)),
[DateApproved] [datetime] NULL,
[FMS_Elog_ChangesetID] [uniqueidentifier] NOT NULL,
[CanEditDuration] [bit] NOT NULL CONSTRAINT [DF_FMS_Elog_Changeset_History_CanEditDuration] DEFAULT ((1))
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_Changeset_History] ADD CONSTRAINT [PK_FMS_Elog_Changeset_History] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_Changeset_History] ADD CONSTRAINT [FK_FMS_Elog_Changeset_History_FMS_Elog_Changeset] FOREIGN KEY ([FMS_Elog_ChangesetID]) REFERENCES [dbo].[FMS_Elog_Changeset] ([ID])
GO
EXEC sp_addextendedproperty N'MS_Description', N'Allow user edit the starttime and endtime or not', 'SCHEMA', N'dbo', 'TABLE', N'FMS_Elog_Changeset_History', 'COLUMN', N'CanEditDuration'
GO
