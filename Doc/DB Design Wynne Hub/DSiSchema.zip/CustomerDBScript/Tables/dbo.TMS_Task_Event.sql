CREATE TABLE [dbo].[TMS_Task_Event]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__TMS_Task_Event__ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__TMS_Task_Event__DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__TMS_Task_Event__DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[TMS_OrderItemID] [uniqueidentifier] NULL,
[Driver_HR_EmployeeID] [uniqueidentifier] NULL,
[ScheduledStartTime] [datetime] NULL,
[ScheduledEndTime] [datetime] NULL,
[MCS_Trip_Stop_TaskID] [uniqueidentifier] NULL,
[EventData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CommonList_TMS_TaskTypeId] [uniqueidentifier] NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__TMS_Task_Event__IsDelete] DEFAULT ((0)),
[IsRead] [bit] NOT NULL CONSTRAINT [DF__TMS_Task_Event__IsRead] DEFAULT ((0)),
[CommonList_TMS_Task_Event_StatusID] [uniqueidentifier] NULL,
[ActualStartTime] [datetime] NULL,
[ActualEndTime] [datetime] NULL,
[FMS_EquipmentID] [uniqueidentifier] NULL,
[ScheduledReferenceTime] [datetime] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_Task_Event] ADD CONSTRAINT [PK_TMS_Task_Event] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Task_Event__DateModified] ON [dbo].[TMS_Task_Event] ([DateModified]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IDX_TMSTaskEvent__Driver_HR_EmployeeID_ScheduledReferenceTime] ON [dbo].[TMS_Task_Event] ([Driver_HR_EmployeeID], [ScheduledReferenceTime]) INCLUDE ([IsDelete]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_Task_Event] ADD CONSTRAINT [FK__TMS_Task_Event__CommonList_TMS_Task_Event_StatusID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_TMS_Task_Event_StatusID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[TMS_Task_Event] ADD CONSTRAINT [FK__TMS_Task_Event__CommonList_TMS_TaskTypeId__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_TMS_TaskTypeId]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[TMS_Task_Event] ADD CONSTRAINT [FK__TMS_Task_Event__Driver_HR_EmployeeID__x__HR_Employee__ID] FOREIGN KEY ([Driver_HR_EmployeeID]) REFERENCES [dbo].[HR_Employee] ([ID])
GO
ALTER TABLE [dbo].[TMS_Task_Event] ADD CONSTRAINT [FK_TMS_Task_Event__CommonList__TMS_TaskTypeId_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_TMS_TaskTypeId]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[TMS_Task_Event] ADD CONSTRAINT [FK_TMS_Task_Event__MCS_Trip_Stop_TaskID_X_MCS_Trip_Stop_Task__ID] FOREIGN KEY ([MCS_Trip_Stop_TaskID]) REFERENCES [dbo].[MCS_Trip_Stop_Task] ([ID])
GO
ALTER TABLE [dbo].[TMS_Task_Event] ADD CONSTRAINT [FK_TMS_Task_Event__TMS_OrderItemID_X_TMS_Order_Item__ID] FOREIGN KEY ([TMS_OrderItemID]) REFERENCES [dbo].[TMS_Order_Item] ([ID])
GO
ALTER TABLE [dbo].[TMS_Task_Event] ADD CONSTRAINT [FK_TMS_Task_Event_FMS_Equipment] FOREIGN KEY ([FMS_EquipmentID]) REFERENCES [dbo].[FMS_Equipment] ([ID])
GO
