CREATE TABLE [dbo].[System_OrganizationType]
(
[Name] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_System_OrganizationTypes_IsActive] DEFAULT ((1)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_System_OrganizationTypes_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_System_OrganizationTypes_DateModified] DEFAULT (getutcdate()),
[Note] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Level] [int] NOT NULL,
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__System_Organ__ID__56007BC1] DEFAULT (newsequentialid()),
[ParentID] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_OrganizationType] ADD CONSTRAINT [PK_System_OrganizationTypes] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_OrganizationType] ADD CONSTRAINT [FK_System_OrganizationType__ParentID_x_System_OrganizationType__ID] FOREIGN KEY ([ParentID]) REFERENCES [dbo].[System_OrganizationType] ([ID])
GO
