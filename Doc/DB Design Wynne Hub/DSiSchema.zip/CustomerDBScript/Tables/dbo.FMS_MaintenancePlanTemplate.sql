CREATE TABLE [dbo].[FMS_MaintenancePlanTemplate]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_FMS_MaintenancePlanTemplate_ID] DEFAULT (newsequentialid()),
[IsActive] [bit] NOT NULL CONSTRAINT [DF_FMS_MaintenancePlanTemplate_IsActive] DEFAULT ((1)),
[Name] [nvarchar] (150) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CommonList_ServiceTypeID] [uniqueidentifier] NOT NULL,
[Notes] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ServiceIntervalUnits] [decimal] (9, 2) NULL,
[CommonList_ServiceIntervalUOMTypeID] [uniqueidentifier] NOT NULL,
[SecondaryServiceIntervalUnits] [decimal] (9, 2) NULL,
[CommonList_SecondaryServiceIntervalUOMTypeID] [uniqueidentifier] NULL,
[CommonList_NextEventForecastMethodID] [uniqueidentifier] NOT NULL,
[IsRoundServiceforecast] [bit] NOT NULL CONSTRAINT [DF_FMS_MaintenancePlanTemplate_IsRoundServiceforecast] DEFAULT ((0)),
[RoundServiceForecastScale] [int] NULL,
[ServiceFormID] [uniqueidentifier] NULL,
[ServiceWarningThresholdUnits] [decimal] (9, 2) NULL,
[IsResetLastEventUnitsWithActualUnits] [bit] NOT NULL CONSTRAINT [DF_FMS_MaintenancePlanTemplate_IsResetLastEventUnitsWithActualUnits] DEFAULT ((0)),
[TimeThreshold] [decimal] (9, 2) NULL,
[CommonList_TimeThresholdID] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__FMS_MaintenancePlanTemplate__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__FMS_MaintenancePlanTemplate__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL CONSTRAINT [DF__FMS_MaintenancePlanTemplate__CreatedBy] DEFAULT ('00000000-0000-0000-0000-000000000000'),
[ModifiedBy] [uniqueidentifier] NOT NULL CONSTRAINT [DF__FMS_MaintenancePlanTemplate__ModifiedBy] DEFAULT ('00000000-0000-0000-0000-000000000000'),
[Number] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsRequired] [bit] NOT NULL CONSTRAINT [DF__FMS_Maint__IsReq__66F53242] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_MaintenancePlanTemplate] ADD CONSTRAINT [PK_FMS_MaintenancePlanTemplate] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_MaintenancePlanTemplate] ADD CONSTRAINT [FK_FMS_MaintenancePlanTemplate__CommonList_NextEventForecastMethodID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_NextEventForecastMethodID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_MaintenancePlanTemplate] ADD CONSTRAINT [FK_FMS_MaintenancePlanTemplate__CommonList_SecondaryServiceIntervalUOMTypeID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_SecondaryServiceIntervalUOMTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_MaintenancePlanTemplate] ADD CONSTRAINT [FK_FMS_MaintenancePlanTemplate__CommonList_ServiceIntervalUOMTypeID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_ServiceIntervalUOMTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
