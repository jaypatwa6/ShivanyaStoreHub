CREATE TABLE [dbo].[INV_Classification_Job]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__INV_Classification_Job__ID] DEFAULT (newsequentialid()),
[CommonList_INVClassification_TypeID] [uniqueidentifier] NOT NULL,
[CommonList_INVClassification_Job_StatusID] [uniqueidentifier] NOT NULL,
[CompanyCode] [nvarchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[StartDate] [datetime] NOT NULL,
[EndDate] [datetime] NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__INV_Classification_Job__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__INV_Classification_Job__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF__INV_Classification_Job__IsActive] DEFAULT ((1))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[INV_Classification_Job] ADD CONSTRAINT [PK__INV_Classification_Job] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[INV_Classification_Job] ADD CONSTRAINT [FK__INV_Classification_Job__CommonList_INVClassification_TypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_INVClassification_TypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[INV_Classification_Job] ADD CONSTRAINT [FK__INV_Classification_Job__INVClassification_Job_StatusID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_INVClassification_Job_StatusID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
