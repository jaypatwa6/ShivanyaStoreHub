CREATE TABLE [dbo].[OPS_Attachment_Definition]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__OPS_Attachment_Definition__ID] DEFAULT (newsequentialid()),
[OPS_AttachmentID] [uniqueidentifier] NOT NULL,
[CommonList_Attachment_DefinitionTypeID] [uniqueidentifier] NULL,
[ReferenceTable] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ReferenceForeignKeyID] [uniqueidentifier] NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__OPS_Attachment_Definition__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__OPS_Attachment_Definition__DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__OPS_Attachment_Definition__IsDelete] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_Attachment_Definition] ADD CONSTRAINT [PK__OPS_Attachment_Definition] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_Attachment_Definition] ADD CONSTRAINT [FK__OPS_Attachment_Definition__CommonList_Attachment_DefinitionTypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_Attachment_DefinitionTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_Attachment_Definition] ADD CONSTRAINT [FK__OPS_Attachment_Definition__OPS_AttachmentID__x__OPS_Attachment__ID] FOREIGN KEY ([OPS_AttachmentID]) REFERENCES [dbo].[OPS_Attachment] ([ID])
GO
