CREATE TABLE [dbo].[TMS_CustomForm_Subscriber]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__TMS_CustomForm_Subscriber__ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__TMS_CustomForm_Subscriber__DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__TMS_CustomForm_Subscriber__DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[TMS_CustomFormID] [uniqueidentifier] NOT NULL,
[VersionNo] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_CustomForm_Subscriber] ADD CONSTRAINT [PK__TMS_CustomForm_Subscriber] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_CustomForm_Subscriber__DateCreated] ON [dbo].[TMS_CustomForm_Subscriber] ([DateCreated]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_CustomForm_Subscriber__TMS_CustomFormID] ON [dbo].[TMS_CustomForm_Subscriber] ([TMS_CustomFormID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_CustomForm_Subscriber__VersionNo] ON [dbo].[TMS_CustomForm_Subscriber] ([VersionNo]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_CustomForm_Subscriber] ADD CONSTRAINT [FK__TMS_CustomForm_Subscriber__TMS_CustomFormID__x__TMS_CustomForm__ID] FOREIGN KEY ([TMS_CustomFormID]) REFERENCES [dbo].[TMS_CustomForm] ([ID])
GO
