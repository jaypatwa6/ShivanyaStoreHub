CREATE TABLE [dbo].[FMS_Equipment_Specs]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__FMS_Equipmen__ID__681373AD] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_FMS_Equipment_Specs_DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_FMS_Equipment_Specs_DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_FMS_Equipment_Specs_IsActive] DEFAULT ((1)),
[CommonList_EquipmentMakeID] [uniqueidentifier] NOT NULL,
[CommonList_EquipmentModelID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Equipment_Specs] ADD CONSTRAINT [PK_FMS_Equipment_Specs] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Equipment_Specs] WITH NOCHECK ADD CONSTRAINT [FK_FMS_Equipment_Specs__CommonList_EquipmentMakeID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_EquipmentMakeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_Equipment_Specs] WITH NOCHECK ADD CONSTRAINT [FK_FMS_Equipment_Specs__CommonList_EquipmentModelID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_EquipmentModelID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
