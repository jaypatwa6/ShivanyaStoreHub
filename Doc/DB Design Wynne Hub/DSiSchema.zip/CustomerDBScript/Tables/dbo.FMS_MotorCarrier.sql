CREATE TABLE [dbo].[FMS_MotorCarrier]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__ELog_MotorCa__ID__365CE7DF] DEFAULT (newsequentialid()),
[CountryCodeID] [uniqueidentifier] NOT NULL,
[Name] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Address] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[State] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PostalCode] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[USDOTNumber] [nvarchar] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[TimeZone] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[City] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsDefault] [bit] NOT NULL CONSTRAINT [DF_ELog_MotorCarrier_IsDefault] DEFAULT ((1)),
[Phone] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_FMS_MotorCarrier_IsActive] DEFAULT ((1)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__tmp_ms_xx__DateC__3B6BB5BF] DEFAULT (((1)/(1))/(1900)),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__tmp_ms_xx__DateM__3C5FD9F8] DEFAULT (((1)/(1))/(1900)),
[CreatedBy] [uniqueidentifier] NOT NULL CONSTRAINT [DF__tmp_ms_xx__Creat__3D53FE31] DEFAULT ('00000000-0000-0000-0000-000000000000'),
[ModifyBy] [uniqueidentifier] NOT NULL CONSTRAINT [DF__tmp_ms_xx__Modif__3E48226A] DEFAULT ('00000000-0000-0000-0000-000000000000'),
[MotorCarrier24HourStartingTime] [decimal] (3, 1) NULL,
[MotorCarrierTimeZoneOffset] [decimal] (3, 1) NULL,
[Notes] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Address1] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_MotorCarrier] ADD CONSTRAINT [PK_FMS_MotorCarrier] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_MotorCarrier] ADD CONSTRAINT [FK_FMS_MotorCarrier__CountryCodeID_X_System_List_Countries__ID] FOREIGN KEY ([CountryCodeID]) REFERENCES [dbo].[System_List_Country] ([ID])
GO
EXEC sp_addextendedproperty N'MS_Description', N'24-Hour Period Starting Time.', 'SCHEMA', N'dbo', 'TABLE', N'FMS_MotorCarrier', 'COLUMN', N'MotorCarrier24HourStartingTime'
GO
EXEC sp_addextendedproperty N'MS_Description', N'Time Zone Offset from UTC.', 'SCHEMA', N'dbo', 'TABLE', N'FMS_MotorCarrier', 'COLUMN', N'MotorCarrierTimeZoneOffset'
GO
