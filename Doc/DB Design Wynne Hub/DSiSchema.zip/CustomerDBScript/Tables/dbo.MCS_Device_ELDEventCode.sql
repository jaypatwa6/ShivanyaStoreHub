CREATE TABLE [dbo].[MCS_Device_ELDEventCode]
(
[ID] [uniqueidentifier] NOT NULL,
[EventType] [tinyint] NOT NULL,
[EventCode] [tinyint] NOT NULL,
[DateCreated] [datetime] NOT NULL,
[DateModified] [datetime] NOT NULL,
[IsActive] [bit] NOT NULL,
[CommonList_GPSEventTypeID] [uniqueidentifier] NOT NULL,
[EventDescription] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Device_ELDEventCode] ADD CONSTRAINT [PK_MCS_Device_ELDEventCode] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
