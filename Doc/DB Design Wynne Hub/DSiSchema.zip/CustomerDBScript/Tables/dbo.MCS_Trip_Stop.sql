CREATE TABLE [dbo].[MCS_Trip_Stop]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__SDMS_Stop__ID__7BFB3C20] DEFAULT (newsequentialid()),
[System_List_CountryID] [uniqueidentifier] NULL,
[CRM_JobsiteID] [uniqueidentifier] NULL,
[CommonList_OrderPriorityID] [uniqueidentifier] NOT NULL,
[MCS_TripID] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Stop_DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_SDMS_Stop_DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[PromiseTime] [datetime] NULL,
[Sequence] [int] NOT NULL,
[StopNumber] [int] NOT NULL,
[TimeWindow] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Address] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[City] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[State] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PostalCode] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Latitude] [decimal] (9, 6) NULL,
[Longitude] [decimal] (9, 6) NULL,
[SummaryField] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[LocationInstructions] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ActivityInstructions] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DateSynchronized] [datetime] NOT NULL CONSTRAINT [DF__SDMS_Stop__DateS__664CBD7A] DEFAULT (getdate()),
[Name] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Address2] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Acknowledge] [bit] NOT NULL CONSTRAINT [DF__SDMS_Stop__Ackno__4986619A] DEFAULT ((1)),
[Note] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PhoneNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PhoneExtension] [nvarchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Contact] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsDeleted] [bit] NOT NULL CONSTRAINT [DF__SDMS_Stop__IsDel__5BA511D5] DEFAULT ((0)),
[IsNullTime] [bit] NULL CONSTRAINT [DF_SDMS_Stop_IsNullTime] DEFAULT ((1))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Trip_Stop] ADD CONSTRAINT [PK_MCS_Trip_Stop] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Trip_Stop__CRM_JobsiteID] ON [dbo].[MCS_Trip_Stop] ([CRM_JobsiteID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Trip_Stop__DateModified] ON [dbo].[MCS_Trip_Stop] ([DateModified]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Trip_Stop__IsDeleted__ID__MCS_TripID] ON [dbo].[MCS_Trip_Stop] ([IsDeleted], [ID], [MCS_TripID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Trip_Stop__MCS_TripID] ON [dbo].[MCS_Trip_Stop] ([MCS_TripID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Trip_Stop__MCS_TripID__ID__DateSyncrhonized__IsDeleted] ON [dbo].[MCS_Trip_Stop] ([MCS_TripID], [ID], [DateSynchronized], [IsDeleted]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_MCS_Trip_Stop__PromiseTime] ON [dbo].[MCS_Trip_Stop] ([PromiseTime]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Trip_Stop] ADD CONSTRAINT [FK_MCS_Dispatch_Trip_Stop__CRM_JobsiteID_X_CRM_Jobsite__ID] FOREIGN KEY ([CRM_JobsiteID]) REFERENCES [dbo].[CRM_Jobsite] ([ID])
GO
ALTER TABLE [dbo].[MCS_Trip_Stop] WITH NOCHECK ADD CONSTRAINT [FK_MCS_Trip_Stop__CommonList_SalesOrderPriorityID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OrderPriorityID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[MCS_Trip_Stop] ADD CONSTRAINT [FK_MCS_Trip_Stop__MCS_TripID_X_MCS_Trip__ID] FOREIGN KEY ([MCS_TripID]) REFERENCES [dbo].[MCS_Trip] ([ID])
GO
ALTER TABLE [dbo].[MCS_Trip_Stop] ADD CONSTRAINT [FK_MCS_Trip_Stop__System_List_CountryID_X_System_List_Country__ID] FOREIGN KEY ([System_List_CountryID]) REFERENCES [dbo].[System_List_Country] ([ID])
GO
