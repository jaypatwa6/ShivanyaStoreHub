CREATE TABLE [dbo].[RPT2_Subscription]
(
[ID] [uniqueidentifier] NOT NULL,
[Name] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ReportID] [uniqueidentifier] NOT NULL,
[FilterID] [uniqueidentifier] NULL,
[DateStart] [datetime] NOT NULL,
[DateEnd] [datetime] NULL,
[FormatType] [int] NOT NULL,
[IsActive] [bit] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL,
[AllowSubscribe] [bit] NULL,
[DateRangeMode] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[RPT2_Subscription] ADD CONSTRAINT [PK_RPT2_Subscription] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
