CREATE TABLE [dbo].[MCS_Notification]
(
[Id] [uniqueidentifier] NOT NULL,
[HR_EmployeeId] [uniqueidentifier] NOT NULL,
[Title] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Message] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsNotify] [bit] NOT NULL CONSTRAINT [DF__MCS_Notif__IsNot__4FFCBE51] DEFAULT ((0)),
[IsRead] [bit] NOT NULL CONSTRAINT [DF__MCS_Notif__IsRea__50F0E28A] DEFAULT ((0)),
[HTML_Message] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DateCreated] [datetime] NULL,
[DateModified] [datetime] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Notification] ADD CONSTRAINT [PK_Notification] PRIMARY KEY CLUSTERED  ([Id]) ON [PRIMARY]
GO
