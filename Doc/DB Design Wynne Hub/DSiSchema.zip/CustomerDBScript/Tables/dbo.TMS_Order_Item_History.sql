CREATE TABLE [dbo].[TMS_Order_Item_History]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_TMS_Order_Item_History_ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL,
[OrderNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[LoadNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[InvoiceNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Description] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[EventType] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Data] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_Order_Item_History] ADD CONSTRAINT [PK_TMS_Order_Item_History] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Item_History__OrderNumber_LoadNumber_DateCreated] ON [dbo].[TMS_Order_Item_History] ([OrderNumber], [LoadNumber], [DateCreated]) ON [PRIMARY]
GO
