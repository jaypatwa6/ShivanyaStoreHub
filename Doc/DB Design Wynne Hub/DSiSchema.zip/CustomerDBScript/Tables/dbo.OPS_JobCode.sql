CREATE TABLE [dbo].[OPS_JobCode]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__OPS_JobCode__ID] DEFAULT (newsequentialid()),
[Name] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CommonList_OPS_Task_ShortDescriptionID] [uniqueidentifier] NOT NULL,
[CommonList_OPS_WorkOrder_Task_BillTypeID] [uniqueidentifier] NULL,
[CommonList_OPS_WorkOrder_Task_RepairTypeID] [uniqueidentifier] NULL,
[CommonList_OPS_Labor_CodeID] [uniqueidentifier] NULL,
[Notes] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF__OPS_JobCode_IsActive] DEFAULT ((1)),
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__OPS_JobCode_IsDelete] DEFAULT ((0)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__OPS_JobCode_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__OPS_JobCode_DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsAvailableForMobileLink] [bit] NOT NULL CONSTRAINT [DF__OPS_JobCode__IsAvailableForMobileLink] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_JobCode] ADD CONSTRAINT [PK__OPS_JobCode] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_JobCode] ADD CONSTRAINT [UQ__OPS_JobCode__Name] UNIQUE NONCLUSTERED  ([Name]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_JobCode] ADD CONSTRAINT [FK__OPS_JobCode__CommonList_OPS_Labor_CodeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPS_Labor_CodeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_JobCode] ADD CONSTRAINT [FK__OPS_JobCode__CommonList_OPS_Task_ShortDescriptionID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPS_Task_ShortDescriptionID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_JobCode] ADD CONSTRAINT [FK__OPS_JobCode__CommonList_OPS_WorkOrder_Task_BillTypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPS_WorkOrder_Task_BillTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_JobCode] ADD CONSTRAINT [FK__OPS_JobCode__CommonList_OPS_WorkOrder_Task_RepairTypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPS_WorkOrder_Task_RepairTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
