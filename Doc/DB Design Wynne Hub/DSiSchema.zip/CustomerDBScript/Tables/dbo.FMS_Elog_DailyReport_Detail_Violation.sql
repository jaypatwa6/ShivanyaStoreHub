CREATE TABLE [dbo].[FMS_Elog_DailyReport_Detail_Violation]
(
[ID] [uniqueidentifier] NOT NULL,
[StartTime] [datetime] NOT NULL,
[CommonList_Elog_ViolationTypeID] [uniqueidentifier] NOT NULL,
[FMS_Elog_DailyReport_DetailID] [uniqueidentifier] NOT NULL,
[Note] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__FMS_Elog___IsDel__6809520C] DEFAULT ((0)),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_FMS_Elog_DailyReport_Detail_Violation_DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL CONSTRAINT [DF_FMS_Elog_DailyReport_Detail_Violation_ModifiedBy] DEFAULT ('00000000-0000-0000-0000-000000000000')
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_DailyReport_Detail_Violation] ADD CONSTRAINT [PK_FMS_Elog_DailyReport_Detail_Violation] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_FMS_Elog_DailyReport_Detail_Violion__DailyReport_DetailID_DateModified] ON [dbo].[FMS_Elog_DailyReport_Detail_Violation] ([FMS_Elog_DailyReport_DetailID], [DateModified]) INCLUDE ([CommonList_Elog_ViolationTypeID], [ID], [IsDelete], [ModifiedBy], [Note], [StartTime]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_DailyReport_Detail_Violation] ADD CONSTRAINT [FK_FMS_Elog_DailyReport_Detail_Violation_FMS_Elog_DailyReport_Detail] FOREIGN KEY ([FMS_Elog_DailyReport_DetailID]) REFERENCES [dbo].[FMS_Elog_DailyReport_Detail] ([ID])
GO
EXEC sp_addextendedproperty N'MS_Description', N'The date that the record was modified.', 'SCHEMA', N'dbo', 'TABLE', N'FMS_Elog_DailyReport_Detail_Violation', 'COLUMN', N'DateModified'
GO
EXEC sp_addextendedproperty N'MS_Description', N'The account login ID of the one who made changes on the record.', 'SCHEMA', N'dbo', 'TABLE', N'FMS_Elog_DailyReport_Detail_Violation', 'COLUMN', N'ModifiedBy'
GO
