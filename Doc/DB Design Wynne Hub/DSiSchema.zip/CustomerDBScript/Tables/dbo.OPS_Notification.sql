CREATE TABLE [dbo].[OPS_Notification]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__OPS_Notification__ID] DEFAULT (newsequentialid()),
[Name] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[System_OrganizationID] [uniqueidentifier] NULL,
[System_Organization_LocationID] [uniqueidentifier] NULL,
[CommonList_OPSNotification_TriggerObjectID] [uniqueidentifier] NOT NULL,
[CommonList_OPSNotification_TriggerActionID] [uniqueidentifier] NOT NULL,
[Rule] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[PrecompiledExpression] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Message] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Receiver] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__OPS_Notification__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__OPS_Notification__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__OPS_Notification__IsDelete] DEFAULT ((0)),
[IsActive] [bit] NOT NULL CONSTRAINT [DF__OPS_Notification__IsActive] DEFAULT ((0)),
[MessageTitle] [nvarchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_Notification] ADD CONSTRAINT [PK__OPS_Notification] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_Notification] ADD CONSTRAINT [FK__OPS_Notification__CommonList_OPSNotification_TriggerActionID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPSNotification_TriggerActionID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_Notification] ADD CONSTRAINT [FK__OPS_Notification__CommonList_OPSNotification_TriggerObjectID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPSNotification_TriggerObjectID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_Notification] ADD CONSTRAINT [FK__OPS_Notification__System_Organization_LocationID__x__System_Organization__ID] FOREIGN KEY ([System_Organization_LocationID]) REFERENCES [dbo].[System_Organization] ([ID])
GO
ALTER TABLE [dbo].[OPS_Notification] ADD CONSTRAINT [FK__OPS_Notification__System_OrganizationID__x__System_Organization__ID] FOREIGN KEY ([System_OrganizationID]) REFERENCES [dbo].[System_Organization] ([ID])
GO
