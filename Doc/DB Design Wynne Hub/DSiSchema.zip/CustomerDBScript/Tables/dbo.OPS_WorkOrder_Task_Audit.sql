CREATE TABLE [dbo].[OPS_WorkOrder_Task_Audit]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__OPS_WorkOrder_Task_Audit__ID] DEFAULT (newsequentialid()),
[OPS_WorkOrder_TaskID] [uniqueidentifier] NOT NULL,
[ChangedField] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DataType] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[OriginalValue] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[NewValue] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ActionFrom] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__OPS_WorkOrder_Task_Audit__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__OPS_WorkOrder_Task_Audit__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_Audit] ADD CONSTRAINT [PK__OPS_WorkOrder_Task_Audit] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_Audit] ADD CONSTRAINT [FK__OPS_WorkOrder_Task_Audit__OPS_WorkOrder_TaskID__x__OPS_WorkOrder_Task__ID] FOREIGN KEY ([OPS_WorkOrder_TaskID]) REFERENCES [dbo].[OPS_WorkOrder_Task] ([ID])
GO
