CREATE TABLE [dbo].[System_UpgradeHistory]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__System_Commo__ID__6AD0B01E] DEFAULT (newsequentialid()),
[System_SettingID] [uniqueidentifier] NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[System_ModuleID] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_System_CommonLists_UpgradeHistory_DateCreated] DEFAULT (getutcdate()),
[Component] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Moduleversion] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[UpgradePackageName] [nvarchar] (150) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[UpgradePackageVersion] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DeveloperNotes] [nvarchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[SQLScript] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_UpgradeHistory] ADD CONSTRAINT [PK_System_UpgradeHistory] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_UpgradeHistory] ADD CONSTRAINT [FK_System_UpgradeHistory_System_ModuleID_X_System_Module_ID] FOREIGN KEY ([System_ModuleID]) REFERENCES [dbo].[System_Module] ([ID])
GO
ALTER TABLE [dbo].[System_UpgradeHistory] WITH NOCHECK ADD CONSTRAINT [FK_System_UpgradeHistory_System_SettingID_X_System_Setting_ID] FOREIGN KEY ([System_SettingID]) REFERENCES [dbo].[System_Setting] ([ID])
GO
