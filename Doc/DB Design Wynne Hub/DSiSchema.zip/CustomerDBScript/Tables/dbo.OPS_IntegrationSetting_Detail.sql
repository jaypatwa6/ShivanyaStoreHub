CREATE TABLE [dbo].[OPS_IntegrationSetting_Detail]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__OPS_IntegrationSetting_Detail__ID] DEFAULT (newsequentialid()),
[OPS_IntegrationSettingID] [uniqueidentifier] NOT NULL,
[IntegrationParameter] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IntegrationColumn] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ParameterValue] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ParameterDataType] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ExtendedData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Sequence] [int] NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__OPS_IntegrationSetting_Detail_IsDelete] DEFAULT ((0)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__OPS_IntegrationSetting_Detail_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__OPS_IntegrationSetting_Detail_DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_IntegrationSetting_Detail] ADD CONSTRAINT [PK__OPS_IntegrationSetting_Detail] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_IntegrationSetting_Detail] ADD CONSTRAINT [FK__OPS_IntegrationSetting_Detail__OPS_IntegrationSettingID__x__OPS_IntegrationSetting__ID] FOREIGN KEY ([OPS_IntegrationSettingID]) REFERENCES [dbo].[OPS_IntegrationSetting] ([ID])
GO
