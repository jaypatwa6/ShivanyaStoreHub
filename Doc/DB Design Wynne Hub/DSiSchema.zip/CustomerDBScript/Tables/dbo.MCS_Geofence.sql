CREATE TABLE [dbo].[MCS_Geofence]
(
[Name] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Address] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[City] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[State] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PostalCode1] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PostalCode2] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Latitude] [decimal] (9, 6) NULL,
[Longitude] [decimal] (9, 6) NULL,
[RadiusInKm] [decimal] (4, 2) NULL,
[DistanceUnit] [nvarchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Polygon] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[MinLatitude] [decimal] (9, 6) NULL,
[MaxLatitude] [decimal] (9, 6) NULL,
[MinLongitude] [decimal] (9, 6) NULL,
[MaxLongitude] [decimal] (9, 6) NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_Mobile_GPS_Geofence_IsActive] DEFAULT ((1)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Mobile_GPS_Geofence_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_Mobile_GPS_Geofence_DateModified] DEFAULT (getutcdate()),
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__Mobile_GPS_G__ID__3B219CFC] DEFAULT (newsequentialid()),
[System_List_CountryID] [uniqueidentifier] NULL,
[System_OrganizationID] [uniqueidentifier] NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[CommonList_GeofenceTypeID] [uniqueidentifier] NOT NULL,
[IsPublic] [bit] NOT NULL CONSTRAINT [DF__MCS_Geofe__IsPub__450A2E92] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Geofence] ADD CONSTRAINT [PK_MCS_Geofence] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Geofence] ADD CONSTRAINT [UQ_MCS_Geofence_Name] UNIQUE NONCLUSTERED  ([Name]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Geofence] ADD CONSTRAINT [FK_MCS_Geofence__CommonList_GeofenceTypeID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_GeofenceTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[MCS_Geofence] ADD CONSTRAINT [FK_MCS_Geofence__System_List_CountryID_X_System_List_Countries__ID] FOREIGN KEY ([System_List_CountryID]) REFERENCES [dbo].[System_List_Country] ([ID])
GO
ALTER TABLE [dbo].[MCS_Geofence] ADD CONSTRAINT [FK_MCS_Geofence__System_OrganizationID_X_System_Organizations__ID] FOREIGN KEY ([System_OrganizationID]) REFERENCES [dbo].[System_Organization] ([ID]) ON DELETE SET NULL
GO
