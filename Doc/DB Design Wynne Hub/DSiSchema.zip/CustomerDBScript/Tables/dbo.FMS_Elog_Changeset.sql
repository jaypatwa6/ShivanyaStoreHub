CREATE TABLE [dbo].[FMS_Elog_Changeset]
(
[ID] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL,
[DateModified] [datetime] NOT NULL,
[CommonList_ElogChangesetStatusID] [uniqueidentifier] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[HR_EmployeeID] [uniqueidentifier] NULL,
[DateEffected] [datetime] NOT NULL,
[DateAccepted] [datetime] NULL,
[Annotation] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_Changeset] ADD CONSTRAINT [PK_FMS_Elog_Changeset] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Elog_Changeset__HR_EmployeeID] ON [dbo].[FMS_Elog_Changeset] ([HR_EmployeeID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_Changeset] ADD CONSTRAINT [FK_FMS_Elog_ChangeRequest_System_CommonList_Item] FOREIGN KEY ([CommonList_ElogChangesetStatusID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_Elog_Changeset] ADD CONSTRAINT [FK_FMS_Elog_Changeset_HR_Employee] FOREIGN KEY ([HR_EmployeeID]) REFERENCES [dbo].[HR_Employee] ([ID])
GO
