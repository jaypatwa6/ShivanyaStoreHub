CREATE TABLE [dbo].[MCS_Trip_Stop_Task_Event]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__SDMS_TaskEve__ID__54E16EFF] DEFAULT (newsequentialid()),
[CommonList_TaskStatusID] [uniqueidentifier] NOT NULL,
[MCS_Trip_Stop_TaskID] [uniqueidentifier] NOT NULL,
[MCS_Device_CommEventID] [uniqueidentifier] NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_StopActivityEvent_DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_SDMS_TaskEvent_DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[Note] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CustomData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ActiveTasks] [int] NULL,
[MCS_Device_EventSummaryID] [uniqueidentifier] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Trip_Stop_Task_Event] ADD CONSTRAINT [PK_MCS_Trip_Stop_Task_Event] PRIMARY KEY NONCLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Trip_Stop_Task_Event__DateModified] ON [dbo].[MCS_Trip_Stop_Task_Event] ([DateModified]) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [IX__MCS_Trip_Stop_Task_Event__MCS_Trip_Stop_TaskID] ON [dbo].[MCS_Trip_Stop_Task_Event] ([MCS_Trip_Stop_TaskID], [ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Trip_Stop_Task_Event] ADD CONSTRAINT [FK__MCS_Trip___MCS_D__33FF9E21] FOREIGN KEY ([MCS_Device_EventSummaryID]) REFERENCES [dbo].[MCS_Device_EventSummary] ([ID])
GO
ALTER TABLE [dbo].[MCS_Trip_Stop_Task_Event] ADD CONSTRAINT [FK__MCS_Trip___MCS_D__5A254709] FOREIGN KEY ([MCS_Device_EventSummaryID]) REFERENCES [dbo].[MCS_Device_EventSummary] ([ID])
GO
ALTER TABLE [dbo].[MCS_Trip_Stop_Task_Event] ADD CONSTRAINT [FK__MCS_Trip___MCS_D__5B196B42] FOREIGN KEY ([MCS_Device_EventSummaryID]) REFERENCES [dbo].[MCS_Device_EventSummary] ([ID])
GO
ALTER TABLE [dbo].[MCS_Trip_Stop_Task_Event] ADD CONSTRAINT [FK_MCS_Trip_Stop_Task_Event__CommonList_TaskStatusID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_TaskStatusID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[MCS_Trip_Stop_Task_Event] ADD CONSTRAINT [FK_MCS_Trip_Stop_Task_Event__MCS_Dispatch_Trip_Stop_TaskID_X_MCS_Trip_Stop_Task__ID] FOREIGN KEY ([MCS_Trip_Stop_TaskID]) REFERENCES [dbo].[MCS_Trip_Stop_Task] ([ID]) ON DELETE CASCADE
GO
