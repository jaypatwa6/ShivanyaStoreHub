CREATE TABLE [dbo].[INV_Classification_Setting]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__INV_Classification_Setting__ID] DEFAULT (newsequentialid()),
[CommonList_INVClassification_TypeID] [uniqueidentifier] NOT NULL,
[CommonList_INVClassification_MetricID] [uniqueidentifier] NOT NULL,
[LabellingRule] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__INV_Classification_Setting__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__INV_Classification_Setting__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__INV_Classification_Setting__IsDelete] DEFAULT ((0)),
[IsActive] [bit] NOT NULL CONSTRAINT [DF__INV_Classification_Setting__IsActive] DEFAULT ((1))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[INV_Classification_Setting] ADD CONSTRAINT [PK__INV_Classification_Setting] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[INV_Classification_Setting] ADD CONSTRAINT [FK__INV_Classification_Setting__CommonList_INVClassification_MetricID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_INVClassification_MetricID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[INV_Classification_Setting] ADD CONSTRAINT [FK__INV_Classification_Setting__CommonList_INVClassification_TypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_INVClassification_TypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
