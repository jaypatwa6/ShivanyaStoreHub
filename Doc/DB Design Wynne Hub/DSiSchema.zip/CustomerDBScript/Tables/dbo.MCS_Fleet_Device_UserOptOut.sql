CREATE TABLE [dbo].[MCS_Fleet_Device_UserOptOut]
(
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Mobile_GPS_Fleet_USerOptOut_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_Mobile_GPS_Fleet_USerOptOut_DateModified] DEFAULT (getutcdate()),
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__MCS_Fleet_De__ID__15DA3E5D] DEFAULT (newsequentialid()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[Account_LoginID] [uniqueidentifier] NULL,
[MCS_FleetID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Fleet_Device_UserOptOut] ADD CONSTRAINT [PK_MCS_Fleet_Device_UserOptOut] PRIMARY KEY NONCLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Fleet_Device_UserOptOut__Account_LoginID] ON [dbo].[MCS_Fleet_Device_UserOptOut] ([Account_LoginID]) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [IX__MCS_Fleet_Device_UserOptOut__MCS_FleetID] ON [dbo].[MCS_Fleet_Device_UserOptOut] ([MCS_FleetID], [ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Fleet_Device_UserOptOut] ADD CONSTRAINT [FK_MCS_Fleet_Device_UserOptOut__MCS_FleetID_X_MCS_Fleet_ID] FOREIGN KEY ([MCS_FleetID]) REFERENCES [dbo].[MCS_Fleet] ([ID])
GO
