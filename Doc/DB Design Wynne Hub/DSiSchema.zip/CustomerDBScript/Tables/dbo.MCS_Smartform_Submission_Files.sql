CREATE TABLE [dbo].[MCS_Smartform_Submission_Files]
(
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Mobile_Smartforms_SubmissionFiles_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_Mobile_Smartforms_SubmissionFiles_DateModified] DEFAULT (getutcdate()),
[FileURL] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[FileName] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[FileType] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__Mobile_Smart__ID__7DE38492] DEFAULT (newsequentialid()),
[MCS_Smartform_SubmissionID] [uniqueidentifier] NOT NULL,
[MCS_Smartform_Submission_ResponseID] [uniqueidentifier] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_MCS_Smartform_Submission_Files_IsActive] DEFAULT ((1)),
[PhysicalDocId] [bigint] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Smartform_Submission_Files] ADD CONSTRAINT [PK_MCS_Smartform_Submission_Files] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Smartform_Submission_Files__MCS_Smartform_Submission_ResponseID] ON [dbo].[MCS_Smartform_Submission_Files] ([MCS_Smartform_Submission_ResponseID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Smartform_Submission_Files__MCS_Smartform_SubmissionID] ON [dbo].[MCS_Smartform_Submission_Files] ([MCS_Smartform_SubmissionID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Smartform_Submission_Files] ADD CONSTRAINT [FK_MCS_Smartform_Submission_Files_MCS_Smartform_Submission_ResponseID_X_MCS_Smartform_Submission_Response_ID] FOREIGN KEY ([MCS_Smartform_Submission_ResponseID]) REFERENCES [dbo].[MCS_Smartform_Submission_Response] ([ID])
GO
ALTER TABLE [dbo].[MCS_Smartform_Submission_Files] ADD CONSTRAINT [FK_MCS_Smartform_Submission_Files_MCS_Smartform_SubmissionID_X_MCS_Smartform_Submission_ID] FOREIGN KEY ([MCS_Smartform_SubmissionID]) REFERENCES [dbo].[MCS_Smartform_Submission] ([ID])
GO
