CREATE TABLE [dbo].[MCS_Device_DataUsage]
(
[ID] [uniqueidentifier] NOT NULL ROWGUIDCOL CONSTRAINT [DF__MCS_Device_D__ID__38B0DB53] DEFAULT (newid()),
[DeviceID] [uniqueidentifier] NOT NULL,
[Date] [int] NOT NULL,
[DataUsage] [int] NOT NULL,
[DateCreated] [datetime] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Device_DataUsage] ADD CONSTRAINT [PK_MCS_Device_DataUsage] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Device_DataUsage] ADD CONSTRAINT [Unique_Constraint] UNIQUE NONCLUSTERED  ([DeviceID], [Date]) WITH (IGNORE_DUP_KEY=ON) ON [PRIMARY]
GO
