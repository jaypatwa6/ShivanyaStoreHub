CREATE TABLE [dbo].[OPS_IntegrationSetting]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__OPS_IntegrationSetting__ID] DEFAULT (newsequentialid()),
[Keyword] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ExtendedData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[System_OrganizationID] [uniqueidentifier] NULL,
[Integration_CommonList_ApplicationID] [uniqueidentifier] NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF__OPS_IntegrationSetting_IsActive] DEFAULT ((1)),
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__OPS_IntegrationSetting_IsDelete] DEFAULT ((0)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__OPS_IntegrationSetting_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__OPS_IntegrationSetting_DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_IntegrationSetting] ADD CONSTRAINT [PK__OPS_IntegrationSetting] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_IntegrationSetting] ADD CONSTRAINT [FK__OPS_IntegrationSetting__Integration_CommonList_ApplicationID__x__System_CommonList_Item__ID] FOREIGN KEY ([Integration_CommonList_ApplicationID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_IntegrationSetting] ADD CONSTRAINT [FK__OPS_IntegrationSetting__System_OrganizationID__x__System_Organization__ID] FOREIGN KEY ([System_OrganizationID]) REFERENCES [dbo].[System_Organization] ([ID])
GO
