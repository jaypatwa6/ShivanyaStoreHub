CREATE TABLE [dbo].[SFE_BussinessProcess]
(
[ActionList] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_SFE_BussinessProcess_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_SFE_BussinessProcess_DateModified] DEFAULT (getutcdate()),
[BusinessProcessName] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CodeName] [nvarchar] (150) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__SFE_Bussines__ID__6F7F8B4B] DEFAULT (newsequentialid()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[SFE_BussinessProcess] ADD CONSTRAINT [PK_SFE_BussinessProcess] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
