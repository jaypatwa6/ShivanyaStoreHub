CREATE TABLE [dbo].[SFE_Custom_TableRelationship]
(
[RelationName] [nvarchar] (150) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[OneTableName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[OneTableColumn] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ManyTableName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ManyTableColumn] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[LookupFieldName] [nvarchar] (2000) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DisplayMode] [nvarchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[IsRequired] [bit] NOT NULL CONSTRAINT [DF_SFE_Custom_TableRelationship_IsRequired] DEFAULT ((0)),
[IsNotAllowDeleteLookupData] [bit] NOT NULL,
[LookupFieldFilterCriteria] [nvarchar] (150) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_SFE_Custom_TableRelationship_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_SFE_Custom_TableRelationship_DateModified] DEFAULT (getutcdate()),
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__SFE_Custom_T__ID__7DCDAAA2] DEFAULT (newsequentialid()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[OneTableID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[SFE_Custom_TableRelationship] ADD CONSTRAINT [PK_SFE_Custom_TableRelationship] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[SFE_Custom_TableRelationship] ADD CONSTRAINT [FK_SFE_Custom_TableRelationship__OneTableID_x_SFE_Custom_Table__ID] FOREIGN KEY ([OneTableID]) REFERENCES [dbo].[SFE_Custom_Table] ([ID])
GO
