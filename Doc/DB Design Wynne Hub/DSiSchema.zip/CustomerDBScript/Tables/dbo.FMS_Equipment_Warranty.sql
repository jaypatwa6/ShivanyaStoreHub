CREATE TABLE [dbo].[FMS_Equipment_Warranty]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__FMS_Equipment_Warranty__ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__FMS_Equipment_Warranty__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__FMS_Equipment_Warranty__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__FMS_Equipment_Warranty__IsDelete] DEFAULT ((0)),
[StartTime] [datetime] NOT NULL,
[EndTime] [datetime] NOT NULL,
[Name] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CommonList_FMSEquipment_Warranty_TypeID] [uniqueidentifier] NOT NULL,
[FMS_EquipmentID] [uniqueidentifier] NOT NULL,
[Note] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Equipment_Warranty] ADD CONSTRAINT [PK_FMS_Equipment_Warranty] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Equipment_Warranty] ADD CONSTRAINT [FK__FMS_Equipment_Warranty__CommonList_FMSEquipment_Warranty_TypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_FMSEquipment_Warranty_TypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_Equipment_Warranty] ADD CONSTRAINT [FK__FMS_Equipment_Warranty__FMS_EquipmentID__x__FMS_Equipment__ID] FOREIGN KEY ([FMS_EquipmentID]) REFERENCES [dbo].[FMS_Equipment] ([ID])
GO
