CREATE TABLE [dbo].[OPS_WorkOrder_Task]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__Sales_OrderT__ID__791ECF75] DEFAULT (newsequentialid()),
[OPS_WorkOrderID] [uniqueidentifier] NOT NULL,
[CommonList_OrderTypeID] [uniqueidentifier] NULL,
[CommonList_OrderPriorityID] [uniqueidentifier] NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Sales_OrderTask_DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_Sales_OrderTask_DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[Note] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_Sales_OrderTask_IsActive] DEFAULT ((1)),
[IsDelete] [bit] NOT NULL CONSTRAINT [DF_Sales_OrderTask_IsDelete] DEFAULT ((0)),
[SegmentNo] [nvarchar] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[JobInfo] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[EventData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[System_OrganizationID] [uniqueidentifier] NULL,
[JobInfoFull] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CommonList_OPSWorkOrder_Task_BillTypeID] [uniqueidentifier] NULL,
[CommonList_OPSWorkOrder_Task_RepairTypeID] [uniqueidentifier] NULL,
[CommonList_OPSWorkOrder_Task_StatusID] [uniqueidentifier] NULL,
[EstimatedStartTime] [datetime] NULL,
[EstimatedEndTime] [datetime] NULL,
[EstimatedInMin] [decimal] (18, 2) NULL,
[CommonList_OPSWorkOrder_Task_DepartmentTypeID] [uniqueidentifier] NULL,
[CommonList_OPSWorkOrder_Task_JobCodeTypeID] [uniqueidentifier] NULL,
[CommonList_OPSWorkOrder_Task_WorkCategoryTypeID] [uniqueidentifier] NULL,
[LaborRatePerHour] [decimal] (18, 2) NULL,
[LaborMultiplier] [decimal] (18, 2) NULL,
[LaborEstimatedCost] [decimal] (18, 2) NULL,
[PartsEstimatedCost] [decimal] (18, 2) NULL,
[OtherEstimatedCost] [decimal] (18, 2) NULL,
[MaterialEstimatedCost] [decimal] (18, 2) NULL,
[CommonList_OPSWorkOrder_Task_StageID] [uniqueidentifier] NULL,
[CommonList_OPSWorkOrder_Task_PartStageID] [uniqueidentifier] NULL,
[PartEstimatedTime] [datetime] NULL,
[TaskNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CommonList_OPS_Integration_Task_StageID] [uniqueidentifier] NULL,
[Integration_CommonList_ApplicationID] [uniqueidentifier] NULL,
[Integration_ReferenceID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ExtendedData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[OPS_JobCode_DetailID] [uniqueidentifier] NULL,
[CommonList_WorkOrder_Task_QuoteStatusID] [uniqueidentifier] NULL,
[OPS_WorkOrder_Task_QuoteID] [uniqueidentifier] NULL,
[IntegrationDateModified] [datetime] NULL,
[ReservationNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CommonList_ReservationTypeID] [uniqueidentifier] NULL,
[WLSOrderNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task] ADD CONSTRAINT [PK_OPS_WorkOrder_Task] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__OPS_WorkOrder_Task__StageID_X_IsDelete_DateCreated_DateModified_OPS_WorkOrderID] ON [dbo].[OPS_WorkOrder_Task] ([CommonList_OPSWorkOrder_Task_StageID], [IsDelete], [DateCreated], [DateModified], [OPS_WorkOrderID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task] ADD CONSTRAINT [FK__OPS_WorkOrder_Task__CommonList_OPS_Integration_Task_StageID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPS_Integration_Task_StageID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task] ADD CONSTRAINT [FK__OPS_WorkOrder_Task__CommonList_OPSWorkOrder_Task_BillTypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPSWorkOrder_Task_BillTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task] ADD CONSTRAINT [FK__OPS_WorkOrder_Task__CommonList_OPSWorkOrder_Task_DepartmentTypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPSWorkOrder_Task_DepartmentTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task] ADD CONSTRAINT [FK__OPS_WorkOrder_Task__CommonList_OPSWorkOrder_Task_JobCodeTypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPSWorkOrder_Task_JobCodeTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task] ADD CONSTRAINT [FK__OPS_WorkOrder_Task__CommonList_OPSWorkOrder_Task_PartStageID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPSWorkOrder_Task_PartStageID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task] ADD CONSTRAINT [FK__OPS_WorkOrder_Task__CommonList_OPSWorkOrder_Task_RepairTypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPSWorkOrder_Task_RepairTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task] ADD CONSTRAINT [FK__OPS_WorkOrder_Task__CommonList_OPSWorkOrder_Task_StageID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPSWorkOrder_Task_StageID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task] ADD CONSTRAINT [FK__OPS_WorkOrder_Task__CommonList_OPSWorkOrder_Task_StatusID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPSWorkOrder_Task_StatusID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task] ADD CONSTRAINT [FK__OPS_WorkOrder_Task__CommonList_OPSWorkOrder_Task_WorkCategoryTypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPSWorkOrder_Task_WorkCategoryTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task] ADD CONSTRAINT [FK__OPS_WorkOrder_Task__CommonList_ReservationTypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_ReservationTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task] ADD CONSTRAINT [FK__OPS_WorkOrder_Task__CommonList_WorkOrder_Task_QuoteStatusID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_WorkOrder_Task_QuoteStatusID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task] ADD CONSTRAINT [FK__OPS_WorkOrder_Task__Integration_CommonList_ApplicationID__x__System_CommonList_Item__ID] FOREIGN KEY ([Integration_CommonList_ApplicationID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task] ADD CONSTRAINT [FK__OPS_WorkOrder_Task__OPS_JobCode_DetailID__x__OPS_JobCode_Detail__ID] FOREIGN KEY ([OPS_JobCode_DetailID]) REFERENCES [dbo].[OPS_JobCode_Detail] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task] ADD CONSTRAINT [FK__OPS_WorkOrder_Task__OPS_WorkOrder_Task_QuoteID__x__OPS_WorkOrder_Task__ID] FOREIGN KEY ([OPS_WorkOrder_Task_QuoteID]) REFERENCES [dbo].[OPS_WorkOrder_Task] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task] WITH NOCHECK ADD CONSTRAINT [FK_OPS_WorkOrder_Task__Commonlist_WorkOrderPriorityID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OrderPriorityID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task] WITH NOCHECK ADD CONSTRAINT [FK_OPS_WorkOrder_Task__Commonlist_WorkOrderTaskTypeID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OrderTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task] ADD CONSTRAINT [FK_OPS_WorkOrder_Task__OPS_WorkOrderID_X_OPS_WorkOrder__ID] FOREIGN KEY ([OPS_WorkOrderID]) REFERENCES [dbo].[OPS_WorkOrder] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task] ADD CONSTRAINT [FK_OPS_WorkOrder_Task__System_OrganizationID_X_System_Organizations_ID] FOREIGN KEY ([System_OrganizationID]) REFERENCES [dbo].[System_Organization] ([ID])
GO
