CREATE TABLE [dbo].[System_CustomPayload_Property]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_System_CustomPayload_Property_ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_System_CustomPayload_Property_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_System_CustomPayload_Property_DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[ReferenceName] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[TableName] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DisplayName] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_System_CustomPayload_Property_IsActive] DEFAULT ((1)),
[System_ModuleID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_CustomPayload_Property] ADD CONSTRAINT [PK_System_CustomPayload_Property] PRIMARY KEY CLUSTERED ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_CustomPayload_Property] ADD CONSTRAINT [FK_System_CustomPayload_Property___System_ModuleID_x_System_Module__ID] FOREIGN KEY ([System_ModuleID]) REFERENCES [dbo].[System_Module] ([ID])
GO
