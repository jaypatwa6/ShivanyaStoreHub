CREATE TABLE [dbo].[FMS_Equipment_MeterReadingLatestValue]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_FMS_Equipment_MeterReadingLatestValue_ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_FMS_Equipment_MeterReadingLatestValue_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_FMS_Equipment_MeterReadingLatestValue_DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[FMS_EquipmentID] [uniqueidentifier] NOT NULL,
[MeterReadingDate] [datetime] NOT NULL,
[ReadingValue] [decimal] (12, 2) NOT NULL,
[EstimatedWeeklyUsage] [decimal] (12, 2) NULL,
[CommonList_MeterReadingTypeID] [uniqueidentifier] NOT NULL,
[Notes] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Sequence] [int] NOT NULL CONSTRAINT [DF__FMS_Equipment_MeterReadingLatestValue__Sequence] DEFAULT ((1)),
[ExtendedData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__FMS_Equipment_MeterReadingLatestValue__IsDelete] DEFAULT ((0)),
[OPS_WorkOrder_TaskID] [uniqueidentifier] NULL,
[IsNewMeter] [bit] NULL,
[IsUpdateMeter] [bit] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Equipment_MeterReadingLatestValue] ADD CONSTRAINT [PK_FMS_Equipment_MeterReadingLatestValue] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Equipment_MeterReadingLatestValue__FMS_EquipmentID] ON [dbo].[FMS_Equipment_MeterReadingLatestValue] ([FMS_EquipmentID]) INCLUDE ([ReadingValue], [CommonList_MeterReadingTypeID], [Sequence]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Equipment_MeterReadingLatestValue] ADD CONSTRAINT [FK__FMS_Equipment_MeterReadingLatestValue__OPS_WorkOrder_TaskID__x__OPS_WorkOrder_Task__ID] FOREIGN KEY ([OPS_WorkOrder_TaskID]) REFERENCES [dbo].[OPS_WorkOrder_Task] ([ID])
GO
ALTER TABLE [dbo].[FMS_Equipment_MeterReadingLatestValue] ADD CONSTRAINT [FK_FMS_Equipment_MeterReadingLatestValue___FMS_EquipmentID_x_FMS_Equipment__ID] FOREIGN KEY ([FMS_EquipmentID]) REFERENCES [dbo].[FMS_Equipment] ([ID])
GO
ALTER TABLE [dbo].[FMS_Equipment_MeterReadingLatestValue] ADD CONSTRAINT [FK_FMS_Equipment_MeterReadingLatestValue__CommonList_MeterReadingTypeID_x_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_MeterReadingTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
