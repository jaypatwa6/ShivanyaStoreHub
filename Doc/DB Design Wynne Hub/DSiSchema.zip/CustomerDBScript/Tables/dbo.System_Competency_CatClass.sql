CREATE TABLE [dbo].[System_Competency_CatClass]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__System_Competency_CatClass__ID] DEFAULT (newsequentialid()),
[System_CompetencyID] [uniqueidentifier] NOT NULL,
[CategoryCode] [nvarchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ClassificationCode] [nvarchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_System_Competency_CatClass_IsActive] DEFAULT ((1)),
[IsDelete] [bit] NULL CONSTRAINT [DF_System_Competency_CatClass_IsDelete] DEFAULT ((0)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_System_Competency_CatClass_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_System_Competency_CatClass_DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Competency_CatClass] ADD CONSTRAINT [PK__System_Competency_CatClass] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Competency_CatClass] WITH NOCHECK ADD CONSTRAINT [FK__System_Competency_CatClass__System_CompetencyID__X__System_Competency__ID] FOREIGN KEY ([System_CompetencyID]) REFERENCES [dbo].[System_Competency] ([ID])
GO
