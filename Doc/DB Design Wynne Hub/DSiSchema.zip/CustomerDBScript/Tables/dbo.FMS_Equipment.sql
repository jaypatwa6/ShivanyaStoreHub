CREATE TABLE [dbo].[FMS_Equipment]
(
[Number] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Name] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[VIN] [nvarchar] (75) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[VIN_2] [nvarchar] (75) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_FMS_Equipment_IsActive] DEFAULT ((1)),
[IsDelete] [bit] NOT NULL CONSTRAINT [DF_FMS_Equipment_IsDelete] DEFAULT ((0)),
[IsCMV] [bit] NOT NULL CONSTRAINT [DF_FMS_Equipment_IsCMV] DEFAULT ((1)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_FMS_Equipment_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_FMS_Equipment_DateModified] DEFAULT (getutcdate()),
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__FMS_Equipmen__ID__487B981A] DEFAULT (newsequentialid()),
[System_OrganizationID] [uniqueidentifier] NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[CommonList_EquipmentTypeID] [uniqueidentifier] NOT NULL,
[CommonList_EquipmentMakeID] [uniqueidentifier] NOT NULL,
[CommonList_EquipmentModelID] [uniqueidentifier] NOT NULL,
[CRM_CustomerID] [uniqueidentifier] NULL,
[CommonList_EquipmentCategoryID] [uniqueidentifier] NOT NULL,
[FMS_MotorCarrierID] [uniqueidentifier] NULL,
[EquipmentLicense] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CommonList_EquipmentFuelTypeID] [uniqueidentifier] NOT NULL,
[StockNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[SerialNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[MachineSerialNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[AlternativeMachineSerialNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[JDLinkMachineID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ExtendedData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CommonList_EquipmentClassificationID] [uniqueidentifier] NULL,
[CommonList_EquipmentStatusID] [uniqueidentifier] NULL,
[DateReservation] [datetime] NULL,
[DateDelivered] [datetime] NULL,
[DateManufactured] [datetime] NULL,
[ShipWeightInPound] [decimal] (18, 2) NULL,
[ShipLengthInInch] [decimal] (18, 2) NULL,
[ShipWidthInInch] [decimal] (18, 2) NULL,
[ShipHeightInInch] [decimal] (18, 2) NULL,
[IsPilot] [bit] NULL,
[IsPermit] [bit] NULL,
[IsStackable] [bit] NULL,
[ReservationNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[System_Organization_CurrentStoreLocationID] [uniqueidentifier] NULL,
[Integration_CommonList_ApplicationID] [uniqueidentifier] NULL,
[Tags] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CommonList_ReservationTypeID] [uniqueidentifier] NULL,
[DateMaintenancePlanSynced] [datetime] NULL,
[MapExtendedData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Equipment] ADD CONSTRAINT [PK_FMS_Equipment] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Equipment__CommonList_EquipmentMakeID] ON [dbo].[FMS_Equipment] ([CommonList_EquipmentMakeID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Equipment__CommonList_EquipmentModelID] ON [dbo].[FMS_Equipment] ([CommonList_EquipmentModelID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Equipment__CommonList_EquipmentType/ID] ON [dbo].[FMS_Equipment] ([CommonList_EquipmentTypeID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Equipment__IsActive] ON [dbo].[FMS_Equipment] ([IsActive]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Equipment_IsActive_IsCMV_IsDelete_CommonList_EquipmentId] ON [dbo].[FMS_Equipment] ([IsActive], [IsCMV], [IsDelete], [CommonList_EquipmentTypeID]) INCLUDE ([ID], [Number]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Equipment__IsDelete] ON [dbo].[FMS_Equipment] ([IsDelete]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Equipment__Number] ON [dbo].[FMS_Equipment] ([Number]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Equipment__System_OrganizationID] ON [dbo].[FMS_Equipment] ([System_OrganizationID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Equipment__VIN_X_IsDelete] ON [dbo].[FMS_Equipment] ([VIN], [IsDelete]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Equipment] ADD CONSTRAINT [FK__FMS_Equipment__CommonList_EquipmentClassificationID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_EquipmentClassificationID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_Equipment] ADD CONSTRAINT [FK__FMS_Equipment__CommonList_EquipmentStatusID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_EquipmentStatusID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_Equipment] ADD CONSTRAINT [FK__FMS_Equipment__CommonList_ReservationTypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_ReservationTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_Equipment] ADD CONSTRAINT [FK__FMS_Equipment__System_Organization_CurrentStoreLocationID__x__System_Organization__ID] FOREIGN KEY ([System_Organization_CurrentStoreLocationID]) REFERENCES [dbo].[System_Organization] ([ID])
GO
ALTER TABLE [dbo].[FMS_Equipment] WITH NOCHECK ADD CONSTRAINT [FK_FMS_Equipment__CommonList_EquipmentCategoryID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_EquipmentCategoryID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_Equipment] WITH NOCHECK ADD CONSTRAINT [FK_FMS_Equipment__CommonList_EquipmentMakeID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_EquipmentMakeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_Equipment] WITH NOCHECK ADD CONSTRAINT [FK_FMS_Equipment__CommonList_EquipmentModelID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_EquipmentModelID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_Equipment] WITH NOCHECK ADD CONSTRAINT [FK_FMS_Equipment__CommonList_EquipmentTypeID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_EquipmentTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_Equipment] WITH NOCHECK ADD CONSTRAINT [FK_FMS_Equipment__CommonList_EquipmentTypeID_X_System_CommonList_Item_ID] FOREIGN KEY ([CommonList_EquipmentTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_Equipment] ADD CONSTRAINT [FK_FMS_Equipment__CRM_CustomerID_X_FMS_Equipment_ID] FOREIGN KEY ([CRM_CustomerID]) REFERENCES [dbo].[CRM_Customer] ([ID])
GO
ALTER TABLE [dbo].[FMS_Equipment] ADD CONSTRAINT [FK_FMS_Equipment__FMS_MotorCarrierID_X_FMS_MotorCarrier__ID] FOREIGN KEY ([FMS_MotorCarrierID]) REFERENCES [dbo].[FMS_MotorCarrier] ([ID])
GO
ALTER TABLE [dbo].[FMS_Equipment] ADD CONSTRAINT [FK_FMS_Equipment__System_OrganizationID_X_System_Organizations__ID] FOREIGN KEY ([System_OrganizationID]) REFERENCES [dbo].[System_Organization] ([ID]) ON DELETE SET NULL
GO
