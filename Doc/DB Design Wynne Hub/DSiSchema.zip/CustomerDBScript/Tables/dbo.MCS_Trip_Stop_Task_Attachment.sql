CREATE TABLE [dbo].[MCS_Trip_Stop_Task_Attachment]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__SDMS_TaskAtt__ID__5B8E6C8E] DEFAULT (newsequentialid()),
[MCS_Trip_Stop_TaskID] [uniqueidentifier] NOT NULL,
[System_List_AttachmentTypeID] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[FileName] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_StopActivityAttachment_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_SDMS_TaskAttachment_DateModified] DEFAULT (getutcdate()),
[Note] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DateSynchronized] [datetime] NOT NULL CONSTRAINT [DF__SDMS_Task__DateS__6EC0713C] DEFAULT (getdate()),
[IsDeleted] [bit] NOT NULL CONSTRAINT [DF__SDMS_Task__IsDel__6FB49575] DEFAULT ((0)),
[PhysicalDocId] [int] NULL,
[ReceivedBy] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ExtendedData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Trip_Stop_Task_Attachment] ADD CONSTRAINT [PK_MCS_Trip_Stop_Task_Attachment] PRIMARY KEY NONCLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Trip_Stop_Task_Attachment__DateCreated] ON [dbo].[MCS_Trip_Stop_Task_Attachment] ([DateCreated]) INCLUDE ([MCS_Trip_Stop_TaskID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_MCS_Trip_Stop_Task_Attachment_PhysicalDocId_CreatedBy] ON [dbo].[MCS_Trip_Stop_Task_Attachment] ([DateCreated]) INCLUDE ([MCS_Trip_Stop_TaskID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Trip_Stop_Task_Attachment__DateModified] ON [dbo].[MCS_Trip_Stop_Task_Attachment] ([DateModified]) INCLUDE ([CreatedBy], [DateCreated], [DateSynchronized], [ExtendedData], [FileName], [ID], [IsDeleted], [MCS_Trip_Stop_TaskID], [ModifiedBy], [Note], [PhysicalDocId], [ReceivedBy], [System_List_AttachmentTypeID]) WITH (FILLFACTOR=100) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Trip_Stop_Task_Attachment__FileName] ON [dbo].[MCS_Trip_Stop_Task_Attachment] ([FileName]) INCLUDE ([IsDeleted]) WITH (FILLFACTOR=100) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Trip_Stop_Task_Attachment__IsDelete] ON [dbo].[MCS_Trip_Stop_Task_Attachment] ([IsDeleted]) WITH (FILLFACTOR=100) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [IX__MCS_Trip_Stop_Task_Attachment__MCS_Trip_Stop_TaskID] ON [dbo].[MCS_Trip_Stop_Task_Attachment] ([MCS_Trip_Stop_TaskID], [ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Trip_Stop_Task_Attachment] ADD CONSTRAINT [FK_MCS_Trip_Stop_Task_Attachment__MCS_Dispatch_Trip_Stop_TaskID_X_MCS_Trip_Stop_Task__ID] FOREIGN KEY ([MCS_Trip_Stop_TaskID]) REFERENCES [dbo].[MCS_Trip_Stop_Task] ([ID]) ON DELETE CASCADE
GO
ALTER TABLE [dbo].[MCS_Trip_Stop_Task_Attachment] ADD CONSTRAINT [FK_MCS_Trip_Stop_Task_Attachment__System_List_AttachmentTypeID_X_System_CommonList_Item__ID] FOREIGN KEY ([System_List_AttachmentTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
