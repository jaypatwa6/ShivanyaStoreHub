CREATE TABLE [dbo].[ATS_CatClassAlternative]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__ATS_CatClassAlternative__ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__ATS_CatClassAlternative__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__ATS_CatClassAlternative__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF__ATS_CatClassAlternative__IsActive] DEFAULT ((1)),
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__ATS_CatClassAlternative__IsDelete] DEFAULT ((0)),
[CategoryCode] [nvarchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ClassificationCode] [nvarchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[WeekRate] [decimal] (18, 2) NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[ATS_CatClassAlternative] ADD CONSTRAINT [PK_ATS_CatClassAlternative] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
