CREATE TABLE [dbo].[FMS_DeviceEquipmentPairing]
(
[EquipmentID] [uniqueidentifier] NOT NULL,
[MCS_DeviceID] [uniqueidentifier] NOT NULL,
[IsActive] [bit] NOT NULL,
[DateCreated] [datetime] NOT NULL,
[DateModified] [datetime] NULL,
[CreatedBy] [uniqueidentifier] NULL,
[ModifiedBy] [uniqueidentifier] NULL,
[IsDeleted] [bit] NOT NULL CONSTRAINT [DF__FMS_Devic__IsDel__06ADD4BD] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_DeviceEquipmentPairing] ADD CONSTRAINT [FK_FMS_DeviceEquipmentPairing_FMS_Equipment] FOREIGN KEY ([EquipmentID]) REFERENCES [dbo].[FMS_Equipment] ([ID])
GO
ALTER TABLE [dbo].[FMS_DeviceEquipmentPairing] ADD CONSTRAINT [FK_FMS_DeviceEquipmentPairing_MCS_Device] FOREIGN KEY ([MCS_DeviceID]) REFERENCES [dbo].[MCS_Device] ([ID])
GO
