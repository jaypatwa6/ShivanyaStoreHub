CREATE TABLE [dbo].[CRM_Customer_Contact_Phone]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__CRM_Customer__ID__3939548A] DEFAULT (newsequentialid()),
[PhoneNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Extension] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_CRM_Customer_Contact_Phone_IsActive] DEFAULT ((1)),
[IsPrimary] [bit] NULL CONSTRAINT [DF_CRM_Customer_Contact_Phone_IsPrimary] DEFAULT ((0)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_CRM_Customer_Contact_Phone_DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_CRM_Customer_Contact_Phone_DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[CRM_Customer_ContactID] [uniqueidentifier] NOT NULL,
[CommonList_PhoneTypeID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[CRM_Customer_Contact_Phone] ADD CONSTRAINT [PK_CRM_Customer_Contact_Phone] PRIMARY KEY NONCLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [IX__CRM_Customer_Contact_Phone__CRM_Customer_ContactID] ON [dbo].[CRM_Customer_Contact_Phone] ([CRM_Customer_ContactID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__CRM_Customer_Contact_Phone__IsActive] ON [dbo].[CRM_Customer_Contact_Phone] ([IsActive]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[CRM_Customer_Contact_Phone] WITH NOCHECK ADD CONSTRAINT [FK_CRM_Customer_Contact_Phone__CommonList_PhoneTypeID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_PhoneTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[CRM_Customer_Contact_Phone] ADD CONSTRAINT [FK_CRM_Customer_Contact_Phone__CustomerContactID_X_CRM_Customer_Contact__ID] FOREIGN KEY ([CRM_Customer_ContactID]) REFERENCES [dbo].[CRM_Customer_Contact] ([ID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
