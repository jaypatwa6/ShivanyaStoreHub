CREATE TABLE [dbo].[FMS_MaintenancePlan]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_FMS_MaintenancePlan_ID] DEFAULT (newsequentialid()),
[IsActive] [bit] NOT NULL CONSTRAINT [DF_FMS_MaintenancePlan_IsActive] DEFAULT ((1)),
[FMS_EquipmentID] [uniqueidentifier] NOT NULL,
[FMS_MaintenancePlanTemplateID] [uniqueidentifier] NOT NULL,
[CommonList_ServiceTypeID] [uniqueidentifier] NOT NULL,
[LastEventUnits] [decimal] (9, 2) NOT NULL CONSTRAINT [DF_FMS_MaintenancePlan_LastEventUnits] DEFAULT ((0)),
[LastEventDate] [datetime] NOT NULL,
[NextEventEstimatedDate] [datetime] NULL,
[Notes] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ServiceIntervalUnits] [decimal] (9, 2) NULL,
[CommonList_ServiceIntervalUOMTypeID] [uniqueidentifier] NOT NULL,
[SecondaryServiceIntervalUnits] [decimal] (9, 2) NULL,
[CommonList_SecondaryServiceIntervalUOMTypeID] [uniqueidentifier] NOT NULL,
[CommonList_NextEventForecastMethodID] [uniqueidentifier] NOT NULL,
[IsRoundServiceforecast] [bit] NULL CONSTRAINT [DF_FMS_MaintenancePlan_IsRoundServiceforecast] DEFAULT ((0)),
[RoundServiceForecastScale] [int] NULL,
[ServiceFormID] [uniqueidentifier] NULL,
[ServiceWarningThresholdUnits] [decimal] (9, 2) NULL,
[IsResetLastEventUnitsWithActualUnits] [bit] NOT NULL CONSTRAINT [DF_FMS_MaintenancePlan_IsResetLastEventUnitsWithActualUnits] DEFAULT ((0)),
[TimeThreshold] [decimal] (9, 2) NULL,
[CommonList_TimeThresholdID] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__FMS_MaintenancePlan__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__FMS_MaintenancePlan__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL CONSTRAINT [DF__FMS_MaintenancePlan__CreatedBy] DEFAULT ('00000000-0000-0000-0000-000000000000'),
[ModifiedBy] [uniqueidentifier] NOT NULL CONSTRAINT [DF__FMS_MaintenancePlan__ModifiedBy] DEFAULT ('00000000-0000-0000-0000-000000000000'),
[Parent_FMS_MaintenancePlanID] [uniqueidentifier] NULL,
[CommonList_MaintenanceHistoryDueStatusID] [uniqueidentifier] NULL,
[ExtendedData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsLatestPlan] [bit] NOT NULL CONSTRAINT [DF__FMS_MaintenancePlan_IsLatestPlan] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_MaintenancePlan] ADD CONSTRAINT [PK_FMS_MaintenancePlan] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_MaintenancePlan__FMS_EquipmentID_FMS_MaintenancePlanTemplateID_ID] ON [dbo].[FMS_MaintenancePlan] ([FMS_EquipmentID], [FMS_MaintenancePlanTemplateID], [ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_MaintenancePlan] ADD CONSTRAINT [FK__FMS_MaintenancePlan__CommonList_MaintenanceHistoryDueStatusID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_MaintenanceHistoryDueStatusID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_MaintenancePlan] ADD CONSTRAINT [FK__FMS_MaintenancePlan__Parent_FMS_MaintenancePlanID__x__FMS_MaintenancePlan__ID] FOREIGN KEY ([Parent_FMS_MaintenancePlanID]) REFERENCES [dbo].[FMS_MaintenancePlan] ([ID])
GO
ALTER TABLE [dbo].[FMS_MaintenancePlan] ADD CONSTRAINT [FK_FMS_MaintenancePlan__CommonList_NextEventForecastMethodID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_NextEventForecastMethodID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_MaintenancePlan] ADD CONSTRAINT [FK_FMS_MaintenancePlan__CommonList_SecondaryServiceIntervalUOMTypeID_X_FMS_MaintenancePlan__ID] FOREIGN KEY ([CommonList_SecondaryServiceIntervalUOMTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_MaintenancePlan] ADD CONSTRAINT [FK_FMS_MaintenancePlan__CommonList_ServiceIntervalUOMTypeID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_ServiceIntervalUOMTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_MaintenancePlan] ADD CONSTRAINT [FK_FMS_MaintenancePlan__CommonList_ServiceTypeID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_ServiceTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[FMS_MaintenancePlan] ADD CONSTRAINT [FK_FMS_MaintenancePlan__FMS_Equipment_MaintenancePlanTemplateID_X_FMS_MaintenancePlanTemplate__ID] FOREIGN KEY ([FMS_MaintenancePlanTemplateID]) REFERENCES [dbo].[FMS_MaintenancePlanTemplate] ([ID])
GO
ALTER TABLE [dbo].[FMS_MaintenancePlan] ADD CONSTRAINT [FK_FMS_MaintenancePlan__FMS_EquipmentID_X_FMS_Equipment__ID] FOREIGN KEY ([FMS_EquipmentID]) REFERENCES [dbo].[FMS_Equipment] ([ID])
GO
