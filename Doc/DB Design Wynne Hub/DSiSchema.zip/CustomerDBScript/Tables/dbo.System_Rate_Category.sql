CREATE TABLE [dbo].[System_Rate_Category]
(
[Id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_System_Rate_Category_Id] DEFAULT (newsequentialid()),
[System_RateID] [uniqueidentifier] NOT NULL,
[CommonList_CategoryID] [uniqueidentifier] NOT NULL,
[IsActive] [bit] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Rate_Category] ADD CONSTRAINT [PK_System_Rate_Category] PRIMARY KEY CLUSTERED  ([Id]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Rate_Category] ADD CONSTRAINT [FK_System_Rate_CategoryID_System_CommonList_Item_ID] FOREIGN KEY ([CommonList_CategoryID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[System_Rate_Category] ADD CONSTRAINT [FK_System_Rate_CategoryId_System_RateId] FOREIGN KEY ([System_RateID]) REFERENCES [dbo].[System_Rate] ([Id])
GO
