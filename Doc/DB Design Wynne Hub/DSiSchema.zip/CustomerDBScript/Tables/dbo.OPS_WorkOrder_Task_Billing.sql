CREATE TABLE [dbo].[OPS_WorkOrder_Task_Billing]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__OPS_WorkOrder_Task_Billing__ID] DEFAULT (newsequentialid()),
[OPS_WorkOrder_TaskID] [uniqueidentifier] NOT NULL,
[QuoteLabor] [decimal] (18, 2) NULL,
[CommonList_System_CurrencyID] [uniqueidentifier] NULL,
[PONumber] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[System_Organization_BillFromID] [uniqueidentifier] NULL,
[System_Organization_BillToID] [uniqueidentifier] NULL,
[Taxes] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ServiceCall] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CRM_CustomerID] [uniqueidentifier] NULL,
[CustomerJobNumber] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CustomerJobName] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CRM_Customer_DriverLicenseID] [uniqueidentifier] NULL,
[HR_Employee_SalesRepID] [uniqueidentifier] NULL,
[RepairTicket] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CommonList_OPS_Labor_CodeID] [uniqueidentifier] NULL,
[System_Organization_DepartmentID] [uniqueidentifier] NULL,
[CommonList_OPS_Expense_CodeID] [uniqueidentifier] NULL,
[Phone] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[AuthorizedBy] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CommonList_OPS_ClaimTypeID] [uniqueidentifier] NULL,
[ClaimNumber] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ClaimDate] [datetime] NULL,
[ClaimExpectedAmount] [decimal] (18, 2) NULL,
[ClaimPaid] [bit] NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__OPS_WorkOrder_Task_Billing__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__OPS_WorkOrder_Task_Billing__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__OPS_WorkOrder_Task_Billing__IsDelete] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_Billing] ADD CONSTRAINT [PK_OPS_WorkOrder_Task_Billing] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__OPS_WorkOrder_Task_Billing__TaskID_X_IsDelete] ON [dbo].[OPS_WorkOrder_Task_Billing] ([OPS_WorkOrder_TaskID], [IsDelete]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_Billing] ADD CONSTRAINT [FK__OPS_WorkOrder_Task_Billing__CommonList_OPS_ClaimTypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPS_ClaimTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_Billing] ADD CONSTRAINT [FK__OPS_WorkOrder_Task_Billing__CommonList_OPS_Expense_CodeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPS_Expense_CodeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_Billing] ADD CONSTRAINT [FK__OPS_WorkOrder_Task_Billing__CommonList_OPS_Labor_CodeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPS_Labor_CodeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_Billing] ADD CONSTRAINT [FK__OPS_WorkOrder_Task_Billing__CommonList_System_CurrencyID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_System_CurrencyID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_Billing] ADD CONSTRAINT [FK__OPS_WorkOrder_Task_Billing__CRM_Customer_DriverLicenseID__x__CRM_Customer__ID] FOREIGN KEY ([CRM_Customer_DriverLicenseID]) REFERENCES [dbo].[CRM_Customer] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_Billing] ADD CONSTRAINT [FK__OPS_WorkOrder_Task_Billing__CRM_CustomerID__x__CRM_Customer__ID] FOREIGN KEY ([CRM_CustomerID]) REFERENCES [dbo].[CRM_Customer] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_Billing] ADD CONSTRAINT [FK__OPS_WorkOrder_Task_Billing__HR_Employee_SalesRepID__x__HR_Employee__ID] FOREIGN KEY ([HR_Employee_SalesRepID]) REFERENCES [dbo].[HR_Employee] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_Billing] ADD CONSTRAINT [FK__OPS_WorkOrder_Task_Billing__OPS_WorkOrder_TaskID__x__OPS_WorkOrder_Task__ID] FOREIGN KEY ([OPS_WorkOrder_TaskID]) REFERENCES [dbo].[OPS_WorkOrder_Task] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_Billing] ADD CONSTRAINT [FK__OPS_WorkOrder_Task_Billing__System_Organization_BillFromID__x__System_Organization__ID] FOREIGN KEY ([System_Organization_BillFromID]) REFERENCES [dbo].[System_Organization] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_Billing] ADD CONSTRAINT [FK__OPS_WorkOrder_Task_Billing__System_Organization_BillToID__x__System_Organization__ID] FOREIGN KEY ([System_Organization_BillToID]) REFERENCES [dbo].[System_Organization] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_Billing] ADD CONSTRAINT [FK__OPS_WorkOrder_Task_Billing__System_Organization_DepartmentID__x__System_Organization__ID] FOREIGN KEY ([System_Organization_DepartmentID]) REFERENCES [dbo].[System_Organization] ([ID])
GO
