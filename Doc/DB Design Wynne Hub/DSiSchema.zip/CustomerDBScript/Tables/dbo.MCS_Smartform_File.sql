CREATE TABLE [dbo].[MCS_Smartform_File]
(
[Id] [uniqueidentifier] NOT NULL,
[MCS_SmartformId] [uniqueidentifier] NOT NULL,
[PhysicalDocId] [bigint] NOT NULL,
[FileName] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[FileURL] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[FileType] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF__MCS_Smart__IsActive] DEFAULT ((1)),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Smartform_File] ADD CONSTRAINT [PK_MCS_Smartform_File] PRIMARY KEY CLUSTERED  ([Id]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Smartform_File__DateCreated] ON [dbo].[MCS_Smartform_File] ([DateCreated]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Smartform_File__IsActive] ON [dbo].[MCS_Smartform_File] ([IsActive]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Smartform_File__MCS_SmartformID] ON [dbo].[MCS_Smartform_File] ([MCS_SmartformId]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Smartform_File] ADD CONSTRAINT [FK_MCS_Smartform_File__MCS_SmartformId_x_MCS_Smartform__Id] FOREIGN KEY ([MCS_SmartformId]) REFERENCES [dbo].[MCS_Smartform] ([ID])
GO
