CREATE TABLE [dbo].[MCS_Trip_Stop_Task_Contact]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__SDMS_TaskCon__ID__58B1FFE3] DEFAULT (newsequentialid()),
[MCS_Trip_Stop_TaskID] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[Name] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PhoneNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_StopActivityContact_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_SDMS_TaskContact_DateModified] DEFAULT (getutcdate()),
[Description] [nvarchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DateSynchronized] [datetime] NOT NULL CONSTRAINT [DF__SDMS_Task__DateS__719CDDE7] DEFAULT (getdate()),
[PhoneExtension] [nvarchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsDeleted] [bit] NOT NULL CONSTRAINT [DF__SDMS_Task__IsDel__72910220] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Trip_Stop_Task_Contact] ADD CONSTRAINT [PK_MCS_Trip_Stop_Task_Contact] PRIMARY KEY NONCLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Trip_Stop_Task_Contact__IsDelete] ON [dbo].[MCS_Trip_Stop_Task_Contact] ([IsDeleted]) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [IX__MCS_Trip_Stop_Task_Contact__MCS_Trip_Stop_TaskID] ON [dbo].[MCS_Trip_Stop_Task_Contact] ([MCS_Trip_Stop_TaskID], [ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Trip_Stop_Task_Contact] ADD CONSTRAINT [FK_MCS_Trip_Stop_Task_Contact__MCS_Dispatch_Trip_Stop_TaskID_X_MCS_Trip_Stop_Task__ID] FOREIGN KEY ([MCS_Trip_Stop_TaskID]) REFERENCES [dbo].[MCS_Trip_Stop_Task] ([ID]) ON DELETE CASCADE
GO
