CREATE TABLE [dbo].[System_Module_SystemNumber]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_System_Module_SystemNumber_ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_System_Module_SystemNumber_DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_System_Module_SystemNumber_DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_System_Module_SystemNumber_IsActive] DEFAULT ((1)),
[Name] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[TableName] [nvarchar] (150) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ColumnName] [nvarchar] (150) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[LastValue] [int] NOT NULL CONSTRAINT [DF_System_Module_SystemNumber_LastValue] DEFAULT ((1000)),
[IncrementBy] [int] NOT NULL CONSTRAINT [DF_System_Module_SystemNumber_IncrementBy] DEFAULT ((1)),
[Prefix] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Suffix] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Note] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Module_SystemNumber] ADD CONSTRAINT [PK_System_Module_SystemNumber] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
