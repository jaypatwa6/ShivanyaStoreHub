CREATE TABLE [dbo].[FMS_DVIR_Setting]
(
[Id] [uniqueidentifier] NOT NULL,
[HR_EmployeeId] [uniqueidentifier] NOT NULL,
[PreTrip] [bit] NOT NULL,
[PostTrip] [bit] NOT NULL,
[PreTripNotification] [bit] NOT NULL,
[PostTripNotification] [bit] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_DVIR_Setting] ADD CONSTRAINT [PK_FMS_DVIR_Setting] PRIMARY KEY CLUSTERED  ([Id]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_DVIR_Setting] ADD CONSTRAINT [FK_FMS_DVIR_Setting_HR_Employee] FOREIGN KEY ([HR_EmployeeId]) REFERENCES [dbo].[HR_Employee] ([ID]) ON DELETE CASCADE
GO
