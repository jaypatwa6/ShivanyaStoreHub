CREATE TABLE [dbo].[System_Database_Migration_History]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__System_Database_Migration_History__ID] DEFAULT (newsequentialid()),
[SprintName] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[TFSID] [bigint] NULL,
[TfsChangesetId] [bigint] NULL,
[Script] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ScriptLastModifiedBy] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ScriptLastModifiedDate] [datetime] NULL,
[ScriptLastExecutedBy] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ScriptLastExecutedDate] [datetime] NULL CONSTRAINT [DF__System_Database_Migration_History__ScriptLastExecutedDate] DEFAULT (getutcdate()),
[Status] [bit] NOT NULL,
[Logs] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Database_Migration_History] ADD CONSTRAINT [PK__System_Database_Migration_History__ID] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
