CREATE TABLE [dbo].[OPS_JobCode_Detail]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__OPS_JobCode_Detail__ID] DEFAULT (newsequentialid()),
[OPS_JobCodeID] [uniqueidentifier] NOT NULL,
[CommonList_EquipmentCategoryID] [uniqueidentifier] NOT NULL,
[CommonList_FMS_Equipment_ClassificationID] [uniqueidentifier] NOT NULL,
[CommonList_EquipmentMakeID] [uniqueidentifier] NULL,
[CommonList_EquipmentModelID] [uniqueidentifier] NULL,
[EstimatedInMin] [decimal] (18, 2) NOT NULL,
[Notes] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__OPS_JobCode_Detail_IsDelete] DEFAULT ((0)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__OPS_JobCode_Detail_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__OPS_JobCode_Detail_DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_JobCode_Detail] ADD CONSTRAINT [PK__OPS_JobCode_Detail] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_JobCode_Detail] ADD CONSTRAINT [FK__OPS_JobCode__CommonList_EquipmentCategoryID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_EquipmentCategoryID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_JobCode_Detail] ADD CONSTRAINT [FK__OPS_JobCode__CommonList_EquipmentMakeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_EquipmentMakeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_JobCode_Detail] ADD CONSTRAINT [FK__OPS_JobCode__CommonList_EquipmentModelID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_EquipmentModelID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_JobCode_Detail] ADD CONSTRAINT [FK__OPS_JobCode__CommonList_FMS_Equipment_ClassificationID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_FMS_Equipment_ClassificationID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_JobCode_Detail] ADD CONSTRAINT [FK__OPS_JobCode_Detail__OPS_JobCodeID__x__OPS_JobCode__ID] FOREIGN KEY ([OPS_JobCodeID]) REFERENCES [dbo].[OPS_JobCode] ([ID])
GO
