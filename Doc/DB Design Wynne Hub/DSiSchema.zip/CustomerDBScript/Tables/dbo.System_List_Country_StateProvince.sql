CREATE TABLE [dbo].[System_List_Country_StateProvince]
(
[Name] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Code] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__System_List___ID__1A69E950] DEFAULT (newsequentialid()),
[System_List_CountryID] [uniqueidentifier] NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF__System_List_Country_StateProvince__IsActive] DEFAULT ((1))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_List_Country_StateProvince] ADD CONSTRAINT [PK_System_List_Countries_StateProvinces] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__System_List_Country_StateProvince__System_List_CountryID] ON [dbo].[System_List_Country_StateProvince] ([System_List_CountryID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_List_Country_StateProvince] ADD CONSTRAINT [FK_System_List_Countries_StateProvinces__System_List_CountryID_X_System_List_Countries__ID] FOREIGN KEY ([System_List_CountryID]) REFERENCES [dbo].[System_List_Country] ([ID])
GO
