CREATE TABLE [dbo].[FMS_Elog_DailyReport_CountdownTimer]
(
[Id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_FMS_Elog_DailyReport_CountdownTimer_Id] DEFAULT (newsequentialid()),
[HR_EmployeeId] [uniqueidentifier] NOT NULL,
[FMS_Elog_HOSRuleId] [uniqueidentifier] NULL,
[RemainingResetWorkShiftLimit] [int] NULL,
[RemainingResetCycle] [int] NULL,
[RemainingOnDutyWorkShiftLimit] [int] NULL,
[RemainingOnDutyDayLimit] [int] NULL,
[RemainingElapsedTimeWorkShiftLimit] [int] NULL,
[RemainingDrivingWorkShiftLimit] [int] NULL,
[RemainingDrivingDayLimit] [int] NULL,
[RemainingCycle] [int] NULL,
[IsWeek2Cycle2] [bit] NULL,
[IsSplitSB] [bit] NULL,
[IsFerry] [bit] NULL,
[IsExisted8HoursConsecutiveOffDuty] [bit] NULL,
[IsExisted2HoursOffDuty] [bit] NULL,
[IsDeferralDay2] [bit] NULL,
[IsDeferralDay1] [bit] NULL,
[IsCycling] [bit] NULL,
[IsCycle2] [bit] NULL,
[IsAdverseDriving] [bit] NULL,
[GPSTimeStamp] [datetime] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_FMS_Elog_DailyReport_CountdownTimer_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[Is14thDayCycle] [bit] NULL CONSTRAINT [DF__FMS_Elog___Is14t__1CC7330E] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_DailyReport_CountdownTimer] ADD CONSTRAINT [PK_FMS_Elog_DailyReport_CountdownTimer] PRIMARY KEY CLUSTERED  ([Id]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_DailyReport_CountdownTimer] ADD CONSTRAINT [FK_FMS_Elog_DailyReport_CountdownTimer_FMS_Elog_HOSRule] FOREIGN KEY ([FMS_Elog_HOSRuleId]) REFERENCES [dbo].[FMS_Elog_HOSRule] ([ID]) ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FMS_Elog_DailyReport_CountdownTimer] ADD CONSTRAINT [FK_FMS_Elog_DailyReport_CountdownTimer_HR_Employee] FOREIGN KEY ([HR_EmployeeId]) REFERENCES [dbo].[HR_Employee] ([ID])
GO
