CREATE TABLE [dbo].[HR_Employee]
(
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_HR_Employee_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_HR_Employee_DateModified] DEFAULT (getutcdate()),
[Number] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[FirstName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[LastName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_HR_Employee_IsActive] DEFAULT ((1)),
[DateHired] [datetime] NULL,
[DriverLicenseNumber] [nvarchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DriverLicenseExpiration] [datetime] NULL,
[DateOfBirth] [datetime] NULL,
[DateTermination] [datetime] NULL,
[Email] [nvarchar] (150) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Note] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__HR_Employee__ID__44AB0736] DEFAULT (newsequentialid()),
[CommonList_EmployeeTypeID] [uniqueidentifier] NOT NULL,
[System_OrganizationID] [uniqueidentifier] NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[MotorCarrierID] [uniqueidentifier] NULL,
[Account_LoginID] [uniqueidentifier] NULL,
[FMS_Elog_HOSRuleID] [uniqueidentifier] NULL,
[DriverStartLocation] [int] NULL,
[System_List_StateProvince_DriverLicenseIssuedStateID] [uniqueidentifier] NULL,
[IsSystemEmployee] [bit] NOT NULL CONSTRAINT [DF_HR_Employee_IsSystemEmployee] DEFAULT ((0)),
[IsExemptRestBreak] [bit] NOT NULL CONSTRAINT [DF_HR_Employee_IsExemptRestBreak] DEFAULT ((0)),
[IsExemptHOSRule] [bit] NOT NULL CONSTRAINT [DF_HR_Employee_IsExemptHOSRule] DEFAULT ((0)),
[GetDriverFeedback] [bit] NOT NULL CONSTRAINT [DF__HR_Employ__GetDr__3F5DD8E2] DEFAULT ((0)),
[ExtendedData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[StartingTime] [smallint] NULL,
[IntegrationProfileName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IntegrationProfileActive] [bit] NULL,
[Integration_CommonList_ApplicationID] [uniqueidentifier] NULL,
[CommonList_OPS_Integration_Inactive_ActionID] [uniqueidentifier] NULL,
[HomeOffice_CRM_JobsiteID] [uniqueidentifier] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[HR_Employee] ADD CONSTRAINT [PK_HR_Employee] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE UNIQUE NONCLUSTERED INDEX [UQ__HR_Employee__Account_LoginID] ON [dbo].[HR_Employee] ([Account_LoginID]) WHERE ([Account_LoginID] IS NOT NULL) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__HR_Employee__CommonList_EmployeeTypeID] ON [dbo].[HR_Employee] ([CommonList_EmployeeTypeID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__HR_Employee__IsActive] ON [dbo].[HR_Employee] ([IsActive]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__HR_Employee__EmployeeNumber] ON [dbo].[HR_Employee] ([Number]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[HR_Employee] ADD CONSTRAINT [UQ_HR_Employee__Number] UNIQUE NONCLUSTERED ([Number]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__HR_Employee__System_OrganizationID] ON [dbo].[HR_Employee] ([System_OrganizationID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[HR_Employee] ADD CONSTRAINT [FK__HR_Employee__CommonList_OPS_Integration_Inactive_ActionID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPS_Integration_Inactive_ActionID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[HR_Employee] ADD CONSTRAINT [FK__HR_Employee__Integration_CommonList_ApplicationID__x__System_CommonList_Item__ID] FOREIGN KEY ([Integration_CommonList_ApplicationID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[HR_Employee] WITH NOCHECK ADD CONSTRAINT [FK_HR_Employee__CommonList_EmployeeTypeID_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_EmployeeTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[HR_Employee] ADD CONSTRAINT [FK_HR_Employee__HomeOffice_CRM_JobsiteID_X_CRM_Jobsite__ID] FOREIGN KEY ([HomeOffice_CRM_JobsiteID]) REFERENCES [dbo].[CRM_Jobsite] ([ID])
GO
ALTER TABLE [dbo].[HR_Employee] ADD CONSTRAINT [FK_HR_Employee__MotorCarrierID_X_FMS_MotorCarrier__ID] FOREIGN KEY ([MotorCarrierID]) REFERENCES [dbo].[FMS_MotorCarrier] ([ID])
GO
ALTER TABLE [dbo].[HR_Employee] WITH NOCHECK ADD CONSTRAINT [FK_HR_Employee__System_List_StateProvince_DriverLicenseIssuedStateID_X_System_List_Country_StateProvince__ID] FOREIGN KEY ([System_List_StateProvince_DriverLicenseIssuedStateID]) REFERENCES [dbo].[System_List_Country_StateProvince] ([ID])
GO
ALTER TABLE [dbo].[HR_Employee] ADD CONSTRAINT [FK_HR_Employee__System_OrganizationID_X_System_Organizations__ID] FOREIGN KEY ([System_OrganizationID]) REFERENCES [dbo].[System_Organization] ([ID]) ON DELETE SET NULL
GO
EXEC sp_addextendedproperty N'MS_Description', N'Exempt Driver Configuration.', 'SCHEMA', N'dbo', 'TABLE', N'HR_Employee', 'COLUMN', N'IsExemptHOSRule'
GO
