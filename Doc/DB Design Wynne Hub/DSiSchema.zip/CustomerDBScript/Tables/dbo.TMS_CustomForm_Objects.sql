CREATE TABLE [dbo].[TMS_CustomForm_Objects]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__TMS_CustomForm_Objects__ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__TMS_CustomForm_Objects__DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__TMS_CustomForm_Objects__DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[TMS_CustomFormID] [uniqueidentifier] NOT NULL,
[ObjectReferenceName] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ObjectType] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ObjectValue] [nvarchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ObjectFilePath] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_CustomForm_Objects] ADD CONSTRAINT [PK__TMS_CustomForm_Objects] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_CustomForm_Objects__DateCreated] ON [dbo].[TMS_CustomForm_Objects] ([DateCreated]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_CustomForm_Objects__ObjectReferenceName] ON [dbo].[TMS_CustomForm_Objects] ([ObjectReferenceName]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_CustomForm_Objects__TMS_CustomFormID] ON [dbo].[TMS_CustomForm_Objects] ([TMS_CustomFormID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_CustomForm_Objects] ADD CONSTRAINT [FK__TMS_CustomForm_Objects__MCS_SmartformID__x__TMS_CustomForm__ID] FOREIGN KEY ([TMS_CustomFormID]) REFERENCES [dbo].[TMS_CustomForm] ([ID])
GO
