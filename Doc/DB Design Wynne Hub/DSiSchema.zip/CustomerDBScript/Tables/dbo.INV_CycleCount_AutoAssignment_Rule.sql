CREATE TABLE [dbo].[INV_CycleCount_AutoAssignment_Rule]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__INV_CycleCount_AutoAssignment_Rule__ID] DEFAULT (newsequentialid()),
[Name] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Description] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[RuleSetting] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__INV_CycleCount_AutoAssignment_Rule__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__INV_CycleCount_AutoAssignment_Rule__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsDeleted] [bit] NOT NULL CONSTRAINT [DF_INV_CycleCount_AutoAssignment_Rule_IsDeleted] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[INV_CycleCount_AutoAssignment_Rule] ADD CONSTRAINT [PK__INV_CycleCount_AutoAssignment_Rule] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
