CREATE TABLE [dbo].[INV_CycleCount]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__INV_CycleCount__ID] DEFAULT (newsequentialid()),
[System_OrganizationID] [uniqueidentifier] NOT NULL,
[CommonList_INV_CycleCountTypeID] [uniqueidentifier] NOT NULL,
[CommonList_INV_CycleCountStatusID] [uniqueidentifier] NOT NULL,
[Number] [int] NOT NULL,
[Days] [int] NOT NULL,
[StartDate] [datetime] NOT NULL,
[EndDate] [datetime] NULL,
[IntegrationSystemDate] [datetime] NOT NULL,
[IntegrationModifiedDate] [datetime] NULL,
[ActiveDay] [int] NOT NULL,
[ClosedDay] [int] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__INV_CycleCount__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__INV_CycleCount__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsDeleted] [bit] NOT NULL CONSTRAINT [DF_INV_CycleCount_IsDeleted] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[INV_CycleCount] ADD CONSTRAINT [PK__INV_CycleCount] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[INV_CycleCount] ADD CONSTRAINT [FK__INV_CycleCount__CommonList_INV_CycleCountStatusID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_INV_CycleCountStatusID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[INV_CycleCount] ADD CONSTRAINT [FK__INV_CycleCount__CommonList_INV_CycleCountTypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_INV_CycleCountTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[INV_CycleCount] ADD CONSTRAINT [FK__INV_CycleCount__System_OrganizationID__x__System_Organization__ID] FOREIGN KEY ([System_OrganizationID]) REFERENCES [dbo].[System_Organization] ([ID])
GO
