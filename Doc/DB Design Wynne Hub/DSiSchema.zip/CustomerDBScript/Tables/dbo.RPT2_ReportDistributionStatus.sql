CREATE TABLE [dbo].[RPT2_ReportDistributionStatus]
(
[ID] [uniqueidentifier] NOT NULL,
[AccountId] [bigint] NOT NULL,
[LastStatus] [bit] NOT NULL,
[DateDistribute] [datetime] NULL,
[ReportId] [uniqueidentifier] NOT NULL ROWGUIDCOL CONSTRAINT [DF_RPT2_ReportDistributionStatus_ReportId] DEFAULT (newid())
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[RPT2_ReportDistributionStatus] ADD CONSTRAINT [PK_RPT2_ReportDistributionStatus] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
