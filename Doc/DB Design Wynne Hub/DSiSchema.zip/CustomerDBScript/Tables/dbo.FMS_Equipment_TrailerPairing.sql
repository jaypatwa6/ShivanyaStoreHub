CREATE TABLE [dbo].[FMS_Equipment_TrailerPairing]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__FMS_Equipment_TrailerPairing__ID] DEFAULT (newsequentialid()),
[FMS_EquipmentID] [uniqueidentifier] NOT NULL,
[FMS_Equipment_TrailerID] [uniqueidentifier] NOT NULL,
[IsPrimary] [bit] NOT NULL CONSTRAINT [DF_FMS_Equipment_TrailerPairing_IsPrimary] DEFAULT ((1)),
[IsDelete] [bit] NULL CONSTRAINT [DF_FMS_Equipment_TrailerPairing_IsDelete] DEFAULT ((0)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_FMS_Equipment_TrailerPairing_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_FMS_Equipment_TrailerPairing_DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Equipment_TrailerPairing] ADD CONSTRAINT [PK__FMS_Equipment_TrailerPairing] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Equipment_TrailerPairing] WITH NOCHECK ADD CONSTRAINT [FK__FMS_Equipment_TrailerPairing__FMS_Equipment_TrailerID__X__FMS_Equipment__ID] FOREIGN KEY ([FMS_Equipment_TrailerID]) REFERENCES [dbo].[FMS_Equipment] ([ID])
GO
ALTER TABLE [dbo].[FMS_Equipment_TrailerPairing] WITH NOCHECK ADD CONSTRAINT [FK__FMS_Equipment_TrailerPairing__FMS_EquipmentID__X__FMS_Equipment__ID] FOREIGN KEY ([FMS_EquipmentID]) REFERENCES [dbo].[FMS_Equipment] ([ID])
GO
