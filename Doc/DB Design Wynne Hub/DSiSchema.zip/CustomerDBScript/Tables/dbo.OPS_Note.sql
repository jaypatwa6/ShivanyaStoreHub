CREATE TABLE [dbo].[OPS_Note]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__OPS_Note__ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__OPS_Note__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__OPS_Note__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__OPS_Note__IsDelete] DEFAULT ((0)),
[IsExternal] [bit] NOT NULL CONSTRAINT [DF__OPS_Note__IsExternal] DEFAULT ((0)),
[Note] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CommonList_OPSNote_TypeID] [uniqueidentifier] NOT NULL,
[ReferenceTable] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ReferenceForeignKeyID] [uniqueidentifier] NULL,
[ExtendedData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Integration_CommonList_ApplicationID] [uniqueidentifier] NULL,
[Integration_ReferenceID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_Note] ADD CONSTRAINT [PK__OPS_Note] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_Note] ADD CONSTRAINT [FK__OPS_Note__CommonList_OPSNote_TypeID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPSNote_TypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_Note] ADD CONSTRAINT [FK__OPS_Note__Integration_CommonList_ApplicationID__x__System_CommonList_Item__ID] FOREIGN KEY ([Integration_CommonList_ApplicationID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
