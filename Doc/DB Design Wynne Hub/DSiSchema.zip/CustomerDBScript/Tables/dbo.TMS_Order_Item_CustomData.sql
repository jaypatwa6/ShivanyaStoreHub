CREATE TABLE [dbo].[TMS_Order_Item_CustomData]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__TMS_Order_Item_CustomData__ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__TMS_Order_Item_CustomData__DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__TMS_Order_Item_CustomData__DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[TMS_Order_ItemID] [uniqueidentifier] NOT NULL,
[TMS_CustomFormID] [uniqueidentifier] NOT NULL,
[ChargeValue] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[StockNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Machine] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Make] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Model] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Meter] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PIN] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ShippedBy] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ReceivedBy] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[BillingType] [uniqueidentifier] NULL,
[AccountNumber] [uniqueidentifier] NULL,
[AuthorizationNo] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Integration_Application] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Integration_RowId] [nvarchar] (36) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Integration_WorkOrderNo] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Data_Source] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Type] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[FMS_EquipmentID] [uniqueidentifier] NULL,
[EstimatedInMin] [decimal] (18, 2) NULL,
[IsSerialized] [bit] NULL,
[SegmentNo] [int] NULL,
[CommonList_LoadCategoryID] [uniqueidentifier] NULL,
[Integration_DocNo] [nvarchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Integration_TripID] [nvarchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Integration_PickupNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_Order_Item_CustomData] ADD CONSTRAINT [PK__TMS_Order_Item_CustomData] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Item_CustomData__DateModified] ON [dbo].[TMS_Order_Item_CustomData] ([DateModified]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Item_CustomData__TMS_Order_ItemID] ON [dbo].[TMS_Order_Item_CustomData] ([TMS_Order_ItemID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Item_CustomData__Integration_WorkOrderNo] ON [dbo].[TMS_Order_Item_CustomData] ([TMS_Order_ItemID], [Integration_WorkOrderNo]) INCLUDE ([Machine], [PIN]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_Order_Item_CustomData] ADD CONSTRAINT [FK__TMS_Order_Item_CustomData__CommonList_LoadCategoryID__x__System_CommonList_Item__Id] FOREIGN KEY ([CommonList_LoadCategoryID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order_Item_CustomData] ADD CONSTRAINT [FK__TMS_Order_Item_CustomData__TMS_CustomFormID__x__TMS_CustomForm__ID] FOREIGN KEY ([TMS_CustomFormID]) REFERENCES [dbo].[TMS_CustomForm] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order_Item_CustomData] ADD CONSTRAINT [FK__TMS_Order_Item_CustomData__TMS_Order_ItemID__x__TMS_Order_Item__ID] FOREIGN KEY ([TMS_Order_ItemID]) REFERENCES [dbo].[TMS_Order_Item] ([ID])
GO
