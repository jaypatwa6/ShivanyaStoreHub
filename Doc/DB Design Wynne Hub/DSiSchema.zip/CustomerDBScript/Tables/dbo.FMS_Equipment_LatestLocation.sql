CREATE TABLE [dbo].[FMS_Equipment_LatestLocation]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_FMS_Equipment_LatestLocation_ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_FMS_Equipment_LatestLocation_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_FMS_Equipment_LatestLocation_DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[FMS_EquipmentID] [uniqueidentifier] NOT NULL,
[GpsTimeStamp] [datetime] NOT NULL,
[Latitude] [decimal] (9, 6) NULL,
[Longitude] [decimal] (9, 6) NULL,
[Heading] [decimal] (9, 6) NULL,
[Speed] [decimal] (9, 6) NULL,
[FormattedLocation] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IntegrationID] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Equipment_LatestLocation] ADD CONSTRAINT [PK_FMS_Equipment_LatestLocation] PRIMARY KEY CLUSTERED ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Equipment_LatestLocation] ADD CONSTRAINT [FK_FMS_Equipment_LatestLocation___FMS_EquipmentID_x_FMS_Equipment__ID] FOREIGN KEY ([FMS_EquipmentID]) REFERENCES [dbo].[FMS_Equipment] ([ID])
GO
