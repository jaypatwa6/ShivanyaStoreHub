CREATE TABLE [dbo].[FMS_Elog_SpecialDrivingStatus]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__FMS_Elog_SpecialDrivingStatus__ID] DEFAULT (newsequentialid()),
[HR_EmployeeID] [uniqueidentifier] NOT NULL,
[System_CommonList_SpecialDrivingStatusID] [uniqueidentifier] NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF__FMS_Elog_SpecialDrivingStatus__IsActive] DEFAULT ((1)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__FMS_Elog_SpecialDrivingStatus__DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__FMS_Elog_SpecialDrivingStatus__DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_SpecialDrivingStatus] ADD CONSTRAINT [PK__FMS_Elog_SpecialDrivingStatus__ID] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_SpecialDrivingStatus] ADD CONSTRAINT [FK__FMS_Elog_SpecialDrivingStatus__HR_EmployeeID_x_HR_Employee__ID] FOREIGN KEY ([HR_EmployeeID]) REFERENCES [dbo].[HR_Employee] ([ID])
GO
ALTER TABLE [dbo].[FMS_Elog_SpecialDrivingStatus] ADD CONSTRAINT [FK__FMS_Elog_SpecialDrivingStatus__System_CommonList_SpecialDrivingStatusID_x_System_CommonList_Item__ID] FOREIGN KEY ([System_CommonList_SpecialDrivingStatusID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
