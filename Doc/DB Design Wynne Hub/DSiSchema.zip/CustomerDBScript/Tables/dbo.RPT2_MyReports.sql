CREATE TABLE [dbo].[RPT2_MyReports]
(
[Id] [uniqueidentifier] NOT NULL CONSTRAINT [DF__RPT2_MyRepor__Id__7968E838] DEFAULT (newsequentialid()),
[RPT2_ReportID] [uniqueidentifier] NOT NULL,
[Account_LoginID] [uniqueidentifier] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__RPT2_MyRe__DateC__7A5D0C71] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__RPT2_MyRe__DateM__7B5130AA] DEFAULT (getutcdate()),
[GroupID] [bigint] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[RPT2_MyReports] ADD CONSTRAINT [FK_RPT2_MyReports_RPT2_Report] FOREIGN KEY ([RPT2_ReportID]) REFERENCES [dbo].[RPT2_Report] ([ID])
GO
