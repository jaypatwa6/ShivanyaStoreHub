CREATE TABLE [dbo].[TMS_Order_Event_Summary]
(
[Id] [uniqueidentifier] NOT NULL CONSTRAINT [DF__TMS_Order_Event_Summary__ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__TMS_Order_Event_Summary__DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__TMS_Order_Event_Summary__DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[TMS_OrderId] [uniqueidentifier] NULL,
[TMS_Order_ItemId] [uniqueidentifier] NULL,
[TMS_Order_Item_TaskId] [uniqueidentifier] NULL,
[CommonList_TMSOrder_StatusId] [uniqueidentifier] NULL,
[CommonList_TMSOrder_Item_StatusId] [uniqueidentifier] NULL,
[CommonList_TMSOrder_Item_Task_StatusId] [uniqueidentifier] NULL,
[CommonList_TMSOrder_Item_Task_TypeId] [uniqueidentifier] NULL,
[MCS_Device_EventSummaryID] [uniqueidentifier] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_Order_Event_Summary] ADD CONSTRAINT [PK__TMS_Order_Event_Summary] PRIMARY KEY CLUSTERED ([Id]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Event_Summary__TMSOrder_Item_StatusID_X_TMS_Order_ItemID_X_ID] ON [dbo].[TMS_Order_Event_Summary] ([CommonList_TMSOrder_Item_StatusId], [TMS_Order_ItemId], [Id]) INCLUDE ([DateCreated]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Event_Summary__DateModified] ON [dbo].[TMS_Order_Event_Summary] ([DateModified]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Event_Summary__TMS_Order_Item_TaskId__DateCreated] ON [dbo].[TMS_Order_Event_Summary] ([TMS_Order_Item_TaskId], [DateCreated] DESC) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Event_Summary_TMS_Order_Item_TaskId_TMS_Order_ItemId] ON [dbo].[TMS_Order_Event_Summary] ([TMS_Order_Item_TaskId], [TMS_Order_ItemId]) INCLUDE ([CommonList_TMSOrder_Item_Task_StatusId], [DateCreated], [DateModified], [Id]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Event_Summary_TMS_Order_ItemId_Id_TMS_Order_Item_TaskId] ON [dbo].[TMS_Order_Event_Summary] ([TMS_Order_ItemId], [Id], [TMS_Order_Item_TaskId]) INCLUDE ([CommonList_TMSOrder_Item_Task_StatusId], [DateCreated], [DateModified]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__TMS_Order_Event_Summary_TMS_Order_ItemId_TMS_Order_Item_TaskId_Id] ON [dbo].[TMS_Order_Event_Summary] ([TMS_Order_ItemId], [TMS_Order_Item_TaskId], [Id]) INCLUDE ([CommonList_TMSOrder_Item_Task_StatusId], [DateCreated], [DateModified]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMS_Order_Event_Summary] ADD CONSTRAINT [FK__TMS_Order_Event_Summary__CommonList_TMSOrder_Item_StatusId__x__System_CommonList_Item__Id] FOREIGN KEY ([CommonList_TMSOrder_Item_StatusId]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order_Event_Summary] ADD CONSTRAINT [FK__TMS_Order_Event_Summary__CommonList_TMSOrder_Item_Task_StatusId__x__System_CommonList_Item__Id] FOREIGN KEY ([CommonList_TMSOrder_Item_Task_StatusId]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order_Event_Summary] ADD CONSTRAINT [FK__TMS_Order_Event_Summary__CommonList_TMSOrder_Item_Task_TypeId__x__System_CommonList_Item__Id] FOREIGN KEY ([CommonList_TMSOrder_Item_Task_TypeId]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order_Event_Summary] ADD CONSTRAINT [FK_TMS_Order_Event_Summary__CommonList_TMSOrder_StatusId__x__System_CommonList_Item__Id] FOREIGN KEY ([CommonList_TMSOrder_StatusId]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order_Event_Summary] ADD CONSTRAINT [FK_TMS_Order_Event_Summary__MCS_Device_EventSummaryID__x__MCS_Device_EventSummary__Id] FOREIGN KEY ([MCS_Device_EventSummaryID]) REFERENCES [dbo].[MCS_Device_EventSummary] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order_Event_Summary] ADD CONSTRAINT [FK_TMS_Order_Event_Summary__TMS_Order_Item_TaskId__x__TMS_Order_Item_Task__Id] FOREIGN KEY ([TMS_Order_Item_TaskId]) REFERENCES [dbo].[TMS_Order_Item_Task] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order_Event_Summary] ADD CONSTRAINT [FK_TMS_Order_Event_Summary__TMS_Order_ItemId__x__TMS_Order_Item__Id] FOREIGN KEY ([TMS_Order_ItemId]) REFERENCES [dbo].[TMS_Order_Item] ([ID])
GO
ALTER TABLE [dbo].[TMS_Order_Event_Summary] ADD CONSTRAINT [FK_TMS_Order_Event_Summary__TMS_OrderId__x__TMS_Order__Id] FOREIGN KEY ([TMS_OrderId]) REFERENCES [dbo].[TMS_Order] ([ID])
GO
