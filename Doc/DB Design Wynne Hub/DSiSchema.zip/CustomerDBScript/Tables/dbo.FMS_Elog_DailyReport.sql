CREATE TABLE [dbo].[FMS_Elog_DailyReport]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__FMS_Elog_Dai__ID__7B1C2680] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__FMS_Elog___DateC__7C104AB9] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__FMS_Elog___DateM__7D046EF2] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[StartTime] [datetime] NOT NULL,
[StartTimeZoneOffset] [decimal] (3, 1) NOT NULL,
[EndTime] [datetime] NULL,
[EndTimeZoneOffset] [decimal] (3, 1) NULL,
[IsApproved] [bit] NOT NULL CONSTRAINT [DF__FMS_Elog___IsApp__7DF8932B] DEFAULT ((0)),
[DateApproved] [datetime] NULL,
[FMS_Elog_HOSRuleID] [uniqueidentifier] NOT NULL,
[HR_EmployeeID] [uniqueidentifier] NOT NULL,
[MotorCarrierState] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[MotorCarrierID] [uniqueidentifier] NULL,
[IsWeeklyReset] [bit] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_DailyReport] ADD CONSTRAINT [PK_FMS_Elog_DailyReport] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Elog_DailyReport__DateCreated] ON [dbo].[FMS_Elog_DailyReport] ([DateCreated]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__FMS_Elog_DailyReport__HR_EmployeeID] ON [dbo].[FMS_Elog_DailyReport] ([HR_EmployeeID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[FMS_Elog_DailyReport] ADD CONSTRAINT [FK_FMS_Elog_DailyReport_FMS_Elog_HOSRule] FOREIGN KEY ([FMS_Elog_HOSRuleID]) REFERENCES [dbo].[FMS_Elog_HOSRule] ([ID])
GO
ALTER TABLE [dbo].[FMS_Elog_DailyReport] ADD CONSTRAINT [FK_FMS_Elog_DailyReport_HR_Employee] FOREIGN KEY ([HR_EmployeeID]) REFERENCES [dbo].[HR_Employee] ([ID])
GO
