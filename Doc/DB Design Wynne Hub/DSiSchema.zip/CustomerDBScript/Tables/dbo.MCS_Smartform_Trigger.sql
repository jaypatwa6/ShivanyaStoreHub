CREATE TABLE [dbo].[MCS_Smartform_Trigger]
(
[IsActive] [bit] NOT NULL CONSTRAINT [DF_Mobile_Smartforms_Triggers_IsActive] DEFAULT ((1)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Mobile_Smartforms_Triggers_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_Mobile_Smartforms_Triggers_DateModified] DEFAULT (getutcdate()),
[Condition] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__Mobile_Smart__ID__614745E4] DEFAULT (newsequentialid()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[MCS_SmartformID] [uniqueidentifier] NOT NULL,
[CommonList_SmartformTriggerTypeID] [uniqueidentifier] NOT NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__MCS_Smart__IsDel__5A4F643B] DEFAULT ((0)),
[IsSubmissionRequired] [bit] NOT NULL CONSTRAINT [DF__MCS_Smart__IsSub__5B05F357] DEFAULT ((0)),
[PromptMessage] [nvarchar] (300) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Smartform_Trigger] ADD CONSTRAINT [PK_MCS_Smartform_Trigger] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Smartform_Trigger__IsActive] ON [dbo].[MCS_Smartform_Trigger] ([IsActive]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Smartform_Trigger__MCS_SmartformID] ON [dbo].[MCS_Smartform_Trigger] ([MCS_SmartformID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Smartform_Trigger] WITH NOCHECK ADD CONSTRAINT [FK_MCS_Smartform_Trigger_CommonList_SmartformTriggerTypeID_X_System_CommonList_Item_ID] FOREIGN KEY ([CommonList_SmartformTriggerTypeID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[MCS_Smartform_Trigger] WITH NOCHECK ADD CONSTRAINT [FK_MCS_Smartform_Trigger_MCS_SmartformID_X_MCS_Smartform_ID] FOREIGN KEY ([MCS_SmartformID]) REFERENCES [dbo].[MCS_Smartform] ([ID])
GO
