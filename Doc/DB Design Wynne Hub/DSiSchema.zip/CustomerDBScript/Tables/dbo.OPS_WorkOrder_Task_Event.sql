CREATE TABLE [dbo].[OPS_WorkOrder_Task_Event]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__OPS_WorkOrder_Task_Event__ID] DEFAULT (newsequentialid()),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__OPS_WorkOrder_Task_Event__DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__OPS_WorkOrder_Task_Event__DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[OPS_WorkOrderID] [uniqueidentifier] NULL,
[OPS_WorkOrder_TaskID] [uniqueidentifier] NULL,
[Driver_HR_EmployeeID] [uniqueidentifier] NULL,
[ScheduledStartTime] [datetime] NULL,
[ScheduledEndTime] [datetime] NULL,
[QuantityScheduled] [int] NULL,
[QuantityCompleted] [int] NULL,
[MCS_Trip_Stop_TaskID] [uniqueidentifier] NULL,
[EventData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CommonList_OPS_WorkorderItemTaskTypeId] [uniqueidentifier] NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__OPS_WorkOrder_Task_Event__IsDelete] DEFAULT ((0)),
[IsRead] [bit] NOT NULL CONSTRAINT [DF__OPS_WorkOrder_Task_Event__IsRead] DEFAULT ((0)),
[CommonList_OPSWorkOrder_Task_Event_StatusID] [uniqueidentifier] NULL,
[ActualStartTime] [datetime] NULL,
[ActualEndTime] [datetime] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_Event] ADD CONSTRAINT [PK_OPS_WorkOrder_Task_Event] PRIMARY KEY CLUSTERED ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__OPS_WorkOrder_Task_Event__TaskID_HR_EmployeeID_IsDelete] ON [dbo].[OPS_WorkOrder_Task_Event] ([OPS_WorkOrder_TaskID], [Driver_HR_EmployeeID], [IsDelete]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_Event] ADD CONSTRAINT [FK__OPS_WorkOrder_Task_Event__CommonList_OPSWorkOrder_Task_Event_StatusID__x__System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPSWorkOrder_Task_Event_StatusID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_Event] ADD CONSTRAINT [FK__OPS_WorkOrder_Task_Event__Driver_HR_EmployeeID__x__HR_Employee__ID] FOREIGN KEY ([Driver_HR_EmployeeID]) REFERENCES [dbo].[HR_Employee] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_Event] ADD CONSTRAINT [FK_OPS_WorkOrder_Task_Event__CommonList_OPS_WorkorderItemTaskTypeId_X_System_CommonList_Item__ID] FOREIGN KEY ([CommonList_OPS_WorkorderItemTaskTypeId]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_Event] ADD CONSTRAINT [FK_OPS_WorkOrder_Task_Event__MCS_Trip_Stop_TaskID_X_MCS_Trip_Stop_Task__ID] FOREIGN KEY ([MCS_Trip_Stop_TaskID]) REFERENCES [dbo].[MCS_Trip_Stop_Task] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_Event] ADD CONSTRAINT [FK_OPS_WorkOrder_Task_Event__OPS_WorkOrder_TaskID_X_OPS_WorkOrder_Task__ID] FOREIGN KEY ([OPS_WorkOrder_TaskID]) REFERENCES [dbo].[OPS_WorkOrder_Task] ([ID])
GO
ALTER TABLE [dbo].[OPS_WorkOrder_Task_Event] ADD CONSTRAINT [FK_OPS_WorkOrder_Task_Event__OPS_WorkOrderID_X_OPS_WorkOrder__ID] FOREIGN KEY ([OPS_WorkOrderID]) REFERENCES [dbo].[OPS_WorkOrder] ([ID])
GO
