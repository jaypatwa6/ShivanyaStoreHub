CREATE TABLE [dbo].[MCS_Smartform_Question]
(
[IsActive] [bit] NOT NULL CONSTRAINT [DF_Mobile_Smartforms_Questions_IsActive] DEFAULT ((1)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Mobile_Smartforms_Questions_DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_Mobile_Smartforms_Questions_DateModified] DEFAULT (getutcdate()),
[Sequence] [int] NULL,
[Name] [nvarchar] (400) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ShortName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Keyword] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Description] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[InputParameters] [xml] NULL,
[IsResponseRequired] [bit] NOT NULL CONSTRAINT [DF_Mobile_Smartforms_Questions_IsResponseRequired] DEFAULT ((0)),
[DefaultAnswer] [nvarchar] (400) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__Mobile_Smart__ID__00BFF13D] DEFAULT (newsequentialid()),
[CommonList_SmartformResponseID] [uniqueidentifier] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[MCS_SmartformID] [uniqueidentifier] NOT NULL,
[PreviousQuestionID] [uniqueidentifier] NULL,
[Version] [int] NULL,
[ParentId] [uniqueidentifier] NULL,
[IsSystemQuestion] [bit] NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__MCS_Smart__IsDel__473C8FC7] DEFAULT ((0)),
[GroupNumber] [int] NULL,
[AllowMultipleResponses] [bit] NULL CONSTRAINT [DF__MCS_Smart__Allow__134A4C7A] DEFAULT ((0)),
[InspectionType] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Smartform_Question] ADD CONSTRAINT [PK_MCS_Smartform_Question] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX__MCS_Smartform_Question__MCS_SmartformID] ON [dbo].[MCS_Smartform_Question] ([MCS_SmartformID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[MCS_Smartform_Question] ADD CONSTRAINT [FK_MCS_Smartform_Question__PreviousQuestionID_X_MCS_Smartform_Question__ID] FOREIGN KEY ([PreviousQuestionID]) REFERENCES [dbo].[MCS_Smartform_Question] ([ID])
GO
ALTER TABLE [dbo].[MCS_Smartform_Question] WITH NOCHECK ADD CONSTRAINT [FK_MCS_Smartform_Question_CommonList_SmartformResponseID_X_System_CommonList_Item_ID] FOREIGN KEY ([CommonList_SmartformResponseID]) REFERENCES [dbo].[System_CommonList_Item] ([ID])
GO
ALTER TABLE [dbo].[MCS_Smartform_Question] ADD CONSTRAINT [FK_MCS_Smartform_Question_MCS_SmartformID_X_MCS_Smartform_ID] FOREIGN KEY ([MCS_SmartformID]) REFERENCES [dbo].[MCS_Smartform] ([ID])
GO
