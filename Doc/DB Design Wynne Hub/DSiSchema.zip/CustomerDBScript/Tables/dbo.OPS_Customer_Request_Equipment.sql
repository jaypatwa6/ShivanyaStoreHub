CREATE TABLE [dbo].[OPS_Customer_Request_Equipment]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__OPS_Customer_Request_Equipment__ID] DEFAULT (newsequentialid()),
[OPS_Customer_RequestID] [uniqueidentifier] NOT NULL,
[Number] [nvarchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[SerialNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Description] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Category] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Classification] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Make] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Model] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[MeterReadingType] [nvarchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[MeterReadingValue] [decimal] (12, 2) NULL,
[System_Organization_AssignedLocationID] [uniqueidentifier] NULL,
[System_Organization_CurrentLocationID] [uniqueidentifier] NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__OPS_Customer_Request_Equipment__DateCreated] DEFAULT (getutcdate()),
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__OPS_Customer_Request_Equipment__DateModified] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__OPS_Customer_Request_Equipment__IsDelete] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_Customer_Request_Equipment] ADD CONSTRAINT [PK__OPS_Customer_Request_Equipment] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[OPS_Customer_Request_Equipment] ADD CONSTRAINT [FK__OPS_Customer_Request_Equipment__OPS_Customer_Request_EquipmentID__x__OPS_Customer_Request__ID] FOREIGN KEY ([OPS_Customer_RequestID]) REFERENCES [dbo].[OPS_Customer_Request] ([ID])
GO
ALTER TABLE [dbo].[OPS_Customer_Request_Equipment] ADD CONSTRAINT [FK__OPS_Customer_Request_Equipment__System_Organization_AssignedLocationID__x__System_Organization__ID] FOREIGN KEY ([System_Organization_AssignedLocationID]) REFERENCES [dbo].[System_Organization] ([ID])
GO
ALTER TABLE [dbo].[OPS_Customer_Request_Equipment] ADD CONSTRAINT [FK__OPS_Customer_Request_Equipment__System_Organization_CurrentLocationID__x__System_Organization__ID] FOREIGN KEY ([System_Organization_CurrentLocationID]) REFERENCES [dbo].[System_Organization] ([ID])
GO
