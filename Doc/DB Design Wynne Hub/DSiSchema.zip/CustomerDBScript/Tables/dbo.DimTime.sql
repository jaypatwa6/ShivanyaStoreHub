CREATE TABLE [dbo].[DimTime]
(
[DimTimeSK] [int] NOT NULL,
[Time] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Time24] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[HourName] [varchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[MinuteName] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Hour] [tinyint] NULL,
[Hour24] [tinyint] NULL,
[Minute] [tinyint] NULL,
[Second] [int] NULL,
[AM] [char] (2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[DimTime] ADD CONSTRAINT [PK__DimTime__CE270D99E48BBEF1] PRIMARY KEY CLUSTERED  ([DimTimeSK]) ON [PRIMARY]
GO
