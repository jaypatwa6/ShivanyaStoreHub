CREATE SYNONYM [dbo].[Master_Account_ManagementGroupMember] FOR [DSiMaster].[dbo].[Account_ManagementGroupMember]
GO
