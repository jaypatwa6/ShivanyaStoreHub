CREATE SYNONYM [dbo].[Master_Account_Login] FOR [DSiMaster].[dbo].[Account_Login]
GO
