CREATE SYNONYM [dbo].[Master_Account] FOR [DSiMaster].[dbo].[Account]
GO
