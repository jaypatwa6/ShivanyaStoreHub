SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

	-- =============================================
	-- Author:		Nguyen Hoai
	-- Create date: 12/9/2015
	-- Description:	Get list rest break elog item by Header id
	-- =============================================
CREATE FUNCTION [dbo].[fn_GetResetBreaksViolation] 
	(
	-- Add the parameters for the function here
	@HeaderId as uniqueidentifier,
	@StatusOn as uniqueidentifier,
	@StatusDriving uniqueidentifier	
	)
	RETURNS nvarchar(max)
	AS
	BEGIN
	-- Declare the return variable here
	DECLARE @lstRestBreak nvarchar(max) = ''
	DECLARE @i int
	DECLARE @PractitionerId int
	DECLARE @numrows int
	DECLARE @sumTotalTime bigint =0
	DECLARE @valueResetBreak bigint = '28800' -- 28800 = 8 hours
	DECLARE @Practitioner TABLE (
		idx smallint Primary Key IDENTITY(1,1)
		, ID uniqueidentifier
		, StartDate Datetime
		, EndDate datetime null
		, TotalInTicks int
		, CommonList_ElogStatusTypeID uniqueidentifier
	)
	DECLARE @startdate datetime
	DECLARE @enddate datetime
	DECLARE @currentTotalTime bigint =0
	DECLARE @TotalTimeOff bigint = 0 
	DECLARE @enddateBefore datetime = null
	DECLARE @currentstatus uniqueidentifier
	
	--Insert new table by Header id and On Duty Status
	INSERT @Practitioner SELECT  ID,StartDate, EndDate, CAST(TotalInTicks * POWER(10.00000000000,-7) AS int) , CommonList_ElogStatusTypeID FROM FMS_Elog_Modify 
						where FMS_Elog_HeaderID = @HeaderId and (CommonList_ElogStatusTypeID = @StatusOn or CommonList_ElogStatusTypeID = @StatusDriving) 
						order by StartDate
	-- Add the T-SQL statements to compute the return value here
	SET @i = 1
	SET @numrows = (SELECT COUNT(*) FROM @Practitioner)
	IF @numrows > 0		
		WHILE (@i <= @numrows)
		BEGIN
		
		SET @enddate = (SELECT EndDate FROM @Practitioner WHERE idx = @i)
		SET @startdate = (SELECT StartDate FROM @Practitioner WHERE idx = @i)
		SET @currentstatus = (SELECT CommonList_ElogStatusTypeID FROM @Practitioner WHERE idx = @i)
		SET @currentTotalTime = (SELECT TotalInTicks FROM @Practitioner WHERE idx = @i)		
		SET @sumTotalTime = @sumTotalTime + @currentTotalTime
		
		IF @enddateBefore  is not null
		SET @TotalTimeOff =  DATEDIFF(SECOND,@enddateBefore ,  @startdate) --Check time off
		ELSE
		SET @TotalTimeOff = 0

		--Returm list start time rest break
		IF (@sumTotalTime > @valueResetBreak  and  @currentstatus =  @StatusDriving)
		SET @lstRestBreak = @lstRestBreak + ',' +  CONVERT(NVARCHAR(50), @startdate, 113)
		 
		
		--Reset sum total time = 0  (1800 = 30 minute)
		IF @TotalTimeOff >= '1800' 
		SET @sumTotalTime = 0
		
		SET @enddateBefore = @enddate
		SET @i  =  @i + 1 
		 
	END
	-- Return the result of the function
	RETURN @lstRestBreak
	END
GO
