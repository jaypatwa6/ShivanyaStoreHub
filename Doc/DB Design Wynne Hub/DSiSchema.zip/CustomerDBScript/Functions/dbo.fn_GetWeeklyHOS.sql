SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[fn_GetWeeklyHOS]
(
	@employeeID as uniqueidentifier
)
RETURNS numeric(18,2)
AS
BEGIN
declare @Result numeric(18,2)
set @Result=0
	set @Result = (select CASE WHEN dbo.fn_CheckInterstate(Header.Id,HR.Account_LoginID) = 1 
THEN iif(R.IntrastateMultiDayHours1 - Header.WeeklyOnduty > 0,iif((R.IntrastateMultiDayHours1 - Header.WeeklyOnduty)*60 - (select top 1 DateDiff(minute,StartDate,GETUTCDATE()) from FMS_Elog_Modify
 where FMS_Elog_HeaderID=Header.Id and EndDate is null
 order by StartDate desc) > 0,(R.IntrastateMultiDayHours1 - Header.WeeklyOnduty)*60 - (select top 1 DateDiff(minute,StartDate,GETUTCDATE()) from FMS_Elog_Modify
 where FMS_Elog_HeaderID=Header.Id and EndDate is null
 order by StartDate desc),0),0)
ELSE iif(R.InterstateMultiDayHours1 - Header.WeeklyOnduty > 0,iif((R.InterstateMultiDayHours1 - Header.WeeklyOnduty)*60 - (select top 1 DateDiff(minute,StartDate,GETUTCDATE()) from FMS_Elog_Modify
 where FMS_Elog_HeaderID=Header.Id and EndDate is null
 order by StartDate desc) > 0,(R.InterstateMultiDayHours1 - Header.WeeklyOnduty)*60 - (select top 1 DateDiff(minute,StartDate,GETUTCDATE()) from FMS_Elog_Modify
 where FMS_Elog_HeaderID=Header.Id and EndDate is null
 order by StartDate desc),0),0)
END
 as RemainingCurrentWeeklyHOS
from FMS_Elog_Header AS Header
inner join FMS_Elog_HOSRule as R on Header.FMS_Elog_HOSRuleId = R.Id
inner join HR_Employee as HR on Header.HR_EmployeeID = HR.ID
where  Header.Id = ( select top 1 FMS_Elog_Header.Id from FMS_Elog_Header
inner join HR_Employee on FMS_Elog_Header.HR_EmployeeID = HR_Employee.ID
where HR_Employee.Id= @employeeID
order by DateStartDailyReset desc))
return @Result
END

GO
