SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[fn_GetLoadNumberOfTripStopTask](@tripStopTaskId AS UNIQUEIDENTIFIER)
RETURNS INT
AS
BEGIN
	DECLARE @xml xml;
	DECLARE @loadNumber INT;
	SET @xml = (SELECT TOP 1 [DocumentNumbers] FROM [MCS_Trip_Stop_Task] WHERE ID = @tripStopTaskId)
	SET @loadNumber = (SELECT a.b.value('LoadNumber[1]','varchar(10)')
						FROM @xml.nodes('data') as a(b))
	RETURN @loadNumber;
END
GO
