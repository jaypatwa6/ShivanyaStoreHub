SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[fn_CheckInterstate]
(
	@headerId as uniqueidentifier,
	@userId as uniqueidentifier
)
RETURNS bit
AS
BEGIN
declare @Result bit
set @Result=0
	 if((select count(*)
		from [dbo].[FMS_Elog_Modify] as modifiedSub 
			left join [dbo].[FMS_Elog_Header] as headerSub on headerSub.Id = modifiedSub.FMS_Elog_HeaderID and headerSub.Id = @headerId
			left join [dbo].[MCS_Device_EventSummary] as commenventSub on commenventSub.Id = modifiedSub.MCS_Device_EventSummaryID				
		where modifiedSub.StartDate <=   headerSub.DateCreated
		and modifiedSub.StartDate >= (DATEADD(day, -8, headerSub.DateCreated))
		and HeaderSub.CreatedBy = @userId
		and (
		(iif(headerSub.MotorCarrierState is not null and LTRIM(headerSub.MotorCarrierState) != '',
		 headerSub.MotorCarrierState,
		 (select defaulMC.[state]  from FMS_MotorCarrier as defaulMC where isdefault = 1))  != commenventSub.[State]
		or commenventSub.[State] is null
		)
		or modifiedSub.IsInterstateLoad = 1					
			)
		) > 0) set @Result=1
		return @Result
END
GO
