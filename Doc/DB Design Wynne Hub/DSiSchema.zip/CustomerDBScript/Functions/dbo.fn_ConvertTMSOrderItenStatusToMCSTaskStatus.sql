SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
--if there is no attachment, no task event, no task conact, no order item task -> remove it
--else set IsDeleted = 1
CREATE FUNCTION [dbo].[fn_ConvertTMSOrderItenStatusToMCSTaskStatus](@tmsTaskStatusId AS UNIQUEIDENTIFIER, @isPickupTask AS BIT, @isDeliveryTask AS BIT)
RETURNS UNIQUEIDENTIFIER
AS
BEGIN
	DECLARE @mcsStatusKeyword NVARCHAR(50);
	DECLARE @tmsStatusKeyword NVARCHAR(50) = (SELECT Keyword FROM System_CommonList_Item 
												WHERE ID = @tmsTaskStatusId
												AND System_CommonListID = (SELECT ID FROM System_CommonList WHERE Keyword = 'TMS_OrderItemStatus'));
	IF (@tmsStatusKeyword = 'TMS_OrderItemStatus_Dispatched')
	BEGIN
		SET @mcsStatusKeyword = 'NotStarted';
	END
	IF (@tmsStatusKeyword = 'TMS_OrderItemStatus_OutForPickup')
	BEGIN
		IF (@isPickupTask = 1)
			SET @mcsStatusKeyword = 'EnRoute';
	END
	IF (@tmsStatusKeyword = 'TMS_OrderItemStatus_AtPickup')
	BEGIN
		IF (@isPickupTask = 1)
			SET @mcsStatusKeyword = 'OnSite';
	END
	IF (@tmsStatusKeyword = 'TMS_OrderItemStatus_PickupComplete')
	BEGIN
		IF (@isPickupTask = 1)
			SET @mcsStatusKeyword = 'Complete';
	END
	IF (@tmsStatusKeyword = 'TMS_OrderItemStatus_OutForDelivery')
	BEGIN
		IF (@isDeliveryTask = 1)
			SET @mcsStatusKeyword = 'EnRoute';
	END
	IF (@tmsStatusKeyword = 'TMS_OrderItemStatus_AtDelivery')
	BEGIN
		IF (@isDeliveryTask = 1)
			SET @mcsStatusKeyword = 'OnSite';
	END
	IF (@tmsStatusKeyword = 'TMS_OrderItemStatus_DeliveryComplete')
	BEGIN
		SET @mcsStatusKeyword = 'Complete';
	END

	IF (@tmsStatusKeyword IN ('TMS_OrderItemStatus_Pending', 'TMS_OrderItemStatus_ReadyForDispatch', 'TMS_OrderItemStatus_Open'))
	BEGIN
		SET @mcsStatusKeyword = 'NotStarted';
	END

	IF (@tmsStatusKeyword = 'TMS_OrderItemStatus_Closed')
	BEGIN
		SET @mcsStatusKeyword = 'Complete';
	END

	IF (@tmsStatusKeyword = 'TMS_OrderItemStatus_OnHold')
	BEGIN
		SET @mcsStatusKeyword = 'Paused';
	END

	DECLARE @mscStatusId AS UNIQUEIDENTIFIER;
	SET @mscStatusId = (SELECT ID FROM System_CommonList_Item WHERE Keyword = @mcsStatusKeyword AND System_CommonListID = (SELECT ID FROM System_CommonList WHERE Keyword = 'Dispatch_TaskStatus'))

	RETURN @mscStatusId;
END
--#######################################################################################
GO
