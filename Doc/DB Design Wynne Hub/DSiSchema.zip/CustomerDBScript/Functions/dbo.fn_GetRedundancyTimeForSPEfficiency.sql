SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[fn_GetRedundancyTimeForSPEfficiency] 
	(
	-- Add the parameters for the function here
	@STARTDATE as datetime,
	@ENDDATE as datetime,
	@DRIVING_STATUS uniqueidentifier,
	@ONDUTY_STATUS uniqueidentifier,
	@YARDMOVE_STATUS uniqueidentifier,
	@IsCheckOnduty  bit	
	)
	RETURNS @OndutyTimeTable TABLE (
		idx int Primary Key IDENTITY(1,1)
		, DurationInTicks bigint  		 
		, HR_EmployeeID uniqueidentifier)

	AS
	BEGIN  
	 
	DECLARE @OndutyTable TABLE (
		idx int Primary Key IDENTITY(1,1)
		, ID uniqueidentifier
		, StartTime Datetime
		, EndTime datetime null
		, DurationInTicks bigint
		, HR_EmployeeID uniqueidentifier
	);
	DECLARE @OndutyTable1 TABLE (
		idx int Primary Key IDENTITY(1,1)
		, ID uniqueidentifier
		, StartTime Datetime
		, EndTime datetime null
		, DurationInTicks bigint
		, HR_EmployeeID uniqueidentifier
	);

	DECLARE @OndutyTable2 TABLE (
		idx int Primary Key IDENTITY(1,1)
		, ID uniqueidentifier
		, StartTime Datetime
		, EndTime datetime null
		, DurationInTicks bigint
		, HR_EmployeeID uniqueidentifier
	);
	 

			 
		IF(@IsCheckOnduty = 1)
			INSERT @OndutyTable  SELECT ID, StartTime, EndTime, DurationInTicks, HR_EmployeeID FROM [DBO].[FMS_Elog_DailyReport_Detail] WITH (NOLOCK) WHERE (StartTime < @STARTDATE 
			AND EndTime > @ENDDATE) AND (CommonList_ElogStatusTypeID = @DRIVING_STATUS OR CommonList_ElogStatusTypeID = @ONDUTY_STATUS OR CommonList_ElogStatusTypeID = @YARDMOVE_STATUS)
		ELSE
			INSERT @OndutyTable  SELECT ID, StartTime, EndTime, DurationInTicks , HR_EmployeeID FROM [DBO].[FMS_Elog_DailyReport_Detail] WITH (NOLOCK) WHERE (StartTime < @STARTDATE 
			AND EndTime > @ENDDATE) AND  CommonList_ElogStatusTypeID = @DRIVING_STATUS  
		DECLARE @numrowsOnduty int = (SELECT COUNT(*) FROM @OndutyTable)	    
		IF(@numrowsOnduty > 0)
		BEGIN
			DECLARE @i_onduty int = 1
			DECLARE @employee_onduty uniqueidentifier
			DECLARE @totalTimeOnduty bigint =  (DATEDIFF(SECOND ,@STARTDATE ,  @ENDDATE) * POWER(10.00000000000,7))
			IF @numrowsOnduty > 0		
				WHILE (@i_onduty <= @numrowsOnduty)
				BEGIN
					DECLARE @DurationInTicks_onduty bigint = (SELECT DurationInTicks FROM @OndutyTable WHERE idx = @i_onduty)
					SET @employee_onduty = (SELECT HR_EmployeeID FROM @OndutyTable WHERE idx = @i_onduty)

					INSERT INTO  @OndutyTimeTable (DurationInTicks, HR_EmployeeID ) VALUES (@DurationInTicks_onduty - @totalTimeOnduty,@employee_onduty )
					
					SET @i_onduty  =  @i_onduty + 1 
		 
			END
		END
			 
		IF(@IsCheckOnduty = 1)
			INSERT @OndutyTable1  SELECT ID, StartTime, EndTime, DurationInTicks , HR_EmployeeID FROM [DBO].[FMS_Elog_DailyReport_Detail] WITH (NOLOCK) WHERE StartTime < @STARTDATE AND (ENDTIME BETWEEN @STARTDATE AND @ENDDATE)
			AND (  CommonList_ElogStatusTypeID = @DRIVING_STATUS OR  CommonList_ElogStatusTypeID = @ONDUTY_STATUS OR CommonList_ElogStatusTypeID = @YARDMOVE_STATUS)
		ELSE
			INSERT @OndutyTable1  SELECT ID, StartTime, EndTime, DurationInTicks , HR_EmployeeID FROM [DBO].[FMS_Elog_DailyReport_Detail] WITH (NOLOCK) WHERE StartTime < @STARTDATE AND (ENDTIME BETWEEN @STARTDATE AND @ENDDATE)
			AND CommonList_ElogStatusTypeID = @DRIVING_STATUS
		DECLARE @numrowsOnduty1 int = (SELECT COUNT(*) FROM @OndutyTable1)	    
		IF(@numrowsOnduty1 > 0)
		BEGIN
			DECLARE @i_onduty1 int = 1
			DECLARE @employee_onduty1 uniqueidentifier
			DECLARE @totalTimeOnduty1 bigint 
			DECLARE @StartTime1 datetime
			IF @numrowsOnduty1 > 0		
				WHILE (@i_onduty1 <= @numrowsOnduty1)
				BEGIN
				SET @StartTime1 = (SELECT StartTime FROM @OndutyTable1 WHERE idx = @i_onduty1)
				SET @totalTimeOnduty1 = DATEDIFF(SECOND ,@StartTime1 ,  @STARTDATE) * POWER(10.00000000000,7)
				SET @employee_onduty1 = (SELECT HR_EmployeeID FROM @OndutyTable1 WHERE idx = @i_onduty1)
				INSERT INTO  @OndutyTimeTable VALUES (@totalTimeOnduty1, @employee_onduty1 )
				SET @i_onduty1  =  @i_onduty1 + 1 
		 
			END
		END

		IF(@IsCheckOnduty = 1)
			INSERT @OndutyTable2  SELECT ID, StartTime, EndTime, DurationInTicks , HR_EmployeeID FROM [DBO].[FMS_Elog_DailyReport_Detail] WITH (NOLOCK) WHERE ENDTIME > @ENDDATE AND (StartTime BETWEEN @STARTDATE AND @ENDDATE)
			AND (  CommonList_ElogStatusTypeID = @DRIVING_STATUS OR  CommonList_ElogStatusTypeID = @ONDUTY_STATUS OR CommonList_ElogStatusTypeID = @YARDMOVE_STATUS)
		ELSE
			INSERT @OndutyTable2  SELECT ID, StartTime, EndTime, DurationInTicks , HR_EmployeeID FROM [DBO].[FMS_Elog_DailyReport_Detail] WITH (NOLOCK) WHERE ENDTIME > @ENDDATE AND (StartTime BETWEEN @STARTDATE AND @ENDDATE)
			AND CommonList_ElogStatusTypeID = @DRIVING_STATUS
		DECLARE @numrowsOnduty2 int = (SELECT COUNT(*) FROM @OndutyTable2)	    
		IF(@numrowsOnduty2 > 0)
		BEGIN
			DECLARE @i_onduty2 int = 1
			DECLARE @employee_onduty2 uniqueidentifier
			DECLARE @totalTimeOnduty2 bigint 
			DECLARE @EndTime2 datetime
			IF @numrowsOnduty2 > 0		
				WHILE (@i_onduty2 <= @numrowsOnduty2)
				BEGIN
				SET @EndTime2 = (SELECT EndTime FROM @OndutyTable2 WHERE idx = @i_onduty2)
				SET @totalTimeOnduty2 = DATEDIFF(SECOND ,@ENDDATE ,@EndTime2) * POWER(10.00000000000,7)
				SET @employee_onduty2 = (SELECT HR_EmployeeID FROM @OndutyTable2 WHERE idx = @i_onduty2)
				IF((select COUNT(*) from @OndutyTimeTable where HR_EmployeeID = @employee_onduty2) > 0)
					BEGIN 
						UPDATE @OndutyTimeTable SET DurationInTicks = DurationInTicks + @totalTimeOnduty2 WHERE HR_EmployeeID = @employee_onduty2
					END
				ELSE
					BEGIN 
						INSERT INTO  @OndutyTimeTable VALUES (@totalTimeOnduty2, @employee_onduty2 )
					END
				
				SET @i_onduty2  =  @i_onduty2 + 1 
		 
			END
		END
					 
	
		RETURN   
	END

GO
