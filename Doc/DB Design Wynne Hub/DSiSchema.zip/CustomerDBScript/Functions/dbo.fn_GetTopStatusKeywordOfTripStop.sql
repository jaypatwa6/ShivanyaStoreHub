SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE FUNCTION [dbo].[fn_GetTopStatusKeywordOfTripStop](@tripStopId AS UNIQUEIDENTIFIER)
RETURNS NVARCHAR(50)
AS
BEGIN
DECLARE @tripStopTaskStatusKeyword nvarchar(50);
	SET @tripStopTaskStatusKeyword = (SELECT TOP 1 item.Keyword FROM MCS_Trip_Stop_Task as task JOIN System_CommonList_Item as item ON task.[CommonList_TaskStatusID] = item.ID
										WHERE task.MCS_Trip_StopID = @tripStopId AND item.Keyword NOT IN ('Complete','Cancel','Paused') ORDER BY item.Sequence DESC)
	DECLARE @statusKeyword nvarchar(50) = 'Pending';
	IF (@tripStopTaskStatusKeyword IS NOT NULL AND @tripStopTaskStatusKeyword != '')
	BEGIN
		IF (@tripStopTaskStatusKeyword = 'NotStarted')
		BEGIN
			SET @statusKeyword = 'NotStarted'
		END
		IF (@tripStopTaskStatusKeyword = 'EnRoute')
		BEGIN
			SET @statusKeyword = 'EnRoute'
		END
		IF (@tripStopTaskStatusKeyword = 'OnSite')
		BEGIN
			SET @statusKeyword = 'OnSite'
		END
	END
	ELSE
	BEGIN
		DECLARE @tripStopTaskCount int;
		SET @tripStopTaskCount = (SELECT COUNT(ID) FROM MCS_Trip_Stop_Task WHERE [MCS_Trip_StopID] = @tripStopId);
		IF (@tripStopTaskCount > 0)
		BEGIN
			DECLARE @tripStopTaskCountPaused int;
			SET @tripStopTaskCountPaused = (SELECT COUNT(task.ID) FROM MCS_Trip_Stop_Task AS task JOIN System_CommonList_Item AS item on  task.CommonList_TaskStatusID = item.ID WHERE [MCS_Trip_StopID] = @tripStopId AND item.Keyword = 'Paused' AND task.IsDeleted = 0);
			IF (@tripStopTaskCountPaused = @tripStopTaskCount)
			BEGIN
				SET @statusKeyword = 'Paused'
			END
			ELSE
			BEGIN
				DECLARE @tripStopTaskCountComplete int;
				SET @tripStopTaskCountComplete = (SELECT COUNT(task.ID) FROM MCS_Trip_Stop_Task AS task JOIN System_CommonList_Item AS item on  task.CommonList_TaskStatusID = item.ID WHERE [MCS_Trip_StopID] = @tripStopId AND item.Keyword = 'Complete'  AND task.IsDeleted = 0);
				DECLARE @tripStopTaskCountCompleteDeleted int;
				SET @tripStopTaskCountCompleteDeleted = (SELECT COUNT(task.ID) FROM MCS_Trip_Stop_Task AS task JOIN System_CommonList_Item AS item on  task.CommonList_TaskStatusID = item.ID WHERE [MCS_Trip_StopID] = @tripStopId AND item.Keyword = 'Complete'  AND task.IsDeleted = 1);
				IF (@tripStopTaskCountComplete = @tripStopTaskCount OR @tripStopTaskCountCompleteDeleted = @tripStopTaskCount)
				BEGIN
					SET @statusKeyword = 'Complete'
				END
				ELSE
				BEGIN
					DECLARE @tripStopTaskCountCancel int;
					SET @tripStopTaskCountCancel = (SELECT COUNT(task.ID) FROM MCS_Trip_Stop_Task AS task JOIN System_CommonList_Item AS item on  task.CommonList_TaskStatusID = item.ID WHERE [MCS_Trip_StopID] = @tripStopId AND item.Keyword = 'Cancel'  AND task.IsDeleted = 0);
					IF (@tripStopTaskCountCancel = @tripStopTaskCount)
					BEGIN
						SET @statusKeyword = 'Cancel'
					END
				END
			END
		END
	END
	RETURN @statusKeyword;
END
GO
