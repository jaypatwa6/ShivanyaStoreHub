SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
--if there is no attachment, no task event, no task conact, no order item task -> remove it
--else set IsDeleted = 1
CREATE FUNCTION [dbo].[fn_CheckAssociatedTripStopTask](@tripStopTaskId AS UNIQUEIDENTIFIER)
RETURNS BIT
AS
BEGIN

	DECLARE @count INT;
	
	SET @count = (SELECT COUNT(ID) FROM MCS_Trip_Stop_Task_Event WHERE MCS_Trip_Stop_TaskID = @tripStopTaskId);
	IF (@count IS NULL OR @count <= 0)
	BEGIN
		SET @count = (SELECT COUNT(ID) FROM MCS_Trip_Stop_Task_Contact WHERE MCS_Trip_Stop_TaskID = @tripStopTaskId);
		IF (@count IS NULL OR @count <= 0)
		BEGIN
			SET @count =  (SELECT COUNT(ID) FROM MCS_Trip_Stop_Task_Attachment WHERE MCS_Trip_Stop_TaskID = @tripStopTaskId);
			IF (@count IS NULL OR @count <= 0)
			BEGIN
				SET @count =  (SELECT COUNT(ID) FROM TMS_Order_Item_Task WHERE MCS_Trip_Stop_TaskID = @tripStopTaskId);
			END
		END
	END
	
	IF (@count IS NULL OR @count <= 0)
		RETURN 0;

	RETURN 1;
END
GO
