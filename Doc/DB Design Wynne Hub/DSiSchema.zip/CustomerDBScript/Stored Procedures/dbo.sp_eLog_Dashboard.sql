SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

-- =============================================
-- Author:		HIEU 
-- Create date: 2016-08-06
-- Last modified date: 2024-03-19 - DSIMOB-8713
-- Description:	get data for eLog Dashboard
-- =============================================
-- [sp_eLog_Dashboard] @Account_ManagementGroupID=0, @Account_LoginID='269ca9db-a76b-11e9-812e-00155da8010e'
CREATE PROCEDURE [dbo].[sp_eLog_Dashboard]
	@Account_ManagementGroupID bigint,
	@Account_LoginID uniqueidentifier = null
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	SET @Account_ManagementGroupID = ISNULL(@Account_ManagementGroupID, 0)		
	declare @Account_ManagementGroupIDTemp bigint = @Account_ManagementGroupID
	declare @Account_LoginIDTemp uniqueidentifier = @Account_LoginID	
	
	-- get maximum ios mobile app version
	declare @maxiOSMobileAppVersion nvarchar(50)
	select top 1 @maxiOSMobileAppVersion = SoftwareVersion
	from
	(
		select md.SoftwareVersion, md.[DateModified],
		SUBSTRING(md.SoftwareVersion, 0 , CHARINDEX('.', md.SoftwareVersion)) as t1,
		SUBSTRING(md.SoftwareVersion, CHARINDEX('.', md.SoftwareVersion) + 1, charindex('.', md.SoftwareVersion, (charindex('.', md.SoftwareVersion, 1))+1) - 3) as t2
		from [dbo].[MCS_Device] md	
		where md.isactive = 1
			and md.OSType = 'iOS'
			and md.DeviceType = 'Smartphone'
	) t
	order by (case when ISNUMERIC(t.t1) = 1 then CAST(t.t1 AS INT) else CAST(0 AS INT) end) desc, 
		(case when ISNUMERIC(t.t2) = 1 then CAST(t.t2 AS INT) else CAST(0 AS INT) end)  desc,
		DateModified desc
	
	-- get maximum android mobile app version
	declare @maxAndroidMobileAppVersion nvarchar(50)
	select top 1 @maxAndroidMobileAppVersion = SoftwareVersion
	from
	(
		select md.SoftwareVersion, md.[DateModified],
		SUBSTRING(md.SoftwareVersion, 0 , CHARINDEX('.', md.SoftwareVersion)) as t1,
		SUBSTRING(md.SoftwareVersion, CHARINDEX('.', md.SoftwareVersion) + 1, charindex('.', md.SoftwareVersion, (charindex('.', md.SoftwareVersion, 1))+1) - 3) as t2
		from [dbo].[MCS_Device] md	
		where md.isactive = 1
			and md.OSType = 'Android'
			and md.DeviceType = 'Smartphone'
	) t
	order by (case when ISNUMERIC(t.t1) = 1 then CAST(t.t1 AS INT) else CAST(0 AS INT) end) desc, 
		(case when ISNUMERIC(t.t2) = 1 then CAST(t.t2 AS INT) else CAST(0 AS INT) end)  desc,
		DateModified desc	


	declare @InterstateDailyResetHoursDefault int
	declare @InterstateWeeklyResetHoursDefault int
	declare @IntrastateDailyResetHoursDefault int
	declare @IntrastateWeeklyResetHoursDefault int
	select top 1  
		@InterstateDailyResetHoursDefault = InterstateDailyResetHours
		,@InterstateWeeklyResetHoursDefault = InterstateWeeklyResetHours
		,@IntrastateDailyResetHoursDefault = IntrastateDailyResetHours
		,@IntrastateWeeklyResetHoursDefault = IntrastateWeeklyResetHours
	from [dbo].[FMS_Elog_HOSRule] 
	where [IsDefault] = 1 	
							
	 -- Create Temporary Table for nearest 3 months
	DECLARE @TempDailyReportDetailTbl AS TABLE (
			HR_EmployeeID uniqueidentifier, 
			Keyword varchar(50), 
			StartTime datetime, 
			EndTime datetime, 
			StartTimeKey bigint, 
			EndTimeKey bigint, 
			MCS_EventSummaryID uniqueidentifier,
			Is16HourRuleException bit,
			IsAdverseDriving bit,
			DistanceInKM decimal(18,2)
	);
	INSERT INTO @TempDailyReportDetailTbl
	select HR_EmployeeID, Keyword, StartTime, EndTime, StartTimeKey, 0, MCS_EventSummaryID, Is16HourRuleException, IsAdverseDriving, DistanceInKM
	from v_elog_DailyReportDetail vedrd	
	where vedrd.StartTime  > dateadd(month, -3, getutcdate())
	order by vedrd.StartTime desc

select *	--   [sp_eLog_Dashboard_sb] @Account_ManagementGroupID=24051	   [sp_eLog_Dashboard] @Account_ManagementGroupID=24051
	, SecondRemainingOnDuty = 
		CASE WHEN IsInternalState = 1
			THEN (
				case 
					when StartTimeOfAdverseDriving is not null
						then CAST(((InterstateMaxOnDutyHours + 2) * 3600) - isnull(DailyOnDuty, 0) AS bigint)
					when StartTimeOf16HourRuleException is not null
						then CAST((InterstateMaxExemptionHours * 3600) - isnull(DailyOnDuty, 0) AS bigint)
					else CAST((InterstateMaxOnDutyHours * 3600) - isnull(DailyOnDuty, 0) AS bigint)
				end
			) 
			ELSE CAST(((IntrastateMaxOnDutyHours + (case when StartTimeOfAdverseDriving is not null then 2 else 0 end)) * 3600) - isnull(DailyOnDuty, 0) AS bigint)						
		END
	, TotalSecondOnDuty = 
		CASE WHEN IsInternalState = 1
			THEN (
				case 
					when StartTimeOfAdverseDriving is not null
						then (InterstateMaxOnDutyHours + 2) * 3600
					when StartTimeOf16HourRuleException is not null
						then InterstateMaxExemptionHours * 3600
					else InterstateMaxOnDutyHours * 3600
				end
			) 
			ELSE ((IntrastateMaxOnDutyHours + (case when StartTimeOfAdverseDriving is not null then 2 else 0 end)) * 3600) 				
		END
	, SecondRemainingDailyReset = 	
		CAST (
			case when LastEndTimeOn is not null
				then 
					(
						CASE WHEN IsInternalState = 1
							THEN (InterstateDailyResetHours * 3600) 				 
							ELSE (IntrastateDailyResetHours * 3600) 					
						END
					) -	DATEDIFF(SECOND, LastEndTimeOn, GETUTCDATE())																												
				else 0 
			end 			
		AS bigint)			
	, TotalSecondDailyReset = 
		(
			CASE WHEN IsInternalState = 1
				THEN (InterstateDailyResetHours * 3600) 
				ELSE (IntrastateDailyResetHours * 3600) 					
			END
		) 			
	, SecondRemainingDriving = 
		CASE WHEN IsInternalState = 1
			THEN CAST(((InterstateMaxDriveHours + (case when StartTimeOfAdverseDriving is not null then 2 else 0 end)) * 3600) - isnull(DailyDriving, 0) AS bigint)
			ELSE CAST(((IntrastateMaxDriveHours + (case when StartTimeOfAdverseDriving is not null then 2 else 0 end)) * 3600) - isnull(DailyDriving, 0) AS bigint)
		END
	, TotalSecondDriving = 
		(CASE WHEN IsInternalState = 1
			THEN ((InterstateMaxDriveHours + (case when StartTimeOfAdverseDriving is not null then 2 else 0 end)) * 3600) 
			ELSE ((IntrastateMaxDriveHours + (case when StartTimeOfAdverseDriving is not null then 2 else 0 end)) * 3600) 				
		END )			
	, SecondRemainingBreak = (		 --  [sp_eLog_Dashboard_sb] @Account_ManagementGroupID=24051
		SELECT -- top 1 CAST((8 * 3600) - DATEDIFF(SECOND, t1.Starttime, (case when Keyword <> 'Driving_On_Duty' then isnull(StartTime, GETUTCDATE() )  else GETUTCDATE() end) ) AS bigint) 
			top 1 CAST(		   
				(8 * 3600) - (
								select sum(datediff(SECOND, vdrd3.Starttime, isnull(vdrd3.Endtime, GETUTCDATE())))						
								from @TempDailyReportDetailTbl vdrd3
								where vdrd3.Keyword = 'Driving_On_Duty' 
									and vdrd3.HR_EmployeeID = ttttt.HR_EmployeeID
									and vdrd3.StartTime >= t1.StartTime
									and vdrd3.StartTime >= StartTimeOfDay  								
							)
					AS bigint)
		FROM (
				SELECT ROW_NUMBER() OVER (ORDER BY vdrd2.StartTime desc) AS rownum,								
					StartTime, 
					EndTime
				from @TempDailyReportDetailTbl vdrd2
				where vdrd2.Keyword = 'Driving_On_Duty' 
					and vdrd2.HR_EmployeeID = ttttt.HR_EmployeeID
					and vdrd2.StartTime <> isnull(vdrd2.EndTime, getutcdate())
					and vdrd2.StartTime >= StartTimeOfDay 				
			)t1
			LEFT JOIN (
				SELECT ROW_NUMBER() OVER (ORDER BY vdrd2.StartTime desc) AS rownum2,
						StartTime2 = StartTime, 
						EndTime2 = EndTime
				from @TempDailyReportDetailTbl vdrd2
				where vdrd2.Keyword = 'Driving_On_Duty' 
					and vdrd2.HR_EmployeeID = ttttt.HR_EmployeeID
					and vdrd2.StartTime <> isnull(vdrd2.EndTime, getutcdate())
					and vdrd2.StartTime >= StartTimeOfDay  				
			)t2 ON t1.rownum = t2.rownum2 - 1
		WHERE DATEDIFF(SECOND, t2.EndTime2, isnull(t1.StartTime, GETUTCDATE())) >= 1800
			OR t2.StartTime2 is null 	
	)		
	, TotalSecondBreak = (8 * 3600)
	, SecondRemainingBreakReset = 	
		CAST ( 
			case when LastEndTimeDriving is not null
				then (30 * 60) - DATEDIFF(SECOND, LastEndTimeDriving, GETUTCDATE())
				else 0 
			end 			
		AS bigint)	
	, SecondRemainingCycle =  
		case when StartTimeOfRolling is not null
			then (
				select (InterstateMultiDayHours1 * 3600) - sum(datediff(s, vdrd2.StartTime, isnull(vdrd2.EndTime, getutcdate())))
				from @TempDailyReportDetailTbl vdrd2
				where vdrd2.Keyword IN ('On_Duty', 'Driving_On_Duty', 'ELOG_SpecialStatus_YardMove')
					and vdrd2.HR_EmployeeID = ttttt.HR_EmployeeID
					and vdrd2.StartTime >= StartTimeOfRolling  				
			)
			when IsInternalState = 1 then CAST((InterstateMultiDayHours1 * 3600) - isnull(WeeklyOnduty, 0)  AS bigint)
			else CAST((IntrastateMultiDayHours1 * 3600) - isnull(WeeklyOnduty, 0)  AS bigint)
		end	
	, TotalSecondCycle = 
		CASE WHEN IsInternalState = 1
			THEN (InterstateMultiDayHours1 * 3600) 
			ELSE (IntrastateMultiDayHours1 * 3600) 					
		END
	, SecondRemainingWeeklyReset = 	
		CAST ( 
			case when LastEndTimeOn is not null
				then 
					(
						CASE WHEN IsInternalState = 1
							THEN (InterstateWeeklyResetHours * 3600) 
							ELSE (IntrastateWeeklyResetHours * 3600) 					
						END
					) -	DATEDIFF(SECOND, LastEndTimeOn, GETUTCDATE())
				else 0 
			end 			
		AS bigint)			
	, TotalSecondWeeklyReset = 
		CASE WHEN IsInternalState = 1
			THEN (InterstateWeeklyResetHours * 3600) 
			ELSE (IntrastateWeeklyResetHours * 3600) 					
		END 			  
	
from (		  --   [sp_eLog_Dashboard_sb] @Account_ManagementGroupID=24051
	 select *		
		, Is16HourRuleExceptionView = (		 		
			case when IsInternalState = 1 and StartTimeOf16HourRuleException is not null and StartTime >= StartTimeOf16HourRuleException
				then CAST(1 AS bit)
				else CAST(0 AS bit)
			end
		)
		, IsAdverseDrivingView = (			
			case when StartTimeOfAdverseDriving is not null and StartTime >= StartTimeOfAdverseDriving
				then CAST(1 AS bit)
				else CAST(0 AS bit)
			end
		)		
		, IsApplyRollingCycle = 
			CASE WHEN StartTimeOfRolling is not null
				THEN CAST(1 AS bit)
				ELSE  CAST(0 AS bit)
			END			
	 from (				 --   [sp_eLog_Dashboard_sb] @Account_ManagementGroupID=24051
		select *
			 ,TotalDistanceInKM = (
				SELECT SUM(vdrd2.DistanceInKM) 
				from @TempDailyReportDetailTbl vdrd2
				where vdrd2.HR_EmployeeID = ttt.HR_EmployeeID
					and vdrd2.StartTime >= StartTimeOfDay				
				) * 0.621371192,
			-- get all times before last ON point in a day 
			DailyOnDuty = (			
				select SUM(datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())))
				from (
					select
						hr_employeeid, 
						keyword, 
						grp, 
						starttime_grp = min(starttime), 
						endtime_grp = max(endtime)
					from (
							select 
								ss.*, 
								count(*) over (partition by grp, Keyword) as cnt
							from (
									select 
										s.hr_employeeid,
										s.keyword,
										s.starttime, 
										endtime = isnull(s.endtime, getutcdate()),
										grp = (
											row_number() over (partition by s.hr_employeeid order by s.starttime desc)
											 - row_number() over (partition by s.hr_employeeid, s.Keyword order by s.starttime desc)
										) 
									from (
										select 
											hr_employeeid, 
											starttime, 
											endtime,
											keyword_ori = vdrd2.Keyword,
											keyword = case when vdrd2.Keyword = 'ELOG_SpecialStatus_PersonalConveyance' then 'Off_Duty' else vdrd2.Keyword end
										from @TempDailyReportDetailTbl vdrd2
										WHERE vdrd2.hr_employeeid = ttt.HR_EmployeeID																													
											and vdrd2.StartTime >= StartTimeOfDay	-- update to start of current day
									) s
							   ) ss
							 
						 ) sss
					where sss.cnt >= 1
					group by sss.hr_employeeid, sss.keyword, sss.grp 					 
				) ssss
				where keyword <> 'In_Sleeper' 
					or (keyword = 'In_Sleeper' and datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())) < 7 * 3600)		
			),				
			DailyDriving = (
				select sum(datediff(s, vdrd2.StartTime, isnull(vdrd2.EndTime, GETUTCDATE())))
				from @TempDailyReportDetailTbl vdrd2
				where vdrd2.Keyword = 'Driving_On_Duty'
					and vdrd2.HR_EmployeeID = ttt.HR_EmployeeID
					and vdrd2.StartTime >= ttt.StartTimeOfDay				
				Group by vdrd2.Keyword
			), 
			WeeklyOnduty = 	(
				select sum(DATEDIFF(s, vdrd2.StartTime, isnull(vdrd2.EndTime, GETUTCDATE())))
				from @TempDailyReportDetailTbl vdrd2
				where vdrd2.Keyword IN ('On_Duty', 'Driving_On_Duty', 'ELOG_SpecialStatus_YardMove') 
					and vdrd2.HR_EmployeeID = ttt.HR_EmployeeID
					and vdrd2.StartTime >= ttt.StartTimeOfWeek							
				)
		from (
			select tt.* 			
			-- Rolling 7/8 days cycle: get all logs which come from past 7th or 8th day to calculate remaining cycle time, it is greater than start of week 			
			,StartTimeOfRolling = case when IsInternalState = 1
											then (	
												select top 1 StartTime
												from (
													SELECT  ROW_NUMBER() OVER (ORDER BY t1.StartTime desc) AS rownum
														, t1.StartTime
													FROM (
															SELECT ROW_NUMBER() OVER (ORDER BY StartTime desc) AS rownum,								
																vdrd2.StartTime, 
																vdrd2.EndTime
															from v_elog_DailyReportDetail vdrd2
															where vdrd2.Keyword IN ('On_Duty', 'Driving_On_Duty', 'ELOG_SpecialStatus_YardMove') 
																and vdrd2.HR_EmployeeID = tt.HR_EmployeeID
																and vdrd2.StartTime <> isnull(vdrd2.EndTime, getutcdate())		
																and vdrd2.StartTime >= StartTimeOfWeek													
														)t1
														LEFT JOIN (
															SELECT ROW_NUMBER() OVER (ORDER BY StartTime desc) AS rownum2,
																	StartTime2 = StartTime, 
																	EndTime2 = EndTime
															from v_elog_DailyReportDetail vdrd2
															where vdrd2.Keyword IN ('On_Duty', 'Driving_On_Duty', 'ELOG_SpecialStatus_YardMove') 
																and vdrd2.HR_EmployeeID = tt.HR_EmployeeID
																and vdrd2.StartTime <> isnull(vdrd2.EndTime, getutcdate()) 	
																and vdrd2.StartTime >= StartTimeOfWeek													
														)t2 ON t1.rownum = t2.rownum2 - 1
													WHERE 	
														 (
															DATEDIFF(SECOND, t2.EndTime2, isnull(t1.StartTime, GETUTCDATE())) >= 10 * 3600
															OR t2.StartTime2 is null
														)	
												) t
												where rownum = InterstateMultiDayDays1					
										)
									else null end
			, StartTimeOf16HourRuleException = (
											case
												when Last16HoursStartTime >= StartTimeOfDay and LatestSplitSleeperBerth is not null and Last16HoursStartTime >= SplitSleeperBerth2ndSegment then Last16HoursStartTime    
												when LatestSplitSleeperBerth is null and Last16HoursStartTime >= StartTimeOfDay then Last16HoursStartTime else null end
											)	
			, StartTimeOfAdverseDriving = (
											case
												when LastAdverseDrivingStartTime >= StartTimeOfDay and LatestSplitSleeperBerth is not null and LastAdverseDrivingStartTime >= SplitSleeperBerth2ndSegment then LastAdverseDrivingStartTime    
												when LatestSplitSleeperBerth is null and LastAdverseDrivingStartTime >= StartTimeOfDay then LastAdverseDrivingStartTime else null end
											)	
			, StartTimeOfSplitSleeperBerth = LatestSplitSleeperBerth			
		from (	-- tt
			SELECT t.*
					  --   [sp_eLog_Dashboard_sb] @Account_ManagementGroupID=24051					
				,StartTimeOfDay = (
					case 
						when t.IsInternalState = 1 
							then (case when LatestSplitSleeperBerth is not null and LatestSplitSleeperBerth > DailyResetInterstate then LatestSplitSleeperBerth else isnull(DailyResetInterstate, FirstLogStartTime) end) 
						else (case when LatestSplitSleeperBerth is not null and LatestSplitSleeperBerth > DailyResetIntrastate then LatestSplitSleeperBerth else isnull(DailyResetIntrastate, FirstLogStartTime) end) 
					end
				)							
				, StartTimeOfWeek = (case when t.IsInternalState = 1 then isnull(WeeklyResetInterstate, FirstLogStartTime) else isnull(WeeklyResetIntrastate, FirstLogStartTime) end)			
				, LastEndTimeOn = LastOnDutyEndTime	
				, LastEndTimeDriving = LastDrivingEndTime									
			FROM ( -- t
				SELECT 		
					FirstLogStartTime = (
						select top 1 vdrd2.StartTime 
						from @TempDailyReportDetailTbl vdrd2
						where vdrd2.HR_EmployeeID = fedrd.HR_EmployeeID	and vdrd2.Keyword IN ('On_Duty', 'Driving_On_Duty', 'ELOG_SpecialStatus_YardMove') 							
						order by vdrd2.StartTime asc
					),
					FirstName = isnull(he.FirstName, ''), 
					LastName = isnull(he.LastName, ''), 	
					NotExempt = 0,--isnull(he.IsExemptRestBreak, 0),
					al.UserName,	
					he.Email,
                    empCommon.Keyword as EmployeeType,
					HasContact = case when exists(select 1 from [dbo].[HR_Employee_Phone] hep where hep.HR_EmployeeID = he.ID and hep.IsActive = 1) then 1 else 0 end,
					fedrd.HR_EmployeeID,
					OSType = md.OSType,
					md.OSVersion,
					DeviceType = isnull(md.DeviceType, 'Unknown'), -- Smartphone, Black box (like Atrack, Squarell, GL505... devices), Bluetooth and Unknown			
					md.SoftwareVersion,
					MaximumSoftwareVersion = case when md.OSType = 'Android' and md.DeviceType = 'Smartphone' then @maxAndroidMobileAppVersion when md.OSType = 'iOS' and md.DeviceType = 'Smartphone' then @maxiOSMobileAppVersion else '' end,
					md.SerialNumber,
					-- 0: Not use, 1: working, 2: problem
					DeviceGPS = case when isnull(md.Latitude, 0) = 0 OR isnull(md.Longitude, 0) = 0 then 1 else 0 end, 				
					-- 0: Not use, 1: working, 2: problem
					DeviceBlueTooth = 0,					
					BatteryLevel = isnull(md.BatteryLevel, 0), 
					Keyword = scli.Keyword,		
					CurrentStatus = case 
								when scli.Keyword = 'On_Duty' then 'ON'--'On Duty (ON)' 
									when scli.Keyword = 'Driving_On_Duty' then 'D'--'Driving (D)' 
									when scli.Keyword = 'In_Sleeper' then 'SB'--'Sleeper Berth (SB)' 
									when scli.Keyword = 'Off_Duty' then 'OFF'--'Off Duty (OFF)' 
									when scli.Keyword = 'ELOG_SpecialStatus_PersonalConveyance' then 'PC'--'Personal Conveyance (PC)' 
									when scli.Keyword = 'ELOG_SpecialStatus_YardMove' then 'YM'--'Yard Move (YM)' 
									else '' 						
								end,
					EquipmentNumber = fe.Number,
					fedrd.ID,
					fedrd.ShippingDocNumber,
					StartTime = fedrd.StartTime,	
					fedrd.StartTimeZoneOffset,
					TimeZone = isnull(al.TimeZone, 'Pacific Standard Time'),
					CurrentTime = GETUTCDATE(),
					CurrentDuration = cast(DATEDIFF(second, fedrd.StartTime, GETUTCDATE()) AS bigint),				
					Note = mdces.ELD_Annotation,
					DistanceInKM = fedrd.DistanceInKM * 0.621371192,
					-- fedrd.FMS_Elog_DailyReportID,
					Duration = dbo.fn_GetDurationBySecond(DATEDIFF(second, fedrd.StartTime, GETUTCDATE())),
					DriverID = al.ID,	
					[Address] = mdces.Address + ' ' + mdces.City + ', ' + mdces.State + ' ' + mdces.PostalCode1,
					mdces.City,
					mdces.State,		
					-- calculate the hours remaining										
					IsInternalState = CASE WHEN 		
												fedrd.IsInterstateLoad = 1	
												OR (fedr.MotorCarrierID IS NOT NULL AND mdces.State <> fmc.State)		
												OR (												
														select count (*)
														from (
															select temp_state.State
															from (
																select mdce2.State
																from @TempDailyReportDetailTbl vdrd2
																	INNER JOIN dbo.MCS_Device_EventSummary mdce2 ON mdce2.ID = vdrd2.MCS_EventSummaryID	and mdce2.State is not null
																where vdrd2.HR_EmployeeID = fedr.HR_EmployeeID
																	and vdrd2.StartTime between DATEADD(day, -7, fedrd.StartTime) and DATEADD(Second, 1, fedrd.StartTime)																
																union all
																select isnull(fmc.State, mdces.State) as State
															) temp_state
															group by temp_state.State
														) temp_state_count
													) > 1		
												THEN cast(1 AS BIT)
												ELSE cast(0 AS BIT) 
											END
					,IsShortHaulException = case when exists (
															select 1
															from [dbo].[FMS_Elog_SpecialDrivingStatus] esds2
																inner join [dbo].[System_CommonList_Item] cli2 on cli2.ID = esds2.System_CommonList_SpecialDrivingStatusID
															where esds2.IsActive = 1
																and esds2.HR_EmployeeID = fedrd.HR_EmployeeID
																and cli2.Keyword = 'ELOG_SpecialStatus_ShortHaulException'
															) then CAST(1 AS bit) else CAST(0 AS bit) end
					,dailyWeeklyReset.DailyResetInterstate
					,dailyWeeklyReset.DailyResetIntrastate
					,dailyWeeklyReset.WeeklyResetInterstate
					,dailyWeeklyReset.WeeklyResetIntrastate	
					,nearestlogs.LastOnDutyEndTime	
					,nearestlogs.LastDrivingEndTime	
					,nearestlogs.Last16HoursStartTime	
					,nearestlogs.LastAdverseDrivingStartTime
					,LatestSplitSleeperBerth = ssb.endtime_ssb	
					,SplitSleeperBerth2ndSegment = ssb.endtime_2nd	
					,DVIRDefect_CurrentDay = (case when dvir.HasDefectCurrentDay is not null and dvir.HasDefectCurrentDay = 1 then dvir.SumDefectCurrentDay else -1 end)
					,DVIRDefect_PastSevenDays  = (case when dvir.HasDefect7Days is not null and dvir.HasDefect7Days = 1 then dvir.SumDefect7Days else -1 end)	
					,mdces.Latitude
					,mdces.Longitude, 
					DiagnosticCode = lastEventCode.EventCode,
					MotorCarrier = fmc.Address + ', ' + fmc.City + ', ' + fmc.State + ' ' + fmc.PostalCode,
					feh2.InterstateMaxOnDutyHours,
					feh2.IntrastateMaxOnDutyHours,			
					feh2.InterstateMultiDayHours1,
					feh2.IntrastateMultiDayHours1,	
					feh2.InterstateMultiDayDays1,
					feh2.IntrastateMultiDayDays1,
					feh2.InterstateMaxDriveHours,
					feh2.IntrastateMaxDriveHours,
					feh2.InterstateDailyResetHours, 
					feh2.IntrastateDailyResetHours,
					feh2.InterstateWeeklyResetHours, 
					feh2.IntrastateWeeklyResetHours,
					feh2.InterstateMaxExemptionHours,
					fedrd.Is16HourRuleException,
					fedrd.IsOversizedLoad,
					fedrd.IsAdverseDriving
				FROM 
					(
						SELECT fedrd2.HR_EmployeeID,  MAX(fedrd2.StartTime) as MaxTime
						FROM @TempDailyReportDetailTbl fedrd2						
							INNER JOIN dbo.HR_Employee he2 ON he2.ID = fedrd2.HR_EmployeeID and he2.IsActive = 1	
						WHERE -- fedrd2.ELD_EventRecordStatus = 1 AND										
							 (
								(@Account_ManagementGroupIDTemp = 0 AND he2.Account_LoginID = @Account_LoginIDTemp)
								OR (
									@Account_ManagementGroupID > 0
									AND EXISTS(
										SELECT 1 
										FROM [dbo].[Master_Account_ManagementGroupMember] amgm							 
										WHERE amgm.ManagementGroupID = @Account_ManagementGroupIDTemp
											AND amgm.UserID = he2.Account_LoginID
									)
								)
							)
						GROUP BY fedrd2.HR_EmployeeID
					) data
					INNER JOIN dbo.FMS_Elog_DailyReport_Detail fedrd ON fedrd.StartTime = data.MaxTime and fedrd.HR_EmployeeID = data.HR_EmployeeID and fedrd.ELD_EventRecordStatus = 1	and fedrd.endtime is null
					INNER JOIN dbo.HR_Employee he ON he.ID = fedrd.HR_EmployeeID and he.IsActive = 1
                    LEFT JOIN dbo.System_CommonList_Item empCommon ON empCommon.ID = he.CommonList_EmployeeTypeID
					INNER JOIN dbo.System_CommonList_Item scli ON scli.ID = fedrd.CommonList_ElogStatusTypeID
					INNER JOIN dbo.FMS_Elog_DailyReport fedr ON fedr.ID = fedrd.FMS_Elog_DailyReportID 					
					INNER JOIN dbo.FMS_Elog_HOSRule feh2 ON feh2.ID = fedr.FMS_Elog_HOSRuleID			
					inner JOIN dbo.MCS_Device_EventSummary mdces ON mdces.ID = fedrd.MCS_EventSummaryID
					inner JOIN dbo.MCS_Device md ON md.ID = mdces.MCS_DeviceID
					LEFT JOIN dbo.FMS_Equipment fe ON fe.ID = mdces.FMS_EquipmentID
					LEFT JOIN dbo.FMS_MotorCarrier fmc on fmc.ID = fedr.MotorCarrierID
					LEFT join (
						select  mdce.[HR_EmployeeID], mdeec.EventCode, count(*) as c
						from [dbo].[MCS_Device_EventSummary] mdce
							inner join (
								select des.[HR_EmployeeID], max(des.DateCreated) as DateCreatedMax, max(des.ReceivedTime) as ReceivedTimeMax--, ROW_NUMBER() OVER(PARTITION BY des.GpsTimeStamp ORDER BY des.GpsTimeStamp desc) AS freq
								from [dbo].[MCS_Device_EventSummary] des 	
									inner join [dbo].[MCS_Device_ELDEventCode] deec on deec.ID = des.[MCS_Device_ELDEventCodeID] 
								where deec.EventType = 7 
								group by des.[HR_EmployeeID]	
							) mdcem on mdcem.HR_EmployeeID = mdce.HR_EmployeeID  and mdcem.DateCreatedMax = mdce.DateCreated and mdcem.ReceivedTimeMax = mdce.ReceivedTime 
							inner join  [dbo].[MCS_Device_ELDEventCode] mdeec on mdeec.ID = mdce.[MCS_Device_ELDEventCodeID] and mdeec.EventType = 7
						--where mdce.hr_employeeid = '155B6282-A4DE-11EA-815A-00155DB47809'
						group by mdce.[HR_EmployeeID], mdeec.EventCode
					) lastEventCode on lastEventCode.HR_EmployeeID = he.ID
					-- account info		DSIMaster	
					INNER JOIN [dbo].[Master_Account_Login] al ON al.ID = he.Account_LoginID and isnull(al.IsDelete, 0) = 0 and al.IsActive = 1	  
					-- first log, latest driving log, latest on-duty log, latest 16 hours rule exception, latest adverse driving 
					inner join (  					
						select hr_employeeid
							--,LastOnDutyStartTime = max(OnDutyStartTime)
							,LastOnDutyEndTime = max(OnDutyEndTime)
							,LastDrivingEndTime = max(DrivingEndTime)
							,Last16HoursStartTime = max(Use16HoursStartTime)
							,LastAdverseDrivingStartTime = max(UseAdverseDrivingStartTime)
						from (
							select hr_employeeid
								, DrivingEndTime = case when Keyword = 'Driving_On_Duty' then EndTime else null end
								--, OnDutyStartTime = case when Keyword = 'On_Duty'	then StartTime else null end
								, OnDutyEndTime = case when Keyword = 'On_Duty' or Keyword = 'Driving_On_Duty' or Keyword = 'ELOG_SpecialStatus_YardMove' then EndTime else null end
								, Use16HoursStartTime = case when Is16HourRuleException = 1 then StartTime else null end
								, UseAdverseDrivingStartTime = case when IsAdverseDriving = 1 then StartTime else null end
							from @TempDailyReportDetailTbl
						) common
						group by hr_employeeid 				
					) nearestlogs  on nearestlogs.hr_employeeid	= he.ID
					-- daily and weekly reset					
					inner join (					
						select hr_employeeid
							,DailyResetInterstate = max(dailyResetInterstate)
							,DailyResetIntrastate = max (dailyResetIntrastate)
							,WeeklyResetInterstate = max(weeklyResetInterstate)
							,WeeklyResetIntrastate = max(weeklyResetIntrastate)	
						from (
							select *
								,hours = 	datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())) / 3600
								,duration_grp = datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())) 
								,dailyResetInterstate = case when isOn = 0 and datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())) >= InterstateDailyResetHours * 3600
									then endtime_grp else null end
								,dailyResetIntrastate = case when isOn = 0 and datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())) >= IntrastateDailyResetHours * 3600
														then endtime_grp else null end
								,weeklyResetInterstate = case when isOn = 0 and datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())) >= InterstateWeeklyResetHours * 3600
														then endtime_grp else null end
								,weeklyResetIntrastate = case when isOn = 0 and datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())) >= IntrastateWeeklyResetHours * 3600
														then endtime_grp else null end
							from (
								select
									hr_employeeid, 
									InterstateDailyResetHours,
									InterstateWeeklyResetHours,
									IntrastateDailyResetHours,
									IntrastateWeeklyResetHours,
									--  keyword, 
									isOn,
									grp, 
									starttime_grp = min(starttime), 
									endtime_grp = max(endtime)
								from (
										select 
											rr.*, 
											count(*) over (partition by grp, isOn) as cnt
										from (
												select *
													,grp = (
														row_number() over (partition by r.hr_employeeid order by r.starttime desc)
															- row_number() over (partition by r.hr_employeeid, r.isOn order by r.starttime desc)
													) 
												from (
													select 
														hr_employeeid, 
														starttime, 			   
														endtime,
														keyword,
														InterstateDailyResetHours = isnull(hos2.InterstateDailyResetHours, @InterstateDailyResetHoursDefault),
														InterstateWeeklyResetHours= isnull(hos2.InterstateWeeklyResetHours, @InterstateWeeklyResetHoursDefault),
														IntrastateDailyResetHours = isnull(hos2.IntrastateDailyResetHours, @IntrastateDailyResetHoursDefault),
														IntrastateWeeklyResetHours = isnull(hos2.IntrastateWeeklyResetHours, @IntrastateWeeklyResetHoursDefault),
														isOn = case when vdrd2.Keyword in ('ELOG_SpecialStatus_PersonalConveyance', 'Off_Duty', 'In_Sleeper') then 0 else 1 end
													from @TempDailyReportDetailTbl vdrd2
														inner join [dbo].[HR_Employee] h2 on h2.ID = vdrd2.hr_employeeid														
														left join [dbo].[FMS_Elog_HOSRule] hos2 on hos2.ID = h2.[FMS_Elog_HOSRuleID] 
													-- where vdrd2.EndTime is not null 
														--and vdrd2.StartTime >= DATEADD(month, -2,getutcdate())													
													--	and fedrd3.StartTime > '2020-11-01'	-- update to start of current day
												) r							
											) rr
										-- where keyword = 'Off_Duty'
										) rrr
								where rrr.cnt >= 1 	--  and hr_employeeid = 'D8B3C916-F729-11E7-8124-00155DB47818'
								group by rrr.hr_employeeid
									,rrr.isOn
									,rrr.grp
									,InterstateDailyResetHours
									,InterstateWeeklyResetHours
									,IntrastateDailyResetHours
									,IntrastateWeeklyResetHours
							) ssss
							--where isOn = 0	  and hr_employeeid='4E361018-83F7-11EA-8130-00155DA8010E'
						) rrrrr 
						group by hr_employeeid
					) dailyWeeklyReset on dailyWeeklyReset.hr_employeeid = he.ID
					INNER join (			 --   [sp_eLog_Dashboard_sb] @Account_ManagementGroupID=24051	
						select HR_EmployeeID
							, HasDefectCurrentDay = max(HasDefectCurrentDay)
							, SumDefectCurrentDay = max(SumDefectCurrentDay)
							, HasDefect7Days = max(HasDefect7Days)
							, SumDefect7Days = max(SumDefect7Days)
						from (
							select HR_EmployeeID
								, HasDefectCurrentDay = max(HasDefectCurrentDay)
								, SumDefectCurrentDay = sum(CountDefectCurrentday)
								, HasDefect7Days = max(HasDefect7Days)
								, SumDefect7Days = sum(CountDefect7Days)
							from ( -- [sp_eLog_Dashboard] @Account_ManagementGroupID=0, @Account_LoginID='35a8c7cb-f253-11ea-815a-00155db47809'
									select  HR_EmployeeID	 = mss2.HR_EmployeeID	 -- ee.ID
									, HasDefectCurrentDay =  (
										case 
											when msq2.Keyword = 'DVIR.DefectCount' and cast(dateadd(hh, isnull(d.[TimeZoneOffset], -7), mss2.[DateRecorded]) as date) = cast(dateadd(hh, isnull(d.[TimeZoneOffset], -7), GETUTCDATE()) as date)
												then 1
											else 0 end
									)
									, CountDefectCurrentday =  (
										case 
											when msq2.Keyword = 'DVIR.DefectCount' and cast(dateadd(hh, isnull(d.[TimeZoneOffset], -7), mss2.[DateRecorded]) as date) = cast(dateadd(hh, isnull(d.[TimeZoneOffset], -7), GETUTCDATE()) as date)
												then CONVERT(INT, isnull(mssr2.Response, 0))
											else 0 end
									)	
									, HasDefect7Days =  (
										case 
											when msq2.Keyword = 'DVIR.DefectCount' and cast(dateadd(hh, isnull(d.[TimeZoneOffset], -7), mss2.[DateRecorded]) as date) between cast(DATEADD(d, -8, dateadd(hh, isnull(d.[TimeZoneOffset], -7), GETUTCDATE())) as date) and cast(dateadd(hh, isnull(d.[TimeZoneOffset], -7), GETUTCDATE()) as date)
												then 1
											else 0 end
									)
									, CountDefect7Days =  (
										case 
											when msq2.Keyword = 'DVIR.DefectCount' and cast(dateadd(hh, isnull(d.[TimeZoneOffset], -7), mss2.[DateRecorded]) as date) between cast(DATEADD(d, -8, dateadd(hh, isnull(d.[TimeZoneOffset], -7), GETUTCDATE())) as date) and cast(dateadd(hh, isnull(d.[TimeZoneOffset], -7), GETUTCDATE()) as date)
												then CONVERT(INT, isnull(mssr2.Response, 0))
											else 0 end
									)						
								from dbo.MCS_Smartform_Submission_Response mssr2
									inner join [dbo].[MCS_Smartform_Submission] mss2 on mss2.ID = mssr2.MCS_Smartform_SubmissionID and mss2.IsActive = 1
									inner join [dbo].[MCS_Smartform_Question] msq2 on msq2.ID = mssr2.MCS_Smartform_QuestionID and msq2.IsActive = 1 and msq2.IsDelete = 0
									inner join [dbo].[MCS_Device] d on d.ID =   mss2.[MCS_DeviceID]	
									--FULL OUTER JOIN [dbo].[HR_Employee] ee ON ee.ID = mss2.HR_EmployeeID		
								where mssr2.IsActive = 1								
									and mssr2.DateCreated >  DATEADD(d, -9, GETUTCDATE())
							) defect
							group by HR_EmployeeID
							UNION
							SELECT HR_EmployeeID = 	ee.ID, null, null, null, null
							FROM [dbo].[HR_Employee]  ee
							where ee.IsActive = 1
						) dvir
						group by HR_EmployeeID	
					) dvir on dvir.HR_EmployeeID = he.ID	
					inner join (	-- check Split Sleeper Berth exception rule	   --  [sp_eLog_Dashboard_sb] @Account_ManagementGroupID=24051
						select HR_EmployeeID	
							,endtime_ssb = max(endtime_ssb)
							,endtime_2nd = max(endtime_2nd)
						from (
							 select hr_employeeid
								,endtime_ssb = max(endtime_ssb)
								,endtime_2nd = max(endtime_grp)
							from (
								select *
									,endtime_ssb = (
										select top 1 endtime_grp
										from (
											select *,
												duration_grp = datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate()))
											from (
												select 
													hr_employeeid,
													keyword, 
													grp, 
													starttime_grp = min(starttime), 
													endtime_grp = max(endtime)
												from (
														select 
															ww.*, 
															count(*) over (partition by grp, Keyword) as cnt
														from (
																select *
																	,grp = (
																		row_number() over (partition by w.hr_employeeid order by w.starttime desc)
																			- row_number() over (partition by w.hr_employeeid, w.Keyword order by w.starttime desc)
																	) 
																from (
																	select 
																		hr_employeeid, 
																		starttime, 
																		endtime,
																		keyword = case when vdrd2.Keyword = 'ELOG_SpecialStatus_PersonalConveyance' then 'Off_Duty' else vdrd2.Keyword end
																	from @TempDailyReportDetailTbl vdrd2
																	where vdrd2.EndTime is not null					
																		and vdrd2.StartTime >= DATEADD(week, -1,getutcdate())	
																		and vdrd2.hr_employeeid = sssss.hr_employeeid
																) w
															) ww
														-- where keyword = 'Off_Duty'
														) www
												where www.cnt >= 1
												group by www.hr_employeeid, www.keyword, www.grp
											) wwww
											where keyword in ('In_Sleeper', 'Off_Duty', 'ELOG_SpecialStatus_PersonalConveyance')
										) wwwww 
										where wwwww.hr_employeeid = sssss.hr_employeeid
											and wwwww.duration_grp >= 2 * 3600 
											and wwwww.duration_grp < 10 * 3600	     
											--and wwwww.starttime_grp <> sssss.starttime_grp
											and wwwww.starttime_grp < sssss.starttime_grp
											and (
												(sssss.keyword = 'In_Sleeper' and sssss.duration_grp >= 7 * 3600 and wwwww.duration_grp + sssss.duration_grp >= 10 * 3600)
												or (
													(sssss.keyword <> 'In_Sleeper' or (sssss.keyword = 'In_Sleeper' and sssss.duration_grp < 7 * 3600))
													and (wwwww.keyword = 'In_Sleeper' and wwwww.duration_grp >= 7 * 3600 and wwwww.duration_grp + sssss.duration_grp >= 10 * 3600)
												)
											)
										order by endtime_grp desc
								)
								from (
									select *,
										h = 	datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())) / 3600,
										duration_grp = datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate()))
			
									from (
										select
											hr_employeeid, 
											keyword, 
											grp, 
											starttime_grp = min(starttime), 
											endtime_grp = max(endtime)
										from (
												select 
													ss.*, 
													count(*) over (partition by grp, Keyword) as cnt
												from (
														select *
															,grp = (
																row_number() over (partition by s.hr_employeeid order by s.starttime desc)
																	- row_number() over (partition by s.hr_employeeid, s.Keyword order by s.starttime desc)
															) 
														from (
															select 
																hr_employeeid, 
																starttime, 			   
																endtime,
																keyword_ori = vdrd2.Keyword,
																keyword = case when vdrd2.Keyword = 'ELOG_SpecialStatus_PersonalConveyance' then 'Off_Duty' else vdrd2.Keyword end
															from @TempDailyReportDetailTbl vdrd2
															where vdrd2.EndTime is not null
																and vdrd2.StartTime >= DATEADD(week, -1,getutcdate())  													
															--	and fedrd3.StartTime > '2020-11-01'	-- update to start of current day
															--and hr_employeeid = 'A21F17FB-A935-11E9-812E-00155DA8010E'
														) s
													) ss
												-- where keyword = 'Off_Duty'
												) sss
										where sss.cnt >= 1
										group by sss.hr_employeeid, sss.keyword, sss.grp
									) ssss
									where keyword in ('In_Sleeper', 'Off_Duty', 'ELOG_SpecialStatus_PersonalConveyance')
								) sssss 
								where sssss.duration_grp >= 2 * 3600 
									and sssss.duration_grp < 10 * 3600
							)ssssss
							where endtime_ssb is not null
							group by hr_employeeid
							
							UNION
							SELECT HR_EmployeeID = 	ee.ID, null	, null
							FROM [dbo].[HR_Employee]  ee
							where ee.IsActive = 1
						) splitsb
						group by HR_EmployeeID  
					) ssb on ssb.hr_employeeid = he.ID	
				)t				
			) tt 			
		) ttt
	)tttt
)ttttt
ORDER BY FirstName + ' ' + LastName		

END



GO
