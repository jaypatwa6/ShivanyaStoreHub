SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

-- =============================================
-- Author:		TRAN.K.H.THANH
-- Create date: 2016/09/20
-- Description:	get data for eLog Dashboard - List Jobsites
-- =============================================
CREATE PROCEDURE [dbo].[sp_eLog_Dashboard_GetJobsiteList]
	 @HR_EmployeeId uniqueidentifier = null,
	 @DateFrom DateTime,
	 @DateTo DateTime
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT	dbo.TMS_Order_Item_Task.Driver_HR_EmployeeID	AS HR_EmployeeID,
			COALESCE(System_CommonList_Item.Name, '')		AS StatusName,
			COALESCE(System_CommonList_Item.Keyword, '')	AS StatusKeyword,
			COALESCE(HR_Employee.FirstName, '')				AS FirstName,
			COALESCE(HR_Employee.LastName, '')				AS LastName,
			CRM_Jobsite.Id									AS JobsiteId,
			CRM_Jobsite.Name								AS JobsiteName,
			CRM_Jobsite.Latitude							AS Latitude,
			CRM_Jobsite.Longitude							AS Longitude,
			COALESCE(CRM_Jobsite.Address, '')				AS JobsiteAddress,
			COALESCE(CRM_Jobsite.City, '')					AS JobsiteCity,
			COALESCE(CRM_Jobsite.State, '')					AS JobsiteState,
			COALESCE(CRM_Jobsite.PostalCode, '')			AS JobsitePostalCode,
			COALESCE(CRM_Jobsite.ContactPhone, '')			AS JobsiteContactPhone,
			COALESCE(CRM_Jobsite.ContactName, '')			AS JobsiteContactName,
			MAX(
			CASE
				WHEN TMS_Order_Event_Summary.MCS_Device_EventSummaryID IS NOT NULL
					THEN MCS_Device_EventSummary.GpsTimeStamp
			END)											AS GpsTimeStamp
	 FROM dbo.TMS_Order_Item_Task
	 INNER JOIN dbo.HR_Employee ON HR_Employee.ID = dbo.TMS_Order_Item_Task.Driver_HR_EmployeeID
	 INNER JOIN dbo.CRM_Jobsite ON CRM_Jobsite.ID = TMS_Order_Item_Task.TaskLocation_CRM_JobsiteID
	 INNER JOIN dbo.TMS_Order_Item ON TMS_Order_Item.ID = TMS_Order_Item_Task.TMS_Order_ItemID
	 INNER JOIN dbo.TMS_Order_Event_Summary ON TMS_Order_Event_Summary.TMS_Order_Item_TaskId = TMS_Order_Item_Task.ID  
	 INNER JOIN dbo.System_CommonList_Item ON System_CommonList_Item.ID = TMS_Order_Event_Summary.CommonList_TMSOrder_Item_Task_StatusId
	 LEFT OUTER JOIN dbo.MCS_Device_EventSummary ON MCS_Device_EventSummary.ID = TMS_Order_Event_Summary.MCS_Device_EventSummaryID
	 WHERE	dbo.TMS_Order_Item_Task.Driver_HR_EmployeeID = @HR_EmployeeId
	 AND	(System_CommonList_Item.Keyword = 'TMS_OrderItemStatus_AtPickup' OR System_CommonList_Item.Keyword = 'TMS_OrderItemStatus_AtDelivery')
	 AND	TMS_Order_Event_Summary.DateCreated BETWEEN @DateFrom AND @DateTo
	 AND	TMS_Order_Event_Summary.MCS_Device_EventSummaryID IS NOT NULL
	 GROUP BY dbo.TMS_Order_Item_Task.Driver_HR_EmployeeID,
		System_CommonList_Item.Name,
		System_CommonList_Item.Keyword,
		HR_Employee.FirstName,
		HR_Employee.LastName,
		CRM_Jobsite.Id,
		CRM_Jobsite.Name,
		CRM_Jobsite.Latitude,
		CRM_Jobsite.Longitude,
		CRM_Jobsite.Address,
		CRM_Jobsite.City,
		CRM_Jobsite.State,
		CRM_Jobsite.PostalCode,
		CRM_Jobsite.ContactPhone,
		CRM_Jobsite.ContactName
	 ORDER BY MAX(
					CASE
						WHEN TMS_Order_Event_Summary.MCS_Device_EventSummaryID IS NOT NULL THEN MCS_Device_EventSummary.GpsTimeStamp
					END
				)
END
GO
