SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

-- =============================================
-- Author:		HIEU - CFB
-- Create date: 3/22/2017
-- Description:	
-- =============================================
-- [sp_eLog_DriverOverview_StatusStatistic] @HR_EmployeeID='05bec806-019e-11e4-80c8-00155db47804', @StartTime='2017-08-01', @EndTime='2018-08-30', @TimezoneOffset=-7
CREATE PROCEDURE [dbo].[sp_eLog_DriverOverview_StatusStatistic]
	@HR_EmployeeID uniqueidentifier,
	@StartTime datetime,
	@EndTime datetime,
	@TimezoneOffset int
AS
BEGIN	
	SET NOCOUNT ON;
	set @StartTime = cast(@StartTime as date)
	set @EndTime = cast(@EndTime as date)
	--select scli.Keyword, 
	--Total = sum(DATEDIFF(s, fedrd.StartTime, isnull(fedrd.EndTime, getutcdate()))) 
	--from [dbo].[FMS_Elog_DailyReport_Detail] fedrd
	--	INNER JOIN dbo.System_CommonList_Item scli ON scli.ID = fedrd.CommonList_ElogStatusTypeID
	--where fedrd.ELD_EventRecordStatus = 1
	--	and fedrd.HR_EmployeeID = @HR_EmployeeID
	--	and fedrd.StartTime between CONVERT(VARCHAR(10), @StartTime,101) and CONVERT(VARCHAR(10), @EndTime,101) 
	--group by scli.Keyword	

	--union all

	select Keyword = case when t.IsApproved = 1 then 'Aprproved' else 'UnApproved' end,
		Total = cast(t.Total as bigint)
	from (
		select 
			IsApproved = convert(varchar(20), isnull(fedrd.IsApproved, 0)), 
			Total = count(*)
		from [dbo].[FMS_Elog_DailyReport_Detail] fedrd	
		where fedrd.ELD_EventRecordStatus = 1
			and fedrd.HR_EmployeeID = @HR_EmployeeID
			--and fedrd.StartTime between CONVERT(VARCHAR(10), @StartTime,101) and CONVERT(VARCHAR(10), @EndTime,101) 
			and (			
				(	cast(DATEADD(hh, @TimezoneOffset, fedrd.StartTime) as date) between @StartTime and dateadd(day, 1, @EndTime) 
					AND cast(DATEADD(hh, @TimezoneOffset, isnull(fedrd.EndTime, getutcdate())) as date) between @StartTime and dateadd(day, 1, @EndTime) 
				)
				OR @StartTime between DATEADD(hh, @TimezoneOffset, fedrd.StartTime) and DATEADD(hh, @TimezoneOffset, fedrd.EndTime)
				OR @EndTime between DATEADD(hh, @TimezoneOffset, fedrd.StartTime) and DATEADD(hh, @TimezoneOffset, fedrd.EndTime)			 
			)
		group by isnull(fedrd.IsApproved, 0)
	)t
	
	union all

	select Keyword = case when tt.IsViolated = 1 then 'Violated' else 'Compliant' end,
		Total = cast(tt.Total as bigint)
	from (
		select t.IsViolated,
		Total = count(*)
		from (
			select scli.Keyword,
				IsViolated = case when exists (select 1 from [dbo].[FMS_Elog_DailyReport_Detail_Violation] fedrdv2 where fedrdv2.FMS_Elog_DailyReport_DetailID = fedrd.ID)
						then 1
					else 0
					end
			from [dbo].[FMS_Elog_DailyReport_Detail] fedrd	
				INNER JOIN dbo.System_CommonList_Item scli ON scli.ID = fedrd.CommonList_ElogStatusTypeID
			where fedrd.ELD_EventRecordStatus = 1
				and fedrd.HR_EmployeeID = @HR_EmployeeID
				--and scli.Keyword in ('On_Duty', 'Driving_On_Duty', 'ELOG_SpecialStatus_YardMove')
				--and fedrd.StartTime between CONVERT(VARCHAR(10), @StartTime,101) and CONVERT(VARCHAR(10), @EndTime,101) 
				and (			
					(	cast(DATEADD(hh, @TimezoneOffset, fedrd.StartTime) as date) between @StartTime and dateadd(day, 1, @EndTime) 
						AND cast(DATEADD(hh, @TimezoneOffset, isnull(fedrd.EndTime, getutcdate())) as date) between @StartTime and dateadd(day, 1, @EndTime) 
					)
					OR @StartTime between DATEADD(hh, @TimezoneOffset, fedrd.StartTime) and DATEADD(hh, @TimezoneOffset, fedrd.EndTime)
					OR @EndTime between DATEADD(hh, @TimezoneOffset, fedrd.StartTime) and DATEADD(hh, @TimezoneOffset, fedrd.EndTime)			 
				)
		)t
		group by t.IsViolated
	)tt

	
	
END






GO
