SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- =============================================
-- Author:		Tuyen
-- Create date: 10/20/2013
-- Description:	create all primary key (column ID) in database
-- =============================================
CREATE procedure [dbo].[sp_ReCreatePrimaryKey]
as
begin
declare @Column nvarchar(100)
set @Column = 'ID' 
	DECLARE pk_cursor CURSOR  FOR 
		SELECT 'IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N''[dbo].'+Table_name+''') AND name = N''PK_'+Table_name+''')
		ALTER TABLE dbo.' + Table_name + ' ADD CONSTRAINT PK_'+ Table_name +'
		PRIMARY KEY (' + @Column + ')'
		FROM INFORMATION_SCHEMA.COLUMNS
		where column_name = @Column 

	OPEN pk_cursor
	declare @addPK    nvarchar(1000)
	FETCH NEXT FROM pk_cursor INTO @addPK
	WHILE @@FETCH_STATUS = 0 
	BEGIN 
   
		EXEC (@addPK)
		FETCH NEXT FROM pk_cursor INTO @addPK
	END 

	CLOSE pk_cursor 
	DEALLOCATE pk_cursor
end
GO
