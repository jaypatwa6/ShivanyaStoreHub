SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- =============================================
-- Author:		HIEU - CFB
-- Last date: Aug 21th 2023
-- Description:	get data for eLog Dashboard
-- =============================================
-- [sp_eLog_Dashboard_Canada] @Account_ManagementGroupID=0, @Account_LoginID='a252e29f-2219-eb11-8140-00155db47807'
create PROCEDURE [dbo].[sp_eLog_Dashboard_Canada]
	@Account_ManagementGroupID bigint,
	@Account_LoginID uniqueidentifier = null
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	SET @Account_ManagementGroupID = ISNULL(@Account_ManagementGroupID, 0)		
	declare @Account_ManagementGroupIDTemp bigint = @Account_ManagementGroupID
	declare @Account_LoginIDTemp uniqueidentifier = @Account_LoginID

	-- get maximum ios mobile app version
	declare @maxiOSMobileAppVersion nvarchar(50)
	select top 1 @maxiOSMobileAppVersion = SoftwareVersion
	from
	(
		select md.SoftwareVersion, md.[DateModified],
		SUBSTRING(md.SoftwareVersion, 0 , CHARINDEX('.', md.SoftwareVersion)) as t1,
		SUBSTRING(md.SoftwareVersion, CHARINDEX('.', md.SoftwareVersion) + 1, charindex('.', md.SoftwareVersion, (charindex('.', md.SoftwareVersion, 1))+1) - 3) as t2
		from [dbo].[MCS_Device] md	
		where md.isactive = 1
			and md.OSType = 'iOS'
			and md.DeviceType = 'Smartphone'
	) t
	order by (case when ISNUMERIC(t.t1) = 1 then CAST(t.t1 AS INT) else CAST(0 AS INT) end) desc, 
		(case when ISNUMERIC(t.t2) = 1 then CAST(t.t2 AS INT) else CAST(0 AS INT) end)  desc,
		DateModified desc
	--select top 1 @maxiOSMobileAppVersion = md.SoftwareVersion
	--from [dbo].[MCS_Device] md	
	--where md.isactive = 1
	--	and md.OSType = 'iOS'
	--	and md.DeviceType = 'Smartphone'
	--order by md.SoftwareVersion desc

	-- get maximum android mobile app version
	declare @maxAndroidMobileAppVersion nvarchar(50)
	select top 1 @maxAndroidMobileAppVersion = SoftwareVersion
	from
	(
		select md.SoftwareVersion, md.[DateModified],
		SUBSTRING(md.SoftwareVersion, 0 , CHARINDEX('.', md.SoftwareVersion)) as t1,
		SUBSTRING(md.SoftwareVersion, CHARINDEX('.', md.SoftwareVersion) + 1, charindex('.', md.SoftwareVersion, (charindex('.', md.SoftwareVersion, 1))+1) - 3) as t2
		from [dbo].[MCS_Device] md	
		where md.isactive = 1
			and md.OSType = 'Android'
			and md.DeviceType = 'Smartphone'
	) t
	order by (case when ISNUMERIC(t.t1) = 1 then CAST(t.t1 AS INT) else CAST(0 AS INT) end) desc, 
		(case when ISNUMERIC(t.t2) = 1 then CAST(t.t2 AS INT) else CAST(0 AS INT) end)  desc,
		DateModified desc	
	--select top 1 @maxAndroidMobileAppVersion = md.SoftwareVersion
	--from [dbo].[MCS_Device] md	
	--where md.isactive = 1
	--	and md.OSType = 'Android'
	--	and md.DeviceType = 'Smartphone'
	--order by md.SoftwareVersion desc

	 -- Create Temporary Table for nearest 3 months
	DECLARE @TempDVIRtbl AS TABLE (
			HR_EmployeeID uniqueidentifier,
			DateRecorded datetime, 
			Response int
	);
	INSERT INTO @TempDVIRtbl
	select mss2.HR_EmployeeID, mss2.[DateRecorded], CONVERT(INT, isnull(mssr2.Response, 0)) 
	from dbo.MCS_Smartform_Submission_Response mssr2
		inner join [dbo].[MCS_Smartform_Submission] mss2 on mss2.ID = mssr2.MCS_Smartform_SubmissionID and mss2.IsActive = 1
		inner join [dbo].[MCS_Smartform_Question] msq2 on msq2.ID = mssr2.MCS_Smartform_QuestionID and msq2.IsActive = 1 and msq2.IsDelete = 0
	where mssr2.IsActive = 1 
		--and mss2.HR_EmployeeID = zz.HR_EmployeeID							
		and msq2.Keyword = 'DVIR.DefectCount'
		and mss2.[DateRecorded] between DATEADD(d, -9, GETUTCDATE()) and GETUTCDATE()	


	select *,
		Is16HourRuleExceptionView = CAST(0 AS bit)
		, IsAdverseDrivingView = CAST(0 AS bit)
		, IsOversizedLoad
		, IsAdverseDriving
		, SecondRemainingOnDuty = CAST(0 AS bigint)
		, TotalSecondOnDuty = 0
		, SecondRemainingDailyReset = CAST(0 AS bigint)		
		, TotalSecondDailyReset =  0
		, SecondRemainingDriving = CAST(0 AS bigint)
		, TotalSecondDriving = 	0
		, SecondRemainingBreak = CAST(0 AS bigint)	
		, TotalSecondBreak = (8 * 3600)
		, SecondRemainingBreakReset = CAST(0 AS bigint)
		, SecondRemainingCycle = CAST(0 AS bigint)
		, IsApplyRollingCycle = CAST(0 AS bit)
		, StartTimeOfWeek
		, TotalSecondCycle = 0
		, SecondRemainingWeeklyReset = CAST(0 AS bigint)		
		, TotalSecondWeeklyReset = 0
		, DVIRDefect_CurrentDay = 
		(
			case when exists (
				select 1 
				from @TempDVIRtbl tempDVIR		
				where tempDVIR.HR_EmployeeID = zz.HR_EmployeeID								
					and cast(dateadd(hh, zz.StartTimeZoneOffset, tempDVIR.[DateRecorded]) as date) = cast(dateadd(hh, zz.StartTimeZoneOffset, GETUTCDATE()) as date)														
				) then (
					select sum(tempDVIR.Response)
					from @TempDVIRtbl tempDVIR		
					where tempDVIR.HR_EmployeeID = zz.HR_EmployeeID								
						and cast(dateadd(hh, zz.StartTimeZoneOffset, tempDVIR.[DateRecorded]) as date) = cast(dateadd(hh, zz.StartTimeZoneOffset, GETUTCDATE()) as date)	
				) else -1 end
		)					
		,DVIRDefect_PastSevenDays = 
		(
			case when exists (
				select 1
				from @TempDVIRtbl tempDVIR	
				where tempDVIR.HR_EmployeeID = zz.HR_EmployeeID		
					and cast(dateadd(hh, zz.StartTimeZoneOffset, tempDVIR.[DateRecorded]) as date) between cast(DATEADD(d, -8, dateadd(hh, zz.StartTimeZoneOffset, GETUTCDATE())) as date) and cast(dateadd(hh, zz.StartTimeZoneOffset, GETUTCDATE()) as date)	
		
			) then (
				select sum(tempDVIR.Response)
				from @TempDVIRtbl tempDVIR	
				where tempDVIR.HR_EmployeeID = zz.HR_EmployeeID		
					and cast(dateadd(hh, zz.StartTimeZoneOffset, tempDVIR.[DateRecorded]) as date) between cast(DATEADD(d, -8, dateadd(hh, zz.StartTimeZoneOffset, GETUTCDATE())) as date) and cast(dateadd(hh, zz.StartTimeZoneOffset, GETUTCDATE()) as date)	
				) else -1 end 
		) 		
	from (
		SELECT *,	
			-- get all times before last ON point in a day 
			DailyOnDuty = 0,
			DailyDriving = 0, 
			WeeklyOnduty = 0,
			LastEndTimeOn = NULL,
			LastEndTimeDriving = NULL,
			StartTimeOfRolling = NULL,
			StartTimeOf16HourRuleException = NULL,
			StartTimeOfAdverseDriving = NULL		
		FROM (
			SELECT 			
				FirstName = isnull(he.FirstName, ''), 
				LastName = isnull(he.LastName, ''), 	
				NotExempt = 0,--isnull(he.IsExemptRestBreak, 0),
				al.UserName,	
				he.Email,
                empCommon.Keyword as EmployeeType,
				he.StartingTime,
				HasContact = case when exists(select 1 from [dbo].[HR_Employee_Phone] hep where hep.HR_EmployeeID = he.ID and hep.IsActive = 1) then 1 else 0 end,
				fedrd.HR_EmployeeID,
				OSType = md.OSType,
				md.OSVersion,
				DeviceType = isnull(md.DeviceType, 'Unknown'), -- Smartphone, Black box (like Atrack, Squarell, GL505... devices), Bluetooth and Unknown			
				md.SoftwareVersion,
				MaximumSoftwareVersion = case when md.OSType = 'Android' and md.DeviceType = 'Smartphone' then @maxAndroidMobileAppVersion when md.OSType = 'iOS' and md.DeviceType = 'Smartphone' then @maxiOSMobileAppVersion else '' end,
				md.SerialNumber,
				-- 0: Not use, 1: working, 2: problem
				DeviceGPS = case when isnull(md.Latitude, 0) = 0 OR isnull(md.Longitude, 0) = 0 then 1 else 0 end, 				
				-- 0: Not use, 1: working, 2: problem
				DeviceBlueTooth = 0,				
					--CASE WHEN mdces.MCS_OriginalDeviceID is not null 			
					--THEN 
					--	CASE WHEN mdces.MalfunctionCode in ('2', 'E')
					--				AND EXISTS (
					--						select 1 
					--						from MCS_Device_ELDEventCode mdec2 
					--						where mdec2.ID = mdces.MCS_Device_ELDEventCodeID
					--							and mdec2.EventType = 7
					--							and mdec2.EventCode = 3
					--				)
					--	THEN 
					--	2
					--	ELSE 1 END
					--ELSE 0 END,		
				--cast(0 AS BIT),
				BatteryLevel = isnull(md.BatteryLevel, 0), 
				Keyword = scli.Keyword,
                PermitStatus = case
							when permit.Keyword = 'Permit_None' then ''
								when permit.Keyword = 'Permit_Special' then 'SP'
								when permit.Keyword = 'Permit_NonOilWell' then 'NO'
								when permit.Keyword = 'Permit_OilWell' then 'OW'
								else '' 						
							end,
				CurrentStatus = case 
							when scli.Keyword = 'On_Duty' then 'ON'--'On Duty (ON)' 
								when scli.Keyword = 'Driving_On_Duty' then 'D'--'Driving (D)' 
								when scli.Keyword = 'In_Sleeper' then 'SB'--'Sleeper Berth (SB)' 
								when scli.Keyword = 'Off_Duty' then 'OFF'--'Off Duty (OFF)' 
								when scli.Keyword = 'ELOG_SpecialStatus_PersonalConveyance' then 'PC'--'Personal Conveyance (PC)' 
								when scli.Keyword = 'ELOG_SpecialStatus_YardMove' then 'YM'--'Yard Move (YM)' 
								else '' 						
							end,
				EquipmentNumber = fe.Number,
				fedrd.ID,
				fedrd.ShippingDocNumber,
				StartTime = fedrd.StartTime,	
				fedrd.StartTimeZoneOffset,
				TimeZone = isnull(al.TimeZone, 'Pacific Standard Time'),
				CurrentTime = GETUTCDATE(),
				CurrentDuration = cast(DATEDIFF(second, fedrd.StartTime, GETUTCDATE()) AS bigint),
				StartTimeOfDay = NULL,
				StartTimeOfWeek = NULL,
				Note = mdces.ELD_Annotation,
				DistanceInKM = fedrd.DistanceInKM * 0.621371192,
				TotalDistanceInKM = (SELECT SUM(fedrd2.DistanceInKM) FROM dbo.FMS_Elog_DailyReport_Detail fedrd2 WHERE fedrd2.FMS_Elog_DailyReportID = fedr.ID and fedrd2.ELD_EventRecordStatus = 1	 GROUP BY fedrd2.FMS_Elog_DailyReportID) * 0.621371192,
				fedrd.FMS_Elog_DailyReportID,
				Duration = dbo.fn_GetDurationBySecond(DATEDIFF(second, fedrd.StartTime, GETUTCDATE())),
				DriverID = al.ID,	
				[Address] = mdces.Address + ' ' + mdces.City + ', ' + mdces.State + ' ' + mdces.PostalCode1,
				mdces.City,
				mdces.State,		
				-- calculate the hours remaining										
				IsInternalState = case 
							when locationDriver.Keyword = 'HOS_North60N' then cast(0 AS BIT)
								when locationDriver.Keyword = 'HOS_South60N' then cast(1 AS BIT)
								else cast(0 AS BIT)						
							end,			
				mdces.Latitude,
				mdces.Longitude,
				DiagnosticCode = lastEventCode.EventCode,
				MotorCarrier = fmc.Address + ', ' + fmc.City + ', ' + fmc.State + ' ' + fmc.PostalCode,
				feh2.InterstateMaxOnDutyHours,
				feh2.IntrastateMaxOnDutyHours,			
				feh2.InterstateMultiDayHours1,
				feh2.IntrastateMultiDayHours1,	
				feh2.InterstateMultiDayDays1,
				feh2.IntrastateMultiDayDays1,
				feh2.InterstateMaxDriveHours,
				feh2.IntrastateMaxDriveHours,
				feh2.InterstateDailyResetHours,
				feh2.IntrastateDailyResetHours,
				feh2.InterstateWeeklyResetHours,
				feh2.IntrastateWeeklyResetHours,
				feh2.InterstateMaxExemptionHours,
				fedrd.Is16HourRuleException,
				fedrd.IsOversizedLoad,
				fedrd.IsAdverseDriving
			FROM 
				(
					SELECT fedrd2.HR_EmployeeID,  MAX(fedrd2.StartTime) as MaxTime
					FROM dbo.FMS_Elog_DailyReport_Detail fedrd2						
						INNER JOIN dbo.HR_Employee he2 ON he2.ID = fedrd2.HR_EmployeeID and he2.IsActive = 1	
					WHERE fedrd2.ELD_EventRecordStatus = 1										
						AND (
							(@Account_ManagementGroupIDTemp = 0 AND he2.Account_LoginID = @Account_LoginIDTemp)
							OR (
								@Account_ManagementGroupID > 0
								AND EXISTS(
									SELECT 1 
									FROM [dbo].[Master_Account_ManagementGroupMember] amgm							 
									WHERE amgm.ManagementGroupID = @Account_ManagementGroupIDTemp
										AND amgm.UserID = he2.Account_LoginID
								)
							)
						)
					GROUP BY fedrd2.HR_EmployeeID
				) data
				INNER JOIN dbo.FMS_Elog_DailyReport_Detail fedrd ON fedrd.StartTime = data.MaxTime and fedrd.HR_EmployeeID = data.HR_EmployeeID and fedrd.ELD_EventRecordStatus = 1	and fedrd.endtime is null
				INNER JOIN dbo.HR_Employee he ON he.ID = fedrd.HR_EmployeeID and he.IsActive = 1	
                LEFT JOIN dbo.System_CommonList_Item empCommon ON empCommon.ID = he.CommonList_EmployeeTypeID	
				INNER JOIN dbo.System_CommonList_Item scli ON scli.ID = fedrd.CommonList_ElogStatusTypeID
				INNER JOIN dbo.FMS_Elog_DailyReport fedr ON fedr.ID = fedrd.FMS_Elog_DailyReportID  
				INNER JOIN dbo.FMS_Elog_HOSRule feh2 ON feh2.ID = fedr.FMS_Elog_HOSRuleID			
				LEFT JOIN dbo.MCS_Device_EventSummary mdces ON mdces.ID = fedrd.MCS_EventSummaryID
				LEFT JOIN dbo.MCS_Device md ON md.ID = mdces.MCS_DeviceID
				LEFT JOIN dbo.FMS_Equipment fe ON fe.ID = mdces.FMS_EquipmentID
				LEFT JOIN dbo.FMS_MotorCarrier fmc on fmc.ID = fedr.MotorCarrierID
                LEFT JOIN dbo.System_CommonList_Item permit ON permit.ID = fedrd.CommonList_ElogPermitStatusID
				LEFT JOIN dbo.System_CommonList_Item locationDriver ON locationDriver.ID = fedrd.CommonList_ZoneID
				LEFT join (
					select  mdce.[HR_EmployeeID], mdeec.EventCode, count(*) as c
					from [dbo].[MCS_Device_EventSummary] mdce
						inner join (
							select des.[HR_EmployeeID], max(des.DateCreated) as DateCreatedMax--, ROW_NUMBER() OVER(PARTITION BY des.GpsTimeStamp ORDER BY des.GpsTimeStamp desc) AS freq
							from [dbo].[MCS_Device_EventSummary] des 	
								inner join [dbo].[MCS_Device_ELDEventCode] deec on deec.ID = des.[MCS_Device_ELDEventCodeID] 
							where deec.EventType = 7 
							group by des.[HR_EmployeeID]	
						) mdcem on mdcem.HR_EmployeeID = mdce.HR_EmployeeID  and mdcem.DateCreatedMax = mdce.DateCreated
						inner join  [dbo].[MCS_Device_ELDEventCode] mdeec on mdeec.ID = mdce.[MCS_Device_ELDEventCodeID] and mdeec.EventType = 7
					--where mdce.hr_employeeid = '155B6282-A4DE-11EA-815A-00155DB47809'
					group by mdce.[HR_EmployeeID], mdeec.EventCode
				) lastEventCode on lastEventCode.HR_EmployeeID = he.ID
				-- account info		DSIMaster	
				INNER JOIN [dbo].[Master_Account_Login] al ON al.ID = he.Account_LoginID and isnull(al.IsDelete, 0) = 0 and al.IsActive = 1
		) t			
		
	)zz
	ORDER BY FirstName + ' ' + LastName	

END

GO
