SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[SP_Order_UpdateMcsTaskContact](@userId AS UNIQUEIDENTIFIER, @orderId AS UNIQUEIDENTIFIER, @mcsTaskId AS UNIQUEIDENTIFIER, @tmsTaskId AS UNIQUEIDENTIFIER)
AS
BEGIN
	DECLARE @tmsTaskTypeId AS UNIQUEIDENTIFIER, @tmsTaskTypeKeyword AS NVARCHAR(50), @mcsTaskType AS NVARCHAR(50);
	DECLARE @contactPhone AS NVARCHAR(50), @contactExtension AS NVARCHAR(50), @contactName AS NVARCHAR(50), @mcsStopLocationInstructions NVARCHAR(4000);
	SELECT @tmsTaskTypeId = CommonList_TMSOrderItemTaskTypeId FROM TMS_Order_Item_Task WHERE ID = @tmsTaskId;
	SELECT @tmsTaskTypeKeyword = keyword from System_CommonList_Item WHERE ID = @tmsTaskTypeId;
	--get jobsite info
	SELECT @contactPhone = ContactPhone, @contactExtension = ContactExtension, @contactName = ContactName
	FROM CRM_Jobsite WHERE ID = (SELECT TaskLocation_CRM_JobsiteID FROM TMS_Order_Item_Task WHERE ID = @tmsTaskId);

	IF (@tmsTaskTypeKeyword = 'TMS_Order_Type_Pickup')
	BEGIN --pickup task
		--get pickup jobsite note		
		SET @mcsStopLocationInstructions = (SELECT OriginJobsiteNotes FROM TMS_Order WHERE ID = @OrderId);
	END
	IF (@tmsTaskTypeKeyword = 'TMS_Order_Type_Delivery')
	BEGIN --delivery task
		--get delivery jobsite note	
		SET @mcsStopLocationInstructions = (SELECT DestinationJobsiteNotes FROM TMS_Order WHERE ID = @OrderId);
	END	
	
	DECLARE @customerContactName NVARCHAR(101), @customerContactPhone NVARCHAR(300);
	SET @customerContactName = (SELECT CONCAT(FirstName, ' ', LastName) FROM CRM_Customer_Contact WHERE ID = (SELECT CRM_Customer_ContactID FROM TMS_Order WHERE ID = @OrderId));
	SET @customerContactPhone = (SELECT TOP 1 CONCAT(PhoneNumber, ' ext ', Extension) FROM CRM_Customer_Contact_Phone 
										WHERE CRM_Customer_ContactID = (SELECT CRM_Customer_ContactID FROM TMS_Order WHERE ID = @OrderId)
										ORDER BY IsPrimary DESC);
	IF EXISTS (SELECT ID FROM [dbo].[MCS_Trip_Stop_Task_Contact] WHERE MCS_Trip_Stop_TaskID = @mcsTaskId)
	BEGIN
		--update for jobsite contact
		UPDATE MCS_Trip_Stop_Task_Contact 
		SET Name = @contactName, PhoneNumber = CONCAT(@contactPhone, ' ext ', @contactExtension), [Description] = @tmsTaskTypeKeyword,
		ModifiedBy = @userId, CreatedBy = @userId, DateCreated = GETUTCDATE(), DateModified = GETUTCDATE(), IsDeleted = 0
		WHERE MCS_Trip_Stop_TaskID = @mcsTaskId
		--update for customer contact
		IF (@customerContactPhone IS NULL)
			SET @customerContactPhone = '';
		INSERT INTO MCS_Trip_Stop_Task_Contact 
		(Name, PhoneNumber, [Description], MCS_Trip_Stop_TaskID, ModifiedBy, CreatedBy, DateCreated, DateModified, IsDeleted)
		VALUES (@customerContactName, @customerContactPhone, 'CUSTOMER', @mcsTaskId, @userId, @userId, GETUTCDATE(), GETUTCDATE(), 0);
	END
	ELSE
	BEGIN
		--create new for jobsite contact
		INSERT INTO MCS_Trip_Stop_Task_Contact 
		(Name, PhoneNumber, [Description], MCS_Trip_Stop_TaskID, ModifiedBy, CreatedBy, DateCreated, DateModified, IsDeleted)
		VALUES (@contactName, CONCAT(@contactPhone, ' ext ', @contactExtension), @tmsTaskTypeKeyword, @mcsTaskId, @userId, @userId, GETUTCDATE(), GETUTCDATE(), 0);
		--create new for customer contact
		IF (@customerContactPhone IS NULL)
			SET @customerContactPhone = '';
		INSERT INTO MCS_Trip_Stop_Task_Contact 
		(Name, PhoneNumber, [Description], MCS_Trip_Stop_TaskID, ModifiedBy, CreatedBy, DateCreated, DateModified, IsDeleted)
		VALUES (@customerContactName, @customerContactPhone, 'CUSTOMER', @mcsTaskId, @userId, @userId, GETUTCDATE(), GETUTCDATE(), 0);
	END
END

GO
