SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- =============================================
-- Author:		Huan Nguyen
-- Create date: 5/18/2016 8:50:28 PM
-- Description: Speed Report
-- =============================================
CREATE PROCEDURE [dbo].[sp_SpeedReport]
 @startdate datetime,
 @enddate datetime,
 @timezone float,
 @browser_colName nvarchar(256),
 @browser_colValue nvarchar(max)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
select * from (
	select isnull(FMS_Equipment.Number,'') as Equipment,concat(HR_Employee.FirstName,' ',HR_Employee.LastName) as Driver,
cast(round(isnull(MCS_Device_CommEvent.VelocityInKPH,0) * 0.621371192,2) as smallint) as Velocity,
DATEADD(hour, @timezone,MCS_Device_CommEvent.GpsTimeStamp) as GpsTimeStamp,
concat(MCS_Device_CommEvent.Address,' ',MCS_Device_CommEvent.City,' ',MCS_Device_CommEvent.State) as Address
,isnull(MCS_Device_CommEvent.City,'') as City
,isnull(MCS_Device_CommEvent.State,'') as State
from MCS_Device_CommEvent 
left join HR_Employee on HR_Employee.Id = MCS_Device_CommEvent.HR_EmployeeID  
left join FMS_Equipment on FMS_Equipment.Id = MCS_Device_CommEvent.FMS_EquipmentID  
where  MCS_Device_CommEvent.IsMoving = 1 and MCS_Device_CommEvent.VelocityInKPH > 0 and MCS_Device_CommEvent.GpsTimeStamp between @startdate and @enddate) as a
WHERE CASE @browser_colName 
				WHEN 'Driver' THEN Driver
				WHEN 'Equipment' THEN Equipment
				WHEN 'City' THEN City
				WHEN 'State' THEN State
				ELSE ''
			END = @browser_colValue
	order by Equipment,Driver,GpsTimeStamp

END
GO
