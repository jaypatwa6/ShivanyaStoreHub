SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[SP_Calendar_DispatchNewTask](@userId AS UNIQUEIDENTIFIER, @orderId AS UNIQUEIDENTIFIER, @OrderItemId AS UNIQUEIDENTIFIER, @orderItemTaskId AS UNIQUEIDENTIFIER)
AS
BEGIN
	DECLARE @existingTripStopId AS UNIQUEIDENTIFIER, @existingTripStopTaskId AS UNIQUEIDENTIFIER;
	EXEC SP_Calendar_FindExistedMcsStop @orderItemTaskId, @orderId, @returnedMcsStopId = @existingTripStopId OUTPUT;
	
	IF (@existingTripStopId IS NOT NULL)
	BEGIN
		EXEC SP_Calendar_MergeMcsStop @userId, @orderItemTaskId, @orderId, @orderItemId, @returnedMcsTaskId = @existingTripStopTaskId OUTPUT;
	END
	IF (@existingTripStopId IS NULL)
	BEGIN -- CREATE NEW MCS STOP AND TASK
		--create new mcs trip (just create new trip if it is not exists)
		DECLARE @mcsTripId AS UNIQUEIDENTIFIER;
		EXEC SP_Calendar_CreateNewMcsTrip @userId, @orderItemTaskId, @returnedMcsTripId = @mcsTripId OUTPUT;
		EXEC SP_Calendar_CreateNewMcsStop @userId, @mcsTripId, @orderId, @orderItemId, @orderItemTaskId, @returnedMcsStopId = @existingTripStopId OUTPUT;
		EXEC SP_Calendar_CreateNewMcsTask @userId, @existingTripStopId, @orderId, @orderItemId, @orderItemTaskId, @returnedMcsTaskId = @existingTripStopTaskId OUTPUT;
	END
	--UPDATE TMS TASK
	UPDATE TMS_Order_Item_Task SET MCS_Trip_Stop_TaskID = @existingTripStopTaskId WHERE ID = @OrderItemTaskId;
	--UPDATE/CREATE TASK CONTACT
	EXEC SP_Calendar_UpdateMcsTaskContact @userId, @orderId, @existingTripStopTaskId, @orderItemTaskId;
END
GO
