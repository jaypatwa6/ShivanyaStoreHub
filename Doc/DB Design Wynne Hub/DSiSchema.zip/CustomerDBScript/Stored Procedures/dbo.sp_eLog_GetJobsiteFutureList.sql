SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

-- =============================================
-- Author:		Thanh T.K.H
-- Create date: 10/25/2016
-- Description:	Get Jobsite Future List
-- =============================================
CREATE PROCEDURE [dbo].[sp_eLog_GetJobsiteFutureList]
	 @Account_LoginId uniqueidentifier,
	 @FMS_Elog_DailyReportID uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @DateFrom DateTime
	SET		@DateFrom = (
							SELECT	TOP 1	StartTime
							FROM	FMS_Elog_DailyReport
							WHERE	ID = @FMS_Elog_DailyReportID 
							AND		CreatedBy = @Account_LoginId
							ORDER BY StartTime DESC
						)

	SELECT	DISTINCT
			B.PromiseTime											AS GpsTimeStamp,
			B.Latitude												AS Latitude,
			B.Longitude												AS Longitude,
            COALESCE(E.Name, COALESCE(B.Name, ''))					AS JobsiteName,
			COALESCE(E.Address, COALESCE(B.Address, ''))			AS JobsiteAddress,
			COALESCE(E.City, COALESCE(B.City, ''))					AS JobsiteCity,
			COALESCE(E.State, COALESCE(B.State, ''))				AS JobsiteState,
			COALESCE(E.PostalCode, COALESCE(B.PostalCode, ''))		AS JobsitePostalCode,
			COALESCE(E.ContactPhone, COALESCE(B.PhoneNumber, ''))	AS JobsiteContactPhone,
			COALESCE(E.ContactName, COALESCE(B.Contact, ''))		AS JobsiteContactName
	FROM	MCS_Trip A
	INNER JOIN MCS_Trip_Stop B ON B.MCS_TripID = A.ID
	INNER JOIN MCS_Trip_Stop_Task C ON C.MCS_Trip_StopID = B.ID
	INNER JOIN System_CommonList_Item D ON D.ID = C.CommonList_TaskStatusID
	LEFT OUTER JOIN CRM_Jobsite E ON E.ID = B.CRM_JobsiteID
	WHERE
		(
			D.Keyword <> 'Complete'
			AND D.Keyword <> 'Cancel'
			AND D.Keyword <> 'Paused'
		)
		AND (B.Latitude IS NOT NULL AND B.Latitude <> 0)
		AND (B.Longitude IS NOT NULL  AND B.Longitude <> 0)
		AND A.AssignedToEmployeeID IN
									(
										SELECT DISTINCT HR_EmployeeID
										FROM FMS_Elog_DailyReport_Detail
										WHERE CreatedBy = @Account_LoginId
										AND FMS_Elog_DailyReportID = @FMS_Elog_DailyReportID
										GROUP BY HR_EmployeeID
									)
		AND B.PromiseTime >= @DateFrom
	ORDER BY B.PromiseTime
END
GO
