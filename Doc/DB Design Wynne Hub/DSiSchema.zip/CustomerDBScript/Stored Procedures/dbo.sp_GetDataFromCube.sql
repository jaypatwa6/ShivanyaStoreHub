SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[sp_GetDataFromCube] (@mdx_query AS VARCHAR(MAX), @linked_server AS VARCHAR(500), @columns AS VARCHAR(MAX), @filter AS VARCHAR(MAX) = NULL)
AS
BEGIN
	DECLARE @open_query AS NVARCHAR(MAX)
	SET @open_query = 'SELECT ' + @columns + ' FROM OpenQuery ("' + @linked_server + '",''' + @mdx_query + ''')'
	IF @filter IS NULL SET @filter = ''
	SET @open_query = @open_query + ' ' + @filter
	EXEC (@open_query)	
END
GO
