SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[SP_Order_ReDispatchTask](@userId AS UNIQUEIDENTIFIER, @OrderId AS UNIQUEIDENTIFIER, @OrderItemId AS UNIQUEIDENTIFIER, @OrderItemTaskId AS UNIQUEIDENTIFIER)
AS
BEGIN
	DECLARE @mcsTasktatusCompletedId AS UNIQUEIDENTIFIER, @mcsTaskStatusCanceledId AS UNIQUEIDENTIFIER;
	SELECT @mcsTaskStatusCanceledId = ID FROM System_CommonList_Item WHERE Keyword = 'Cancel' and System_CommonListID = (SELECT ID FROM System_CommonList WHERE keyword = 'Dispatch_TaskStatus');
	SELECT @mcsTasktatusCompletedId = ID FROM System_CommonList_Item WHERE Keyword = 'Complete' and System_CommonListID = (SELECT ID FROM System_CommonList WHERE keyword = 'Dispatch_TaskStatus');
	--GET tmsTask information
	DECLARE @tmsDriverId AS UNIQUEIDENTIFIER, @tmsTaskTypeId AS UNIQUEIDENTIFIER, @mcsTaskId AS UNIQUEIDENTIFIER;
	SELECT @tmsTaskTypeId = CommonList_TMSOrderItemTaskTypeId, @tmsDriverId = Driver_HR_EmployeeID, @mcsTaskId = MCS_Trip_Stop_TaskID FROM TMS_Order_Item_Task WHERE ID = @OrderItemTaskId;
	--GET mcsTask information
	DECLARE @mcsTaskTypeId AS UNIQUEIDENTIFIER;
	SELECT @mcsTaskTypeId = CommonList_OrderTypeID FROM MCS_Trip_Stop_Task WHERE ID = @mcsTaskId;
	--GET mcsStop
	DECLARE @tripStopId AS UNIQUEIDENTIFIER = (SELECT MCS_Trip_StopID FROM MCS_Trip_Stop_Task where ID = @mcsTaskId);

	--Check type of tmsTask and mcsTask
	DEClARE @tmsTaskTypeKeyword AS NVARCHAR(50), @mcsTaskTypeKeyword AS NVARCHAR(50), @isSameTaskType AS BIT = 0;
	SET @tmsTaskTypeKeyword = (SELECT Keyword FROM System_CommonList_Item where ID = @tmsTaskTypeId)
	SET @mcsTaskTypeKeyword = (SELECT Keyword FROM System_CommonList_Item where ID = @mcsTaskTypeId)
	IF ((@tmsTaskTypeKeyword = 'TMS_Order_Type_Pickup' AND @mcsTaskTypeKeyword = 'Pickup')
	OR (@tmsTaskTypeKeyword = 'TMS_Order_Type_Delivery' AND @mcsTaskTypeKeyword = 'Delivery'))
	BEGIN
		SET @isSameTaskType = 1;
	END

	--get mcsData and tmsData
	DECLARE @mcsDriverId AS UNIQUEIDENTIFIER, @mcsPromiseTime AS DATETIME, @mcsLat AS DECIMAL (9,6), @mcsLong AS DECIMAL (9,6), @mcsAddress NVARCHAR(255);
	DECLARE @tmsPromiseTime AS DATETIME, @tmsLat AS DECIMAL (9,6), @tmsLong AS DECIMAL (9,6), @tmsAddress NVARCHAR(255);
	IF (@isSameTaskType = 1)
	BEGIN -- get mcs data
		SET @mcsDriverId = (SELECT AssignedToEmployeeID FROM MCS_Trip WHERE ID = (SELECT MCS_TripID FROM MCS_Trip_Stop WHERE ID = @tripStopId));
		SELECT @mcsPromiseTime = PromiseTime, @mcsLat = Latitude, @mcsLong = Longitude, @mcsAddress = [Address] FROM MCS_Trip_Stop WHERE ID = @tripStopId;
	END
	ELSE
	BEGIN
		--delete old mcsTask
		EXEC SP_Order_DeleteMcsTask @mcsTaskId, @userId;
		--create new mcsTask with tmsTask type
		SET @mcsTaskId = NULL;
	END

	--variables to hold infor from jobsite
	DECLARE @address AS NVARCHAR(255), @lat AS DECIMAL(9,6), @long AS DECIMAL(9,6);
	SELECT  @tmsAddress = [Address], @tmsLat =Latitude , @tmsLong = Longitude
	FROM CRM_Jobsite WHERE ID = (SELECT TaskLocation_CRM_JobsiteID FROM TMS_Order_Item_Task WHERE ID = @OrderItemTaskId);
	--get tmsData
	SELECT @tmsDriverId = Driver_HR_EmployeeID, @tmsPromiseTime = ScheduledTime FROM TMS_Order_Item_Task WHERE ID = @OrderItemTaskId;

	--check changing between tmsTask and mcsTask
	IF (@tmsDriverId = @mcsDriverId AND @tmsPromiseTime = @mcsPromiseTime AND @tmsAddress = @mcsAddress AND @tmsLat = @mcsLat AND @tmsLong = @mcsLong)
	BEGIN -- no change
		--check @tripStopTaskId to create new mcsTask or just need to update
		IF (@mcsTaskId IS NULL OR @mcsTaskId = '00000000-0000-0000-0000-000000000000')
		BEGIN -- create new mcsTask base on tmsTask type
			EXEC SP_Order_CreateNewMcsTask @userId, @tripStopId, @orderId, @orderItemId, @orderItemTaskId, @returnedMcsTaskId = @mcsTaskId OUTPUT;
			UPDATE TMS_Order_Item_Task SET MCS_Trip_Stop_TaskID = @mcsTaskId WHERE ID = @OrderItemTaskId;
		END
		ELSE
		BEGIN -- update task type of mcsTask because tmsTask and mcsTask type are not the same
			DECLARE @mcsTaskType AS NVARCHAR(50);
			IF (@tmsTaskTypeKeyword = 'TMS_Order_Type_Pickup')
			BEGIN
				SET @mcsTaskType = 'Pickup';
			END
			IF (@tmsTaskTypeKeyword = 'TMS_Order_Type_Delivery')
			BEGIN
				SET @mcsTaskType = 'Delivery';
			END
			UPDATE MCS_Trip_Stop_Task
			SET CommonList_OrderTypeID = (SELECT ID FROM System_CommonList_Item WHERE Keyword = @mcsTaskType AND System_CommonListID = (SELECT ID FROM System_CommonList WHERE Keyword = 'Dispatch_TaskType'))
			WHERE ID = @mcsTaskId;
		END
	END
	ELSE
	BEGIN -- changed
		IF (@tmsDriverId != @mcsDriverId)
		BEGIN
			EXEC SP_Order_DeleteMcsTask @mcsTaskId, @userId;
			EXEC SP_Order_DeleteMcsStop @tripStopId, @userId;
			EXEC SP_Order_DispatchNewTask @UserId, @OrderId, @orderItemId, @OrderItemTaskId;
		END
		ELSE
		BEGIN
			--split task
			DECLARE @existingTripStopId AS UNIQUEIDENTIFIER, @existingTripStopTaskId AS UNIQUEIDENTIFIER;
			EXEC SP_Order_FindExistedMcsStop @orderItemTaskId, @orderId, @returnedMcsStopId = @existingTripStopId OUTPUT;
	
			IF (@existingTripStopId IS NULL)
			BEGIN
				--create new mcs trip (just create new trip if it is not exists)
				DECLARE @mcsTripId AS UNIQUEIDENTIFIER;
				EXEC SP_Order_CreateNewMcsTrip @userId, @orderItemTaskId, @returnedMcsTripId = @mcsTripId OUTPUT;
				EXEC SP_Order_CreateNewMcsStop @userId, @mcsTripId, @orderId, @orderItemId, @orderItemTaskId, @returnedMcsStopId = @existingTripStopId OUTPUT;
			END
			UPDATE MCS_Trip_Stop_Task SET MCS_Trip_StopID = @existingTripStopId WHERE ID = @mcsTaskId;
			--delete unused stop
			EXEC SP_Order_DeleteMcsStop @tripStopId, @userId;
		END
	END
	EXEC SP_Order_UpdateMcsTaskContact @userId, @orderId, @mcsTaskId, @orderItemTaskId;
END
GO
