SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

-- =============================================
-- Author:		Thanh T.K.H
-- Create date: 10/25/2016
-- Description:	Get Jobsite Event List
-- =============================================
CREATE PROCEDURE [dbo].[sp_eLog_GetJobsiteEventList]
	 @Account_LoginId uniqueidentifier,
	 @FMS_Elog_DailyReportID uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @DateFrom DateTime
	DECLARE @DateTo DateTime

	SET		@DateFrom = (
							SELECT	TOP 1	StartTime
							FROM	FMS_Elog_DailyReport
							WHERE	ID = @FMS_Elog_DailyReportID 
							AND		CreatedBy = @Account_LoginId
							ORDER BY StartTime DESC
						)

	SET		@DateTo = (
							SELECT	TOP 1	isnull(EndTime, getdate())
							FROM	FMS_Elog_DailyReport
							WHERE	ID = @FMS_Elog_DailyReportID 
							AND		CreatedBy = @Account_LoginId
							ORDER BY StartTime DESC
						)
		
	SELECT	*
	FROM	(
				SELECT	DISTINCT
						commevent.GpsTimeStamp,
						commevent.Latitude,
						commevent.Longitude
				FROM	MCS_Device_CommEvent commevent
				WHERE	commevent.HR_EmployeeID IN (
														SELECT	DISTINCT
																HR_EmployeeID
														FROM	FMS_Elog_DailyReport_Detail
														WHERE	CreatedBy = @account_LoginId
														AND		FMS_Elog_DailyReportID = @FMS_Elog_DailyReportID
													)
				AND		commevent.Latitude IS NOT NULL 
				AND		commevent.Longitude IS NOT NULL
				AND		commevent.Latitude <> 0 
				AND		commevent.Longitude <> 0
				AND		commevent.GpsTimeStamp BETWEEN @DateFrom AND @DateTo
			) TEMPTABLE
	GROUP BY	GpsTimeStamp,
				Latitude,
				Longitude
	ORDER BY	GPSTimeStamp
END

GO
