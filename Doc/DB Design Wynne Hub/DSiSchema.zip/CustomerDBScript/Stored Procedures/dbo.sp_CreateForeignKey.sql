SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- =============================================
-- Author:		Tuyen
-- Create date: 10/20/2013
-- Description:	create a foreign key in database
--- parameter @cascade value = '' or 'ON DELETE CASCADE' or 'ON UPDATE CASCADE' or 'ON DELETE CASCADE    ON UPDATE CASCADE'
-- =============================================
CREATE procedure [dbo].[sp_CreateForeignKey]
(
@Table nvarchar(100),
@Column nvarchar(100),
@ParentTable nvarchar(100),
@Parentcolumn nvarchar(100),
@cascade nvarchar(100)
)
as
begin

declare @SqlString nvarchar(1000)
set @SqlString = 'IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N''FK_' + @Table + '__' + @Column + '_X_' + @ParentTable + '__' + @ParentColumn + ''') AND parent_object_id = OBJECT_ID(N'''+@Table+'''))
ALTER TABLE ' + @Table + ' ADD CONSTRAINT FK_' + @Table + '__' + @Column + '_X_' + @ParentTable + '__' + @ParentColumn + ' FOREIGN KEY (['+@Column+']) REFERENCES ' + @ParentTable + '(['+@Parentcolumn+']) ' + @cascade 
exec(@SqlString)

End
GO
