SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- =============================================
-- Author:		Tuyen
-- Create date: 10/20/2013
-- Description:	delete all foreign key in database
-- =============================================
create procedure [dbo].[SP_DeleteAllForeignKeys]
as
begin

	DECLARE fk_cursor CURSOR  FOR 
		SELECT
			'ALTER TABLE ' + s.name + '.' + OBJECT_NAME(fk.parent_object_id)
				+ ' DROP CONSTRAINT ' + fk.NAME  AS DropStatement
		FROM
			sys.foreign_keys fk
		INNER JOIN sys.foreign_key_columns fkc ON fk.object_id = fkc.constraint_object_id
		INNER JOIN sys.schemas s ON fk.schema_id = s.schema_id
		INNER JOIN sys.tables t ON fkc.referenced_object_id = t.object_id
		INNER JOIN sys.schemas ss ON t.schema_id = ss.schema_id

	OPEN fk_cursor
	declare @DeletePK    nvarchar(1000)
	FETCH NEXT FROM fk_cursor INTO @DeletePK
	WHILE @@FETCH_STATUS = 0 
	BEGIN 
   
		EXEC (@DeletePK)
		FETCH NEXT FROM fk_cursor INTO @DeletePK
	END 

	CLOSE fk_cursor 
	DEALLOCATE fk_cursor

end
GO
