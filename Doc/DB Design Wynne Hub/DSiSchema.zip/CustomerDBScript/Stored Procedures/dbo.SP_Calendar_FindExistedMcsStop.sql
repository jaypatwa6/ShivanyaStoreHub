SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[SP_Calendar_FindExistedMcsStop](@tmsTaskId AS UNIQUEIDENTIFIER, @orderId AS UNIQUEIDENTIFIER, @returnedMcsStopId AS UNIQUEIDENTIFIER OUTPUT)
AS
BEGIN
	--get type of tms task
	DECLARE @tmsDriverId AS UNIQUEIDENTIFIER, @tmsTaskTypeId AS UNIQUEIDENTIFIER, @tmsScheduledTime AS DATETIME;
	SELECT @tmsScheduledTime = ScheduledTime , @tmsTaskTypeId = CommonList_TMSOrderItemTaskTypeId, @tmsDriverId = Driver_HR_EmployeeID FROM TMS_Order_Item_Task WHERE ID = @tmsTaskId;
	
	--get jobsite information base on tms task type
	DECLARE @jobsiteAddress AS NVARCHAR(255), @jobsiteLat AS DECIMAL(9,6), @jobsiteLong AS DECIMAL(9,6);
	--pickup task: get from original jobsite
	SELECT @jobsiteAddress = Address, @jobsiteLat =Latitude , @jobsiteLong = Longitude
	FROM CRM_Jobsite WHERE ID = (SELECT TaskLocation_CRM_JobsiteID FROM TMS_Order_Item_Task WHERE ID = @tmsTaskId);
	
	--Find stop base on jobsite infomation, tms task's driver and tms task's scheduled time
	DECLARE @mcsStopCursor AS CURSOR, @mcsStopId AS UNIQUEIDENTIFIER;
	SET @mcsStopCursor = CURSOR FOR (SELECT TOP 1 MCS_Trip_Stop.ID FROM MCS_Trip_Stop JOIN MCS_Trip on MCS_Trip_Stop.MCS_TripID = MCS_Trip.ID 
										WHERE MCS_Trip.AssignedToEmployeeID = @tmsDriverId 
										AND MCS_Trip_Stop.Latitude = @jobsiteLat
										AND MCS_Trip_Stop.Longitude = @jobsiteLong
										AND MCS_Trip_Stop.IsDeleted = 0
										AND MCS_Trip_Stop.[Address] = @jobsiteAddress
										AND MCS_Trip_Stop.PromiseTime IS NOT NULL AND MCS_Trip_Stop.PromiseTime = @tmsScheduledTime)
	OPEN @mcsStopCursor FETCH NEXT FROM @mcsStopCursor INTO @mcsStopId;
	WHILE @@FETCH_STATUS = 0
	BEGIN
		DECLARE @mcsStopStatusKeyword NVARCHAR(50) = (SELECT [dbo].[fn_GetTopStatusKeywordOfTripStop](@mcsStopId));
		IF (@mcsStopStatusKeyword != 'Cancel' AND @mcsStopStatusKeyword != 'Complete')
		BEGIN
			SET @returnedMcsStopId = @mcsStopId;
		END
		FETCH NEXT FROM @mcsStopCursor INTO @mcsStopId;
	END
	CLOSE @mcsStopCursor;
	DEALLOCATE @mcsStopCursor;
END
GO
