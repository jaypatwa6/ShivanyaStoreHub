SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[SP_DeleteMcsTask](@mcsTaskId AS UNIQUEIDENTIFIER, @userId AS UNIQUEIDENTIFIER)
AS
BEGIN
	DECLARE @isAssociatedTask BIT;
	SET @isAssociatedTask = (SELECT [dbo].[fn_CheckAssociatedTripStopTask](@mcsTaskId));
	IF (@isAssociatedTask IS NULL OR @isAssociatedTask <= 0)
	BEGIN
		--delete 
		DELETE MCS_Trip_Stop_Task WHERE ID = @mcsTaskId;
	END
	ELSE
	BEGIN
		--set IsDeleted = 1
		UPDATE MCS_Trip_Stop_Task SET IsDeleted = 1, ModifiedBy = @userId, DateModified = GETUTCDATE(), DateSynchronized = GETUTCDATE() WHERE ID = @mcsTaskId;
	END
END
GO
