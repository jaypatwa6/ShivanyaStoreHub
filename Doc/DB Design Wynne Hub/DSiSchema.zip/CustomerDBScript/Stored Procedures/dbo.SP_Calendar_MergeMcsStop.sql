SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[SP_Calendar_MergeMcsStop](@userId AS UNIQUEIDENTIFIER, @tmsTaskId AS UNIQUEIDENTIFIER, @orderId AS UNIQUEIDENTIFIER, @orderItemId AS UNIQUEIDENTIFIER, @returnedMcsTaskId AS UNIQUEIDENTIFIER OUTPUT)
AS
BEGIN
	--get type of tms task
	DECLARE @tmsDriverId AS UNIQUEIDENTIFIER, @tmsTaskTypeId AS UNIQUEIDENTIFIER, @tmsScheduledTime AS DATETIME, @tmsTaskTypeKeyword AS NVARCHAR(50);
	SELECT @tmsScheduledTime = ScheduledTime , @tmsTaskTypeId = CommonList_TMSOrderItemTaskTypeId, @tmsDriverId = Driver_HR_EmployeeID FROM TMS_Order_Item_Task WHERE ID = @tmsTaskId;
	SELECT @tmsTaskTypeKeyword = keyword from System_CommonList_Item WHERE ID = @tmsTaskTypeId;
	
	--get jobsite information base on tms task type
	DECLARE @jobsiteAddress AS NVARCHAR(255), @jobsiteLat AS DECIMAL(9,6), @jobsiteLong AS DECIMAL(9,6);
	--get from original jobsite
	SELECT @jobsiteAddress = Address, @jobsiteLat =Latitude , @jobsiteLong = Longitude
	FROM CRM_Jobsite WHERE ID = (SELECT TaskLocation_CRM_JobsiteID FROM TMS_Order_Item_Task WHERE ID = @tmsTaskId);
	
	--Find stop base on jobsite infomation, tms task's driver and tms task's scheduled time
	DECLARE @mcsStopCursor AS CURSOR, @mcsStopId AS UNIQUEIDENTIFIER;
	SET @mcsStopCursor = CURSOR FOR (SELECT MCS_Trip_Stop.ID FROM MCS_Trip_Stop JOIN MCS_Trip on MCS_Trip_Stop.MCS_TripID = MCS_Trip.ID 
										WHERE MCS_Trip.AssignedToEmployeeID = @tmsDriverId 
										AND MCS_Trip_Stop.Latitude = @jobsiteLat
										AND MCS_Trip_Stop.Longitude = @jobsiteLong
										AND MCS_Trip_Stop.IsDeleted = 0
										AND MCS_Trip_Stop.[Address] = @jobsiteAddress
										AND MCS_Trip_Stop.PromiseTime IS NOT NULL AND MCS_Trip_Stop.PromiseTime = @tmsScheduledTime)
	OPEN @mcsStopCursor FETCH NEXT FROM @mcsStopCursor INTO @mcsStopId;
	WHILE @@FETCH_STATUS = 0
	BEGIN
		DECLARE @mcsStopStatusKeyword NVARCHAR(50) = (SELECT [dbo].[fn_GetTopStatusKeywordOfTripStop](@mcsStopId));
		IF (@mcsStopStatusKeyword != 'Cancel' AND @mcsStopStatusKeyword != 'Complete')
		BEGIN
			DECLARE @mcsTaskCursor CURSOR, @mcsTaskId AS UNIQUEIDENTIFIER, @mcsTaskStatusId AS UNIQUEIDENTIFIER, @mcsOrderTypeId AS UNIQUEIDENTIFIER;
			SET @mcsTaskCursor = CURSOR FOR (SELECT ID, [CommonList_TaskStatusID], [CommonList_OrderTypeID] FROM MCS_Trip_Stop_Task WHERE [MCS_Trip_StopID] = @mcsStopId);
			DECLARE @taskStatusCanceledId AS UNIQUEIDENTIFIER = (SELECT ID FROM System_CommonList_Item WHERE Keyword = 'Cancel' and System_CommonListID = (SELECT ID FROM System_CommonList WHERE keyword = 'Dispatch_TaskStatus'));
			DECLARE @tasktatusCompletedId AS UNIQUEIDENTIFIER = (SELECT ID FROM System_CommonList_Item WHERE Keyword = 'Complete' and System_CommonListID = (SELECT ID FROM System_CommonList WHERE keyword = 'Dispatch_TaskStatus'));
			OPEN @mcsTaskCursor FETCH NEXT FROM @mcsTaskCursor INTO @mcsTaskId, @mcsTaskStatusId, @mcsOrderTypeId;
			WHILE @@FETCH_STATUS = 0
			BEGIN
				DECLARE @taskLoadNumber INT, @orderItemNumber INT, @mcsTaskTypeKeyword NVARCHAR(50), @orderItemTaskTypeKeyword NVARCHAR(50);
				SET @taskLoadNumber = ([dbo].[fn_GetLoadNumberOfTripStopTask](@mcsTaskId));
				SET @orderItemNumber = (SELECT OrderItemNumber FROM TMS_Order_Item WHERE ID = @orderItemId);
				SET @mcsTaskTypeKeyword = (SELECT Keyword FROM [System_CommonList_Item] WHERE ID = @mcsOrderTypeId);
				--check same task
				IF (@taskLoadNumber = @orderItemNumber
					AND @mcsTaskStatusId NOT IN (SELECT ID FROM [System_CommonList_Item] WHERE Keyword IN ('Cancel','Complete'))
					AND ((@mcsTaskTypeKeyword = 'Pickup' AND @tmsTaskTypeKeyword = 'TMS_Order_Type_Pickup')
						OR (@mcsTaskTypeKeyword = 'Delivery' AND @tmsTaskTypeKeyword = 'TMS_Order_Type_Delivery'))
					)
				BEGIN
					IF (@returnedMcsTaskId IS NOT NULL)
					BEGIN
						-- DELETE MCS task
						EXEC SP_Calendar_DeleteMcsTask  @returnedMcsTaskId, @userId;
						-- DELETE MCS stop
						EXEC SP_Calendar_DeleteMcsStop @mcsStopId, @userId;
					END
					ELSE 
						SET @returnedMcsTaskId = @mcsTaskId;											
				END
				FETCH NEXT FROM @mcsTaskCursor INTO @mcsTaskId, @mcsTaskStatusId, @mcsOrderTypeId;
			END
			CLOSE @mcsTaskCursor;
			DEALLOCATE @mcsTaskCursor;
		END
		FETCH NEXT FROM @mcsStopCursor INTO @mcsStopId;
	END
	CLOSE @mcsStopCursor;
	DEALLOCATE @mcsStopCursor;
	
	IF (@returnedMcsTaskId IS NOT NULL)--UPDATE MCS TASK
	BEGIN
		IF NOT EXISTS (SELECT task.ID FROM MCS_Trip_Stop_Task AS task JOIN System_CommonList_Item AS [status] ON task.CommonList_TaskStatusID = [status].ID
						WHERE task.ID = @returnedMcsTaskId AND [status].Keyword NOT IN ('Cancel', 'Complete'))
		BEGIN
			DECLARE @mscTaskStatusId AS UNIQUEIDENTIFIER;
			DECLARE @orderItemStatusId AS UNIQUEIDENTIFIER = (SELECT CommonList_TMSOrderItemStatusID FROM TMS_Order_Item WHERE ID = @orderItemId);
			IF (@tmsTaskTypeKeyword = 'TMS_Order_Type_Pickup')
			BEGIN
				SET @mscTaskStatusId = (SELECT dbo.fn_ConvertTMSOrderItenStatusToMCSTaskStatus(@orderItemStatusId,1,0));
			END
			IF (@tmsTaskTypeKeyword = 'TMS_Order_Type_Delivery')
			BEGIN
				SET @mscTaskStatusId = (SELECT dbo.fn_ConvertTMSOrderItenStatusToMCSTaskStatus(@orderItemStatusId,0,1));
			END
			UPDATE MCS_Trip_Stop_Task SET CommonList_TaskStatusID = @mscTaskStatusId, DateSynchronized = GETUTCDATE(), DateModified = GETUTCDATE(), ModifiedBy = @userId WHERE ID = @returnedMcsTaskId;
		END
	END
	ELSE --CREATE NEW MCS TASK
	BEGIN
		EXEC SP_Calendar_CreateNewMcsTask @userId, @mcsStopId, @orderId, @orderItemId, @tmsTaskId, @returnedMcsTaskId = @returnedMcsTaskId OUTPUT;
	END
END
GO
