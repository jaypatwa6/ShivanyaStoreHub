SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

-- =============================================
-- Author:		TRAN.K.H.THANH
-- Create date: 2016/09/20
-- Description:	get data for eLog Dashboard - List Jobsites From CommEvent & CommEventSummary
-- =============================================
CREATE PROCEDURE [dbo].[sp_eLog_Dashboard_GetJobsiteEventList]
	 @HR_EmployeeId uniqueidentifier = null,
	 @DateFrom DateTime,
	 @DateTo DateTime
AS
BEGIN
	SET NOCOUNT ON;
		
	SELECT	*
	FROM	(
				SELECT	commevent.GpsTimeStamp,
						commevent.Latitude,
						commevent.Longitude
				FROM MCS_Device_CommEvent commevent
				LEFT OUTER JOIN System_CommonList_Item cmi ON cmi.ID = commevent.CommonList_DeviceEventTypeID
				WHERE	commevent.HR_EmployeeID = @HR_EmployeeId
				AND		cmi.Keyword = 'Time_Interval'
				AND		(commevent.Latitude IS NOT NULL AND commevent.Longitude IS NOT NULL)
				AND		(commevent.Latitude <> 0 AND commevent.Longitude <> 0)
				AND		commevent.GpsTimeStamp BETWEEN @DateFrom AND @DateTo

				UNION ALL

				SELECT	commEventSummary.GpsTimeStamp,
						commEventSummary.Latitude,
						commEventSummary.Longitude
				FROM	MCS_Device_EventSummary commEventSummary
				WHERE	commEventSummary.HR_EmployeeID = @HR_EmployeeId
				AND		(commEventSummary.Latitude IS NOT NULL AND commEventSummary.Longitude IS NOT NULL)
				AND		(commEventSummary.Latitude <> 0 AND commEventSummary.Longitude <> 0)
				AND		commEventSummary.GpsTimeStamp BETWEEN @DateFrom AND @DateTo
			) TEMPTABLE
	GROUP BY	GpsTimeStamp,
				Latitude,
				Longitude
	ORDER BY	GPSTimeStamp
END








GO
