SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

-- =============================================
-- Author:		Huan Nguyen
-- Create date: 3/1/2017 8:50:28 PM
-- Description: Uncertified Logs Report
-- =============================================
CREATE PROCEDURE [dbo].[sp_eLog_UncertifiedLogsReport]
 @startdate datetime,
 @enddate datetime,
 @timezone float,
 @browser_colName nvarchar(256),
 @browser_colValue nvarchar(max)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
declare @hosStart datetime
set @hosStart = dateadd(hh,@timezone,@startdate)
declare @hosEnd datetime
set @hosEnd = dateadd(hh,@timezone,@enddate)
set @hosEnd = dateadd(n,-1,@hosEnd)
    -- Insert statements for procedure here
select * from (
	SELECT employee.Number AS [Employee Number],
 CONCAT(employee.FirstName, ' ', employee.LastName) as [Employee Name], 
 (SELECT top 1 summary.HOSCertifiedDate    
  FROM [dbo].[MCS_Device_EventSummary] AS summary   
  WHERE employee.ID = summary.HR_EmployeeID 
  and summary.HOSCertifiedDate 
  BETWEEN @hosStart and @hosEnd
  ORDER BY summary.HOSCertifiedDate DESC) AS [Last Approval Date]
 ,
  (SELECT datediff(dd,@startdate,@enddate) - 
		(SELECT count(DISTINCT summary.HOSCertifiedDate)
	  FROM [dbo].[MCS_Device_EventSummary] AS summary   
	  WHERE summary.HR_EmployeeID = employee.ID 
		and summary.HOSCertifiedDate is not null 
	    and summary.HOSCertifiedDate BETWEEN @hosStart and @hosEnd
	   and not exists (
	   SELECT top 1 1
		FROM [FMS_Elog_DailyReport_Detail] AS logs 
		WHERE logs.HR_EmployeeID = employee.ID
		AND logs.IsApproved = 0 
		AND logs.ELD_EventRecordStatus != 3
		AND logs.EndTime is not null 
		AND cast(dateadd(hh,@timezone,logs.StartTime) as date) = summary.HOSCertifiedDate
	   ))) 
	as [Number Unapproved]
  FROM [HR_Employee] AS employee
  RIGHT JOIN [FMS_Elog_DailyReport_Detail] AS detail   ON detail.HR_EmployeeID = employee.ID  
  WHERE employee.IsActive = 1  and employee.IsSystemEmployee = 0
  GROUP BY employee.Number,employee.FirstName, employee.LastName, employee.ID) 
  as b
WHERE CASE @browser_colName 
				WHEN 'Employee Number' THEN [Employee Number]
				WHEN 'Employee Name' THEN [Employee Name]
				ELSE ''
			END = @browser_colValue
	order by [Employee Number] , [Employee Name]

END

GO
