SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[sp_TMSNonDispatchedPastDueReport]
 @startdate datetime,
 @enddate datetime,
 @timezone float,
 @browser_colName nvarchar(256),
 @browser_colValue nvarchar(max)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT
		OrderNumber																	AS OrderNumber,
		SysCommonName																AS Status,		
		CusName																		AS Customer,
		Description																	AS Description,
		Quantity																	AS Quantity,
		PickupSite																	AS PickupSite,
		DeliverySite																AS DeliverySite,
		CONVERT(datetime,DATEADD(hour, @timezone, ScheduledDeliveryTime))			AS ScheduledDelivery,
		DATEDIFF(day, ScheduledDeliveryTime, GETDATE())								AS DateLate
	FROM
	(
		SELECT	[SYSCOMMON].Name									AS SysCommonName,
				[ORDER].OrderNumber									AS OrderNumber,
				[CUS].Name											AS CusName,
				[ITEM].FreightDescription							AS Description,
				[ITEM].QuantityOrdered								AS Quantity,
				[PICKUPSITE].Name									AS PickupSite,
				[DELIVERYSITE].Name									AS DeliverySite,
				--CASE [SYSCOMMON].Name
				--	WHEN 'Dispatched' THEN 
						(
							SELECT	TOP 1 ScheduledTime
							FROM	TMS_Order_Item_Task
							WHERE	TMS_Order_ItemID = [ITEM].ID
							ORDER BY DateCreated DESC
						)
				--	ELSE
				--		(
				--			SELECT NULL
				--		)
				--END
																	AS ScheduledDeliveryTime
		FROM	TMS_ORDER_ITEM [ITEM]
		INNER JOIN TMS_ORDER [ORDER]					ON [ORDER].ID = [ITEM].TMS_OrderID
		INNER JOIN SYSTEM_COMMONLIST_ITEM [SYSCOMMON]	ON [SYSCOMMON].ID = [ITEM].CommonList_TMSOrderItemStatusID
		LEFT OUTER JOIN CRM_Jobsite [PICKUPSITE]		ON [PICKUPSITE].ID = [ORDER].Origin_CRM_JobsiteID
		LEFT OUTER JOIN CRM_Jobsite [DELIVERYSITE]		ON [DELIVERYSITE].ID = [ORDER].Destination_CRM_JobsiteID
		LEFT OUTER JOIN TMS_Order_CustomData [ORDERCUS]	ON [ORDERCUS].TMS_OrderID = [ORDER].ID
		LEFT OUTER JOIN CRM_Customer [CUS]				ON [CUS].ID = [ORDER].CRM_CustomerID
		WHERE	[ORDER].ISDELETE = 0
		AND		[SYSCOMMON].Keyword IN ('TMS_OrderItemStatus_Pending', 'TMS_OrderItemStatus_ReadyForDispatch', 'TMS_OrderItemStatus_Dispatched')
	) AS X
	WHERE CASE @browser_colName
					WHEN 'OrderNumber' THEN [OrderNumber]
					WHEN 'Status' THEN [SysCommonName]
					ELSE ''
				END = @browser_colValue
		AND
			(	ScheduledDeliveryTime IS NULL
			OR	
				(
					ScheduledDeliveryTime BETWEEN @startdate AND @enddate
				AND DATEDIFF(day,ScheduledDeliveryTime,GETDATE()) > 0
				)
			)
	GROUP BY
		SysCommonName,
		OrderNumber,
		CusName,
		Description,
		Quantity,
		PickupSite,
		DeliverySite,
		ScheduledDeliveryTime
	ORDER BY
		[OrderNumber]
END

GO
