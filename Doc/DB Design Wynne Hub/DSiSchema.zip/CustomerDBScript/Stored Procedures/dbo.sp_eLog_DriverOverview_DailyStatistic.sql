SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- =============================================
-- Author:		Hieu
-- Create date: Aug 21th 2023
-- Description:	Get phone PhonNumberType
-- =============================================
-- [sp_GetCommonListItem] 'System_PhoneNumberType'
-- [dbo].[sp_eLog_DriverOverview_DailyStatistic] 'ffb01778-045a-11ee-8162-00155db47809', '2023-08-03 17:00:00.000', '2023-08-17 17:00:00.000', -6
create PROCEDURE [dbo].[sp_eLog_DriverOverview_DailyStatistic]
	@HR_EmployeeID uniqueidentifier,
	@StartTime datetime,
	@EndTime datetime,
	@TimezoneOffset int
AS
BEGIN
	SET NOCOUNT ON;	
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

	--declare @HR_EmployeeID uniqueidentifier ='7727d2fb-0acf-ed11-bc30-000d3a9a0e11'
	--declare @StartTime datetime ='2023-08-03 17:00:00.000'
	--declare @EndTime datetime ='2023-08-17 17:00:00.000'
	--declare @TimezoneOffset int = -6


	set @StartTime = cast(@StartTime as date)
	set @EndTime = cast(@EndTime as date)

	declare @StartTime_temp datetime = cast(@StartTime as date)
	declare @EndTime_temp datetime = cast(@EndTime as date)
	declare @HR_EmployeeID_temp uniqueidentifier = @HR_EmployeeID
	declare @TimezoneOffset_temp int = @TimezoneOffset
	declare @Account_LoginID_temp uniqueidentifier 
	select top 1 @Account_LoginID_temp = hr.Account_LoginID from HR_Employee hr where hr.ID = @HR_EmployeeID_temp

	--drop table #tempSummary
	-- optimize sub-query
	declare @tempSummary table (HOSCertifiedDate date)
	insert into @tempSummary 
	select mdes.[HOSCertifiedDate] 
	from [dbo].[MCS_Device_EventSummary] mdes 
	where  mdes.HR_EmployeeID = @HR_EmployeeID_temp 
		and mdes.[HOSCertifiedDate] is not null	
		and mdes.HOSCertifiedDate between dateadd(dd, -2, @StartTime_temp) and dateadd(dd, 2, @EndTime_temp)

	declare @tempElog table (ID uniqueidentifier, StartTime datetime, EndTime datetime, Keyword varchar(50), DistanceInKM decimal(18, 2), IsApproved bit)
	insert into @tempElog 
	select  fedrd.ID, 
		DATEADD(hh, @TimezoneOffset_temp, fedrd.StartTime), 
		DATEADD(hh, @TimezoneOffset_temp, isnull(fedrd.EndTime, getutcdate())), 
		fedrd.Keyword, 
		fedrd.DistanceInKM, 
		isnull(fedrd.IsApproved, 0)
	from [dbo].v_elog_DailyReportDetail fedrd
		-- INNER JOIN dbo.System_CommonList_Item scli ON scli.ID = fedrd.CommonList_ElogStatusTypeID	
	where  fedrd.HR_EmployeeID = @HR_EmployeeID_temp 
		--and fedrd.Keyword in ('On_Duty', 'ELOG_SpecialStatus_YardMove', 'Driving_On_Duty', 'Off_Duty', 'ELOG_SpecialStatus_PersonalConveyance', 'In_Sleeper')	
		and (
			@StartTime_temp between cast(DATEADD(hh, @TimezoneOffset_temp, fedrd.StartTime) as date) and DATEADD(hh, @TimezoneOffset_temp, isnull(fedrd.EndTime, getutcdate()))
			or @EndTime_temp between cast(DATEADD(hh, @TimezoneOffset_temp, fedrd.StartTime) as date) and DATEADD(hh, @TimezoneOffset_temp, isnull(fedrd.EndTime, getutcdate()))
			or (
				cast(DATEADD(hh, @TimezoneOffset_temp, fedrd.StartTime) as date) >= @StartTime_temp
				and cast(DATEADD(hh, @TimezoneOffset_temp, dateadd(ss, -1,isnull(fedrd.EndTime, getutcdate()))) as date) <= @EndTime_temp
			)
		)
		;
	
	 -- Create Temporary Table for nearest 3 months
	DECLARE @TempDVIRtbl AS TABLE (
			HR_EmployeeID uniqueidentifier,
			DateRecorded datetime, 
			Response int
	);
	INSERT INTO @TempDVIRtbl
	select mss2.HR_EmployeeID, mss2.[DateRecorded], CONVERT(INT, isnull(mssr2.Response, 0)) 
	from dbo.MCS_Smartform_Submission_Response mssr2
		inner join [dbo].[MCS_Smartform_Submission] mss2 on mss2.ID = mssr2.MCS_Smartform_SubmissionID and mss2.IsActive = 1
		inner join [dbo].[MCS_Smartform_Question] msq2 on msq2.ID = mssr2.MCS_Smartform_QuestionID and msq2.IsActive = 1 and msq2.IsDelete = 0
	where mssr2.IsActive = 1 
		--and mss2.HR_EmployeeID = zz.HR_EmployeeID							
		and msq2.Keyword = 'DVIR.DefectCount'
		and mss2.[DateRecorded] between DATEADD(d, -9, GETUTCDATE()) and GETUTCDATE();

	WITH T(tempDate)
		AS
		( 
			SELECT @StartTime_temp as tempDate
			UNION ALL
			SELECT DateAdd(day,1,T.tempDate)  FROM T WHERE T.tempDate < @EndTime_temp
		)
	
		SELECT 	
			CompliantLogs = (
								select count(*)
								from @tempElog fedrd								
								where -- fedrd.HR_EmployeeID = @HR_EmployeeID_temp and
									 not exists (select 1 from [dbo].[FMS_Elog_DailyReport_Detail_Violation] fedrdv where fedrdv.[FMS_Elog_DailyReport_DetailID] = fedrd.ID and fedrdv.IsDelete = 0)										
									and T.tempDate between cast(DATEADD(hh, @TimezoneOffset_temp, fedrd.StartTime) as date) and cast(DATEADD(hh, @TimezoneOffset_temp, dateadd(ss, -1,isnull(fedrd.EndTime, getutcdate()))) as date)
							),
			UnApprovedLogs = cast(0 as int),
			ApprovedLogs = cast(0 as int),
			Account_LoginID = @Account_LoginID_temp,
			HR_EmployeeID = @HR_EmployeeID_temp,
			StartTimeWithoutTime = cast(T.tempDate as datetime),
			ON_Status = ISNULL( (
				select sum(Duration)
				from (
					select 
						Duration = (
							case 
								-- start and end time are in a day and they are the same day
								when T.tempDate = cast(StartTime as date) and T.tempDate = cast(EndTime as date)
									then DATEDIFF(s, StartTime, EndTime)
								-- start time is lower and end time is the same day 
								when T.tempDate > StartTime and T.tempDate = cast(EndTime as date)
									then DATEDIFF(s, T.tempDate, EndTime)
								-- start time is same day and end time is greater
								when T.tempDate = cast(StartTime as date) and T.tempDate < EndTime 
									then DATEDIFF(s, StartTime, dateadd(d,1, T.tempDate))
								-- start and end time are greater
								when T.tempDate > StartTime and dateadd(d,1, T.tempDate) <= EndTime
									then (24 * 60 * 60)
							end	
						) 
					from (
						select 	
							StartTime = tt.StartTime,
							EndTime = tt.EndTime
						from  @tempElog tt									
						where tt.Keyword = 'On_Duty'
							and T.tempDate between cast(tt.StartTime as date) and cast(dateadd(ss, -1,tt.EndTime) as date)
					)tt	
				)t				
			), 0) ,
			YM_Status = ISNULL( (
				select sum(Duration)
				from (
					select 
						Duration = (
							case 
								-- start and end time are in a day and they are the same day
								when T.tempDate = cast(StartTime as date) and T.tempDate = cast(EndTime as date)
									then DATEDIFF(s, StartTime, EndTime)
								-- start time is lower and end time is the same day 
								when T.tempDate > StartTime and T.tempDate = cast(EndTime as date)
									then DATEDIFF(s, T.tempDate, EndTime)
								-- start time is same day and end time is greater
								when T.tempDate = cast(StartTime as date) and T.tempDate < EndTime 
									then DATEDIFF(s, StartTime, dateadd(d,1, T.tempDate))
								-- start and end time are greater
								when T.tempDate > StartTime and dateadd(d,1, T.tempDate) <= EndTime
									then (24 * 60 * 60)
							end	
						) 
					from (
						select 	
							StartTime = tt.StartTime,
							EndTime = tt.EndTime 
						from  @tempElog tt					
						where tt.Keyword = 'ELOG_SpecialStatus_YardMove'
							and T.tempDate between cast(tt.StartTime as date) and cast(dateadd(ss, -1,tt.EndTime) as date)
					)tt	
				)t				
			),0) ,
			D_Status = ISNULL((
				select sum(Duration)
				from (
					select 
						Duration = (
							case 
								-- start and end time are in a day and they are the same day
								when T.tempDate = cast(StartTime as date) and T.tempDate = cast(EndTime as date)
									then DATEDIFF(s, StartTime, EndTime)
								-- start time is lower and end time is the same day 
								when T.tempDate > StartTime and T.tempDate = cast(EndTime as date)
									then DATEDIFF(s, T.tempDate, EndTime)
								-- start time is same day and end time is greater
								when T.tempDate = cast(StartTime as date) and T.tempDate < EndTime 
									then DATEDIFF(s, StartTime, dateadd(d,1, T.tempDate))
								-- start and end time are greater
								when T.tempDate > StartTime and dateadd(d,1, T.tempDate) <= EndTime
									then (24 * 60 * 60)
							end	
						) 
					from (
						select 	
							StartTime = tt.StartTime,
							EndTime = tt.EndTime 
						from  @tempElog tt			
						where tt.Keyword = 'Driving_On_Duty'
							and T.tempDate between cast(tt.StartTime as date) and cast(dateadd(ss, -1,tt.EndTime) as date)
					)tt	
				)t				
			),0) ,
			OFF_Status = ISNULL((
				select sum(Duration)
				from (
					select 
						Duration = (
							case 
								-- start and end time are in a day and they are the same day
								when T.tempDate = cast(StartTime as date) and T.tempDate = cast(EndTime as date)
									then DATEDIFF(s, StartTime, EndTime)
								-- start time is lower and end time is the same day 
								when T.tempDate > StartTime and T.tempDate = cast(EndTime as date)
									then DATEDIFF(s, T.tempDate, EndTime)
								-- start time is same day and end time is greater
								when T.tempDate = cast(StartTime as date) and T.tempDate < EndTime 
									then DATEDIFF(s, StartTime, dateadd(d,1, T.tempDate))
								-- start and end time are greater
								when T.tempDate > StartTime and dateadd(d,1, T.tempDate) <= EndTime
									then (24 * 60 * 60)
							end	
						) 
					from (
						select 	
							StartTime = tt.StartTime,
							EndTime = tt.EndTime 
						from  @tempElog tt				
						where tt.Keyword = 'Off_Duty'
							and T.tempDate between cast(tt.StartTime as date) and cast(dateadd(ss, -1,tt.EndTime) as date)
					)tt	
				)t				
			),0) ,
			PC_Status = ISNULL((
				select sum(Duration)
				from (
					select 
						Duration = (
							case 
								-- start and end time are in a day and they are the same day
								when T.tempDate = cast(StartTime as date) and T.tempDate = cast(EndTime as date)
									then DATEDIFF(s, StartTime, EndTime)
								-- start time is lower and end time is the same day 
								when T.tempDate > StartTime and T.tempDate = cast(EndTime as date)
									then DATEDIFF(s, T.tempDate, EndTime)
								-- start time is same day and end time is greater
								when T.tempDate = cast(StartTime as date) and T.tempDate < EndTime 
									then DATEDIFF(s, StartTime, dateadd(d,1, T.tempDate))
								-- start and end time are greater
								when T.tempDate > StartTime and dateadd(d,1, T.tempDate) <= EndTime
									then (24 * 60 * 60)
							end	
						) 
					from (
						select 	
							StartTime = tt.StartTime,
							EndTime = tt.EndTime 	 
						from  @tempElog tt			
						where tt.Keyword = 'ELOG_SpecialStatus_PersonalConveyance'
							and T.tempDate between cast(tt.StartTime as date) and cast(dateadd(ss, -1,tt.EndTime) as date)
					)tt	
				)t				
			),0) ,
			SB_Status = ISNULL((
				select sum(Duration)
				from (
					select 
						Duration = (
							case 
								-- start and end time are in a day and they are the same day
								when T.tempDate = cast(StartTime as date) and T.tempDate = cast(EndTime as date)
									then DATEDIFF(s, StartTime, EndTime)
								-- start time is lower and end time is the same day 
								when T.tempDate > StartTime and T.tempDate = cast(EndTime as date)
									then DATEDIFF(s, T.tempDate, EndTime)
								-- start time is same day and end time is greater
								when T.tempDate = cast(StartTime as date) and T.tempDate < EndTime 
									then DATEDIFF(s, StartTime, dateadd(d,1, T.tempDate))
								-- start and end time are greater
								when T.tempDate > StartTime and dateadd(d,1, T.tempDate) <= EndTime
									then (24 * 60 * 60)
							end	
						) 
					from (
						select 	
							StartTime = tt.StartTime,
							EndTime = tt.EndTime 	 
						from  @tempElog tt					
						where tt.Keyword = 'In_Sleeper'
							and T.tempDate between cast(tt.StartTime as date) and cast(dateadd(ss, -1,tt.EndTime) as date)
					)tt	
				)t				
			),0),
			ViolatedLogs =  (
								select count(*)
								from (
									select fedrdv.[FMS_Elog_DailyReport_DetailID]
									from @tempElog fedrd
										inner join [dbo].[FMS_Elog_DailyReport_Detail_Violation] fedrdv on fedrdv.[FMS_Elog_DailyReport_DetailID] = fedrd.ID and fedrdv.IsDelete = 0
									where --fedrd.HR_EmployeeID = @HR_EmployeeID_temp and                                        
										 T.tempDate between cast(DATEADD(hh, @TimezoneOffset_temp, fedrdv.StartTime) as date) and cast(DATEADD(hh, @TimezoneOffset_temp, dateadd(ss, -1,isnull(fedrd.EndTime, getutcdate()))) as date)
									group by fedrdv.[FMS_Elog_DailyReport_DetailID]
								)t
                            
							),
			IsCertifyLog = cast((
							case when 
							not exists (
								select 1
								from @tempElog tt
								where tt.IsApproved = 0
									and T.tempDate between cast(tt.StartTime as date) and cast(dateadd(ss, -1,tt.EndTime) as date)
							) 
							and exists (
								select 1
								from @tempSummary tt 
								where T.tempDate = tt.[HOSCertifiedDate]  
							)
							 then 1 else 0 end
						) as bit),
			Distance =  isnull( (
							select cast(sum(tt.DistanceInKM * 0.621371192) as decimal(18,10))
							from @tempElog tt						
							where T.tempDate between cast(tt.StartTime as date) and cast(dateadd(ss, -1,tt.EndTime) as date)

						),0),
			DVIR = 
			(
				case when exists (
					select 1 
					from @TempDVIRtbl tempDVIR		
					where tempDVIR.HR_EmployeeID = @HR_EmployeeID_temp								
						and cast(dateadd(hh, @TimezoneOffset_temp, tempDVIR.[DateRecorded]) as date) = T.tempDate
					--select 1 
					--from dbo.MCS_Smartform_Submission_Response mssr2
					--	inner join [dbo].[MCS_Smartform_Submission] mss2 on mss2.ID = mssr2.MCS_Smartform_SubmissionID and mss2.IsActive = 1
					--	inner join [dbo].[MCS_Smartform_Question] msq2 on msq2.ID = mssr2.MCS_Smartform_QuestionID and msq2.IsActive = 1 and msq2.IsDelete = 0
					--where mssr2.IsActive = 1 
					--	and mss2.HR_EmployeeID = @HR_EmployeeID_temp							
					--	and msq2.Keyword = 'DVIR.DefectCount'
					--	and cast(
					--			dateadd(
					--					hh, 
					--					IIF(
					--						( 
					--							select count(1) 
					--							FROM [dbo].[FMS_Elog_DailyReport_Detail] 
					--							WHERE HR_EmployeeId = @HR_EmployeeID_temp 
					--								and  cast(startTime AS DATE) <= T.tempDate
					--							) > 0, 
					--							@TimezoneOffset_temp,											
					--					0), mss2.[DateRecorded]) AS DATE
					--			) =  T.tempDate															
					) then (
						select sum(CONVERT(INT, isnull(tempDVIR.Response, 0)))
						from @TempDVIRtbl tempDVIR		
						where tempDVIR.HR_EmployeeID = @HR_EmployeeID_temp									
							and cast(dateadd(hh, @TimezoneOffset_temp, tempDVIR.[DateRecorded]) as date) = T.tempDate
						--select sum(CONVERT(INT, isnull(mssr2.Response, 0)))
						--from dbo.MCS_Smartform_Submission_Response mssr2
						--	inner join [dbo].[MCS_Smartform_Submission] mss2 on mss2.ID = mssr2.MCS_Smartform_SubmissionID and mss2.IsActive = 1
						--	inner join [dbo].[MCS_Smartform_Question] msq2 on msq2.ID = mssr2.MCS_Smartform_QuestionID and msq2.IsActive = 1 and msq2.IsDelete = 0
						--where mssr2.IsActive = 1 
						--	and mss2.HR_EmployeeID = @HR_EmployeeID_temp							
						--	and msq2.Keyword = 'DVIR.DefectCount'
						--	and cast(
						--		dateadd(
						--				hh, 
						--				IIF(
						--					( 
						--						select count(1) 
						--						FROM [dbo].[FMS_Elog_DailyReport_Detail] 
						--						WHERE HR_EmployeeId = @HR_EmployeeID_temp 
						--							and  cast(startTime AS DATE) <= T.tempDate
						--						) > 0, 
						--						@TimezoneOffset_temp,											
						--				0), mss2.[DateRecorded]) AS DATE
						--		) =  T.tempDate													
				
					) else -1 
				end
			)			
		FROM T
		order by T.tempDate desc
			   
END

GO
