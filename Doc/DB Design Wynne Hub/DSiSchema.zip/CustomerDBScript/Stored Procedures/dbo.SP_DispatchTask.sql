SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[SP_DispatchTask] @OrderId UNIQUEIDENTIFIER, @UserId UNIQUEIDENTIFIER
AS
BEGIN
	-- GET DATA
	--table containts some common item which are most used
	DECLARE @cachedCommonItemTable TABLE (ID UNIQUEIDENTIFIER, Keyword NVARCHAR(MAX), Sequence INT);
	DECLARE @cachedCommonItemCursor CURSOR;
	SET @cachedCommonItemCursor = CURSOR FOR (SELECT ID, Keyword, Sequence FROM  [System_CommonList_Item] WHERE Keyword LIKE 'TMS_OrderItemStatus_%' OR Keyword LIKE 'TMS_Order_Type_%');
	DECLARE @id UNIQUEIDENTIFIER, @keyword NVARCHAR(MAX), @sequence INT;
	OPEN @cachedCommonItemCursor FETCH NEXT FROM @cachedCommonItemCursor INTO @id, @keyword, @sequence;
	WHILE @@FETCH_STATUS = 0
	BEGIN
		INSERT INTO @cachedCommonItemTable (ID, Keyword, Sequence) VALUES (@id, @keyword, @sequence);
		FETCH NEXT FROM @cachedCommonItemCursor INTO @id, @keyword, @sequence;
	END
	CLOSE @cachedCommonItemCursor;
	DEALLOCATE @cachedCommonItemCursor;
	
	DECLARE @dispatchStatusId UNIQUEIDENTIFIER = (SELECT [ID] FROM @cachedCommonItemTable WHERE [Keyword] = 'TMS_OrderItemStatus_Dispatched');
	DECLARE @dispatchStatusSequence INT = (SELECT [Sequence] FROM @cachedCommonItemTable WHERE [Keyword] = 'TMS_OrderItemStatus_Dispatched');
	DECLARE @pickupTaskTypeId UNIQUEIDENTIFIER = (SELECT [ID] FROM @cachedCommonItemTable WHERE [Keyword] = 'TMS_Order_Type_Pickup');
	DECLARE @deliveryTaskTypeId UNIQUEIDENTIFIER = (SELECT [ID] FROM @cachedCommonItemTable WHERE [Keyword] = 'TMS_Order_Type_Delivery');
	
	BEGIN TRAN;
	--Update Order status
	DECLARE @hightestOrderItemStatusId UNIQUEIDENTIFIER = (SELECT TOP 1 commonListItem.Id
															FROM [TMS_Order_Item] AS orderItem JOIN @cachedCommonItemTable AS commonListItem 
															ON orderItem.CommonList_TMSOrderItemStatusID = commonListItem.Id
															WHERE TMS_OrderID = @OrderId
															ORDER BY commonListItem.Sequence DESC);

	DECLARE @newOrderStatusId UNIQUEIDENTIFIER = (SELECT TOP 1 CommonList_TMS_Order_StatusId FROM [TMS_Order_Event_StatusMapping] 
													WHERE CommonList_TMS_Order_Item_StatusId = (SELECT TOP 1 ID FROM @cachedCommonItemTable 
																								WHERE ID IN (@dispatchStatusId, @hightestOrderItemStatusId)
																								ORDER BY Sequence DESC));
	UPDATE	[TMS_Order]
	SET		CommonList_TMSOrderStatusID = @newOrderStatusId,
			Dispatcher = @UserId
	WHERE	ID = @OrderId;
	
	--get all tms task of order which is assigned to driver
	DECLARE @orderItemTaskCursor CURSOR;
	SET @orderItemTaskCursor = CURSOR FOR (SELECT ID, TMS_Order_ItemID, CommonList_TMSOrderItemTaskTypeId, Driver_HR_EmployeeID, MCS_Trip_Stop_TaskID FROM [TMS_Order_Item_Task] 
											WHERE Driver_HR_EmployeeID IS NOT NULL
												AND TMS_Order_ItemID IN (SELECT ID FROM [TMS_Order_Item] WHERE TMS_OrderID = @OrderId));
	DECLARE @taskId UNIQUEIDENTIFIER;
	DECLARE @taskTypeId UNIQUEIDENTIFIER;
	DECLARE @orderItemId UNIQUEIDENTIFIER;
	DECLARE @driverId UNIQUEIDENTIFIER;
	DECLARE @topStatusId UNIQUEIDENTIFIER;
	DEClARE @mcsTaskID UNIQUEIDENTIFIER;
	
	--CHANGE STATUS OF ORDER ITEM TASK
	--Build dispatchTMSTaskTable - table contain task to be to dispatch
	DECLARE @dispatchTMSTaskTable TABLE (TaskId UNIQUEIDENTIFIER, OrderItemId UNIQUEIDENTIFIER, TaskTypeId UNIQUEIDENTIFIER, TopStatusId UNIQUEIDENTIFIER, AssignedDriverId UNIQUEIDENTIFIER, McsTaskID UNIQUEIDENTIFIER);
	OPEN @orderItemTaskCursor FETCH NEXT FROM @orderItemTaskCursor INTO @taskId, @orderItemId, @taskTypeId, @driverId, @mcsTaskID;
	WHILE @@FETCH_STATUS = 0
	BEGIN
		-- get top status of tms task
		SET @topStatusId = (SELECT TOP 1 ([CommonList_TMSOrder_Item_Task_StatusId]) FROM [TMS_Order_Event_Summary] WHERE [TMS_Order_Item_TaskId] = @taskId ORDER BY [DateCreated] DESC);
		-- only dispatch task if task is open or pending or ready for dispatch
		IF (@topStatusId IS NULL OR @topStatusId IN (SELECT ID FROM @cachedCommonItemTable WHERE Keyword IN ('TMS_OrderItemStatus_Open','TMS_OrderItemStatus_Pending', 'TMS_OrderItemStatus_ReadyForDispatch')))
		BEGIN
			-- change tms task status by adding dispatch event in TMS_Order_Event_Summary
			INSERT INTO [TMS_Order_Event_Summary]
			(DateCreated, CreatedBy, DateModified, ModifiedBy, TMS_OrderId, TMS_Order_ItemId, TMS_Order_Item_TaskId,
			CommonList_TMSOrder_StatusId, CommonList_TMSOrder_Item_StatusId, CommonList_TMSOrder_Item_Task_StatusId, CommonList_TMSOrder_Item_Task_TypeId, MCS_Device_EventSummaryID)
			VALUES(GETUTCDATE(), @userId, GETUTCDATE(), @userId, @OrderId, @orderItemId, @taskId, @newOrderStatusId, @hightestOrderItemStatusId, @dispatchStatusId, @taskTypeId, NULL);
			-- add this tms task into dispatch task
			INSERT INTO @dispatchTMSTaskTable (TaskId, OrderItemId, TaskTypeId, TopStatusId, AssignedDriverId, McsTaskID)
			VALUES (@taskId, @orderItemId, @taskTypeId, @dispatchStatusId, @driverId, @mcsTaskID);
		END
		FETCH NEXT FROM @orderItemTaskCursor INTO @taskId, @orderItemId, @taskTypeId, @driverId, @mcsTaskID;
	END
	CLOSE @orderItemTaskCursor;
	DEALLOCATE @orderItemTaskCursor;

	--CHANGE STATUS OF ORDER ITEM
	--if all tms task of order item > dispatch -> change status of order item to dispatch
	--just changing status to Dispatch if order item status is one of Open, Pending, Ready For Dispatch
	DEClARE @pickupTaskId UNIQUEIDENTIFIER, @deliveryTaskId UNIQUEIDENTIFIER, @topPickupTaskStatusId UNIQUEIDENTIFIER, @topDeliveryStatusId UNIQUEIDENTIFIER, @topDeliveryStatusSequence INT, @topPickupTaskStatusSequence INT;
	DECLARE @dispatchTMSTaskCursor CURSOR;
	SET @dispatchTMSTaskCursor = CURSOR FOR (SELECT TaskId, OrderItemId, TaskTypeId, TopStatusId, AssignedDriverId, McsTaskID FROM @dispatchTMSTaskTable);
	OPEN @dispatchTMSTaskCursor FETCH NEXT FROM @dispatchTMSTaskCursor INTO @taskId, @orderItemId, @taskTypeId, @topStatusId, @driverId, @mcsTaskID;
	WHILE @@FETCH_STATUS = 0
	BEGIN
		--IF all task of order item are > dispatched -> change order item to dispatch
		DECLARE @IsAllTaskDispatched AS BIT;
		EXEC SP_CheckAllTaskIsDispatched @orderItemId, @IsAllTaskDispatched = @IsAllTaskDispatched OUTPUT;
		
		IF (@IsAllTaskDispatched = 1)
		BEGIN
			--just changing status to Dispatch if order item status is one of Open, Pending, Ready For Dispatch
			UPDATE [TMS_Order_Item] SET CommonList_TMSOrderItemStatusID = @dispatchStatusId, [DateModified] = GETUTCDATE()
			WHERE [ID] = @orderItemId AND [TMS_OrderID] = @OrderId AND CommonList_TMSOrderItemStatusID IN (SELECT ID FROM @cachedCommonItemTable WHERE Keyword IN ('TMS_OrderItemStatus_Open','TMS_OrderItemStatus_Pending', 'TMS_OrderItemStatus_ReadyForDispatch'));
			-- add record into TMS_Order_Event_Summary for this
			INSERT INTO [TMS_Order_Event_Summary]
			(DateCreated, CreatedBy, DateModified, ModifiedBy, TMS_OrderId, TMS_Order_ItemId, TMS_Order_Item_TaskId,
			CommonList_TMSOrder_StatusId, CommonList_TMSOrder_Item_StatusId, CommonList_TMSOrder_Item_Task_StatusId, CommonList_TMSOrder_Item_Task_TypeId, MCS_Device_EventSummaryID)
			VALUES(GETUTCDATE(), @userId, GETUTCDATE(), @userId, @OrderId, @orderItemId, @taskId, @newOrderStatusId, @dispatchStatusId, @dispatchStatusId, @taskTypeId, NULL);
		END
		FETCH NEXT FROM @dispatchTMSTaskCursor INTO @taskId, @orderItemId, @taskTypeId, @topStatusId, @driverId, @mcsTaskID;
	END
	CLOSE @dispatchTMSTaskCursor;
	DEALLOCATE @dispatchTMSTaskCursor;
	
	--DISPATCH
	--Just dispatch task with status >= Dispatch
	SET @dispatchTMSTaskCursor = CURSOR FOR (SELECT TaskId, OrderItemId, TaskTypeId, TopStatusId, AssignedDriverId, McsTaskID FROM @dispatchTMSTaskTable);
	OPEN @dispatchTMSTaskCursor FETCH NEXT FROM @dispatchTMSTaskCursor INTO @taskId, @orderItemId, @taskTypeId, @topStatusId, @driverId, @mcsTaskID;
	WHILE @@FETCH_STATUS = 0
	BEGIN
		DECLARE @sequenceStatus INT = (SELECT Sequence FROM @cachedCommonItemTable WHERE ID = @topStatusId);
		IF (@sequenceStatus >= @dispatchStatusSequence)
		BEGIN
			--Status is CANCEL -> dispatch to cancel task
			IF (@sequenceStatus = (SELECT Sequence FROM @cachedCommonItemTable WHERE Keyword = 'TMS_OrderItemStatus_Canceled'))
			BEGIN
				EXEC SP_DispatchCanceledTask @userId, @taskId;
			END
			--Status is completed -> dispatch to complete task
			IF (@sequenceStatus = (SELECT Sequence FROM @cachedCommonItemTable WHERE Keyword = 'TMS_OrderItemStatus_DeliveryComplete'))
				BEGIN
					EXEC SP_DispatchCompletedTask @userId, @taskId;
				END
			--Otherwise dispatch new task
			IF (@driverId IS NOT NULL AND EXISTS (SELECT ID FROM MCS_Device WHERE HR_EmployeeID = @driverId AND IsActive = 1))
			BEGIN
				IF (@mcsTaskID IS NULL)
				--PROCESS NEW DISPATCH
				BEGIN
					EXEC SP_DispatchNewTask @userId, @OrderId, @orderItemId, @taskId;
				END
				ELSE -- @mcsTaskID IS NOT NULL
				BEGIN
					EXEC SP_ReDispatchTask @userId, @OrderId, @orderItemId, @taskId;
				END
			END
		END
		FETCH NEXT FROM @dispatchTMSTaskCursor INTO @taskId, @orderItemId, @taskTypeId, @topStatusId, @driverId, @mcsTaskID;
	END
	CLOSE @dispatchTMSTaskCursor;
	DEALLOCATE @dispatchTMSTaskCursor;
	COMMIT TRAN;
END
GO
