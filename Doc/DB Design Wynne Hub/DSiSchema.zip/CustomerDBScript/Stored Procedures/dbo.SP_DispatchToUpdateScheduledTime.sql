SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[SP_DispatchToUpdateScheduledTime] @TaskId UNIQUEIDENTIFIER, @ScheduledTime DATETIME, @UserId UNIQUEIDENTIFIER
AS
BEGIN
	BEGIN TRAN;
	DECLARE  @OrderId AS UNIQUEIDENTIFIER, @orderItemId AS UNIQUEIDENTIFIER, @mcsTaskId AS UNIQUEIDENTIFIER, @driverId AS UNIQUEIDENTIFIER;
	SELECT @mcsTaskId = MCS_Trip_Stop_TaskID, @orderItemId = TMS_Order_ItemID, @driverId = Driver_HR_EmployeeID FROM TMS_Order_Item_Task WHERE ID = @TaskId;
	SET @OrderId = (SELECT TMS_OrderID FROM TMS_Order_Item WHERE ID = @orderItemId);

	--update scheduled time of task
	UPDATE TMS_Order_Item_Task SET ScheduledTime = @ScheduledTime, ModifiedBy = @UserId, DateModified = GETUTCDATE()  WHERE ID = @TaskId;
	--DISPATCH to update promise time of stop
	BEGIN
		--Otherwise dispatch new task
		IF (@driverId IS NOT NULL AND EXISTS (SELECT ID FROM MCS_Device WHERE HR_EmployeeID = @driverId AND IsActive = 1))
		BEGIN
			IF (@mcsTaskId IS NULL)
			--PROCESS NEW DISPATCH
			BEGIN
				EXEC SP_DispatchNewTask @UserId, @OrderId, @orderItemId, @TaskId;
			END
			ELSE -- @mcsTaskID IS NOT NULL
			BEGIN
				EXEC SP_ReDispatchTask @UserId, @OrderId, @orderItemId, @TaskId;
			END
		END
	END
	COMMIT TRAN;
END
GO
