SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[sp_GetColumnsFromTable] (@table_name NVARCHAR(100), @data_type NVARCHAR(50))	
AS
BEGIN
    SELECT t.ColumnName
	FROM (SELECT COLUMN_NAME AS ColumnName, 
		CASE DATA_TYPE
			WHEN 'uniqueidentifier' THEN 'Guid'
			WHEN 'bit'				THEN 'Boolean'
			WHEN 'int'				THEN 'Int'
			WHEN 'varchar'			THEN 'String'
			WHEN 'nvarchar'			THEN 'String'
			WHEN 'datetime'			THEN 'DateTime'
			WHEN 'date'				THEN 'DateTime'
			WHEN 'decimal'			THEN 'Decimal'
			WHEN 'numeric'			THEN 'Decimal'
			WHEN 'xml'				THEN 'XML'					
		END AS DataType
	FROM INFORMATION_SCHEMA.COLUMNS
	WHERE TABLE_NAME=@table_name) AS t
	WHERE t.DataType = @data_type
END
GO
