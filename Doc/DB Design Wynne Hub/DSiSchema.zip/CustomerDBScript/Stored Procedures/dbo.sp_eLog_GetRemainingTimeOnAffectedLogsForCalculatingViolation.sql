SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

-- =============================================
-- Author:		HIEU - CFB
-- Create date: 03/20/2018
-- Description:	
-- =============================================
-- [sp_eLog_GetRemainingTimeOnAffectedLogsForCalculatingViolation] 'bbcc731b-1eb4-11e9-814a-00155db47809', '2020-12-23 08:00:00.000', '2020-12-24 08:00:00.000'
CREATE PROCEDURE [dbo].[sp_eLog_GetRemainingTimeOnAffectedLogsForCalculatingViolation]
	@HR_EmployeeID uniqueidentifier,
	@From datetime,
	@To datetime
	
AS
BEGIN
	SET NOCOUNT ON;
											   
	declare @_HR_EmployeeID uniqueidentifier = @HR_EmployeeID

	DECLARE @TempDailyWeeklyResetTbl AS TABLE (		
			StartTime datetime, 
			EndTime datetime, 
			Duration bigint, 
			dailyResetInterstate datetime, 
			dailyResetIntrastate datetime,
			weeklyResetInterstate datetime,
			weeklyResetIntrastate datetime
	);
	INSERT INTO @TempDailyWeeklyResetTbl 
	select starttime_grp, endtime_grp, duration_grp, dailyResetInterstate, dailyResetIntrastate, weeklyResetInterstate, weeklyResetIntrastate
	from (
		select *
			,hours = 	datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())) / 3600
			,duration_grp = datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())) 
			,dailyResetInterstate = case when isOn = 0 and datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())) >= InterstateDailyResetHours * 3600
				then endtime_grp else null end
			,dailyResetIntrastate = case when isOn = 0 and datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())) >= IntrastateDailyResetHours * 3600
									then endtime_grp else null end
			,weeklyResetInterstate = case when isOn = 0 and datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())) >= InterstateWeeklyResetHours * 3600
									then endtime_grp else null end
			,weeklyResetIntrastate = case when isOn = 0 and datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())) >= IntrastateWeeklyResetHours * 3600
									then endtime_grp else null end
		from (
			select
				hr_employeeid, 
				InterstateDailyResetHours,
				InterstateWeeklyResetHours,
				IntrastateDailyResetHours,
				IntrastateWeeklyResetHours,
				--  keyword, 
				isOn,
				grp, 
				starttime_grp = min(starttime), 
				endtime_grp = max(endtime)
			from (
					select 
						rr.*, 
						count(*) over (partition by grp, isOn) as cnt
					from (
							select *
								,grp = (
									row_number() over (partition by r.hr_employeeid order by r.starttime desc)
										- row_number() over (partition by r.hr_employeeid, r.isOn order by r.starttime desc)
								) 
							from (
								select 
									hr_employeeid, 
									starttime, 			   
									endtime,
									keyword,
									hos2.InterstateDailyResetHours,
									hos2.InterstateWeeklyResetHours,
									hos2.IntrastateDailyResetHours,
									hos2.IntrastateWeeklyResetHours,
									isOn = case when vdrd2.Keyword in ('ELOG_SpecialStatus_PersonalConveyance', 'Off_Duty', 'In_Sleeper') then 0 else 1 end
								from v_elog_DailyReportDetail vdrd2
									inner join [dbo].[HR_Employee] h2 on h2.ID = vdrd2.hr_employeeid
									inner join [dbo].[FMS_Elog_HOSRule] hos2 on hos2.ID = h2.[FMS_Elog_HOSRuleID] 
								where vdrd2.EndTime is not null 
									and vdrd2.hr_employeeid = @_HR_EmployeeID
								--	vdrd2.StartTime >= DATEADD(month, -1,getutcdate())													
								--	and fedrd3.StartTime > '2020-11-01'	-- update to start of current day
							) r
			
						) rr
					-- where keyword = 'Off_Duty'
					) rrr
			where rrr.cnt >= 1 	--  and hr_employeeid = 'D8B3C916-F729-11E7-8124-00155DB47818'
			group by rrr.hr_employeeid
				,rrr.isOn
				,rrr.grp
				,InterstateDailyResetHours
				,InterstateWeeklyResetHours
				,IntrastateDailyResetHours
				,IntrastateWeeklyResetHours
		) ssss
		--where isOn = 0	 
	) rrrrr 
	where isOn = 0 
		and (
			dailyResetInterstate is not null 
			or dailyResetIntrastate is not null 
			or weeklyResetInterstate is not null 
			or weeklyResetIntrastate is not null 
		)
		and starttime_grp > dateadd(month, -3, @From)
		and starttime_grp < dateadd(month, 3, @To)

	--select * from @TempDailyWeeklyResetTbl
	
	select -- *,
		d.ID,
		--d.ReportItemID,
		d.Keyword,		
		d.StartTime,
		d.EndTime,	
		--d.MaxRestBrealHours,
		--start1 = dateadd(hour, -8, d.StartTime),
		--end1 = dateadd(hour, -8, d.EndTime),
		d.StartTimeOfWeek,
		d.StartTimeOfRolling,	
		d.StartTimeOfDay,
		d.StartTimeOfDayNormal,
		d.StartOfSplitSleeperBerth,
		--split1 = dateadd(hour, -8, d.StartOfSplitSleeperBerth),
		d.DurationSplitSleeperBerth,
		d.SplitSleeperBerth2ndSegment,
		d.IsInterstate,		
		d.LastRestTime,
		d.City,
		d.State,
		d.EquipmentNumber,
		--d.Is16HourRuleException,
		d.IsUse16HourRuleException,
		--d.IsAdverseDriving,
		d.IsUseAdverseDriving,
		d.IsOversizedLoad,
		RemainingOnDutyTime = cast(d.RemainingOnDutyTime as bigint),
		RemainingRestBreakTime= cast(d.RemainingRestBreakTime as bigint),
		RemainingDrivingTime= cast(d.RemainingDrivingTime as bigint),
		RemainingCycleTime = cast((
			CASE WHEN d.Keyword = 'Driving_On_Duty' and d.StartTimeOfRolling is not null
				THEN (
					select (d.InterstateMultiDayHours1 * 3600) - sum(datediff(s, fedrd2.StartTime, isnull(fedrd2.EndTime, getutcdate())))
						from v_elog_DailyReportDetail fedrd2							
						where fedrd2.Keyword IN ('On_Duty', 'Driving_On_Duty', 'ELOG_SpecialStatus_YardMove') 
							and fedrd2.HR_EmployeeID = @_HR_EmployeeID							
							-- get all logs which come from past 7th or 8th day to calculate remaining cycle time, it is greater than start of week 
							and fedrd2.StartTime >= StartTimeOfRolling
				)					 
				ELSE d.RemainingCycleTime
			END
		) as bigint)
			
	from (
		select tttttt.*,
			RemainingOnDutyTime = case when Keyword = 'Driving_On_Duty' 
										then (
											case 												
												when IsUse16HourRuleException = 1 and IsInterstate = 1 and IsUseAdverseDriving = 0
													then MaxExemptionHours 
												else MaxOnDutyHours 
												end
											) - 
											(
												select SUM(datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())))
												from (
													select
														hr_employeeid, 
														keyword, 
														grp, 
														starttime_grp = min(starttime), 
														endtime_grp = max(endtime)
													from (
															select 
																ss.*, 
																count(*) over (partition by grp, Keyword) as cnt
															from (
																	select 
																		s.hr_employeeid,
																		s.keyword,
																		s.starttime, 
																		endtime = isnull(s.endtime, getutcdate()),
																		grp = (
																			row_number() over (partition by s.hr_employeeid order by s.starttime desc)
																			 - row_number() over (partition by s.hr_employeeid, s.Keyword order by s.starttime desc)
																		) 
																	from (
																		select 
																			hr_employeeid, 
																			starttime, 
																			endtime,
																			keyword_ori = vdrd2.Keyword,
																			keyword = case when vdrd2.Keyword = 'ELOG_SpecialStatus_PersonalConveyance' then 'Off_Duty' else vdrd2.Keyword end
																		from v_elog_DailyReportDetail vdrd2
																		WHERE vdrd2.hr_employeeid = @_HR_EmployeeID																													
																			and vdrd2.StartTime >= (case when StartOfSplitSleeperBerth is not null then StartOfSplitSleeperBerth else StartTimeOfDay end)	-- update to start of current day
																			and vdrd2.StartTime < tttttt.EndTime
																	) s
															   ) ss
							 
														 ) sss
													where sss.cnt >= 1
													group by sss.hr_employeeid, sss.keyword, sss.grp 					 
												) ssss
												where keyword <> 'In_Sleeper' 
													or (keyword = 'In_Sleeper' and datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())) < 7 * 3600)	
											
											)
											--datediff(second, (case when StartOfSplitSleeperBerth is not null then StartOfSplitSleeperBerth else StartTimeOfDay end), tttttt.EndTime)
										else 0 end,
			RemainingRestBreakTime = case when Keyword = 'Driving_On_Duty' 
										then (--MaxRestBrealHours - datediff(second, isnull(LastRestTime, tttttt.StartTime), tttttt.EndTime)
											SELECT -- top 1 CAST((8 * 3600) - DATEDIFF(SECOND, t1.Starttime, (case when Keyword <> 'Driving_On_Duty' then isnull(StartTime, GETUTCDATE() )  else GETUTCDATE() end) ) AS bigint) 
												top 1 CAST(		   
													(8 * 3600) - (
																	select sum(datediff(SECOND, vdrd3.Starttime, isnull(vdrd3.Endtime, GETUTCDATE())))						
																	from v_elog_DailyReportDetail vdrd3
																	where vdrd3.Keyword = 'Driving_On_Duty' 
																		and vdrd3.HR_EmployeeID = @_HR_EmployeeID
																		and vdrd3.StartTime < tttttt.EndTime
																		and vdrd3.StartTime >= LastRestTime  								
																)
														AS bigint)
											FROM (
													SELECT ROW_NUMBER() OVER (ORDER BY vdrd2.StartTime desc) AS rownum,								
														StartTime, 
														EndTime
													from v_elog_DailyReportDetail vdrd2
													where vdrd2.Keyword = 'Driving_On_Duty' 
														and vdrd2.HR_EmployeeID = @_HR_EmployeeID
														and vdrd2.StartTime < tttttt.EndTime
														and vdrd2.StartTime >= LastRestTime  			
												)t1
												LEFT JOIN (
													SELECT ROW_NUMBER() OVER (ORDER BY vdrd2.StartTime desc) AS rownum2,
															StartTime2 = StartTime, 
															EndTime2 = EndTime
													from v_elog_DailyReportDetail vdrd2
													where vdrd2.Keyword = 'Driving_On_Duty' 
														and vdrd2.HR_EmployeeID = @_HR_EmployeeID
														and vdrd2.StartTime < tttttt.EndTime
														and vdrd2.StartTime >= LastRestTime  				
												)t2 ON t1.rownum = t2.rownum2 - 1
											WHERE DATEDIFF(SECOND, t2.EndTime2, isnull(t1.StartTime, GETUTCDATE())) >= 1800
												OR t2.StartTime2 is null 
										)
										else 0 end,
			RemainingDrivingTime = case when Keyword = 'Driving_On_Duty' 
										then MaxDriveHours - (
											select sum(datediff(second, fedrd2.StartTime, fedrd2.EndTime))
											from v_elog_DailyReportDetail fedrd2
											where fedrd2.HR_EmployeeID = @_HR_EmployeeID
												and fedrd2.Keyword = 'Driving_On_Duty'
												and fedrd2.StartTime between (case when StartOfSplitSleeperBerth is not null then StartOfSplitSleeperBerth else StartTimeOfDay end) and tttttt.StartTime										
										)
										else 0 end,
			RemainingCycleTime = case when Keyword = 'Driving_On_Duty' 
										then MultiDayHours - (
											select sum(datediff(second, fedrd2.StartTime, fedrd2.EndTime))
											from v_elog_DailyReportDetail fedrd2
											where fedrd2.HR_EmployeeID = @_HR_EmployeeID
												and fedrd2.Keyword in ('On_Duty', 'Driving_On_Duty', 'ELOG_SpecialStatus_YardMove') 
												and fedrd2.StartTime between StartTimeOfWeek and tttttt.StartTime										
										)
										else 0 end,
			-- Rolling 7/8 days cycle: get all logs which come from past 7th or 8th day to calculate remaining cycle time, it is greater than start of week 
			StartTimeOfRolling = case when IsInterstate = 1
										 then (
											select top 1 StartTime 
											from (
												SELECT ROW_NUMBER() OVER (ORDER BY fedr3.StartTime desc) AS rownum,
													fedr3.StartTime	
												FROM @TempDailyWeeklyResetTbl fedr3
												where fedr3.dailyResetInterstate is not null
													and fedr3.StartTime >= StartTimeOfWeek
													and fedr3.StartTime < tttttt.StartTime
											)d
											where rownum = InterstateMultiDayDays1	
										)
									else null end
		from (
			select ttttt.* 				
				,MaxOnDutyHours = (
									case 
										when IsInterstate = 1 
											then (InterstateMaxOnDutyHours + (case when IsUseAdverseDriving = 1 then 2 else 0 end)) 
										else (IntrastateMaxOnDutyHours + (case when IsUseAdverseDriving = 1 then 2 else 0 end)) end
									) * 3600
				,MaxExemptionHours = (case when IsInterstate = 1 then InterstateMaxExemptionHours else IntrastateMaxExemptionHours end) * 3600
				,MultiDayHours = (case when IsInterstate = 1 then InterstateMultiDayHours1 else IntrastateMultiDayHours1 end) * 3600
				,MaxDriveHours = (
					case 
						when IsInterstate = 1 
							then (InterstateMaxDriveHours + (case when IsUseAdverseDriving = 1 then 2 else 0 end)) 
						else (IntrastateMaxDriveHours + (case when IsUseAdverseDriving = 1 then 2 else 0 end)) end
					) * 3600
				,MaxRestBrealHours = 8 * 3600											
				,LastRestTime = (
					case when Keyword = 'Driving_On_Duty'
						then (						
							SELECT top 1 d1.StartTime
							FROM (
									SELECT ROW_NUMBER() OVER (ORDER BY StartTime desc) AS rownum,								
										StartTime, 
										EndTime
									FROM v_elog_DailyReportDetail fedrd2 										
									WHERE fedrd2.Keyword = 'Driving_On_Duty'
										and fedrd2.HR_EmployeeID = @_HR_EmployeeID
										and fedrd2.StartTime <> isnull(fedrd2.EndTime, getutcdate())
										and fedrd2.StartTime between StartTimeOfDay and isnull(ttttt.EndTime, getutcdate())	
										--and fedrd2.FMS_Elog_DailyReportID = t.FMS_Elog_DailyReportID
								)d1
								LEFT JOIN (
									SELECT ROW_NUMBER() OVER (ORDER BY StartTime desc) AS rownum2,
											StartTime2 = StartTime, 
											EndTime2 = EndTime
									FROM v_elog_DailyReportDetail fedrd2		
									WHERE fedrd2.Keyword = 'Driving_On_Duty'
										and fedrd2.HR_EmployeeID = @_HR_EmployeeID
										and fedrd2.StartTime <> isnull(fedrd2.EndTime, getutcdate())
										and fedrd2.StartTime between StartTimeOfDay and isnull(ttttt.EndTime, getutcdate())	
										--and fedrd2.FMS_Elog_DailyReportID = t.FMS_Elog_DailyReportID
								)d2 ON d1.rownum = d2.rownum2 - 1
							WHERE DATEDIFF(SECOND, d2.EndTime2, isnull(d1.StartTime, GETUTCDATE())) >= 1800
								OR d2.StartTime2 is null 	
						)	
						else null end
				)
												
			from (
				select *
					,IsStartDay =case when StartTimeOfDay = tttt.StartTime then 1 else 0 end
					,IsStartWeek = case when StartTimeOfWeek = tttt.StartTime then 1 else 0 end
					,IsUse16HourRuleException = case when exists (
																	select 1 
																	from v_elog_DailyReportDetail fedrd2
																	WHERE fedrd2.HR_EmployeeID = @_HR_EmployeeID
																		and fedrd2.Is16HourRuleException = 1		
																		and fedrd2.StartTime between StartTimeOfDay and isnull(EndTimeOfDay, getutcdate())		
																) then cast(1 AS BIT) else cast(0 AS BIT)  end
					,IsUseAdverseDriving = case when exists (
																select 1 
																from v_elog_DailyReportDetail fedrd2
																WHERE fedrd2.HR_EmployeeID = @_HR_EmployeeID
																		and fedrd2.IsAdverseDriving = 1		
																	and fedrd2.StartTime between StartTimeOfDay and isnull(EndTimeOfDay, getutcdate())	
															) then cast(1 AS BIT) else cast(0 AS BIT) end
					,IsOversizedLoad = case when exists (
																select 1 
																from v_elog_DailyReportDetail fedrd2
																WHERE fedrd2.HR_EmployeeID = @_HR_EmployeeID
																	and fedrd2.IsOversizedLoad = 1		
																	and fedrd2.StartTime between StartTimeOfDay and isnull(EndTimeOfDay, getutcdate())	
															) then cast(1 AS BIT) else cast(0 AS BIT) end
				from (
					 select *
						,StartTimeOfDay = case when StartOfSplitSleeperBerth is not null and StartOfSplitSleeperBerth > StartTimeOfDayNormal then StartOfSplitSleeperBerth else StartTimeOfDayNormal end 
					from (
						 select tt.*						
							, StartOfSplitSleeperBerth = (
								case when Keyword = 'Driving_On_Duty' or Keyword = 'On_Duty' or Keyword = 'ELOG_SpecialStatus_YardMove' 
									then (	-- [sp_eLog_GetRemainingTimeOnAffectedLogsForCalculatingViolation] 'bddaa71a-5e39-11e5-80e3-00155db47815', '2020-11-25', '2020-11-27'								
										select top 1 endtime_ssb
										from (
										   select *
												,endtime_ssb = (
													select top 1 endtime_grp
													from (
														select *,
															duration_grp = datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate()))
														from (
															select 
																hr_employeeid,
																keyword, 
																grp, 
																starttime_grp = min(starttime), 
																endtime_grp = max(endtime)
															from (
																	select 
																		ww.*, 
																		count(*) over (partition by grp, Keyword) as cnt
																	from (
																			select *
																				,grp = (
																					row_number() over (partition by w.hr_employeeid order by w.starttime desc)
																						- row_number() over (partition by w.hr_employeeid, w.Keyword order by w.starttime desc)
																				) 
																			from (
																				select 
																					hr_employeeid, 
																					starttime, 
																					endtime,
																					keyword = case when vdrd2.Keyword = 'ELOG_SpecialStatus_PersonalConveyance' then 'Off_Duty' else vdrd2.Keyword end
																				from v_elog_DailyReportDetail vdrd2
																				where vdrd2.EndTime is not null					
																					and vdrd2.StartTime >= tt.StartTimeOfDayNormal
																					and vdrd2.StartTime <= tt.StartTime	
																					and vdrd2.hr_employeeid = @_HR_EmployeeID
																			) w
																		) ww
																	-- where keyword = 'Off_Duty'
																	) www
															where www.cnt >= 1
															group by www.hr_employeeid, www.keyword, www.grp
														) wwww
														where keyword in ('In_Sleeper', 'Off_Duty', 'ELOG_SpecialStatus_PersonalConveyance')
													) wwwww 
													where wwwww.hr_employeeid = sssss.hr_employeeid
														and wwwww.duration_grp >= 2 * 3600 
														and wwwww.duration_grp < 10 * 3600	     
														--and wwwww.starttime_grp <> sssss.starttime_grp
														and wwwww.starttime_grp < sssss.starttime_grp
														and (
															(sssss.keyword = 'In_Sleeper' and sssss.duration_grp >= 7 * 3600 and wwwww.duration_grp + sssss.duration_grp >= 10 * 3600)
															or (
																(sssss.keyword <> 'In_Sleeper' or (sssss.keyword = 'In_Sleeper' and sssss.duration_grp < 7 * 3600))
																and (wwwww.keyword = 'In_Sleeper' and wwwww.duration_grp >= 7 * 3600 and wwwww.duration_grp + sssss.duration_grp >= 10 * 3600)
															)
														)
													order by endtime_grp desc
											)
											from (
												select *,
													h = 	datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())) / 3600,
													duration_grp = datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate()))
			
												from (
													select
														hr_employeeid, 
														keyword, 
														grp, 
														starttime_grp = min(starttime), 
														endtime_grp = max(endtime)
													from (
															select 
																ss.*, 
																count(*) over (partition by grp, Keyword) as cnt
															from (
																	select *
																		,grp = (
																			row_number() over (partition by s.hr_employeeid order by s.starttime desc)
																				- row_number() over (partition by s.hr_employeeid, s.Keyword order by s.starttime desc)
																		) 
																	from (
																		select 
																			hr_employeeid, 
																			starttime, 			   
																			endtime,
																			keyword_ori = vdrd2.Keyword,
																			keyword = case when vdrd2.Keyword = 'ELOG_SpecialStatus_PersonalConveyance' then 'Off_Duty' else vdrd2.Keyword end
																		from v_elog_DailyReportDetail vdrd2
																		where vdrd2.EndTime is not null
																			and vdrd2.StartTime >= tt.StartTimeOfDayNormal
																			and vdrd2.StartTime <= tt.StartTime	
																			and vdrd2.hr_employeeid = @_HR_EmployeeID
																	) s
																) ss
															-- where keyword = 'Off_Duty'
															) sss
													where sss.cnt >= 1
													group by sss.hr_employeeid, sss.keyword, sss.grp
												) ssss
												where keyword in ('In_Sleeper', 'Off_Duty', 'ELOG_SpecialStatus_PersonalConveyance')
											) sssss 
											where sssss.duration_grp >= 2 * 3600 
												and sssss.duration_grp < 10 * 3600
												and hr_employeeid = @_HR_EmployeeID
										)ssssss
										where endtime_ssb is not null
										order by endtime_ssb desc
							
									) else null end
							)
							, DurationSplitSleeperBerth = (
								case when Keyword = 'Driving_On_Duty' or Keyword = 'On_Duty' or Keyword = 'ELOG_SpecialStatus_YardMove' 
									then (	-- [sp_eLog_GetRemainingTimeOnAffectedLogsForCalculatingViolation] 'bddaa71a-5e39-11e5-80e3-00155db47815', '2020-11-25', '2020-11-27'
										select top 1 duration_ssb
										from (
										   select *
												,duration_ssb = (
													select top 1 (case when wwwww.keyword = 'In_Sleeper' and duration_grp >= 7 * 3600 then 0 else duration_grp end) 
													from (
														select *,
															duration_grp = datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate()))
														from (
															select 
																hr_employeeid,
																keyword, 
																grp, 
																starttime_grp = min(starttime), 
																endtime_grp = max(endtime)
															from (
																	select 
																		ww.*, 
																		count(*) over (partition by grp, Keyword) as cnt
																	from (
																			select *
																				,grp = (
																					row_number() over (partition by w.hr_employeeid order by w.starttime desc)
																						- row_number() over (partition by w.hr_employeeid, w.Keyword order by w.starttime desc)
																				) 
																			from (
																				select 
																					hr_employeeid, 
																					starttime, 
																					endtime,
																					keyword = case when vdrd2.Keyword = 'ELOG_SpecialStatus_PersonalConveyance' then 'Off_Duty' else vdrd2.Keyword end
																				from v_elog_DailyReportDetail vdrd2
																				where vdrd2.EndTime is not null					
																					and vdrd2.StartTime >= tt.StartTimeOfDayNormal
																					and vdrd2.StartTime <= tt.StartTime	
																					and vdrd2.hr_employeeid = @_HR_EmployeeID
																			) w
																		) ww
																	-- where keyword = 'Off_Duty'
																	) www
															where www.cnt >= 1
															group by www.hr_employeeid, www.keyword, www.grp
														) wwww
														where keyword in ('In_Sleeper', 'Off_Duty', 'ELOG_SpecialStatus_PersonalConveyance')
													) wwwww 
													where wwwww.hr_employeeid = sssss.hr_employeeid
														and wwwww.duration_grp >= 2 * 3600 
														and wwwww.duration_grp < 10 * 3600	     
														--and wwwww.starttime_grp <> sssss.starttime_grp
														and wwwww.starttime_grp < sssss.starttime_grp
														and (
															(sssss.keyword = 'In_Sleeper' and sssss.duration_grp >= 7 * 3600 and wwwww.duration_grp + sssss.duration_grp >= 10 * 3600)
															or (
																(sssss.keyword <> 'In_Sleeper' or (sssss.keyword = 'In_Sleeper' and sssss.duration_grp < 7 * 3600))
																and (wwwww.keyword = 'In_Sleeper' and wwwww.duration_grp >= 7 * 3600 and wwwww.duration_grp + sssss.duration_grp >= 10 * 3600)
															)
														)
													order by endtime_grp desc
											)
											from (
												select *,
													h = 	datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())) / 3600,
													duration_grp = datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate()))
			
												from (
													select
														hr_employeeid, 
														keyword, 
														grp, 
														starttime_grp = min(starttime), 
														endtime_grp = max(endtime)
													from (
															select 
																ss.*, 
																count(*) over (partition by grp, Keyword) as cnt
															from (
																	select *
																		,grp = (
																			row_number() over (partition by s.hr_employeeid order by s.starttime desc)
																				- row_number() over (partition by s.hr_employeeid, s.Keyword order by s.starttime desc)
																		) 
																	from (
																		select 
																			hr_employeeid, 
																			starttime, 			   
																			endtime,
																			keyword_ori = vdrd2.Keyword,
																			keyword = case when vdrd2.Keyword = 'ELOG_SpecialStatus_PersonalConveyance' then 'Off_Duty' else vdrd2.Keyword end
																		from v_elog_DailyReportDetail vdrd2
																		where vdrd2.EndTime is not null
																			and vdrd2.StartTime >= tt.StartTimeOfDayNormal
																			and vdrd2.StartTime <= tt.StartTime	
																			and vdrd2.hr_employeeid = @_HR_EmployeeID
																	) s
																) ss
															-- where keyword = 'Off_Duty'
															) sss
													where sss.cnt >= 1
													group by sss.hr_employeeid, sss.keyword, sss.grp
												) ssss
												where keyword in ('In_Sleeper', 'Off_Duty', 'ELOG_SpecialStatus_PersonalConveyance')
											) sssss 
											where sssss.duration_grp >= 2 * 3600 
												and sssss.duration_grp < 10 * 3600
												and hr_employeeid = @_HR_EmployeeID
										)ssssss
										where duration_ssb is not null
										--order by endtime_ssb desc
									) else null end
							)
							, SplitSleeperBerth2ndSegment = (
								case when Keyword = 'Driving_On_Duty' or Keyword = 'On_Duty' or Keyword = 'ELOG_SpecialStatus_YardMove' 
									then (	-- [sp_eLog_GetRemainingTimeOnAffectedLogsForCalculatingViolation] 'bddaa71a-5e39-11e5-80e3-00155db47815', '2020-11-25', '2020-11-27'								
										select top 1 endtime_grp
										from (
										   select *
												,endtime_ssb = (
													select top 1 endtime_grp
													from (
														select *,
															duration_grp = datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate()))
														from (
															select 
																hr_employeeid,
																keyword, 
																grp, 
																starttime_grp = min(starttime), 
																endtime_grp = max(endtime)
															from (
																	select 
																		ww.*, 
																		count(*) over (partition by grp, Keyword) as cnt
																	from (
																			select *
																				,grp = (
																					row_number() over (partition by w.hr_employeeid order by w.starttime desc)
																						- row_number() over (partition by w.hr_employeeid, w.Keyword order by w.starttime desc)
																				) 
																			from (
																				select 
																					hr_employeeid, 
																					starttime, 
																					endtime,
																					keyword = case when vdrd2.Keyword = 'ELOG_SpecialStatus_PersonalConveyance' then 'Off_Duty' else vdrd2.Keyword end
																				from v_elog_DailyReportDetail vdrd2
																				where vdrd2.EndTime is not null					
																					and vdrd2.StartTime >= tt.StartTimeOfDayNormal
																					and vdrd2.StartTime <= tt.StartTime	
																					and vdrd2.hr_employeeid = @_HR_EmployeeID
																			) w
																		) ww
																	-- where keyword = 'Off_Duty'
																	) www
															where www.cnt >= 1
															group by www.hr_employeeid, www.keyword, www.grp
														) wwww
														where keyword in ('In_Sleeper', 'Off_Duty', 'ELOG_SpecialStatus_PersonalConveyance')
													) wwwww 
													where wwwww.hr_employeeid = sssss.hr_employeeid
														and wwwww.duration_grp >= 2 * 3600 
														and wwwww.duration_grp < 10 * 3600	     
														--and wwwww.starttime_grp <> sssss.starttime_grp
														and wwwww.starttime_grp < sssss.starttime_grp
														and (
															(sssss.keyword = 'In_Sleeper' and sssss.duration_grp >= 7 * 3600 and wwwww.duration_grp + sssss.duration_grp >= 10 * 3600)
															or (
																(sssss.keyword <> 'In_Sleeper' or (sssss.keyword = 'In_Sleeper' and sssss.duration_grp < 7 * 3600))
																and (wwwww.keyword = 'In_Sleeper' and wwwww.duration_grp >= 7 * 3600 and wwwww.duration_grp + sssss.duration_grp >= 10 * 3600)
															)
														)
													order by endtime_grp desc
											)
											from (
												select *,
													h = 	datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())) / 3600,
													duration_grp = datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate()))
			
												from (
													select
														hr_employeeid, 
														keyword, 
														grp, 
														starttime_grp = min(starttime), 
														endtime_grp = max(endtime)
													from (
															select 
																ss.*, 
																count(*) over (partition by grp, Keyword) as cnt
															from (
																	select *
																		,grp = (
																			row_number() over (partition by s.hr_employeeid order by s.starttime desc)
																				- row_number() over (partition by s.hr_employeeid, s.Keyword order by s.starttime desc)
																		) 
																	from (
																		select 
																			hr_employeeid, 
																			starttime, 			   
																			endtime,
																			keyword_ori = vdrd2.Keyword,
																			keyword = case when vdrd2.Keyword = 'ELOG_SpecialStatus_PersonalConveyance' then 'Off_Duty' else vdrd2.Keyword end
																		from v_elog_DailyReportDetail vdrd2
																		where vdrd2.EndTime is not null
																			and vdrd2.StartTime >= tt.StartTimeOfDayNormal
																			and vdrd2.StartTime <= tt.StartTime	
																			and vdrd2.hr_employeeid = @_HR_EmployeeID
																	) s
																) ss
															-- where keyword = 'Off_Duty'
															) sss
													where sss.cnt >= 1
													group by sss.hr_employeeid, sss.keyword, sss.grp
												) ssss
												where keyword in ('In_Sleeper', 'Off_Duty', 'ELOG_SpecialStatus_PersonalConveyance')
											) sssss 
											where sssss.duration_grp >= 2 * 3600 
												and sssss.duration_grp < 10 * 3600
												and hr_employeeid = @_HR_EmployeeID
										)ssssss
										where endtime_ssb is not null
										order by endtime_ssb desc
							
									) else null end
							)
						from (
						   select t.*
								,StartTimeOfDayNormal = (
									select top 1 temp1.EndTime
									from @TempDailyWeeklyResetTbl temp1
									where (case when t.IsInterstate = 1 then temp1.dailyResetInterstate else temp1.dailyResetIntrastate end) <= t.StartTime 	
									order by temp1.StartTime desc 
								)
								,EndTimeOfDay = (
									select top 1 temp1.StartTime
									from @TempDailyWeeklyResetTbl temp1
									where (case when t.IsInterstate = 1 then temp1.dailyResetInterstate else temp1.dailyResetIntrastate end) > t.StartTime 	
									order by temp1.StartTime asc 
								)
								,StartTimeOfWeek = (
									select top 1 temp1.EndTime
									from @TempDailyWeeklyResetTbl temp1
									where (case when t.IsInterstate = 1 then temp1.weeklyResetInterstate else temp1.weeklyResetIntrastate end) <= t.StartTime 	
									order by temp1.StartTime desc 
								)
								,EndTimeOfWeek = (
									select top 1 temp1.StartTime
									from @TempDailyWeeklyResetTbl temp1
									where (case when t.IsInterstate = 1 then temp1.weeklyResetInterstate else temp1.weeklyResetIntrastate end) > t.StartTime 	
									order by temp1.StartTime asc 
								) 						 					 
							from (
								 select fedrd.ID,
										ReportItemID = fedrd.ID,
										scli.Keyword,
										--StartTimeOfDay = fedr.StartTime,
										fedrd.StartTime,
										fedrd.EndTime,		
										Duration = datediff(hour,fedrd.StartTime,fedrd.EndTime),
										--IsStartDay =case when fedr.StartTime = fedrd.StartTime then 1 else 0 end,
										--IsStartWeek = case when scli.Keyword = 'Driving_On_Duty' and exists (select 1 from FMS_Elog_DailyReport fedr2 where fedr2.hr_employeeID = @_HR_EmployeeID and fedr2.IsWeeklyReset = 1 and fedrd.StartTime = fedr2.EndTime) then 1 else 0 end,
										-- calculate interstate 
										IsInterstate = CASE WHEN 		
															fedrd.IsInterstateLoad = 1	
															OR (fedr.MotorCarrierID IS NOT NULL AND mdces.State <> fmc.State)		
															OR (												
																	select count (*)
																	from (
																		select temp_state.State
																		from (
																			select mdce2.State
																			from dbo.FMS_Elog_DailyReport_Detail fedrd2													
																				INNER JOIN dbo.MCS_Device_EventSummary mdce2 ON mdce2.ID = fedrd2.MCS_EventSummaryID
																			WHERE fedrd2.HR_EmployeeID = @_HR_EmployeeID
																				AND fedrd2.ELD_EventRecordStatus = 1
																				and mdce2.State is not null
																				and fedrd2.StartTime between DATEADD(day, -7, fedrd.StartTime) and DATEADD(Second, 1, fedrd.StartTime)																
																			union all
																			select fmc.State
																		) temp_state
																		group by temp_state.State
																	) temp_state_count
																) > 1		
															THEN cast(1 AS BIT)
															ELSE cast(0 AS BIT) 
														END,
										fedrd.FMS_Elog_DailyReportID,
										--fedrd.Is16HourRuleException,
										--IsUse16HourRuleException = case when exists (
										--											select 1 
										--											from dbo.FMS_Elog_DailyReport_Detail fedrd2
										--											WHERE fedrd2.HR_EmployeeID = fedrd.HR_EmployeeID
										--												and fedrd2.ELD_EventRecordStatus = 1
										--												and fedrd2.Is16HourRuleException = 1		
										--												and fedrd2.StartTime between fedr.StartTime and isnull(fedr.EndTime, getutcdate())													
										--												--and fedrd.StartTime between fedrd2.StartTime and isnull(fedr.EndTime, getutcdate())
										--										) then cast(1 AS BIT) else cast(0 AS BIT)  end,
										--fedrd.IsOversizedLoad,
										--fedrd.IsAdverseDriving,
										--IsUseAdverseDriving = case when exists (
										--											select 1 
										--											from dbo.FMS_Elog_DailyReport_Detail fedrd2
										--											WHERE fedrd2.HR_EmployeeID = fedrd.HR_EmployeeID
										--												and fedrd2.ELD_EventRecordStatus = 1
										--												and fedrd2.IsAdverseDriving = 1		
										--												and fedrd2.StartTime between fedr.StartTime and isnull(fedr.EndTime, getutcdate())													
										--												--and fedrd.StartTime between fedrd2.StartTime and isnull(fedr.EndTime, getutcdate())
										--										) then cast(1 AS BIT) else cast(0 AS BIT)  end,
										fedr.FMS_Elog_HOSRuleID,
										mdces.FMS_EquipmentID,	
										EquipmentNumber = fe.Number,
										-- check missing city or state violation					
										mdces.City,
										mdces.State
										,feh.InterstateMaxOnDutyHours
										,feh.IntrastateMaxOnDutyHours
										,feh.InterstateMaxExemptionHours
										,feh.IntrastateMaxExemptionHours
										,feh.InterstateMultiDayHours1
										,feh.IntrastateMultiDayHours1
										,feh.InterstateMaxDriveHours
										,feh.IntrastateMaxDriveHours	
										,feh.InterstateMultiDayDays1
										,feh.IntrastateMultiDayDays1			
									from [dbo].[FMS_Elog_DailyReport_Detail] fedrd		
										INNER JOIN dbo.System_CommonList_Item scli ON scli.ID = fedrd.CommonList_ElogStatusTypeID
										INNER JOIN dbo.FMS_Elog_DailyReport fedr ON fedr.ID = fedrd.FMS_Elog_DailyReportID					
										INNER JOIN dbo.MCS_Device_EventSummary mdces ON mdces.ID = fedrd.MCS_EventSummaryID	
										-- get HOS rules value to calculate remainning time for on duty, driving, rest break and cycle
										INNER JOIN dbo.FMS_Elog_HOSRule feh ON feh.ID = fedr.FMS_Elog_HOSRuleID			
										-- use motocarrier state to calculate interstate
										LEFT JOIN dbo.FMS_MotorCarrier fmc on fmc.ID = fedr.MotorCarrierID					
										-- check missing equipment violation
										LEFT JOIN dbo.FMS_Equipment fe ON fe.ID = mdces.FMS_EquipmentID	
									where fedrd.[ELD_EventRecordStatus] = 1
										and fedrd.HR_EmployeeID = @_HR_EmployeeID
										--and fedrd.EndTime is not null	
										and fedrd.StartTime between dateadd(month, -1, @From) and dateadd(month, 1, @To)					
								)t	
								-- get time until the end of week (weekly reset)
								where t.StartTime 
								between
									( 
										case 																		
											when exists (
												select 1-- top 1 temp2.dailyResetInterstate
												from @TempDailyWeeklyResetTbl temp2
												where (case when t.IsInterstate = 1 then temp2.dailyResetInterstate else temp2.dailyResetIntrastate end) <= @From 	
											) then (
												select top 1 temp2.EndTime
												from @TempDailyWeeklyResetTbl temp2
												where (case when t.IsInterstate = 1 then temp2.dailyResetInterstate else temp2.dailyResetIntrastate end) <= @From 	
												order by temp2.StartTime desc
											)
											else @From
										end	
									)  
									and (		
										case 																		
											when exists (
												select 1
												from @TempDailyWeeklyResetTbl temp1
												where (case when t.IsInterstate = 1 then temp1.weeklyResetInterstate else temp1.weeklyResetIntrastate end) > @to 
													and (@From not between temp1.StartTime and temp1.EndTime)
													and (@To not between temp1.StartTime and temp1.EndTime)
											) then (
												select top 1 temp2.EndTime
												from @TempDailyWeeklyResetTbl temp2
												where (case when t.IsInterstate = 1 then temp2.weeklyResetInterstate else temp2.weeklyResetIntrastate end) > @to 
													and (@From not between temp2.StartTime and temp2.EndTime)
													and (@To not between temp2.StartTime and temp2.EndTime)
												order by temp2.StartTime asc
											)
											else getutcdate()
										end		
									)	
						) tt
					) ttt    -- [sp_eLog_GetRemainingTimeOnAffectedLogsForCalculatingViolation] 'bbcc731b-1eb4-11e9-814a-00155db47809', '2020-12-23 08:00:00.000', '2020-12-24 08:00:00.000'
				) tttt				 				
			)ttttt				
		)tttttt
	) d 
	
	order by StartTime desc


END







GO
