SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[sp_TMSOnTimeDeliveryReport]
 @startdate datetime,
 @enddate datetime,
 @timezone float,
 @browser_colName nvarchar(256),
 @browser_colValue nvarchar(max)
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE 
	@deliverycomplete uniqueidentifier,
	@atdelivery uniqueidentifier,
	@outfordelivery uniqueidentifier
	SET @deliverycomplete = (SELECT TOP 1 Id FROM System_CommonList_Item WHERE Keyword = 'TMS_OrderItemStatus_DeliveryComplete')
	SET @atdelivery = (SELECT TOP 1 Id FROM System_CommonList_Item WHERE Keyword = 'TMS_OrderItemStatus_AtDelivery')
	SET @outfordelivery = (SELECT TOP 1 Id FROM System_CommonList_Item WHERE Keyword = 'TMS_OrderItemStatus_OutForDelivery')
	SELECT ScheduledTime
		, [OrderNumber]
		, [OrderItemNumber]
		, [CustomerName]
		, [CustomerCity]
		, [Model]
		, [TruckNo]
		, [DeliverySchedule]
		, [OutForDelivery]
		, [AtDelivery]
		, [DeliveryComplete]
		, [DeliveryVariance]
		, [DeliveryStatus]
		, [DriverName]
		, [DriverID]
		, [Organization]
	FROM (
	SELECT DeliverySchedule as ScheduledTime
		, [OrderNumber]
		, [OrderItemNumber]
		, [CustomerName]
		, [CustomerCity]
		, [Model]
		, [TruckNo]
		, [DeliverySchedule]
		, [OutForDelivery]
		, [AtDelivery]
		, [DeliveryComplete]
		, CONVERT(nvarchar(255), CASE WHEN [DeliverySchedule] IS NULL OR [AtDelivery] IS NULL THEN NULL ELSE DATEDIFF(mi, [DeliverySchedule], [AtDelivery]) END) AS [DeliveryVariance]
		, CASE WHEN [DeliverySchedule] IS NULL OR [AtDelivery] IS NULL THEN NULL 
				WHEN DATEDIFF(mi, [DeliverySchedule], [AtDelivery])  >= 60 THEN 'Very Late'
				WHEN DATEDIFF(mi, [DeliverySchedule], [AtDelivery])  >= 5 THEN 'Late'
				WHEN DATEDIFF(mi, [DeliverySchedule], [AtDelivery])  <= -15 THEN 'Early'
				ELSE 'On Time'
				END AS [DeliveryStatus]
		, [DriverName]
		, [DriverID]
		, [Organization]
	FROM(
		SELECT [order].OrderNumber
			, orderItem.OrderItemNumber AS OrderItemNumber
			, ISNULL(emp.FirstName,'')  + ' ' + ISNULL(emp.LastName,'') AS DriverName
			, emp.ID AS DriverID
			, ISNULL([cus].Name,'')	AS CustomerName
			, ISNULL([cusAddress].City, '')	AS CustomerCity
			, ISNULL([equip].Number,'') AS TruckNo
			, ISNULL([orderItemCus].StockNumber,'') AS StockNumber
			, ISNULL([orderItemCus].Make,'') AS Make
			, ISNULL([orderItemCus].Model,'') AS Model
			, ISNULL([orderItemCus].Machine,'') AS Machine
			, ISNULL([orderItemCus].PIN,'') AS Pin
			, [org].Name AS Organization
			,CONVERT(datetime,DATEADD(hour, @timezone,(
				SELECT tt.ScheduledTime
				FROM TMS_Order_Item_Task tt
						join System_CommonList_Item ss on ss.Id = tt.CommonList_TMSOrderItemTaskTypeId
					WHERE tt.TMS_Order_ItemID = [orderItem].Id and ss.Keyword = 'TMS_Order_Type_Delivery'
			))) AS [DeliverySchedule]
			,CONVERT(datetime, DATEADD(hour, @timezone,(
				SELECT MAX([taskEvent].DATECREATED)
				FROM TMS_Order_Event_Summary [taskEvent]
				WHERE TMS_Order_ItemId = [orderItem].ID and taskEvent.CommonList_TMSOrder_Item_Task_StatusId = @outfordelivery
			))) AS [OutForDelivery]
			,CONVERT(datetime, DATEADD(hour, @timezone,(
				SELECT MAX([taskEvent].DATECREATED)
				FROM TMS_Order_Event_Summary [taskEvent]
				WHERE TMS_Order_ItemId = [orderItem].ID and taskEvent.CommonList_TMSOrder_Item_Task_StatusId = @atdelivery
			))) AS [AtDelivery]
			,CONVERT(datetime, DATEADD(hour, @timezone,(
				SELECT MAX([taskEvent].DATECREATED)
				FROM TMS_Order_Event_Summary [taskEvent]
				WHERE TMS_Order_ItemId = [orderItem].ID and taskEvent.CommonList_TMSOrder_Item_Task_StatusId = @deliverycomplete
			))) AS [DeliveryComplete]
		FROM TMS_Order_Item [orderItem]
			INNER JOIN TMS_Order [order] on [order].ID = [orderItem].TMS_OrderID
			INNER JOIN dbo.TMS_Order_Item_Task AS task ON task.TMS_Order_ItemID = orderItem.ID
			INNER JOIN HR_Employee AS emp on emp.ID = task.Driver_HR_EmployeeID
			INNER JOIN dbo.System_CommonList_Item AS comEmployeeType ON emp.CommonList_EmployeeTypeID = comEmployeeType.ID and comEmployeeType.Keyword in ('HR_EmployeeType_Driver','HR_EmployeeType_SubHauler')
			LEFT OUTER JOIN dbo.CRM_Customer AS cus ON cus.ID = [order].CRM_CustomerID
			LEFT OUTER JOIN dbo.FMS_Equipment AS equip on equip.ID = [task].Truck_FMS_EquipmentID
			LEFT OUTER JOIN dbo.TMS_Order_Item_CustomData AS [orderItemCus] on [orderItemCus].TMS_Order_ItemID = [orderItem].ID
			LEFT OUTER JOIN [dbo].[CRM_Customer_Address] AS [cusAddress] ON [cusAddress].CRM_CustomerID = cus.ID
			INNER JOIN dbo.System_Organization AS org ON [order].System_OrganizationID = org.ID
		WHERE	[order].IsDelete = 0
		AND ScheduledTime between @startdate and @enddate
		GROUP BY
			[order].ID,
			[order].OrderNumber,
			emp.ID,
			emp.FirstName,
			emp.LastName,
			[orderItem].Id,
			[orderItem].OrderItemNumber,
			[cus].Name,
			[cusAddress].City,
			[equip].Number,
			[orderItemCus].StockNumber,
			[orderItemCus].Make,
			[orderItemCus].Model,
			[orderItemCus].Machine,
			[orderItemCus].PIN,
			[org].Name
		) AS T1
	)AS T
	WHERE
	CASE @browser_colName 
		WHEN 'OrderNumber' THEN OrderNumber
		WHEN 'OrderItemNumber' THEN OrderItemNumber
		WHEN 'CustomerName' THEN CustomerName
		WHEN 'CustomerCity' THEN CustomerCity
		WHEN 'Model' THEN Model
		WHEN 'TruckNo' THEN TruckNo
		WHEN 'DeliveryVariance' THEN DeliveryVariance
		WHEN 'DeliveryStatus' THEN DeliveryStatus
		WHEN 'DriverName' THEN DriverName
		WHEN 'Organization' THEN Organization
		ELSE ''
	END = @browser_colValue	
	GROUP BY
		ScheduledTime
		, [OrderNumber]
		, [OrderItemNumber]
		, [CustomerName]
		, [CustomerCity]
		, [Model]
		, [TruckNo]
		, [DeliverySchedule]
		, [OutForDelivery]
		, [AtDelivery]
		, [DeliveryComplete]
		, [DeliveryVariance]
		, [DeliveryStatus]
		, [DriverName]
		, [DriverID]
		, [Organization]
	ORDER BY 
		ScheduledTime
		, DriverID
		, OrderNumber
		, OrderItemNumber	
END

GO
