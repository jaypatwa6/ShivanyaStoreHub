SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- =============================================
-- Author:		Tuyen
-- Create date: 10/20/2013
-- Description:	delete all unique key in database
-- =============================================
create procedure [dbo].[SP_DeleteAllUniqueKeyes]
as
begin

	DECLARE unique_cursor CURSOR  FOR 
		Select 'ALTER TABLE ' + QUOTENAME(OBJECT_NAME([object_id])) + ' DROP CONSTRAINT ' + QUOTENAME([name])
		From sys.indexes
		Where is_unique_constraint = 1

	OPEN unique_cursor
	declare @DeletePK    nvarchar(1000)
	FETCH NEXT FROM unique_cursor INTO @DeletePK
	WHILE @@FETCH_STATUS = 0 
	BEGIN 
   
		EXEC (@DeletePK)
		FETCH NEXT FROM unique_cursor INTO @DeletePK
	END 

	CLOSE unique_cursor 
	DEALLOCATE unique_cursor

end
GO
