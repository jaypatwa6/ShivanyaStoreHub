SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[SP_UpdateMcsTaskContact](@userId AS UNIQUEIDENTIFIER, @orderId AS UNIQUEIDENTIFIER, @mcsTaskId AS UNIQUEIDENTIFIER, @tmsTaskId AS UNIQUEIDENTIFIER)
AS
BEGIN
	DECLARE @tmsTaskTypeId AS UNIQUEIDENTIFIER, @tmsTaskTypeKeyword AS NVARCHAR(50), @mcsTaskType AS NVARCHAR(50), @description AS NVARCHAR(500);
	DECLARE @contactPhone AS NVARCHAR(50), @contactExtension AS NVARCHAR(50), @contactName AS NVARCHAR(50), @mcsStopLocationInstructions NVARCHAR(4000);
	SELECT @tmsTaskTypeId = CommonList_TMSOrderItemTaskTypeId FROM TMS_Order_Item_Task WHERE ID = @tmsTaskId;
	SELECT @tmsTaskTypeKeyword = keyword from System_CommonList_Item WHERE ID = @tmsTaskTypeId;

	--set data from jobsite
	SELECT @contactPhone = ContactPhone, @contactExtension = ContactExtension, @contactName = ContactName
	FROM CRM_Jobsite WHERE ID = (SELECT TaskLocation_CRM_JobsiteID FROM TMS_Order_Item_Task WHERE ID = @tmsTaskId);

	SET @description = 'CUSTOMER';
	IF (@tmsTaskTypeKeyword = 'TMS_Order_Type_Pickup')
	BEGIN --pickup task
		SET @mcsStopLocationInstructions = (SELECT OriginJobsiteNotes FROM TMS_Order WHERE ID = @OrderId);
		SET @description = 'PICKUP';
	END
	IF (@tmsTaskTypeKeyword = 'TMS_Order_Type_Delivery')
	BEGIN --delivery task
		SET @mcsStopLocationInstructions = (SELECT DestinationJobsiteNotes FROM TMS_Order WHERE ID = @OrderId);
		SET @description = 'DELIVERY';
	END
	
	
	DECLARE @customerContactName NVARCHAR(101), @customerContactPhone NVARCHAR(300);
	SET @customerContactName = (SELECT CONCAT(FirstName, ' ', LastName) FROM CRM_Customer_Contact WHERE ID = (SELECT CRM_Customer_ContactID FROM TMS_Order WHERE ID = @OrderId));
	SET @customerContactPhone = (SELECT TOP 1 CONCAT(PhoneNumber, ' ext ', Extension) FROM CRM_Customer_Contact_Phone 
										WHERE CRM_Customer_ContactID = (SELECT CRM_Customer_ContactID FROM TMS_Order WHERE ID = @OrderId)
										ORDER BY IsPrimary DESC);

	--contact for task
	IF EXISTS (SELECT * FROM [dbo].[MCS_Trip_Stop_Task_Contact] WHERE MCS_Trip_Stop_TaskID = @mcsTaskId AND [Description] = @description)
	BEGIN
		--Update
		UPDATE MCS_Trip_Stop_Task_Contact 
		SET Name = @contactName, PhoneNumber = LEFT(CONCAT(@contactPhone, ' ext ', @contactExtension), 50), [Description] = @description,
		ModifiedBy = @userId, CreatedBy = @userId, DateCreated = GETUTCDATE(), DateModified = GETUTCDATE(), IsDeleted = 0
		WHERE MCS_Trip_Stop_TaskID = @mcsTaskId AND [Description] = @description
	END
	ELSE
	BEGIN
		--create new
		INSERT INTO MCS_Trip_Stop_Task_Contact 
			(Name, PhoneNumber, [Description], MCS_Trip_Stop_TaskID, ModifiedBy, CreatedBy, DateCreated, DateModified, IsDeleted)
			VALUES (@contactName, LEFT(CONCAT(@contactPhone, ' ext ', @contactExtension), 50), @description, @mcsTaskId, @userId, @userId, GETUTCDATE(), GETUTCDATE(), 0);
	END

	--contact for customer
	IF EXISTS (SELECT * FROM [dbo].[MCS_Trip_Stop_Task_Contact] WHERE MCS_Trip_Stop_TaskID = @mcsTaskId AND [Description] = 'CUSTOMER')
	BEGIN
		--Update
		UPDATE MCS_Trip_Stop_Task_Contact 
		SET Name = @contactName, PhoneNumber = LEFT(CONCAT(@contactPhone, ' ext ', @contactExtension), 50), [Description] = 'CUSTOMER',
		ModifiedBy = @userId, CreatedBy = @userId, DateCreated = GETUTCDATE(), DateModified = GETUTCDATE(), IsDeleted = 0
		WHERE MCS_Trip_Stop_TaskID = @mcsTaskId AND [Description] = 'CUSTOMER'
	END
	ELSE
	BEGIN
		--create new
		INSERT INTO MCS_Trip_Stop_Task_Contact 
			(Name, PhoneNumber, [Description], MCS_Trip_Stop_TaskID, ModifiedBy, CreatedBy, DateCreated, DateModified, IsDeleted)
			VALUES (@contactName, LEFT(CONCAT(@contactPhone, ' ext ', @contactExtension), 50), 'CUSTOMER', @mcsTaskId, @userId, @userId, GETUTCDATE(), GETUTCDATE(), 0);
	END
END

GO
