SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- =============================================
-- Author:		Tuyen
-- Create date: 10/20/2013
-- Description:	create a foreign key in database
-- =============================================
create procedure [dbo].[sp_ReNameAllColumns] 
(
@oldColumn   varchar(100),
@newColumn varchar(100),
@dataType  varchar(100),
@Default  varchar(100)
)
as
begin


	DECLARE ChangeColum_cursor CURSOR  FOR 
		SELECT Table_name 
		FROM INFORMATION_SCHEMA.COLUMNS
		where column_name = @oldColumn 
		--and table_name = 'Mobile_GPS_GeofenceType'
	OPEN ChangeColum_cursor
	declare @Change_Column_Name  nvarchar(1000)
	declare @Chage_Data_Type nvarchar(1000)
	declare @tableName nvarchar(100)
	FETCH NEXT FROM ChangeColum_cursor INTO @tableName
	WHILE @@FETCH_STATUS = 0 
	BEGIN 
		set @Change_Column_Name = 'sp_RENAME ''[' + @tableName + '].[' + @oldColumn + ']'' ,'''  +@newColumn + ''', ''COLUMN'''
		exec (@Change_Column_Name)
		if(isnull(@dataType,'') <> '')
			begin
				set @Chage_Data_Type = 'ALTER TABLE dbo.' + @tableName + ' ALTER COLUMN ' + @newColumn + ' ' + @dataType
				exec (@Chage_Data_Type)
			end
		
		if(isnull(@Default,'') <> '')
		begin
			declare @addDefault nvarchar(1000)
			set @addDefault = 'ALTER TABLE ' + @tableName + ' ADD  CONSTRAINT [DF_' + @tableName + '_' + @newColumn + ']  DEFAULT ((' + @Default + ')) FOR [' + @newColumn + ']'
			declare @Constain   varchar(100)
			set @Constain= isnull((select o.name 
			from sysobjects o inner join syscolumns c on o.id = c.cdefault inner join sysobjects t on c.id = t.id
			where o.xtype = 'D' and c.name = @newColumn and t.name = @tableName),'')
			if(@Constain = '')
			begin
				exec(@addDefault)
			end
			else
			begin
				
				exec ('ALTER TABLE '+@tableName + ' DROP CONSTRAINT ' + @Constain )
				exec(@addDefault)
			end
		end
		
		FETCH NEXT FROM ChangeColum_cursor INTO @tableName
	END 

	CLOSE ChangeColum_cursor 
	DEALLOCATE ChangeColum_cursor

End

--SELECT *,object_definition(default_object_id) AS definition
--FROM   sys.columns c join sys.default_constraints d
--WHERE  name = @oldColumn
--AND    object_id = object_id('Mobile_GPS_GeofenceType')
GO
