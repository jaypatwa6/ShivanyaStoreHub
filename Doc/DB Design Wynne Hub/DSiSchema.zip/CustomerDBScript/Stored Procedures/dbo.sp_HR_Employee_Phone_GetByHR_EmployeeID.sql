SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- =============================================
-- Author:		HIEU 
-- Last update: Aug 21th 2023
-- Description:	
-- =============================================
create PROCEDURE [dbo].[sp_HR_Employee_Phone_GetByHR_EmployeeID]
	 @HR_EmployeeID uniqueidentifier	 
AS
BEGIN
	SET NOCOUNT ON;
	select 
		hep.ID,
		hep.HR_EmployeeID,
		hep.PhoneNumber,
		hep.IsPrimary,
		PhoneTypeID = hep.CommonList_PhoneTypeID,
		PhoneTypeName = scli.Keyword 		
	from [dbo].[HR_Employee_Phone] hep
		inner join [dbo].[System_CommonList_Item] scli on scli.ID = hep.CommonList_PhoneTypeID
	where hep.IsActive = 1
		and hep.HR_EmployeeID = @HR_EmployeeID
END

GO
