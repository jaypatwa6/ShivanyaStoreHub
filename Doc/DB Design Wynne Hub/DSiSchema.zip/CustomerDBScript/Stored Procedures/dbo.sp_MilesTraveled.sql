SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

-- =============================================
-- Author:		Huan Nguyen
-- Create date: 7/28/2020
-- Edited date:  7/28/2020
-- Description: Miles Traveled Report
-- =============================================
CREATE PROCEDURE [dbo].[sp_MilesTraveled]
 @startdate datetime,
 @enddate datetime,
 @timezone float,
 @browser_colName nvarchar(256),
 @browser_colValue nvarchar(max)
AS
BEGIN
	SET NOCOUNT ON;
	select *  from
 (
 SELECT Concat(hr.FirstName,' ',hr.LastName) as EmployeeName,
eq.Number as EquipmentNumber,CAST(DATEADD(hour, @timezone , e.GpsTimeStamp) AS DATE) as Date, d.SerialNumber , cast(round(sum(e.DistanceTraveledInKM) * 0.621371192,2) as decimal(11,2)) as DistanceTraveledInMiles
from mcs_device_eventsummary e
inner join MCS_Device d on e.mcs_deviceid = d.id
inner join System_CommonList_Item c on c.ID = e.CommonList_DeviceSummaryEventID and c.Keyword = 'MOVING_END'
left join dbo.HR_Employee hr on hr.ID = e.HR_EmployeeID and hr.IsSystemEmployee = 0
left join [dbo].[FMS_Equipment] eq on eq.ID = e.fms_equipmentID
where e.GpsTimeStamp between @startdate and @enddate
and d.DeviceType in ('blackbox','black box')
group by eq.Number,hr.FirstName, hr.LastName, CAST(DATEADD(hour, @timezone , e.GpsTimeStamp) AS DATE), d.serialnumber
	) as a
	WHERE CASE @browser_colName 
				WHEN 'EmployeeName' THEN EmployeeName
				WHEN 'EquipmentNumber' THEN EquipmentNumber
				WHEN 'SerialNumber' THEN SerialNumber
				ELSE ''
			END = @browser_colValue
	order by EmployeeName,EquipmentNumber
END

GO
