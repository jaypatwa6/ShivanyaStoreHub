SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[SP_GetAllUnassignedOrderItem]
	@StartDate DATETIME,
	@EndDate DATETIME
AS
BEGIN
	DECLARE	@Order_Item_Status_Pending UNIQUEIDENTIFIER, @Order_Item_Status_ReadyForDispatch UNIQUEIDENTIFIER
	SET @Order_Item_Status_Pending = '640A61DF-64A0-11E4-AD7C-90004E9ED7CB'
	SET @Order_Item_Status_ReadyForDispatch = '6D656976-0DDF-11E6-9A7F-E4F89C775041'

	CREATE TABLE #TEMP_UNSCHEDULE
	(
		TMS_OrderId UNIQUEIDENTIFIER
		,Pickup_CommonList_TimeTypeID UNIQUEIDENTIFIER
		,PickupRequestedTimeFromRange DATETIME
		,PickupRequestedTimeToRange DATETIME
		,Delivery_CommonList_TimeTypeID UNIQUEIDENTIFIER
		,DeliveryRequestedTimeFromRange DATETIME
		,DeliveryRequestedTimeToRange DATETIME
		,TMS_Order_ItemId UNIQUEIDENTIFIER
		,CommonList_TMSOrderItemStatusID UNIQUEIDENTIFIER
		,TMS_Order_Item_TaskId UNIQUEIDENTIFIER
		,CommonList_TMSOrderItemTaskTypeId UNIQUEIDENTIFIER
		,Integration_RowId NVARCHAR(36)
	)

	IF @StartDate IS NULL AND @EndDate IS NULL
		BEGIN
			INSERT INTO #TEMP_UNSCHEDULE
			SELECT
				dbo.TMS_Order.ID AS TMS_OrderId
				,dbo.TMS_Order.Pickup_CommonList_TimeTypeID
				,dbo.TMS_Order.PickupRequestedTimeFromRange
				,dbo.TMS_Order.PickupRequestedTimeToRange
				,dbo.TMS_Order.Delivery_CommonList_TimeTypeID
				,dbo.TMS_Order.DeliveryRequestedTimeFromRange
				,dbo.TMS_Order.DeliveryRequestedTimeToRange
				,dbo.TMS_Order_Item.ID AS TMS_Order_ItemId
				,dbo.TMS_Order_Item.CommonList_TMSOrderItemStatusID
				,dbo.TMS_Order_Item_Task.Id AS TMS_Order_Item_TaskId
				,dbo.TMS_Order_Item_Task.CommonList_TMSOrderItemTaskTypeId
				,dbo.TMS_Order_CustomData.Integration_RowId
			FROM dbo.TMS_Order 
				JOIN dbo.TMS_Order_Item ON TMS_Order_Item.TMS_OrderID = TMS_Order.ID
				JOIN dbo.TMS_Order_Item_Task ON TMS_Order_Item_Task.TMS_Order_ItemID = TMS_Order_Item.ID
				LEFT JOIN dbo.TMS_Order_CustomData ON TMS_Order_CustomData.TMS_OrderID = TMS_Order.ID		
			WHERE TMS_Order.IsDelete = 0 
				AND TMS_Order_Item.IsDelete = 0	
				AND dbo.TMS_Order_Item.CommonList_TMSOrderItemStatusID IN (@Order_Item_Status_Pending, @Order_Item_Status_ReadyForDispatch)
		END
	ELSE
		BEGIN
			INSERT INTO #TEMP_UNSCHEDULE
			SELECT
				dbo.TMS_Order.ID AS TMS_OrderId
				,dbo.TMS_Order.Pickup_CommonList_TimeTypeID
				,dbo.TMS_Order.PickupRequestedTimeFromRange
				,dbo.TMS_Order.PickupRequestedTimeToRange
				,dbo.TMS_Order.Delivery_CommonList_TimeTypeID
				,dbo.TMS_Order.DeliveryRequestedTimeFromRange
				,dbo.TMS_Order.DeliveryRequestedTimeToRange
				,dbo.TMS_Order_Item.ID AS TMS_Order_ItemId
				,dbo.TMS_Order_Item.CommonList_TMSOrderItemStatusID
				,dbo.TMS_Order_Item_Task.Id AS TMS_Order_Item_TaskId
				,dbo.TMS_Order_Item_Task.CommonList_TMSOrderItemTaskTypeId
				,dbo.TMS_Order_CustomData.Integration_RowId
			FROM dbo.TMS_Order 
				JOIN dbo.TMS_Order_Item ON TMS_Order_Item.TMS_OrderID = TMS_Order.ID
				JOIN dbo.TMS_Order_Item_Task ON TMS_Order_Item_Task.TMS_Order_ItemID = TMS_Order_Item.ID
				LEFT JOIN dbo.TMS_Order_CustomData ON TMS_Order_CustomData.TMS_OrderID = TMS_Order.ID		
			WHERE TMS_Order.IsDelete = 0 
				AND TMS_Order_Item.IsDelete = 0	
				AND dbo.TMS_Order_Item.CommonList_TMSOrderItemStatusID IN (@Order_Item_Status_Pending, @Order_Item_Status_ReadyForDispatch)
				AND (
					dbo.TMS_Order.PickupRequestedTimeFromRange BETWEEN @StartDate AND @EndDate 
					OR dbo.TMS_Order.PickupRequestedTimeToRange BETWEEN @StartDate AND @EndDate 
					OR dbo.TMS_Order.DeliveryRequestedTimeFromRange BETWEEN @StartDate AND @EndDate 
					OR dbo.TMS_Order.DeliveryRequestedTimeToRange BETWEEN @StartDate AND @EndDate
				)
		END
	
	SELECT 
		OI.[ID] AS Id
		,OI.[DateCreated]
		,OI.[CreatedBy]
		,OI.[DateModified]
		,OI.[ModifiedBy]
		,[TMS_OrderID] AS TMSOrderID
		,[FreightDescription]
		,[QuantityOrdered]
		,[QuantityShipped]
		,[QuantityReceived]
		,[CommonList_TMSFreightUnitID] AS CommonListTMSFreightUnitID
		,[UnitWeightInKG]
		,[UnitLengthInM]
		,[UnitWidthInM]
		,[UnitHeightInM]
		,[IsStackable]
		,[Notes]
		,[ReferenceOrderItemDocumentNumbers]
		,[CommonList_TMSOrderItemStatusID] AS CommonListTMSOrderItemStatusID,[OrderItemNumber]
		,[ShipWeightInKG],[ShipLengthInM]
		,[ShipWidthInM]
		,[ShipHeightInM]
		,[TotalTripDurationInMin]
		,[TotalTripDistanceInKM]
		,[IsDelete]  
		,Integration_RowId
	FROM TMS_Order_Item OI JOIN dbo.TMS_Order_Item_CustomData OIC ON OIC.TMS_Order_ItemID = OI.ID
	WHERE OI.ID IN (
		SELECT DISTINCT TMS_Order_ItemId FROM #TEMP_UNSCHEDULE WHERE Integration_RowId IS NULL 
		UNION ALL 
		SELECT DISTINCT TMS_Order_ItemId FROM #TEMP_UNSCHEDULE WHERE Integration_RowId IS NOT NULL AND CommonList_TMSOrderItemStatusID = @Order_Item_Status_ReadyForDispatch
	)
END
GO
