SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[sp_TMSStatusPushTimesByLoad]
 @startdate datetime,
 @enddate datetime,
 @timezone float,
 @browser_colName nvarchar(256),
 @browser_colValue nvarchar(max)
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE 
	--@startdate datetime,
	--@enddate datetime,
	--@timezone float,
	--@browser_colName nvarchar(256),
	--@browser_colValue nvarchar(max),

	@orderitem_dispatched uniqueidentifier,
	@orderitem_invoiced uniqueidentifier,
	@orderitem_completed uniqueidentifier


	--SET @startdate = '2024-3-16'
	--SET @enddate = '2024-07-22'
	--SET @timezone = 0
	--SET @browser_colName= ''
	--SET @browser_colValue = ''

	SET @orderitem_completed = (SELECT TOP 1 Id FROM System_CommonList_Item WHERE Keyword = 'TMS_OrderItemStatus_DeliveryComplete')
	SET @orderitem_dispatched = (SELECT TOP 1 Id FROM System_CommonList_Item WHERE Keyword = 'TMS_OrderItemStatus_Dispatched')
	SET @orderitem_invoiced = (SELECT TOP 1 Id FROM System_CommonList_Item WHERE Keyword = 'TMS_OrderItemStatus_Invoiced')

	SELECT ScheduledTime 
		, [OrderNumber]
		, [OrderItemNumber]
		, [DriverID]
		, [DriverName]
		, [Model]
		, [Changes]
		, [PickupSchedule]
		, [DeliverySchedule]
		, [OutForPickup]
		, [AtPickup]
		, [OutForDelivery]
		, [AtDelivery]
		, [DeliveryComplete]
		, [PickupCity]
		, [DeliveryCity]
	FROM (
			SELECT [Load].OrderNumber
			, [Load].OrderItemNumber AS OrderItemNumber
			, [Load].DriverID
			, [Load].DriverName
			, ISNULL([orderItemCus].Model,'') AS Model
			, [Load].Key5Buttons AS [Changes]
			, CONVERT(datetime,DATEADD(hour, @timezone, [Load].PickupSchedule)) AS ScheduledTime
			, CONVERT(datetime,DATEADD(hour, @timezone, [Load].PickupSchedule)) AS PickupSchedule
			, CONVERT(datetime,DATEADD(hour, @timezone, [Load].DeliverySchedule)) AS DeliverySchedule
			, CONVERT(datetime,DATEADD(hour, @timezone, [Load].OutForPickup)) AS OutForPickup
			, CONVERT(datetime,DATEADD(hour, @timezone, [Load].AtPickup)) AS AtPickup
			, CONVERT(datetime,DATEADD(hour, @timezone, [Load].AtDelivery)) AS AtDelivery
			, CONVERT(datetime,DATEADD(hour, @timezone, [Load].OutForDelivery)) AS OutForDelivery
			, CONVERT(datetime,DATEADD(hour, @timezone, [Load].DeliveryComplete)) AS DeliveryComplete
			,(SELECT jj.City
						FROM TMS_Order_Item_Task tt
							inner join CRM_Jobsite jj on tt.TaskLocation_CRM_JobsiteID = jj.Id
							inner join System_CommonList_Item ss on ss.Id = tt.CommonList_TMSOrderItemTaskTypeId
						WHERE tt.TMS_Order_ItemID = [Load].TMS_Order_ItemID and ss.Keyword = 'TMS_Order_Type_Pickup') AS PickupCity
			,(SELECT jj.City
				FROM TMS_Order_Item_Task tt
					inner join CRM_Jobsite jj on tt.TaskLocation_CRM_JobsiteID = jj.Id
					inner join System_CommonList_Item ss on ss.Id = tt.CommonList_TMSOrderItemTaskTypeId
				WHERE tt.TMS_Order_ItemID = [Load].TMS_Order_ItemID and ss.Keyword = 'TMS_Order_Type_Delivery') AS DeliveryCity
		FROM view_MDTStatusPushTimesByLoad [Load]
			LEFT OUTER JOIN dbo.CRM_Customer AS cus ON cus.ID = [Load].CRM_CustomerID
			LEFT OUTER JOIN dbo.TMS_Order_Item_CustomData AS [orderItemCus] on [orderItemCus].TMS_Order_ItemID = [Load].TMS_Order_ItemID
		WHERE ([Load].CommonList_TMSOrderItemStatusID = @orderitem_dispatched 
						OR [Load].CommonList_TMSOrderItemStatusID = @orderitem_invoiced
						OR [Load].CommonList_TMSOrderItemStatusID = @orderitem_completed)
			AND [Load].PickupSchedule BETWEEN @startdate AND @enddate
		GROUP BY
			[Load].OrderNumber,
			[Load].TMS_Order_ItemID,
			[Load].OrderItemNumber,
			[Load].Key5Buttons,
			[Load].DriverID,
			[Load].DriverName,
			[orderItemCus].Model,
			[Load].PickupSchedule,
			[Load].DeliverySchedule,
			[Load].OutForPickup,
			[Load].AtPickup,
			[Load].AtDelivery,
			[Load].OutForDelivery,
			[Load].DeliveryComplete
		) AS T
	WHERE
		CASE @browser_colName 
			WHEN 'OrderNumber' THEN OrderNumber
			WHEN 'OrderItemNumber' THEN OrderItemNumber
			WHEN 'Model' THEN Model
			WHEN 'PickupCity' THEN PickupCity
			WHEN 'DeliveryCity' THEN DeliveryCity
			WHEN 'DriverName' THEN DriverName
			ELSE ''
		END = @browser_colValue
		GROUP BY
			ScheduledTime 
			, [OrderNumber]
			, [OrderItemNumber]
			, [DriverID]
			, [DriverName]
			, [Model]
			, [Changes]
			, [PickupSchedule]
			, [DeliverySchedule]
			, [OutForPickup]
			, [AtPickup]
			, [OutForDelivery]
			, [AtDelivery]
			, [DeliveryComplete]
			, [PickupCity]
			, [DeliveryCity]
		ORDER BY OrderNumber, OrderItemNumber, ScheduledTime	
END

GO
