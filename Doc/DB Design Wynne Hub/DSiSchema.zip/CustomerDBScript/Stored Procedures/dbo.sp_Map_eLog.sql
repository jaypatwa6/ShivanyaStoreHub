SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- =============================================
-- Author:		Hieu
-- Create date: Aug 7th 2023
-- Description:	get data for eLog on Map
-- =============================================
-- [sp_Map_eLog] 'cbde1db0-a868-11e7-8120-00155db47809'
CREATE PROCEDURE [dbo].[sp_Map_eLog] @Fleet_ID UNIQUEIDENTIFIER = NULL
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

	--declare @Fleet_ID UNIQUEIDENTIFIER = 'cbde1db0-a868-11e7-8120-00155db47809'
	declare @InterstateDailyResetHoursDefault int
	declare @InterstateWeeklyResetHoursDefault int
	declare @IntrastateDailyResetHoursDefault int
	declare @IntrastateWeeklyResetHoursDefault int
	select top 1  
		@InterstateDailyResetHoursDefault = InterstateDailyResetHours
		,@InterstateWeeklyResetHoursDefault = InterstateWeeklyResetHours
		,@IntrastateDailyResetHoursDefault = IntrastateDailyResetHours
		,@IntrastateWeeklyResetHoursDefault = IntrastateWeeklyResetHours
	from [dbo].[FMS_Elog_HOSRule] 
	where [IsDefault] = 1 	
							
	 -- Create Temporary Table for nearest 3 months
	DECLARE @TempDailyReportDetailTbl AS TABLE (
			HR_EmployeeID uniqueidentifier, 
			Keyword varchar(50), 
			StartTime datetime, 
			EndTime datetime, 
			StartTimeKey bigint, 
			EndTimeKey bigint, 
			MCS_EventSummaryID uniqueidentifier,
			Is16HourRuleException bit,
			IsAdverseDriving bit,
			DistanceInKM decimal(18,2)
	);
	INSERT INTO @TempDailyReportDetailTbl
	select HR_EmployeeID, Keyword, StartTime, EndTime, StartTimeKey, 0, MCS_EventSummaryID, Is16HourRuleException, IsAdverseDriving, DistanceInKM
	from v_elog_DailyReportDetail vedrd	
	where vedrd.StartTime  > dateadd(month, -3, getutcdate())
	order by vedrd.StartTime desc

select *	
	, ElogStatus = CurrentStatus
	, SecondRemainingOnDuty = 
		CASE WHEN IsInternalState = 1
			THEN (
				case 
					when StartTimeOfAdverseDriving is not null
						then CAST(((InterstateMaxOnDutyHours + 2) * 3600) - isnull(DailyOnDuty, 0) AS bigint)
					when StartTimeOf16HourRuleException is not null
						then CAST((InterstateMaxExemptionHours * 3600) - isnull(DailyOnDuty, 0) AS bigint)
					else CAST((InterstateMaxOnDutyHours * 3600) - isnull(DailyOnDuty, 0) AS bigint)
				end
			) 
			ELSE CAST(((IntrastateMaxOnDutyHours + (case when StartTimeOfAdverseDriving is not null then 2 else 0 end)) * 3600) - isnull(DailyOnDuty, 0) AS bigint)						
		END
	, TotalSecondOnDuty = 
		CASE WHEN IsInternalState = 1
			THEN (
				case 
					when StartTimeOfAdverseDriving is not null
						then (InterstateMaxOnDutyHours + 2) * 3600
					when StartTimeOf16HourRuleException is not null
						then InterstateMaxExemptionHours * 3600
					else InterstateMaxOnDutyHours * 3600
				end
			) 
			ELSE ((IntrastateMaxOnDutyHours + (case when StartTimeOfAdverseDriving is not null then 2 else 0 end)) * 3600) 				
		END
	, SecondRemainingDailyReset = 	
		CAST (
			case when LastEndTimeOn is not null
				then 
					(
						CASE WHEN IsInternalState = 1
							THEN (InterstateDailyResetHours * 3600) 				 
							ELSE (IntrastateDailyResetHours * 3600) 					
						END
					) -	DATEDIFF(SECOND, LastEndTimeOn, GETUTCDATE())																												
				else 0 
			end 			
		AS bigint)			
	, TotalSecondDailyReset = 
		(
			CASE WHEN IsInternalState = 1
				THEN (InterstateDailyResetHours * 3600) 
				ELSE (IntrastateDailyResetHours * 3600) 					
			END
		) 			
	, SecondRemainingDriving = 
		CASE WHEN IsInternalState = 1
			THEN CAST(((InterstateMaxDriveHours + (case when StartTimeOfAdverseDriving is not null then 2 else 0 end)) * 3600) - isnull(DailyDriving, 0) AS bigint)
			ELSE CAST(((IntrastateMaxDriveHours + (case when StartTimeOfAdverseDriving is not null then 2 else 0 end)) * 3600) - isnull(DailyDriving, 0) AS bigint)
		END
	, TotalSecondDriving = 
		(CASE WHEN IsInternalState = 1
			THEN ((InterstateMaxDriveHours + (case when StartTimeOfAdverseDriving is not null then 2 else 0 end)) * 3600) 
			ELSE ((IntrastateMaxDriveHours + (case when StartTimeOfAdverseDriving is not null then 2 else 0 end)) * 3600) 				
		END )			
	, SecondRemainingBreak = (		 --  [sp_eLog_Dashboard_sb] @Account_ManagementGroupID=24051
		SELECT -- top 1 CAST((8 * 3600) - DATEDIFF(SECOND, t1.Starttime, (case when Keyword <> 'Driving_On_Duty' then isnull(StartTime, GETUTCDATE() )  else GETUTCDATE() end) ) AS bigint) 
			top 1 CAST(		   
				(8 * 3600) - (
								select sum(datediff(SECOND, vdrd3.Starttime, isnull(vdrd3.Endtime, GETUTCDATE())))						
								from @TempDailyReportDetailTbl vdrd3
								where vdrd3.Keyword = 'Driving_On_Duty' 
									and vdrd3.HR_EmployeeID = ttttt.HR_EmployeeID
									and vdrd3.StartTime >= t1.StartTime
									and vdrd3.StartTime >= StartTimeOfDay  								
							)
					AS bigint)
		FROM (
				SELECT ROW_NUMBER() OVER (ORDER BY vdrd2.StartTime desc) AS rownum,								
					StartTime, 
					EndTime
				from @TempDailyReportDetailTbl vdrd2
				where vdrd2.Keyword = 'Driving_On_Duty' 
					and vdrd2.HR_EmployeeID = ttttt.HR_EmployeeID
					and vdrd2.StartTime <> isnull(vdrd2.EndTime, getutcdate())
					and vdrd2.StartTime >= StartTimeOfDay 				
			)t1
			LEFT JOIN (
				SELECT ROW_NUMBER() OVER (ORDER BY vdrd2.StartTime desc) AS rownum2,
						StartTime2 = StartTime, 
						EndTime2 = EndTime
				from @TempDailyReportDetailTbl vdrd2
				where vdrd2.Keyword = 'Driving_On_Duty' 
					and vdrd2.HR_EmployeeID = ttttt.HR_EmployeeID
					and vdrd2.StartTime <> isnull(vdrd2.EndTime, getutcdate())
					and vdrd2.StartTime >= StartTimeOfDay  				
			)t2 ON t1.rownum = t2.rownum2 - 1
		WHERE DATEDIFF(SECOND, t2.EndTime2, isnull(t1.StartTime, GETUTCDATE())) >= 1800
			OR t2.StartTime2 is null 	
	)		
	, TotalSecondBreak = (8 * 3600)
	, SecondRemainingBreakReset = 	
		CAST ( 
			case when LastEndTimeDriving is not null
				then (30 * 60) - DATEDIFF(SECOND, LastEndTimeDriving, GETUTCDATE())
				else 0 
			end 			
		AS bigint)	
	, SecondRemainingCycle =  
		case when StartTimeOfRolling is not null
			then (
				select (InterstateMultiDayHours1 * 3600) - sum(datediff(s, vdrd2.StartTime, isnull(vdrd2.EndTime, getutcdate())))
				from @TempDailyReportDetailTbl vdrd2
				where vdrd2.Keyword IN ('On_Duty', 'Driving_On_Duty', 'ELOG_SpecialStatus_YardMove')
					and vdrd2.HR_EmployeeID = ttttt.HR_EmployeeID
					and vdrd2.StartTime >= StartTimeOfRolling  				
			)
			when IsInternalState = 1 then CAST((InterstateMultiDayHours1 * 3600) - isnull(WeeklyOnduty, 0)  AS bigint)
			else CAST((IntrastateMultiDayHours1 * 3600) - isnull(WeeklyOnduty, 0)  AS bigint)
		end	
	, TotalSecondCycle = 
		CASE WHEN IsInternalState = 1
			THEN (InterstateMultiDayHours1 * 3600) 
			ELSE (IntrastateMultiDayHours1 * 3600) 					
		END
	, SecondRemainingWeeklyReset = 	
		CAST ( 
			case when LastEndTimeOn is not null
				then 
					(
						CASE WHEN IsInternalState = 1
							THEN (InterstateWeeklyResetHours * 3600) 
							ELSE (IntrastateWeeklyResetHours * 3600) 					
						END
					) -	DATEDIFF(SECOND, LastEndTimeOn, GETUTCDATE())
				else 0 
			end 			
		AS bigint)			
	, TotalSecondWeeklyReset = 
		CASE WHEN IsInternalState = 1
			THEN (InterstateWeeklyResetHours * 3600) 
			ELSE (IntrastateWeeklyResetHours * 3600) 					
		END 			  
	
from (		 
	 select *	
	 from (				
		select *,
			-- get all times before last ON point in a day 
			DailyOnDuty = (			
				select SUM(datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())))
				from (
					select
						hr_employeeid, 
						keyword, 
						grp, 
						starttime_grp = min(starttime), 
						endtime_grp = max(endtime)
					from (
							select 
								ss.*, 
								count(*) over (partition by grp, Keyword) as cnt
							from (
									select 
										s.hr_employeeid,
										s.keyword,
										s.starttime, 
										endtime = isnull(s.endtime, getutcdate()),
										grp = (
											row_number() over (partition by s.hr_employeeid order by s.starttime desc)
											 - row_number() over (partition by s.hr_employeeid, s.Keyword order by s.starttime desc)
										) 
									from (
										select 
											hr_employeeid, 
											starttime, 
											endtime,
											keyword_ori = vdrd2.Keyword,
											keyword = case when vdrd2.Keyword = 'ELOG_SpecialStatus_PersonalConveyance' then 'Off_Duty' else vdrd2.Keyword end
										from @TempDailyReportDetailTbl vdrd2
										WHERE vdrd2.hr_employeeid = ttt.HR_EmployeeID																													
											and vdrd2.StartTime >= StartTimeOfDay	-- update to start of current day
									) s
							   ) ss
							 
						 ) sss
					where sss.cnt >= 1
					group by sss.hr_employeeid, sss.keyword, sss.grp 					 
				) ssss
				where keyword <> 'In_Sleeper' 
					or (keyword = 'In_Sleeper' and datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())) < 7 * 3600)		
			),				
			DailyDriving = (
				select sum(datediff(s, vdrd2.StartTime, isnull(vdrd2.EndTime, GETUTCDATE())))
				from @TempDailyReportDetailTbl vdrd2
				where vdrd2.Keyword = 'Driving_On_Duty'
					and vdrd2.HR_EmployeeID = ttt.HR_EmployeeID
					and vdrd2.StartTime >= ttt.StartTimeOfDay				
				Group by vdrd2.Keyword
			), 
			WeeklyOnduty = 	(
				select sum(DATEDIFF(s, vdrd2.StartTime, isnull(vdrd2.EndTime, GETUTCDATE())))
				from @TempDailyReportDetailTbl vdrd2
				where vdrd2.Keyword IN ('On_Duty', 'Driving_On_Duty', 'ELOG_SpecialStatus_YardMove') 
					and vdrd2.HR_EmployeeID = ttt.HR_EmployeeID
					and vdrd2.StartTime >= ttt.StartTimeOfWeek							
				)
		from (
			select tt.* 			
			-- Rolling 7/8 days cycle: get all logs which come from past 7th or 8th day to calculate remaining cycle time, it is greater than start of week 			
			,StartTimeOfRolling = case when IsInternalState = 1
											then (	
												select top 1 StartTime
												from (
													SELECT  ROW_NUMBER() OVER (ORDER BY t1.StartTime desc) AS rownum
														, t1.StartTime
													FROM (
															SELECT ROW_NUMBER() OVER (ORDER BY StartTime desc) AS rownum,								
																vdrd2.StartTime, 
																vdrd2.EndTime
															from v_elog_DailyReportDetail vdrd2
															where vdrd2.Keyword IN ('On_Duty', 'Driving_On_Duty', 'ELOG_SpecialStatus_YardMove') 
																and vdrd2.HR_EmployeeID = tt.HR_EmployeeID
																and vdrd2.StartTime <> isnull(vdrd2.EndTime, getutcdate())		
																and vdrd2.StartTime >= StartTimeOfWeek													
														)t1
														LEFT JOIN (
															SELECT ROW_NUMBER() OVER (ORDER BY StartTime desc) AS rownum2,
																	StartTime2 = StartTime, 
																	EndTime2 = EndTime
															from v_elog_DailyReportDetail vdrd2
															where vdrd2.Keyword IN ('On_Duty', 'Driving_On_Duty', 'ELOG_SpecialStatus_YardMove') 
																and vdrd2.HR_EmployeeID = tt.HR_EmployeeID
																and vdrd2.StartTime <> isnull(vdrd2.EndTime, getutcdate()) 	
																and vdrd2.StartTime >= StartTimeOfWeek													
														)t2 ON t1.rownum = t2.rownum2 - 1
													WHERE 	
														 (
															DATEDIFF(SECOND, t2.EndTime2, isnull(t1.StartTime, GETUTCDATE())) >= 10 * 3600
															OR t2.StartTime2 is null
														)	
												) t
												where rownum = InterstateMultiDayDays1					
										)
									else null end
			, StartTimeOf16HourRuleException = (
											case
												when Last16HoursStartTime >= StartTimeOfDay and LatestSplitSleeperBerth is not null and Last16HoursStartTime >= SplitSleeperBerth2ndSegment then Last16HoursStartTime    
												when LatestSplitSleeperBerth is null and Last16HoursStartTime >= StartTimeOfDay then Last16HoursStartTime else null end
											)	
			, StartTimeOfAdverseDriving = (
											case
												when LastAdverseDrivingStartTime >= StartTimeOfDay and LatestSplitSleeperBerth is not null and LastAdverseDrivingStartTime >= SplitSleeperBerth2ndSegment then LastAdverseDrivingStartTime    
												when LatestSplitSleeperBerth is null and LastAdverseDrivingStartTime >= StartTimeOfDay then LastAdverseDrivingStartTime else null end
											)	
			, StartTimeOfSplitSleeperBerth = LatestSplitSleeperBerth			
		from (	-- tt
			SELECT t.*
				,StartTimeOfDay = (
					case 
						when t.IsInternalState = 1 
							then (case when LatestSplitSleeperBerth is not null and LatestSplitSleeperBerth > DailyResetInterstate then LatestSplitSleeperBerth else isnull(DailyResetInterstate, FirstLogStartTime) end) 
						else (case when LatestSplitSleeperBerth is not null and LatestSplitSleeperBerth > DailyResetIntrastate then LatestSplitSleeperBerth else isnull(DailyResetIntrastate, FirstLogStartTime) end) 
					end
				)							
				, StartTimeOfWeek = (case when t.IsInternalState = 1 then isnull(WeeklyResetInterstate, FirstLogStartTime) else isnull(WeeklyResetIntrastate, FirstLogStartTime) end)			
				, LastEndTimeOn = LastOnDutyEndTime	
				, LastEndTimeDriving = LastDrivingEndTime									
			FROM ( -- t
				SELECT 		
					FirstLogStartTime = (
						select top 1 vdrd2.StartTime 
						from @TempDailyReportDetailTbl vdrd2
						where vdrd2.HR_EmployeeID = fedrd.HR_EmployeeID	and vdrd2.Keyword IN ('On_Duty', 'Driving_On_Duty', 'ELOG_SpecialStatus_YardMove') 							
						order by vdrd2.StartTime asc
					),
					fedrd.HR_EmployeeID,
					DeviceId = md.Id,					
					CurrentStatus = case 
								when fedrd.Keyword = 'On_Duty' then 'ON'--'On Duty (ON)' 
									when fedrd.Keyword = 'Driving_On_Duty' then 'D'--'Driving (D)' 
									when fedrd.Keyword = 'In_Sleeper' then 'SB'--'Sleeper Berth (SB)' 
									when fedrd.Keyword = 'Off_Duty' then 'OFF'--'Off Duty (OFF)' 
									when fedrd.Keyword = 'ELOG_SpecialStatus_PersonalConveyance' then 'PC'--'Personal Conveyance (PC)' 
									when fedrd.Keyword = 'ELOG_SpecialStatus_YardMove' then 'YM'--'Yard Move (YM)' 
									else '' 						
								end,
					StartTime = fedrd.StartTime,			
					-- calculate the hours remaining										
					IsInternalState = CASE WHEN 		
												fedrd.IsInterstateLoad = 1	
												OR (fedr.MotorCarrierID IS NOT NULL AND mdces.State <> fmc.State)		
												OR (												
														select count (*)
														from (
															select temp_state.State
															from (
																select mdce2.State
																from @TempDailyReportDetailTbl vdrd2
																	INNER JOIN dbo.MCS_Device_EventSummary mdce2 ON mdce2.ID = vdrd2.MCS_EventSummaryID	and mdce2.State is not null
																where vdrd2.HR_EmployeeID = fedr.HR_EmployeeID
																	and vdrd2.StartTime between DATEADD(day, -7, fedrd.StartTime) and DATEADD(Second, 1, fedrd.StartTime)																
																union all
																select isnull(fmc.State, mdces.State) as State
															) temp_state
															group by temp_state.State
														) temp_state_count
													) > 1		
												THEN cast(1 AS BIT)
												ELSE cast(0 AS BIT) 
											END
					,dailyWeeklyReset.DailyResetInterstate
					,dailyWeeklyReset.DailyResetIntrastate
					,dailyWeeklyReset.WeeklyResetInterstate
					,dailyWeeklyReset.WeeklyResetIntrastate	
					,nearestlogs.LastOnDutyEndTime	
					,nearestlogs.LastDrivingEndTime	
					,nearestlogs.Last16HoursStartTime	
					,nearestlogs.LastAdverseDrivingStartTime
					,LatestSplitSleeperBerth = ssb.endtime_ssb	
					,SplitSleeperBerth2ndSegment = ssb.endtime_2nd	
					,feh2.InterstateMaxOnDutyHours
					,feh2.IntrastateMaxOnDutyHours		
					,feh2.InterstateMultiDayHours1
					,feh2.IntrastateMultiDayHours1
					,feh2.InterstateMultiDayDays1
					,feh2.IntrastateMultiDayDays1
					,feh2.InterstateMaxDriveHours
					,feh2.IntrastateMaxDriveHours
					,feh2.InterstateDailyResetHours
					,feh2.IntrastateDailyResetHours
					,feh2.InterstateWeeklyResetHours
					,feh2.IntrastateWeeklyResetHours
					,feh2.InterstateMaxExemptionHours
				FROM 
					(		
						--declare @Fleet_ID UNIQUEIDENTIFIER = 'cbde1db0-a868-11e7-8120-00155db47809'
						SELECT fedrd2.HR_EmployeeID, MAX(fedrd2.StartTime) as MaxTime
						FROM v_elog_DailyReportDetail fedrd2
						WHERE exists (
							select 1 
							from [dbo].[MCS_Fleet_Device] f3 
								inner join [dbo].[MCS_Device] d3 on d3.id = f3.[MCS_DeviceID] 
							where d3.HR_EmployeeID = fedrd2.HR_EmployeeID and f3.MCS_FleetID = (CASE WHEN @Fleet_ID = '00000000-0000-0000-0000-000000000000' THEN f3.MCS_FleetID ELSE @Fleet_ID END)
						) 
						GROUP BY fedrd2.HR_EmployeeID
					) data
					INNER JOIN v_elog_DailyReportDetail fedrd ON fedrd.StartTime = data.MaxTime and fedrd.HR_EmployeeID = data.HR_EmployeeID and fedrd.endtime is null
					INNER JOIN dbo.HR_Employee he ON he.ID = fedrd.HR_EmployeeID and he.IsActive = 1
					INNER JOIN dbo.FMS_Elog_DailyReport fedr ON fedr.ID = fedrd.FMS_Elog_DailyReportID 					
					INNER JOIN dbo.FMS_Elog_HOSRule feh2 ON feh2.ID = fedr.FMS_Elog_HOSRuleID			
					inner JOIN dbo.MCS_Device_EventSummary mdces ON mdces.ID = fedrd.MCS_EventSummaryID
					inner JOIN dbo.MCS_Device md ON md.ID = mdces.MCS_DeviceID
					LEFT JOIN dbo.FMS_MotorCarrier fmc on fmc.ID = fedr.MotorCarrierID
					-- first log, latest driving log, latest on-duty log, latest 16 hours rule exception, latest adverse driving 
					inner join (  					
						select hr_employeeid
							--,LastOnDutyStartTime = max(OnDutyStartTime)
							,LastOnDutyEndTime = max(OnDutyEndTime)
							,LastDrivingEndTime = max(DrivingEndTime)
							,Last16HoursStartTime = max(Use16HoursStartTime)
							,LastAdverseDrivingStartTime = max(UseAdverseDrivingStartTime)
						from (
							select hr_employeeid
								, DrivingEndTime = case when Keyword = 'Driving_On_Duty' then EndTime else null end
								--, OnDutyStartTime = case when Keyword = 'On_Duty'	then StartTime else null end
								, OnDutyEndTime = case when Keyword = 'On_Duty' or Keyword = 'Driving_On_Duty' or Keyword = 'ELOG_SpecialStatus_YardMove' then EndTime else null end
								, Use16HoursStartTime = case when Is16HourRuleException = 1 then StartTime else null end
								, UseAdverseDrivingStartTime = case when IsAdverseDriving = 1 then StartTime else null end
							from @TempDailyReportDetailTbl
						) common
						group by hr_employeeid 				
					) nearestlogs  on nearestlogs.hr_employeeid	= he.ID
					-- daily and weekly reset					
					inner join (					
						select hr_employeeid
							,DailyResetInterstate = max(dailyResetInterstate)
							,DailyResetIntrastate = max (dailyResetIntrastate)
							,WeeklyResetInterstate = max(weeklyResetInterstate)
							,WeeklyResetIntrastate = max(weeklyResetIntrastate)	
						from (
							select *
								,hours = 	datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())) / 3600
								,duration_grp = datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())) 
								,dailyResetInterstate = case when isOn = 0 and datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())) >= InterstateDailyResetHours * 3600
									then endtime_grp else null end
								,dailyResetIntrastate = case when isOn = 0 and datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())) >= IntrastateDailyResetHours * 3600
														then endtime_grp else null end
								,weeklyResetInterstate = case when isOn = 0 and datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())) >= InterstateWeeklyResetHours * 3600
														then endtime_grp else null end
								,weeklyResetIntrastate = case when isOn = 0 and datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())) >= IntrastateWeeklyResetHours * 3600
														then endtime_grp else null end
							from (
								select
									hr_employeeid, 
									InterstateDailyResetHours,
									InterstateWeeklyResetHours,
									IntrastateDailyResetHours,
									IntrastateWeeklyResetHours,
									--  keyword, 
									isOn,
									grp, 
									starttime_grp = min(starttime), 
									endtime_grp = max(endtime)
								from (
										select 
											rr.*, 
											count(*) over (partition by grp, isOn) as cnt
										from (
												select *
													,grp = (
														row_number() over (partition by r.hr_employeeid order by r.starttime desc)
															- row_number() over (partition by r.hr_employeeid, r.isOn order by r.starttime desc)
													) 
												from (
													select 
														hr_employeeid, 
														starttime, 			   
														endtime,
														keyword,
														InterstateDailyResetHours = isnull(hos2.InterstateDailyResetHours, @InterstateDailyResetHoursDefault),
														InterstateWeeklyResetHours= isnull(hos2.InterstateWeeklyResetHours, @InterstateWeeklyResetHoursDefault),
														IntrastateDailyResetHours = isnull(hos2.IntrastateDailyResetHours, @IntrastateDailyResetHoursDefault),
														IntrastateWeeklyResetHours = isnull(hos2.IntrastateWeeklyResetHours, @IntrastateWeeklyResetHoursDefault),
														isOn = case when vdrd2.Keyword in ('ELOG_SpecialStatus_PersonalConveyance', 'Off_Duty', 'In_Sleeper') then 0 else 1 end
													from @TempDailyReportDetailTbl vdrd2
														inner join [dbo].[HR_Employee] h2 on h2.ID = vdrd2.hr_employeeid														
														left join [dbo].[FMS_Elog_HOSRule] hos2 on hos2.ID = h2.[FMS_Elog_HOSRuleID] 
													-- where vdrd2.EndTime is not null 
														--and vdrd2.StartTime >= DATEADD(month, -2,getutcdate())													
													--	and fedrd3.StartTime > '2020-11-01'	-- update to start of current day
												) r							
											) rr
										-- where keyword = 'Off_Duty'
										) rrr
								where rrr.cnt >= 1 	--  and hr_employeeid = 'D8B3C916-F729-11E7-8124-00155DB47818'
								group by rrr.hr_employeeid
									,rrr.isOn
									,rrr.grp
									,InterstateDailyResetHours
									,InterstateWeeklyResetHours
									,IntrastateDailyResetHours
									,IntrastateWeeklyResetHours
							) ssss
							--where isOn = 0	  and hr_employeeid='4E361018-83F7-11EA-8130-00155DA8010E'
						) rrrrr 
						group by hr_employeeid
					) dailyWeeklyReset on dailyWeeklyReset.hr_employeeid = he.ID					
					inner join (
						select HR_EmployeeID	
							,endtime_ssb = max(endtime_ssb)
							,endtime_2nd = max(endtime_2nd)
						from (
							 select hr_employeeid
								,endtime_ssb = max(endtime_ssb)
								,endtime_2nd = max(endtime_grp)
							from (
								select *
									,endtime_ssb = (
										select top 1 endtime_grp
										from (
											select *,
												duration_grp = datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate()))
											from (
												select 
													hr_employeeid,
													keyword, 
													grp, 
													starttime_grp = min(starttime), 
													endtime_grp = max(endtime)
												from (
														select 
															ww.*, 
															count(*) over (partition by grp, Keyword) as cnt
														from (
																select *
																	,grp = (
																		row_number() over (partition by w.hr_employeeid order by w.starttime desc)
																			- row_number() over (partition by w.hr_employeeid, w.Keyword order by w.starttime desc)
																	) 
																from (
																	select 
																		hr_employeeid, 
																		starttime, 
																		endtime,
																		keyword = case when vdrd2.Keyword = 'ELOG_SpecialStatus_PersonalConveyance' then 'Off_Duty' else vdrd2.Keyword end
																	from @TempDailyReportDetailTbl vdrd2
																	where vdrd2.EndTime is not null					
																		and vdrd2.StartTime >= DATEADD(week, -1,getutcdate())	
																		and vdrd2.hr_employeeid = sssss.hr_employeeid
																) w
															) ww
														-- where keyword = 'Off_Duty'
														) www
												where www.cnt >= 1
												group by www.hr_employeeid, www.keyword, www.grp
											) wwww
											where keyword in ('In_Sleeper', 'Off_Duty', 'ELOG_SpecialStatus_PersonalConveyance')
										) wwwww 
										where wwwww.hr_employeeid = sssss.hr_employeeid
											and wwwww.duration_grp >= 2 * 3600 
											and wwwww.duration_grp < 10 * 3600	     
											--and wwwww.starttime_grp <> sssss.starttime_grp
											and wwwww.starttime_grp < sssss.starttime_grp
											and (
												(sssss.keyword = 'In_Sleeper' and sssss.duration_grp >= 7 * 3600 and wwwww.duration_grp + sssss.duration_grp >= 10 * 3600)
												or (
													(sssss.keyword <> 'In_Sleeper' or (sssss.keyword = 'In_Sleeper' and sssss.duration_grp < 7 * 3600))
													and (wwwww.keyword = 'In_Sleeper' and wwwww.duration_grp >= 7 * 3600 and wwwww.duration_grp + sssss.duration_grp >= 10 * 3600)
												)
											)
										order by endtime_grp desc
								)
								from (
									select *,
										h = 	datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate())) / 3600,
										duration_grp = datediff(SECOND, starttime_grp, isnull(endtime_grp, getutcdate()))
			
									from (
										select
											hr_employeeid, 
											keyword, 
											grp, 
											starttime_grp = min(starttime), 
											endtime_grp = max(endtime)
										from (
												select 
													ss.*, 
													count(*) over (partition by grp, Keyword) as cnt
												from (
														select *
															,grp = (
																row_number() over (partition by s.hr_employeeid order by s.starttime desc)
																	- row_number() over (partition by s.hr_employeeid, s.Keyword order by s.starttime desc)
															) 
														from (
															select 
																hr_employeeid, 
																starttime, 			   
																endtime,
																keyword_ori = vdrd2.Keyword,
																keyword = case when vdrd2.Keyword = 'ELOG_SpecialStatus_PersonalConveyance' then 'Off_Duty' else vdrd2.Keyword end
															from @TempDailyReportDetailTbl vdrd2
															where vdrd2.EndTime is not null
																and vdrd2.StartTime >= DATEADD(week, -1,getutcdate())  													
															--	and fedrd3.StartTime > '2020-11-01'	-- update to start of current day
															--and hr_employeeid = 'A21F17FB-A935-11E9-812E-00155DA8010E'
														) s
													) ss
												-- where keyword = 'Off_Duty'
												) sss
										where sss.cnt >= 1
										group by sss.hr_employeeid, sss.keyword, sss.grp
									) ssss
									where keyword in ('In_Sleeper', 'Off_Duty', 'ELOG_SpecialStatus_PersonalConveyance')
								) sssss 
								where sssss.duration_grp >= 2 * 3600 
									and sssss.duration_grp < 10 * 3600
							)ssssss
							where endtime_ssb is not null
							group by hr_employeeid
							
							UNION
							SELECT HR_EmployeeID = 	ee.ID, null	, null
							FROM [dbo].[HR_Employee]  ee
							where ee.IsActive = 1
						) splitsb
						group by HR_EmployeeID  
					) ssb on ssb.hr_employeeid = he.ID	
				)t				
			) tt 			
		) ttt
	)tttt
)ttttt

END
	
	









GO
