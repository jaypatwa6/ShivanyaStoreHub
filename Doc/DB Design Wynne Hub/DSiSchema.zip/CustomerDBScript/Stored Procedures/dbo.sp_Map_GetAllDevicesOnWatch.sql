SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[sp_Map_GetAllDevicesOnWatch]	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT device.ID, device.SerialNumber, (employee.FirstName + ' ' + employee.LastName) as DriverName, equipment.Number as EquipmentNumber FROM MCS_Device as device
	LEFT OUTER JOIN  FMS_Equipment as equipment on device.FMS_EquipmentID = equipment.ID
	LEFT OUTER JOIN  HR_Employee as employee on device.HR_EmployeeID = employee.ID	
	LEFT OUTER JOIN  FMS_DeviceEquipmentPairing  as pair ON pair.IsDeleted <> 1 and device.Id = pair.MCS_DeviceID
    WHERE ( device.IsActive = 1) AND (((pair.EquipmentID IS NULL) AND (pair.MCS_DeviceID IS NULL)) OR (( NOT ((pair.EquipmentID IS NULL) AND (pair.MCS_DeviceID IS NULL))) AND (pair.IsActive = 1)))
	Order by DriverName

END
GO
