SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[sp_SetDisplayOrder]
(
	@id INT,
	@dir VARCHAR(10),
	@smartformId INT,
	@currentOrder INT
)
AS
BEGIN
	DECLARE @currentIndex INT, @currentID INT, @minIndex INT, @maxIndex INT
	DECLARE @Indexing TABLE
	(
		RowIndex INT,
		ID INT,
		SmartformID INT,
		SequenceNumber INT
	)
	
	INSERT INTO @Indexing
	SELECT
		ROW_NUMBER() OVER (ORDER BY SequenceNumber ASC) AS RowIndex
		, ID
		, SmartformID
		, SequenceNumber
	FROM Mobile_Smartforms_Questions 
	WHERE SmartformID = @smartformId
	
	SELECT @minIndex = MIN(RowIndex) FROM @Indexing
	SELECT @maxIndex = MAX(RowIndex) FROM @Indexing
	select * from @Indexing
	SELECT @minIndex
	SELECT @maxIndex
	
	IF @dir = 'down'
	BEGIN
		DECLARE @nextRowIndex INT, @nextID INT, @nextOrder INT
		
		SELECT 
			@currentIndex = RowIndex
			,@currentID = ID
		FROM @Indexing WHERE Id = @id
		
		IF(@currentIndex <> @maxIndex)
		BEGIN
			SET @nextRowIndex = @currentIndex + 1
		
			SELECT 
				@nextID = ID
				,@nextOrder = SequenceNumber
			FROM @Indexing WHERE RowIndex = @nextRowIndex
			
			UPDATE Mobile_Smartforms_Questions
			SET 
				SequenceNumber = @nextOrder
			WHERE SmartformID = @smartformId AND ID = @currentID
			
			UPDATE Mobile_Smartforms_Questions
			SET 
				SequenceNumber = @currentOrder
			WHERE SmartformID = @smartformId AND ID = @nextID
		END
	END
	
	IF @dir = 'up'
	BEGIN
		DECLARE @previousRowIndex INT, @previousID INT, @previousOrder INT
		
		SELECT 
			@currentIndex = RowIndex
			,@currentID = ID
		FROM @Indexing WHERE Id = @id
		
		IF(@currentIndex <> @minIndex)
		BEGIN
			SET @previousRowIndex = @currentIndex - 1
		
			SELECT 
				@previousID = ID
				,@previousOrder = SequenceNumber
			FROM @Indexing WHERE RowIndex = @previousRowIndex
			
			UPDATE Mobile_Smartforms_Questions
			SET 
				SequenceNumber = @previousOrder
			WHERE SmartformID = @smartformId AND ID = @currentID
			
			UPDATE Mobile_Smartforms_Questions
			SET 
				SequenceNumber = @currentOrder
			WHERE SmartformID = @smartformId AND ID = @previousID
		END
	END
END
GO
