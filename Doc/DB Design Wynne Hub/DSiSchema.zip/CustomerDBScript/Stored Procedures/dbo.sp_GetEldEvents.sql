SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[sp_GetEldEvents]
    @HR_EmployeeID UNIQUEIDENTIFIER,
    @DateCreated DATETIME,
    @DateModified DATETIME,	
	@FMS_EquipmentID UNIQUEIDENTIFIER = null
AS
BEGIN
    SET NOCOUNT ON;
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

    SELECT [Extent1].[ID] AS DeviceCommEventId,
           [Extent1].[ELD_SequenceID] AS ELDSequenceId,
           [Extent1].[OdometerInKM] AS OdometerInKM,
           [Extent1].[ELD_Annotation] AS DriverComments,
           [Extent1].[ELD_Origin] AS EventOrigin,
           CAST([Extent3].[EventType] AS INT) AS EventType,
           CAST([Extent3].[EventCode] AS INT) AS EventCode,
           [Extent1].[MalfunctionCode] AS DiagnosticMalfunctionCode,
           [Extent1].[HOSCertifiedDate] AS HOSCertifiedDate,
           [Extent1].[Latitude] AS Latitude,
           [Extent1].[Longitude] AS Longitude,
           [Extent1].[GpsTimeStamp] AS GpsTimeStamp,
           [Extent1].[VelocityInKPH] AS VelocityInKPH,
           [Extent1].[IsIgnitionOn] AS IsIgnitionOn,
           [Extent1].[City] AS City,
           [Extent1].[State] AS State,
           [Extent1].[TimeZoneOffset] AS TimeZoneOffset,
           [Extent1].[CommonList_DeviceSummaryEventID] AS CommonListDeviceEventID,
           [Extent1].[FMS_EquipmentID] AS EquipmentId,
           [Extent1].[EngineHours] AS EngineHours,
           [Extent1].[DateCreated] AS DateCreated,
           [Extent1].[DurationInSecond] AS DurationInSecond,
           [Extent1].[ELD_EventRecordStatus] AS ELD_EventRecordStatus,
		   [Extent1].[ExtendData] AS ExtendData
    FROM [dbo].[MCS_Device_EventSummary] AS [Extent1]
        INNER JOIN [dbo].[System_CommonList_Item] AS [Extent2]
            ON [Extent1].[CommonList_DeviceSummaryEventID] = [Extent2].[ID]
        INNER JOIN [dbo].[MCS_Device_ELDEventCode] AS [Extent3]
            ON [Extent1].[MCS_Device_ELDEventCodeID] = [Extent3].[ID]
    WHERE ([Extent2].[Keyword] IN ( 
			N'ELOG_IntermediateLog', 
			N'ELOG_Driver_Entered_DutySubStatus',
			N'ELOG_Driver_Certified_LogEntry', 
			N'Mobile_Application_LoginLogout',
			N'Vehicle_Engine_Power_OnOff', 
			N'ELD_Malfuction',
			'CA_ELD_ADDITIONAL_HOURS',
			'CA_ELD_CYCLE_CHANGE',
			'CA_ELD_OFF_DUTY_TIME_DEFERRAL',
			'CA_ELD_ZONE_CHANGE')
          )
          AND ([Extent2].[Keyword] IS NOT NULL)
          AND ([Extent1].[HR_EmployeeID] = @HR_EmployeeID)
		  AND ( @FMS_EquipmentID IS NULL OR [Extent1].FMS_EquipmentID = @FMS_EquipmentID)
          AND ([Extent1].[DateCreated] > @DateCreated)
          AND ([Extent1].[DateModified] > @DateModified);

END;


GO
