SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[SP_DispatchCanceledOrder](@userId AS UNIQUEIDENTIFIER, @orderId AS UNIQUEIDENTIFIER, @OrderItemId AS UNIQUEIDENTIFIER, @orderItemTaskId AS UNIQUEIDENTIFIER, @ErrorCode AS INT OUTPUT)
AS
BEGIN
	DECLARE @mcsTaskId AS UNIQUEIDENTIFIER, @mcsStopId AS UNIQUEIDENTIFIER, @mcsCanceledStatusId AS UNIQUEIDENTIFIER,@mcsCompletedStatusId AS UNIQUEIDENTIFIER;
	SET @mcsCanceledStatusId = (SELECT ID FROM System_CommonList_Item WHERE Keyword = 'Cancel' and System_CommonListID = (SELECT ID FROM System_CommonList WHERE keyword = 'Dispatch_TaskStatus'));
	SET @mcsCompletedStatusId = (SELECT ID FROM System_CommonList_Item WHERE Keyword = 'Complete' and System_CommonListID = (SELECT ID FROM System_CommonList WHERE keyword = 'Dispatch_TaskStatus'));
	SET @mcsTaskId = (SELECT MCS_Trip_Stop_TaskID FROM TMS_Order_Item_Task WHERE ID = @orderItemTaskId);
	IF (@mcsTaskId IS NOT NULL)
	BEGIN
		IF EXISTS (SELECT ID FROM MCS_Trip_Stop_Task WHERE ID = @mcsTaskId AND IsDeleted = 0)
		BEGIN
			--soft delete mcs task
			UPDATE MCS_Trip_Stop_Task SET IsDeleted = 1, ModifiedBy = @userId, DateModified = GETUTCDATE(), CommonList_TaskStatusID = @mcsCanceledStatusId WHERE ID = @mcsTaskId;
			SET @ErrorCode = @@ERROR;
			IF (@ErrorCode != 0) return;
			--soft delete mcs stop
			SET @mcsStopId = (SELECT MCS_Trip_StopID FROM MCS_Trip_Stop_Task WHERE ID = @mcsTaskId);
			IF NOT EXISTS (SELECT ID FROM MCS_Trip_Stop_Task WHERE MCS_Trip_StopID = @mcsStopId AND IsDeleted = 0 AND CommonList_TaskStatusID != @mcsCanceledStatusId AND CommonList_TaskStatusID != @mcsCompletedStatusId)
			BEGIN
				UPDATE MCS_Trip_Stop SET IsDeleted = 1, DateModified = GETUTCDATE(), ModifiedBy = @userId WHERE ID = @mcsStopId;
				SET @ErrorCode = @@ERROR;
				IF (@ErrorCode != 0) return;
			END
		END
		UPDATE TMS_Order_Item_Task SET MCS_Trip_Stop_TaskID = NULL WHERE ID = @orderItemTaskId
		SET @ErrorCode = @@ERROR;
		IF (@ErrorCode != 0) return;
	END
END
GO
