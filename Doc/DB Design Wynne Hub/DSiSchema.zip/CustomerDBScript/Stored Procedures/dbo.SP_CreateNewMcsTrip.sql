SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[SP_CreateNewMcsTrip](@userId AS UNIQUEIDENTIFIER, @tmsTaskId AS UNIQUEIDENTIFIER, @returnedMcsTripId AS UNIQUEIDENTIFIER OUTPUT)
AS
BEGIN
--AccountID_EmployeeNumber_yyyyMMdd
	declare @mcsTripNumber NVARCHAR(100);
	declare @tmsDriverId AS UNIQUEIDENTIFIER
	select 
	@mcsTripNumber = convert(nvarchar,Master_Account_Login.AccountId) + '_' + convert(nvarchar,HR_Employee.Number) + '_' + convert(nvarchar, TMS_Order_Item_Task.ScheduledTime, 112),
	@tmsDriverId = TMS_Order_Item_Task.Driver_HR_EmployeeID
	from TMS_Order_Item_Task 
	inner join HR_Employee on HR_Employee.ID = TMS_Order_Item_Task.Driver_HR_EmployeeID
	inner join Master_Account_Login on Master_Account_Login.Id = HR_Employee.Account_LoginID
	where TMS_Order_Item_Task.Driver_HR_EmployeeID is not null and TMS_Order_Item_Task.Id = @tmsTaskId

	--check trip is existed before create new trip
	SET @returnedMcsTripId = (SELECT TOP 1 ID FROM MCS_TRIP where TripNumber = @mcsTripNumber and AssignedToEmployeeID = @tmsDriverId);
									
	IF (@returnedMcsTripId IS NULL)									
	BEGIN
		--createw new mcsTrip
		SET @returnedMcsTripId = NEWID();
		INSERT INTO MCS_Trip (ID, DateCreated, CreatedBy, DateModified,ModifiedBy,TripNumber,AssignedToEmployeeID,CustomData)
		VALUES (@returnedMcsTripId, GETUTCDATE(), @userId, GETUTCDATE(),@userId,@mcsTripNumber,@tmsDriverId,N'');
	END
END
GO
