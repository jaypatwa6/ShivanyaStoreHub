SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[SP_CheckAllTaskIsDispatched](@OrderItemId AS UNIQUEIDENTIFIER, @IsAllTaskDispatched BIT OUTPUT)
AS
BEGIN
	DECLARE @cachedCommonItemTable TABLE (ID UNIQUEIDENTIFIER, Keyword NVARCHAR(MAX), Sequence INT);
	DECLARE @cachedCommonItemCursor CURSOR;
	SET @cachedCommonItemCursor = CURSOR FOR (SELECT ID, Keyword, Sequence FROM  [System_CommonList_Item] WHERE Keyword LIKE 'TMS_OrderItemStatus_%' OR Keyword LIKE 'TMS_Order_Type_%');
	DECLARE @id UNIQUEIDENTIFIER, @keyword NVARCHAR(MAX), @sequence INT;
	OPEN @cachedCommonItemCursor FETCH NEXT FROM @cachedCommonItemCursor INTO @id, @keyword, @sequence;
	WHILE @@FETCH_STATUS = 0
	BEGIN
		INSERT INTO @cachedCommonItemTable (ID, Keyword, Sequence) VALUES (@id, @keyword, @sequence);
		FETCH NEXT FROM @cachedCommonItemCursor INTO @id, @keyword, @sequence;
	END
	CLOSE @cachedCommonItemCursor;
	DEALLOCATE @cachedCommonItemCursor;
	
	DECLARE @pickupTaskCursor AS CURSOR, @deliveryTaskCursor AS CURSOR, @taskID AS UNIQUEIDENTIFIER, @taskStatusID AS UNIQUEIDENTIFIER, @dispatchStatusSequence AS INT, @taskStatusSequence AS INT, @checked AS BIT;
	SET @IsAllTaskDispatched = 1;
	SET @checked = 0;
	SET @dispatchStatusSequence = (SELECT Sequence FROM @cachedCommonItemTable WHERE Keyword = 'TMS_OrderItemStatus_Dispatched')
	SET @pickupTaskCursor = CURSOR FOR (SELECT ID FROM TMS_Order_Item_Task WHERE TMS_Order_ItemID = @OrderItemId AND CommonList_TMSOrderItemTaskTypeId = (
		SELECT ID FROM @cachedCommonItemTable WHERE Keyword = 'TMS_Order_Type_Pickup'));
	SET @deliveryTaskCursor = CURSOR FOR (SELECT ID FROM TMS_Order_Item_Task WHERE TMS_Order_ItemID = @OrderItemId AND CommonList_TMSOrderItemTaskTypeId = (
		SELECT ID FROM @cachedCommonItemTable WHERE Keyword = 'TMS_Order_Type_Delivery'));
	
	OPEN @deliveryTaskCursor FETCH NEXT FROM @deliveryTaskCursor INTO @taskID;
	WHILE @@FETCH_STATUS = 0 AND @IsAllTaskDispatched = 1
	BEGIN
		SET @checked = 1;
		SET @taskStatusID = (SELECT TOP 1 (CommonList_TMSOrder_Item_Task_StatusId) FROM TMS_Order_Event_Summary WHERE TMS_Order_Item_TaskId = @taskID ORDER BY DateCreated DESC)
		IF (@taskStatusID IS NULL) 
		BEGIN
			SET @IsAllTaskDispatched = 0;
		END
		ELSE
		BEGIN
			SET @taskStatusSequence = (SELECT Sequence FROM @cachedCommonItemTable WHERE ID = @taskStatusID);
			IF (@taskStatusSequence < @dispatchStatusSequence)
			BEGIN
				SET @IsAllTaskDispatched = 0;
			END
		END
		FETCH NEXT FROM @deliveryTaskCursor INTO @taskID;
	END
	CLOSE @deliveryTaskCursor;
	DEALLOCATE @deliveryTaskCursor;
	
	OPEN @pickupTaskCursor FETCH NEXT FROM @pickupTaskCursor INTO @taskID;
	WHILE @@FETCH_STATUS = 0 AND @IsAllTaskDispatched = 1
	BEGIN
		SET @checked = 1;
		SET @taskStatusID = (SELECT TOP 1 (CommonList_TMSOrder_Item_Task_StatusId) FROM TMS_Order_Event_Summary WHERE TMS_Order_Item_TaskId = @taskID ORDER BY DateCreated DESC)
		IF (@taskStatusID IS NULL) 
		BEGIN
			SET @IsAllTaskDispatched = 0;
		END
		ELSE
		BEGIN
			SET @taskStatusSequence = (SELECT Sequence FROM @cachedCommonItemTable WHERE ID = @taskStatusID);
			IF (@taskStatusSequence < @dispatchStatusSequence)
			BEGIN
				SET @IsAllTaskDispatched = 0;
			END
		END
		FETCH NEXT FROM @pickupTaskCursor INTO @taskID;
	END
	CLOSE @pickupTaskCursor;
	DEALLOCATE @pickupTaskCursor;
	
	--there is no pickup/delivery task -> non dispatched
	IF (@checked = 0)
	BEGIN
		SET @IsAllTaskDispatched = 0;
	END
	
END
GO
