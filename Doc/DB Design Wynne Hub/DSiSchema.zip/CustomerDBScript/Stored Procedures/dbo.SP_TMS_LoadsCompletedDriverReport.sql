SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[SP_TMS_LoadsCompletedDriverReport]
@startdate datetime,
@enddate datetime,
@timezone float
AS
BEGIN
	SET NOCOUNT ON;

     SELECT
	CONVERT(date,DATEADD(hour, @timezone,TMS_Order.DateCreated)) as DateCreated,
	TMS_Order.OrderNumber,
	TMS_Order_Item.OrderItemNumber,
	CRM_Customer.[Name] as CustomerName,
	TMS_Order_Item.FreightDescription,
	(
		select top(1) CONVERT(datetime,DATEADD(hour, @timezone,MCS_Device_EventSummary.GpsTimeStamp ))	
		from TMS_Order_Event_Summary
		inner join MCS_Device_EventSummary on TMS_Order_Event_Summary.MCS_Device_EventSummaryID = MCS_Device_EventSummary.ID
		where TMS_Order_Event_Summary.TMS_Order_Item_TaskId = TMS_Order_Item_Task.ID
		order by MCS_Device_EventSummary.GpsTimeStamp desc
	) as CompletedDate,
	CAST(CASE WHEN TMS_Order_Item.TotalTripDurationInMin IS NULL THEN 0
              WHEN TMS_Order_Item.TotalTripDurationInMin < 0 THEN 0
              ELSE CAST(TMS_Order_Item.TotalTripDurationInMin AS INT) END AS VARCHAR) + ' mins'
       --'N/A'       
       as TotalDriveInSeconds,
 
       CAST(CASE WHEN TMS_Order_Item.TotalTripDistanceInKM IS NULL THEN 0
              WHEN TMS_Order_Item.TotalTripDistanceInKM < 0 THEN 0
              ELSE CAST(TMS_Order_Item.TotalTripDistanceInKM * 0.621371192 AS NUMERIC(10,2)) END AS VARCHAR) 
       --'N/A'
       as TotalDistanceDriven,
	HR_Employee.FirstName + ' ' + HR_Employee.LastName as DriverName,
	TMS_Order_Item_Task.Driver_HR_EmployeeID as DriverID
	FROM TMS_Order_Item  
	inner join TMS_Order_Item_Task on TMS_Order_Item_Task.TMS_Order_ItemID = TMS_Order_Item.ID
	inner join System_CommonList_Item taskType on taskType.ID = TMS_Order_Item_Task.CommonList_TMSOrderItemTaskTypeId 
	inner join System_CommonList_Item deliveryStatus on deliveryStatus.ID = TMS_Order_Item.CommonList_TMSOrderItemStatusID 

	inner join HR_Employee on HR_Employee.ID = TMS_Order_Item_Task.Driver_HR_EmployeeID
	inner join TMS_Order on TMS_Order_Item.TMS_OrderID = TMS_Order.ID 
	left join CRM_Customer on CRM_Customer.ID =  TMS_Order.CRM_CustomerID
	where TMS_Order.IsDelete = 0 
	and TMS_Order.DateCreated between @startdate and @enddate
	
	and  taskType.Keyword ='TMS_Order_Type_Delivery'
	and deliveryStatus.Keyword = 'TMS_OrderItemStatus_DeliveryComplete'
	order by HR_Employee.FirstName , HR_Employee.LastName
END

GO
