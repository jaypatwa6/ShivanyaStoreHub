SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[SP_Calendar_DeleteMcsStop](@mcsStopId AS UNIQUEIDENTIFIER, @userId AS UNIQUEIDENTIFIER)
AS
BEGIN
	DECLARE @countActiveTask INT = (SELECT COUNT(task.ID) 
	FROM MCS_Trip_Stop_Task AS task JOIN MCS_Trip_Stop AS [stop] ON task.MCS_Trip_StopID = [stop].ID
	JOIN System_CommonList_Item AS [status] ON task.CommonList_TaskStatusID = [status].ID
	WHERE [stop].ID = @mcsStopId 
	AND task.IsDeleted = 0
	AND [status].Keyword NOT IN ('Cancel', 'Complete'))
	IF (@countActiveTask IS NULL OR @countActiveTask <= 0)
	BEGIN
		UPDATE [dbo].[MCS_Trip_Stop]
		SET IsDeleted = 1, [DateModified] = GETUTCDATE(), [ModifiedBy] = @userId, DateSynchronized = GETUTCDATE() WHERE ID = @mcsStopId;
	END
END
GO
