SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[SP_Calendar_CreateNewMcsStop](@userId AS UNIQUEIDENTIFIER, @mcsTripId AS UNIQUEIDENTIFIER, @orderId AS UNIQUEIDENTIFIER, @orderItemId AS UNIQUEIDENTIFIER, @tmsTaskId AS UNIQUEIDENTIFIER, @returnedMcsStopId AS UNIQUEIDENTIFIER OUTPUT)
AS
BEGIN
	DECLARE @countryId AS UNIQUEIDENTIFIER, @address AS NVARCHAR(255), @city AS NVARCHAR(50), @state AS NVARCHAR(50), @postalCode AS NVARCHAR(50), @lat AS DECIMAL(9,6), @long AS DECIMAL(9,6), @name AS NVARCHAR(255), @contactPhone AS NVARCHAR(50), @contactExtension AS NVARCHAR(50), @contactName AS NVARCHAR(50);
	DECLARE @mcsStopLocationInstructions NVARCHAR(4000);
	DECLARE @mcsStopSummaryField NVARCHAR(4000);
	SET @mcsStopSummaryField = (SELECT CONCAT('Order#: ',OrderNumber) FROM TMS_Order WHERE ID = @OrderId);
	SET @mcsStopSummaryField = (SELECT CONCAT(@mcsStopSummaryField,', Item#: ', OrderItemNumber) FROM TMS_Order_Item WHERE ID = @orderItemId);
	-----------------------------------------------------------
	DECLARE @tmsTaskTypeId AS UNIQUEIDENTIFIER, @tmsTaskTypeKeyword AS NVARCHAR(50);
	SELECT @tmsTaskTypeId = CommonList_TMSOrderItemTaskTypeId FROM TMS_Order_Item_Task WHERE ID = @tmsTaskId;
	SELECT @tmsTaskTypeKeyword = keyword from System_CommonList_Item WHERE ID = @tmsTaskTypeId;

	--set data from jobsite
	SELECT @countryId = System_List_CountryID, @address = Address, @city = City, @state = [State], @postalCode = PostalCode, @lat =Latitude , @long = Longitude, @name = Name, @contactPhone = ContactPhone, @contactExtension = ContactExtension, @contactName = ContactName
	FROM CRM_Jobsite WHERE ID = (SELECT TaskLocation_CRM_JobsiteID FROM TMS_Order_Item_Task WHERE ID = @tmsTaskId);
	--support one time jobsite which does not have jobsite name
	IF (@name IS NULL) 
	BEGIN
		SET @name = ' ';
	END
	IF (@tmsTaskTypeKeyword = 'TMS_Order_Type_Pickup')
	BEGIN --pickup task
		SET @mcsStopLocationInstructions = (SELECT OriginJobsiteNotes FROM TMS_Order WHERE ID = @OrderId);
	END
	IF (@tmsTaskTypeKeyword = 'TMS_Order_Type_Delivery')
	BEGIN --delivery task
		SET @mcsStopLocationInstructions = (SELECT DestinationJobsiteNotes FROM TMS_Order WHERE ID = @OrderId);
	END
	
	--TODO Sequence
	--Check IsNullTime
	DECLARE @ScheduledTime AS DATETIME = (SELECT ScheduledTime FROM TMS_Order_Item_Task WHERE ID = @tmsTaskId), @IsNullTime AS BIT = 0;
	IF (@ScheduledTime IS NULL)
	BEGIN
		SET @IsNullTime = 1;
	END

	SET @returnedMcsStopId = NEWID();
	INSERT INTO MCS_Trip_Stop (StopNumber, [Sequence],MCS_TripID, ID, DateSynchronized, DateCreated, CreatedBy, DateModified, ModifiedBy, System_List_CountryID, PromiseTime, [Address], City , [State], PostalCode, Latitude, Longitude, SummaryField, LocationInstructions, Name, Acknowledge, PhoneNumber,PhoneExtension,Contact, CommonList_OrderPriorityID, IsNullTime)
	VALUES(
	0,0,@mcsTripId, @returnedMcsStopId, GETUTCDATE(), GETUTCDATE(), @userId, GETUTCDATE(), @userId, @countryId, @ScheduledTime,
	@address, @city , @state, @postalCode, @lat, @long, @mcsStopSummaryField, @mcsStopLocationInstructions, @name, 0, @contactPhone, @contactExtension, @contactName,
	(SELECT ID FROM System_CommonList_Item WHERE Keyword = 'Medium' AND System_CommonListID = (SELECT ID FROM System_CommonList WHERE Keyword = 'Sales_OrderPriority')), @IsNullTime)
END
GO
