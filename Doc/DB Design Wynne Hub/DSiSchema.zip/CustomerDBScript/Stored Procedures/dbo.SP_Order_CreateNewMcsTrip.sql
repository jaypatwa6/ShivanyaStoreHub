SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[SP_Order_CreateNewMcsTrip](@userId AS UNIQUEIDENTIFIER, @tmsTaskId AS UNIQUEIDENTIFIER, @returnedMcsTripId AS UNIQUEIDENTIFIER OUTPUT)
AS
BEGIN
	--check trip is existed before create new trip
	SET @returnedMcsTripId = (SELECT TOP 1 ID FROM MCS_TRIP 
								WHERE ID IN (SELECT MCS_TripID FROM MCS_Trip_Stop 
								WHERE ID IN (SELECT MCS_Trip_StopID FROM MCS_Trip_Stop_Task 
									WHERE ID IN (SELECT MCS_Trip_Stop_TaskID FROM TMS_Order_Item_Task 
													WHERE MCS_TRIP.AssignedToEmployeeID = TMS_Order_Item_Task.Driver_HR_EmployeeID
													 AND TMS_Order_ItemID = (SELECT TMS_Order_ItemID FROM TMS_Order_Item_Task WHERE ID = @tmsTaskId)))));
									
	IF (@returnedMcsTripId IS NULL)									
	BEGIN
		--createw new mcsTrip
		SET @returnedMcsTripId = NEWID();
		DECLARE @mcsTripNumber NVARCHAR(100) = 'TODO:AccountId', @tmsDriverId AS UNIQUEIDENTIFIER;
		SELECT @tmsDriverId = Driver_HR_EmployeeID FROM TMS_Order_Item_Task WHERE ID = @tmsTaskId;
		SET @mcsTripNumber = CONCAT(@mcsTripNumber, '_', (SELECT Number FROM HR_Employee WHERE ID = @tmsDriverId), '_', (select REPLACE(CONVERT(NVARCHAR(max),getutcdate(),121), ' ', '')));
		INSERT INTO MCS_Trip (ID, DateCreated, CreatedBy, DateModified,ModifiedBy,TripNumber,AssignedToEmployeeID,CustomData)
		VALUES (@returnedMcsTripId, GETUTCDATE(), @userId, GETUTCDATE(),@userId,@mcsTripNumber,@tmsDriverId,N'');
	END
END
GO
