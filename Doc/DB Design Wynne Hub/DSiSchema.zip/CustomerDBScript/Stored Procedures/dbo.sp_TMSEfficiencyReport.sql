SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE PROCEDURE [dbo].[sp_TMSEfficiencyReport]
 @startdate datetime,
 @enddate datetime,
 @timezone float,
 @browser_colName nvarchar(256),
 @browser_colValue nvarchar(max)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	  declare 
 --@startdate datetime,
 --@enddate datetime,
 --@timezone float,
 @daily_hours nvarchar(2),
 --@browser_colName nvarchar(256),
 --@browser_colValue nvarchar(max),
 @atpickup uniqueidentifier,
 @deliverycomplete uniqueidentifier,
 @pickupcomplete uniqueidentifier,
 @atdelivery uniqueidentifier,
 @outforpickup uniqueidentifier,
 @outfordelivery uniqueidentifier
--set @startdate = '2020-3-16'
--set @enddate = '2020-03-22'
--set @timezone = 0
--set @browser_colName= ''
--set @browser_colValue = ''
set @outforpickup = (select top 1 Id from System_CommonList_Item where Keyword = 'TMS_OrderItemStatus_OutForPickup')
set @atpickup = (select top 1 Id from System_CommonList_Item where Keyword = 'TMS_OrderItemStatus_AtPickup')
set @deliverycomplete = (select top 1 Id from System_CommonList_Item where Keyword = 'TMS_OrderItemStatus_DeliveryComplete')
set @pickupcomplete = (select top 1 Id from System_CommonList_Item where Keyword = 'TMS_OrderItemStatus_PickupComplete')
set @atdelivery = (select top 1 Id from System_CommonList_Item where Keyword = 'TMS_OrderItemStatus_AtDelivery')
set @outfordelivery = (select top 1 Id from System_CommonList_Item where Keyword = 'TMS_OrderItemStatus_OutForDelivery')
SET @daily_hours = (SELECT TOP 1 COALESCE(Value, COALESCE(DefaultValue, 8)) FROM System_Setting WHERE Name = N'TMS.DefaultRegularWorkingHours')
	select	CONVERT(date,DATEADD(hour, @timezone,ScheduledTime))																							AS SCHEDULEDTIME,
			[DRIVER]																																		AS [DRIVER],
			COALESCE([DRIVEN], 0)																															AS [DRIVEN],
			COALESCE(SUM([DRIVEN])  Over (Partition By CONVERT(date,DATEADD(hour, @timezone,ScheduledTime)), [DRIVER]), 0)									AS [TOTALDRIVENDISTANCE],
			[dbo].[fn_GetDurationBySecond](
					COALESCE([LOADINGTIME], 0)
				+	COALESCE([ORDERCREATEDTOPICKUP], 0)
				+	COALESCE([UNLOADINGTIME], 0)
				+	COALESCE([TOTALDRIVERTIME], 0)
			)																																				AS [DURATION],
			[dbo].[fn_GetDurationBySecond](
			CAST(Sum(
				COALESCE([LOADINGTIME], 0)
				+	COALESCE([ORDERCREATEDTOPICKUP], 0)
				+	COALESCE([UNLOADINGTIME], 0)
				+	COALESCE([TOTALDRIVERTIME], 0)
			) Over (Partition By CONVERT(date,DATEADD(hour, @timezone,ScheduledTime)), [DRIVER]) AS Numeric(18,2)))											AS [TOTALDURATION],		
			CAST(Sum(
				COALESCE([LOADINGTIME], 0)
				+	COALESCE([ORDERCREATEDTOPICKUP], 0)
				+	COALESCE([UNLOADINGTIME], 0)
				+	COALESCE([TOTALDRIVERTIME], 0)
			) Over (Partition By CONVERT(date,DATEADD(hour, @timezone,ScheduledTime)), [DRIVER]) /3600 AS Numeric(18,2))									AS [EFFIENCY],
			@daily_hours																																	AS [DAILYHOURS],
			CAST(CASE WHEN CAST(Sum(
				COALESCE([LOADINGTIME], 0)
				+	COALESCE([ORDERCREATEDTOPICKUP], 0)
				+	COALESCE([UNLOADINGTIME], 0)
				+	COALESCE([TOTALDRIVERTIME], 0)
				) Over (Partition By CONVERT(date,DATEADD(hour, @timezone,ScheduledTime)), [DRIVER]) /3600 AS Numeric(18,2)) = 0.00 THEN 0.00
			ELSE
			COALESCE([STADARDTIME], 0)/
			CAST(
				CAST(Sum(
				COALESCE([LOADINGTIME], 0)
				+	COALESCE([ORDERCREATEDTOPICKUP], 0)
				+	COALESCE([UNLOADINGTIME], 0)
				+	COALESCE([TOTALDRIVERTIME], 0)
			) Over (Partition By CONVERT(date,DATEADD(hour, @timezone,ScheduledTime)), [DRIVER]) /3600 AS Numeric(18,2)) 
			* 100 AS Numeric(19,2)) END AS Numeric(19,2))																										AS [TIMEPERCENT],
			--[DATECREATED],
			[ORDER],
			[CUSTOMER],
			[DESCRIPTION],
			[STATUS],
			CONVERT(datetime,DATEADD(hour, @timezone,ScheduledTime))																					AS [SCHEDULEDPICKUP],
			[ITEMID],
			CONVERT(datetime,DATEADD(hour, @timezone,[OUTFORPICKUP]))																						AS [OUTFORPICKUP],
			CONVERT(datetime,DATEADD(hour, @timezone,[DELIVERYCOMPLETE]))																					AS [DELIVERYCOMPLETE]
	from 
(select isnull(emp.FirstName,'')  + ' ' + isnull(emp.LastName,'')						AS [DRIVER],
			[order].DATECREATED																AS [DATECREATED],
			[order].ORDERNUMBER																AS [ORDER],
			[cus].NAME																		AS [CUSTOMER],
			[item].FREIGHTDESCRIPTION														AS [DESCRIPTION],
			[common].Name																	AS [STATUS],
			--[order].PICKUPREQUESTEDTIMETORANGE												AS [SCHEDULEDPICKUP],
			MAX(task.ScheduledTime) as ScheduledTime,
			[item].ID																		AS [ITEMID],
(
						SELECT MAX( [taskEvent].DATECREATED)
						FROM TMS_Order_Event_Summary [taskEvent]
						WHERE TMS_Order_ItemId = [item].ID  and [taskEvent].CommonList_TMSOrder_Item_Task_StatusId = @outforpickup
					) AS [OUTFORPICKUP],
(
						SELECT MAX( [taskEvent].DATECREATED)
						FROM TMS_Order_Event_Summary [taskEvent]
						WHERE TMS_Order_ItemId = [item].ID  and [taskEvent].CommonList_TMSOrder_Item_Task_StatusId = @deliverycomplete
					) AS [DELIVERYCOMPLETE],
ABS(DATEDIFF(s,
				(SELECT MAX([taskEvent].DATECREATED)
						FROM TMS_Order_Event_Summary [taskEvent]
						WHERE TMS_Order_ItemId = [item].ID and taskEvent.CommonList_TMSOrder_Item_Task_StatusId = @pickupcomplete),		
				(SELECT MAX([taskEvent].DATECREATED)
						FROM TMS_Order_Event_Summary [taskEvent]
						WHERE TMS_Order_ItemId = [item].ID and taskEvent.CommonList_TMSOrder_Item_Task_StatusId = @atpickup)
			))																				AS [LOADINGTIME],
ABS(DATEDIFF(s,(
						SELECT MAX( [taskEvent].DATECREATED)
						FROM TMS_Order_Event_Summary [taskEvent]
						WHERE TMS_Order_ItemId = [item].ID  and [taskEvent].CommonList_TMSOrder_Item_Task_StatusId = @deliverycomplete
					)
				,		
				
					(
						SELECT MAX([taskEvent].DATECREATED)
						FROM TMS_Order_Event_Summary [taskEvent]
						WHERE TMS_Order_ItemId = [item].ID and [taskEvent].CommonList_TMSOrder_Item_Task_StatusId = @atdelivery
					)
			))																				AS [UNLOADINGTIME],
 ABS(DATEDIFF(s,
					(
						SELECT MAX([taskEvent].DATECREATED)
						FROM TMS_Order_Event_Summary [taskEvent]
						WHERE TMS_Order_ItemId = [item].ID and taskEvent.CommonList_TMSOrder_Item_Task_StatusId = @atpickup
					),
				[order].DateCreated
			))																				AS [ORDERCREATEDTOPICKUP],
			[item].TotalTripDurationInMin													AS [STADARDTIME],
(
ABS(DATEDIFF(s,
				(SELECT MAX([taskEvent].DATECREATED)
						FROM TMS_Order_Event_Summary [taskEvent]
						WHERE TMS_Order_ItemId = [item].ID and taskEvent.CommonList_TMSOrder_Item_Task_StatusId = @outforpickup),		
				(SELECT MAX([taskEvent].DATECREATED)
						FROM TMS_Order_Event_Summary [taskEvent]
						WHERE TMS_Order_ItemId = [item].ID and taskEvent.CommonList_TMSOrder_Item_Task_StatusId = @atpickup)
			))
+
ABS(DATEDIFF(s,
				(SELECT MAX([taskEvent].DATECREATED)
						FROM TMS_Order_Event_Summary [taskEvent]
						WHERE TMS_Order_ItemId = [item].ID and taskEvent.CommonList_TMSOrder_Item_Task_StatusId = @outfordelivery),		
				(SELECT MAX([taskEvent].DATECREATED)
						FROM TMS_Order_Event_Summary [taskEvent]
						WHERE TMS_Order_ItemId = [item].ID and taskEvent.CommonList_TMSOrder_Item_Task_StatusId = @atdelivery)
			))
)																							AS [TOTALDRIVERTIME],
			CAST(ROUND([item].TotalTripDistanceInKM * 0.621371192,2) AS DECIMAL(11,2))		AS [DRIVEN]
	FROM	TMS_Order_Item [item]
	INNER JOIN TMS_Order [order] on [order].ID = [item].TMS_OrderID and [item].IsDelete = 0 and [order].ISDELETE = 0
	inner join dbo.TMS_Order_Item_Task AS task ON task.TMS_Order_ItemID = [item].ID and task.ScheduledTime between @startdate and @enddate and task.Driver_HR_EmployeeID is not null
	INNER JOIN CRM_Customer [cus] ON [cus].ID = [order].CRM_CustomerID
	INNER JOIN System_CommonList_Item [Common] ON [Common].ID = [item].COMMONLIST_TMSORDERITEMSTATUSID
	inner join HR_Employee AS emp on emp.ID = task.Driver_HR_EmployeeID and emp.IsActive = 1
	group by 
	emp.FirstName
	,emp.LastName
	,[order].DATECREATED
	,[order].OrderNumber 
	,[item].ID
	,[cus].Name 
	,[item].FREIGHTDESCRIPTION
	,[common].Name
	--,[order].PICKUPREQUESTEDTIMETORANGE
	,[item].TotalTripDurationInMin
	,[item].TotalTripDistanceInKM
	) as t
	WHERE 
	 CASE @browser_colName 
					WHEN 'Driver' THEN [DRIVER]
					WHEN 'Customer' THEN [CUSTOMER]
					WHEN 'Order' THEN [ORDER]
					WHEN 'Status' THEN [STATUS]
					ELSE ''
				END = @browser_colValue
	 ORDER BY [SCHEDULEDTIME], [DRIVER]
END

GO
