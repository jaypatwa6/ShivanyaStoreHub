SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- =============================================
-- Author:		Hieu
-- Create date: Aug 21th 2023
-- Description:	Get phone PhonNumberType
-- =============================================
-- [sp_GetCommonListItem] 'System_PhoneNumberType'
Create PROCEDURE [dbo].[sp_GetCommonListItem]
	 @CommonListKeyword nvarchar(50)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
	select cli.* 
	from [dbo].[System_CommonList_Item]  cli
		inner join [dbo].[System_CommonList] cl on cl.id = cli.System_CommonListID
	where cl.keyword = @CommonListKeyword and cli.IsActive = 1	
END
GO
