SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [dbo].[sp_GetTableSchema] (@query NVARCHAR(MAX), @linked_server NVARCHAR(500) = NULL)
AS
BEGIN	
	DECLARE @xml AS XML, @sqlQuery AS NVARCHAR(max)		
	IF (@linked_server is NULL)		
		BEGIN
			EXEC ('CREATE VIEW myViewDatatype AS SELECT TOP 0 t.*  FROM (' + @query +') AS t')
			print('create');
			SELECT c.name AS Name, 
				CASE t.name
					WHEN 'uniqueidentifier' THEN 'System.Guid'
					WHEN 'bit'				THEN 'System.Boolean'
					WHEN 'int'				THEN 'System.Int16'
					WHEN 'varchar'			THEN 'System.String'
					WHEN 'nvarchar'			THEN 'System.String'
					WHEN 'datetime'			THEN 'System.DateTime'
					WHEN 'date'				THEN 'System.DateTime'
					WHEN 'decimal'			THEN 'System.Decimal'
					WHEN 'numeric'			THEN 'System.Decimal'
					WHEN 'xml'				THEN 'System.XML'
					ELSE 'System.String'
				END AS DataType
			FROM sys.columns c JOIN sys.types t
			ON t.system_type_id = c.system_type_id AND
				t.system_type_id = t.user_type_id
			WHERE object_id = (SELECT OBJECT_ID('dbo.myViewDatatype', 'VIEW'))

			EXEC ('DROP VIEW myViewDatatype')
		END
	ELSE
		BEGIN
			DECLARE @open_query AS NVARCHAR(MAX)
			SET @open_query = 'SELECT * FROM OpenQuery ("' + @linked_server + '",''' + @query + ''')'

			EXEC ('CREATE VIEW myViewDatatype AS SELECT TOP 0 t.*  FROM (' + @open_query +') AS t')

			SELECT c.name AS Name, 
				CASE 
					WHEN c.name LIKE '%MEMBER_CAPTION%' THEN 'Dimension'
					WHEN c.name LIKE '%Measures%' THEN 'Measure'			
				ELSE ''
				END AS CubeType,
				'System.String' AS DataType
			FROM sys.columns c
			WHERE object_id = (SELECT OBJECT_ID('dbo.myViewDatatype', 'VIEW'))

			EXEC ('DROP VIEW myViewDatatype')		
		END
END   

GO
