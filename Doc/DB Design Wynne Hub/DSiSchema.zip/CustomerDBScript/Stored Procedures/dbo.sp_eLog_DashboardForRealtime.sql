SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

-- =============================================
-- Author:		HIEU - CFB
-- Create date: 06/08/2016
-- Description:	get data for eLog Dashboard
-- =============================================
-- [sp_eLog_DashboardForRealtime] '2cde9a8d-2ed8-11e6-80fa-00155db47809'
CREATE PROCEDURE [dbo].[sp_eLog_DashboardForRealtime]
	@HR_EmployeeID uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	
	-- get maximum ios mobile app version
	declare @maxiOSMobileAppVersion nvarchar(50)
	select top 1 @maxiOSMobileAppVersion = md.SoftwareVersion
	from [dbo].[MCS_Device] md	
	where md.isactive = 1
		and md.OSType = 'iOS'
		and md.DeviceType = 'Smartphone'
	order by md.SoftwareVersion desc

	-- get maximum android mobile app version
	declare @maxAndroidMobileAppVersion nvarchar(50)
	select top 1 @maxAndroidMobileAppVersion = md.SoftwareVersion
	from [dbo].[MCS_Device] md	
	where md.isactive = 1
		and md.OSType = 'Android'
		and md.DeviceType = 'Smartphone'
	order by md.SoftwareVersion desc

	select *,		
		Is16HourRuleExceptionView = (
			--case when Is16HourRuleException = 1 
			--		or (
			--			IsInternalState = 1 
			--			and CurrentStatus = 'D'
			--			and StartTimeOf16HourRuleException is not null
			--			and StartTime >= StartTimeOf16HourRuleException
			--		)
			case when IsInternalState = 1 and StartTimeOf16HourRuleException is not null and StartTime >= StartTimeOf16HourRuleException
				then CAST(1 AS bit)
				else CAST(0 AS bit)
			end
		)
		, IsAdverseDrivingView = (
			--case when Is16HourRuleException = 1 
			--		or (
			--			IsInternalState = 1 
			--			and CurrentStatus = 'D'
			--			and StartTimeOf16HourRuleException is not null
			--			and StartTime >= StartTimeOf16HourRuleException
			--		)
			case when StartTimeOfAdverseDriving is not null and StartTime >= StartTimeOfAdverseDriving
				then CAST(1 AS bit)
				else CAST(0 AS bit)
			end
		)
		, IsOversizedLoad
		, IsAdverseDriving
		, SecondRemainingOnDuty = 
			CASE WHEN IsInternalState = 1
				THEN (
					case 
						when StartTimeOfAdverseDriving is not null
							then CAST(((InterstateMaxOnDutyHours + 2) * 3600) - isnull(DailyOnDuty, 0) AS bigint)
						when StartTimeOf16HourRuleException is not null
							then CAST((InterstateMaxExemptionHours * 3600) - isnull(DailyOnDuty, 0) AS bigint)
						else CAST((InterstateMaxOnDutyHours * 3600) - isnull(DailyOnDuty, 0) AS bigint)
					end
				) 
				ELSE CAST(((IntrastateMaxOnDutyHours + (case when StartTimeOfAdverseDriving is not null then 2 else 0 end)) * 3600) - isnull(DailyOnDuty, 0) AS bigint)						
			END
		, TotalSecondOnDuty = 
			CASE WHEN IsInternalState = 1
				THEN (
					case 
						when StartTimeOfAdverseDriving is not null
							then (InterstateMaxOnDutyHours + 2) * 3600
						when StartTimeOf16HourRuleException is not null
							then InterstateMaxExemptionHours * 3600
						else InterstateMaxOnDutyHours * 3600
					end
				) 
				ELSE ((IntrastateMaxOnDutyHours + (case when StartTimeOfAdverseDriving is not null then 2 else 0 end)) * 3600) 				
			END
		, SecondRemainingDailyReset = 	
			CAST (
				case when LastEndTimeOn is not null
					then 
						(
							CASE WHEN IsInternalState = 1
								THEN (InterstateDailyResetHours * 3600) 
								ELSE (IntrastateDailyResetHours * 3600) 					
							END
						) -	DATEDIFF(SECOND, LastEndTimeOn, GETUTCDATE())
					else 0 
				end 			
			AS bigint)			
		, TotalSecondDailyReset = 
			CASE WHEN IsInternalState = 1
				THEN (InterstateDailyResetHours * 3600) 
				ELSE (IntrastateDailyResetHours * 3600) 					
			END
		, SecondRemainingDriving = 
			CASE WHEN IsInternalState = 1
				THEN CAST(((InterstateMaxDriveHours + (case when StartTimeOfAdverseDriving is not null then 2 else 0 end)) * 3600) - isnull(DailyDriving, 0) AS bigint)
				ELSE CAST(((IntrastateMaxDriveHours + (case when StartTimeOfAdverseDriving is not null then 2 else 0 end)) * 3600) - isnull(DailyDriving, 0) AS bigint)
			END
		, TotalSecondDriving = 
			(CASE WHEN IsInternalState = 1
				THEN ((InterstateMaxDriveHours + (case when StartTimeOfAdverseDriving is not null then 2 else 0 end)) * 3600) 
				ELSE ((IntrastateMaxDriveHours + (case when StartTimeOfAdverseDriving is not null then 2 else 0 end)) * 3600) 				
			END )			
		,SecondRemainingBreak = (
			SELECT -- top 1 CAST((8 * 3600) - DATEDIFF(SECOND, t1.Starttime, (case when zz.Keyword <> 'Driving_On_Duty' then isnull(zz.StartTime, GETUTCDATE() )  else GETUTCDATE() end) ) AS bigint) 
				top 1 CAST(
					(8 * 3600) - (
									select sum(datediff(SECOND, fedrd3.Starttime, isnull(fedrd3.Endtime, GETUTCDATE())))						
									FROM dbo.FMS_Elog_DailyReport_Detail fedrd3			
										INNER JOIN dbo.System_CommonList_Item scli3 ON scli3.ID = fedrd3.CommonList_ElogStatusTypeID											
									WHERE scli3.Keyword = 'Driving_On_Duty' 
										and fedrd3.ELD_EventRecordStatus = 1
										and fedrd3.StartTime >= t1.StartTime
										and fedrd3.FMS_Elog_DailyReportID = zz.FMS_Elog_DailyReportID
								)
					 AS bigint)
			FROM (
					SELECT ROW_NUMBER() OVER (ORDER BY StartTime desc) AS rownum,								
						StartTime, 
						EndTime
					FROM dbo.FMS_Elog_DailyReport_Detail fedrd2 			
						INNER JOIN dbo.System_CommonList_Item scli ON scli.ID = fedrd2.CommonList_ElogStatusTypeID											
					WHERE scli.Keyword = 'Driving_On_Duty' 
						and fedrd2.ELD_EventRecordStatus = 1
						and fedrd2.StartTime <> isnull(fedrd2.EndTime, getutcdate())
						and fedrd2.FMS_Elog_DailyReportID = zz.FMS_Elog_DailyReportID
				)t1
				LEFT JOIN (
					SELECT ROW_NUMBER() OVER (ORDER BY StartTime desc) AS rownum2,
							StartTime2 = StartTime, 
							EndTime2 = EndTime
					FROM dbo.FMS_Elog_DailyReport_Detail fedrd2 			
						INNER JOIN dbo.System_CommonList_Item scli ON scli.ID = fedrd2.CommonList_ElogStatusTypeID													
					WHERE scli.Keyword = 'Driving_On_Duty'
						and fedrd2.ELD_EventRecordStatus = 1
						and fedrd2.StartTime <> isnull(fedrd2.EndTime, getutcdate())
						and fedrd2.FMS_Elog_DailyReportID = zz.FMS_Elog_DailyReportID
				)t2 ON t1.rownum = t2.rownum2 - 1
			WHERE DATEDIFF(SECOND, t2.EndTime2, isnull(t1.StartTime, GETUTCDATE())) >= 1800
				OR t2.StartTime2 is null 	
			)		
		, TotalSecondBreak = (8 * 3600)
		, SecondRemainingBreakReset = 	
			CAST ( 
				case when LastEndTimeDriving is not null
					then (30 * 60) - DATEDIFF(SECOND, LastEndTimeDriving, GETUTCDATE())
					else 0 
				end 			
			AS bigint)	
		, SecondRemainingCycle =  
			case when StartTimeOfRolling is not null
				then (
					select (zz.InterstateMultiDayHours1 * 3600) - sum(datediff(s, fedrd2.StartTime, isnull(fedrd2.EndTime, getutcdate())))
						from dbo.FMS_Elog_DailyReport_Detail fedrd2
							INNER JOIN dbo.System_CommonList_Item scli2 ON scli2.ID = fedrd2.CommonList_ElogStatusTypeID
						where scli2.Keyword IN ('On_Duty', 'Driving_On_Duty', 'ELOG_SpecialStatus_YardMove') 
							and fedrd2.ELD_EventRecordStatus = 1
							and fedrd2.HR_EmployeeID = zz.HR_EmployeeID							
							-- get all logs which come from past 7th or 8th day to calculate remaining cycle time, it is greater than start of week 
							and fedrd2.StartTime >= StartTimeOfRolling
				)
				when IsInternalState = 1 then CAST((InterstateMultiDayHours1 * 3600) - isnull(WeeklyOnduty, 0)  AS bigint)
				else CAST((IntrastateMultiDayHours1 * 3600) - isnull(WeeklyOnduty, 0)  AS bigint)
			end			
		, IsApplyRollingCycle = 
			CASE WHEN StartTimeOfRolling is not null
				THEN CAST(1 AS bit)
				ELSE  CAST(0 AS bit)
			END
		, TotalSecondCycle = 
			CASE WHEN IsInternalState = 1
				THEN (InterstateMultiDayHours1 * 3600) 
				ELSE (IntrastateMultiDayHours1 * 3600) 					
			END
		, SecondRemainingWeeklyReset = 	
			CAST ( 
				case when LastEndTimeOn is not null
					then 
						(
							CASE WHEN IsInternalState = 1
								THEN (InterstateWeeklyResetHours * 3600) 
								ELSE (IntrastateWeeklyResetHours * 3600) 					
							END
						) -	DATEDIFF(SECOND, LastEndTimeOn, GETUTCDATE())
					else 0 
				end 			
			AS bigint)			
		, TotalSecondWeeklyReset = 
			CASE WHEN IsInternalState = 1
				THEN (InterstateWeeklyResetHours * 3600) 
				ELSE (IntrastateWeeklyResetHours * 3600) 					
			END
		
	from (
		SELECT *,	
			-- get all times before last ON point in a day 
			DailyOnDuty = (					
				SELECT SUM(DurationElog)
				FROM (	
					SELECT DurationElog = DATEDIFF(s, fedrd2.StartTime, isnull(fedrd2.EndTime, GETUTCDATE()))
					FROM dbo.FMS_Elog_DailyReport_Detail fedrd2		
					WHERE fedrd2.FMS_Elog_DailyReportID = t.FMS_Elog_DailyReportID
						and fedrd2.ELD_EventRecordStatus = 1	
						and fedrd2.StartTime >= t.StartTimeOfDay
						--and fedrd2.StartTime < (
						--							SELECT top 1 isnull(fedrd3.EndTime, GETUTCDATE())
						--							FROM dbo.FMS_Elog_DailyReport_Detail fedrd3			
						--								INNER JOIN dbo.System_CommonList_Item scli ON scli.ID = fedrd3.CommonList_ElogStatusTypeID											
						--							WHERE scli.Keyword IN ('On_Duty', 'Driving_On_Duty', 'ELOG_SpecialStatus_YardMove')
						--								and fedrd3.ELD_EventRecordStatus = 1	
						--								and fedrd3.FMS_Elog_DailyReportID = t.FMS_Elog_DailyReportID												
						--							ORDER BY fedrd3.StartTime desc
						--						)
				)aa				
			),
			DailyDriving = (
				select sum(datediff(s, fedrd2.StartTime, isnull(fedrd2.EndTime, GETUTCDATE())))
				from dbo.FMS_Elog_DailyReport_Detail fedrd2
					INNER JOIN dbo.System_CommonList_Item scli2 ON scli2.ID = fedrd2.CommonList_ElogStatusTypeID
				where fedrd2.FMS_Elog_DailyReportID = t.FMS_Elog_DailyReportID
					and fedrd2.ELD_EventRecordStatus = 1	
					and scli2.Keyword = 'Driving_On_Duty'
				Group by scli2.Keyword
			), 
			WeeklyOnduty = 	(
				select sum(DATEDIFF(s, fedrd2.StartTime, isnull(fedrd2.EndTime, GETUTCDATE())))
				from dbo.FMS_Elog_DailyReport_Detail fedrd2 
					INNER JOIN dbo.System_CommonList_Item scli2 ON scli2.ID = fedrd2.CommonList_ElogStatusTypeID	
				WHERE scli2.Keyword IN ('On_Duty', 'Driving_On_Duty', 'ELOG_SpecialStatus_YardMove') 
					and fedrd2.ELD_EventRecordStatus = 1	
					and fedrd2.HR_EmployeeID = t.HR_EmployeeID	
					and fedrd2.StartTime >= t.StartTimeOfWeek
				--select sum(cycle.CycleDuration)
				--from (
				--	SELECT CycleDuration = 
				--		DATEDIFF(s, t1.StartTime, isnull(t1.EndTime, GETUTCDATE())) 						
				--	FROM (
				--			SELECT ROW_NUMBER() OVER (ORDER BY StartTime asc) AS rownum,								
				--				StartTime, 
				--				EndTime
				--			FROM dbo.FMS_Elog_DailyReport_Detail fedrd2 			
				--				INNER JOIN dbo.System_CommonList_Item scli ON scli.ID = fedrd2.CommonList_ElogStatusTypeID											
				--			WHERE scli.Keyword IN ('On_Duty', 'Driving_On_Duty', 'ELOG_SpecialStatus_YardMove') 
				--				and fedrd2.ELD_EventRecordStatus = 1	
				--				and fedrd2.HR_EmployeeID = t.HR_EmployeeID						
				--				and fedrd2.StartTime >= 
				--					(
				--						case when exists (select 1 from dbo.FMS_Elog_DailyReport fedr3 where fedr3.HR_EmployeeID = t.HR_EmployeeID and fedr3.ID <> '00000000-0000-0000-0000-000000000000' and fedr3.IsWeeklyReset = 1 )
				--							then  (
				--									select top 1 fedr4.EndTime 
				--									from dbo.FMS_Elog_DailyReport fedr4 
				--									where fedr4.HR_EmployeeID = t.HR_EmployeeID  
				--										and fedr4.ID <> '00000000-0000-0000-0000-000000000000'
				--										and fedr4.IsWeeklyReset = 1
				--									order by fedr4.StartTime desc  
				--								)	
				--							else (select top 1 dateadd(minute,-1, fedr4.StartTime) from dbo.FMS_Elog_DailyReport fedr4 where fedr4.HR_EmployeeID = t.HR_EmployeeID and fedr4.ID <> '00000000-0000-0000-0000-000000000000' order by fedr4.StartTime asc) 
				--						end
				--					)		
				--		)t1
				--		LEFT JOIN (
				--			SELECT ROW_NUMBER() OVER (ORDER BY StartTime asc) AS rownum2,
				--					StartTime2 = StartTime, 
				--					EndTime2 = EndTime
				--			FROM dbo.FMS_Elog_DailyReport_Detail fedrd2 			
				--				INNER JOIN dbo.System_CommonList_Item scli ON scli.ID = fedrd2.CommonList_ElogStatusTypeID													
				--			WHERE scli.Keyword IN ('On_Duty', 'Driving_On_Duty', 'ELOG_SpecialStatus_YardMove') 
				--				and fedrd2.ELD_EventRecordStatus = 1
				--				and fedrd2.HR_EmployeeID = t.HR_EmployeeID
				--				and fedrd2.StartTime >=
				--					(
				--						case when exists (select 1 from dbo.FMS_Elog_DailyReport fedr3 where fedr3.HR_EmployeeID = t.HR_EmployeeID and fedr3.ID <> '00000000-0000-0000-0000-000000000000' and fedr3.IsWeeklyReset = 1 )
				--							then  (
				--									select top 1 fedr4.EndTime 
				--									from dbo.FMS_Elog_DailyReport fedr4 
				--									where fedr4.HR_EmployeeID = t.HR_EmployeeID  
				--										and fedr4.ID <> '00000000-0000-0000-0000-000000000000'
				--										and fedr4.IsWeeklyReset = 1
				--									order by fedr4.StartTime desc  
				--								)	
				--							else (select top 1 dateadd(minute,-1, fedr4.StartTime) from dbo.FMS_Elog_DailyReport fedr4 where fedr4.HR_EmployeeID = t.HR_EmployeeID and fedr4.ID <> '00000000-0000-0000-0000-000000000000' order by fedr4.StartTime asc) 
				--						end
				--					)		
				--		)t2 ON t1.rownum = t2.rownum2 - 1					
					
				--	) cycle
			
				),
			LastEndTimeOn = (
					case when t.Keyword in ('Off_Duty', 'In_Sleeper', 'ELOG_SpecialStatus_PersonalConveyance') 
						then (
							select top 1 fedrd2.EndTime
							from [dbo].[FMS_Elog_DailyReport_Detail] fedrd2 
								INNER JOIN dbo.System_CommonList_Item scli2 ON scli2.ID = fedrd2.CommonList_ElogStatusTypeID	
							where scli2.Keyword IN ('On_Duty', 'Driving_On_Duty', 'ELOG_SpecialStatus_YardMove') 
								and fedrd2.ELD_EventRecordStatus = 1
								and fedrd2.HR_EmployeeID = t.HR_EmployeeID
							order by fedrd2.StartTime desc
						)
						else NULL end					
				),
			LastEndTimeDriving = (
					case when t.Keyword <> 'Driving_On_Duty'
						then (
							select top 1 fedrd2.EndTime
							from [dbo].[FMS_Elog_DailyReport_Detail] fedrd2 
								INNER JOIN dbo.System_CommonList_Item scli2 ON scli2.ID = fedrd2.CommonList_ElogStatusTypeID	
							where scli2.Keyword = 'Driving_On_Duty'
								and fedrd2.ELD_EventRecordStatus = 1
								and fedrd2.HR_EmployeeID = t.HR_EmployeeID
							order by fedrd2.StartTime desc
						)
						else NULL end					
				),
			-- Rolling 7/8 days cycle: get all logs which come from past 7th or 8th day to calculate remaining cycle time, it is greater than start of week 
			StartTimeOfRolling = case when IsInternalState = 1
										 then (
											select top 1 StartTime 
											from (
												SELECT ROW_NUMBER() OVER (ORDER BY fedr3.StartTime desc) AS rownum,
													fedr3.StartTime--,
													--fedr.EndTime,
													--fedr.IsWeeklyReset	
												FROM dbo.FMS_Elog_DailyReport fedr3
												where fedr3.HR_EmployeeID = t.HR_EmployeeID
													and fedr3.StartTime >= t.StartTimeOfWeek
											)d
											where rownum = t.InterstateMultiDayDays1	
										)
									else null end,
			StartTimeOf16HourRuleException = (
				select top 1 fedr2.StartTime
				from dbo.FMS_Elog_DailyReport_Detail fedrd2	
					inner join dbo.FMS_Elog_DailyReport fedr2 on fedr2.ID = fedrd2.[FMS_Elog_DailyReportID]
				where fedrd2.HR_EmployeeID = t.HR_EmployeeID 
					and fedrd2.ELD_EventRecordStatus = 1	
					and fedrd2.Is16HourRuleException = 1
					and fedrd2.StartTime >= t.StartTimeOfDay
				order by fedrd2.StartTime desc
			),
			StartTimeOfAdverseDriving = (
				select top 1 fedr2.StartTime
				from dbo.FMS_Elog_DailyReport_Detail fedrd2	
					inner join dbo.FMS_Elog_DailyReport fedr2 on fedr2.ID = fedrd2.[FMS_Elog_DailyReportID]
				where fedrd2.HR_EmployeeID = t.HR_EmployeeID 
					and fedrd2.ELD_EventRecordStatus = 1	
					and fedrd2.IsAdverseDriving = 1
					and fedrd2.StartTime >= t.StartTimeOfDay
				order by fedrd2.StartTime desc
			)						
		FROM (
			SELECT top 1	
				fedrd.HR_EmployeeID,
				OSType = md.OSType,
				md.OSVersion,
				DeviceType = isnull(md.DeviceType, 'Unknown'), -- Smartphone, Black box (like Atrack, Squarell, GL505... devices), Bluetooth and Unknown			
				md.SoftwareVersion,
				MaximumSoftwareVersion = case when md.OSType = 'Android' and md.DeviceType = 'Smartphone' then @maxAndroidMobileAppVersion when md.OSType = 'iOS' and md.DeviceType = 'Smartphone' then @maxiOSMobileAppVersion else '' end,
				md.SerialNumber,
				-- 0: Not use, 1: working, 2: problem
				DeviceGPS = case when isnull(md.Latitude, 0) = 0 OR isnull(md.Longitude, 0) = 0 then 1 else 0 end, 				
				-- 0: Not use, 1: working, 2: problem
				DeviceBlueTooth = 0,				
				BatteryLevel = isnull(md.BatteryLevel, -1), 
				Keyword = scli.Keyword,		
				CurrentStatus = case 
							when scli.Keyword = 'On_Duty' then 'ON'--'On Duty (ON)' 
								when scli.Keyword = 'Driving_On_Duty' then 'D'--'Driving (D)' 
								when scli.Keyword = 'In_Sleeper' then 'SB'--'Sleeper Berth (SB)' 
								when scli.Keyword = 'Off_Duty' then 'OFF'--'Off Duty (OFF)' 
								when scli.Keyword = 'ELOG_SpecialStatus_PersonalConveyance' then 'PC'--'Personal Conveyance (PC)' 
								when scli.Keyword = 'ELOG_SpecialStatus_YardMove' then 'YM'--'Yard Move (YM)' 
								else '' 						
							end,
				EquipmentNumber = fe.Number,			
				StartTime = fedrd.StartTime,				 	
				TimeZone = isnull(al.TimeZone, 'Pacific Standard Time'),
				CurrentTime = GETUTCDATE(),
				CurrentDuration = cast(DATEDIFF(second, fedrd.StartTime, GETUTCDATE()) AS bigint),	
				StartTimeOfDay = (
						case when fedr.ID = '00000000-0000-0000-0000-000000000000'
						then (
							select top 1 fedrd2.StartTime 
							from dbo.FMS_Elog_DailyReport_Detail fedrd2 
							where fedrd2.HR_EmployeeID = he.ID 
								and fedrd2.ELD_EventRecordStatus = 1 
							order by fedrd2.StartTime asc)
						else fedr.StartTime end
					),
				StartTimeOfWeek = (
					case 
						when exists (
							select top 1 1
							from dbo.FMS_Elog_DailyReport fedr2 
							where fedr2.HR_EmployeeID = he.ID 
								and fedr2.IsWeeklyReset = 1 
								and fedr2.ID <> '00000000-0000-0000-0000-000000000000' 
							order by fedr2.StartTime desc
						)
						then (
							select top 1 fedr2.EndTime 
							from dbo.FMS_Elog_DailyReport fedr2 
							where fedr2.HR_EmployeeID = he.ID 
								and fedr2.IsWeeklyReset = 1 
								and fedr2.ID <> '00000000-0000-0000-0000-000000000000' 
							order by fedr2.StartTime desc
						) else (
							select top 1 fedrd3.StartTime 
							from dbo.FMS_Elog_DailyReport_Detail fedrd3 
							where fedrd3.HR_EmployeeID = he.ID 
								and fedrd3.ELD_EventRecordStatus = 1 
							order by fedrd3.StartTime asc
						)
					end	
				),			
				DistanceInKM = fedrd.DistanceInKM * 0.621371192,
				TotalDistanceInKM = (SELECT SUM(fedrd2.DistanceInKM) FROM dbo.FMS_Elog_DailyReport_Detail fedrd2 WHERE fedrd2.FMS_Elog_DailyReportID = fedr.ID and fedrd2.ELD_EventRecordStatus = 1	 GROUP BY fedrd2.FMS_Elog_DailyReportID) * 0.621371192,
				fedrd.FMS_Elog_DailyReportID,
				Duration = dbo.fn_GetDurationBySecond(DATEDIFF(second, fedrd.StartTime, GETUTCDATE())),
				DriverID = al.ID,	
				[Address] = mdces.Address + ' ' + mdces.City + ', ' + mdces.State + ' ' + mdces.PostalCode1,
				mdces.City,
				mdces.State,		
				-- calculate the hours remaining										
				IsInternalState = CASE WHEN 		
											fedrd.IsInterstateLoad = 1	
											OR (fedr.MotorCarrierID IS NOT NULL AND mdces.State <> fmc.State)		
											OR (												
													select count (*)
													from (
														select temp_state.State
														from (
															select mdce2.State
															from dbo.FMS_Elog_DailyReport_Detail fedrd2													
																INNER JOIN dbo.MCS_Device_EventSummary mdce2 ON mdce2.ID = fedrd2.MCS_EventSummaryID
															WHERE fedrd2.HR_EmployeeID = fedr.HR_EmployeeID
																AND fedrd2.ELD_EventRecordStatus = 1
																and mdce2.State is not null
																and fedrd2.StartTime between DATEADD(day, -7, fedrd.StartTime) and DATEADD(Second, 1, fedrd.StartTime)
															union all
															select fmc.State
														) temp_state
														group by temp_state.State
													) temp_state_count
												) > 1		
											THEN cast(1 AS BIT)
											ELSE cast(0 AS BIT) 
										END,			
				mdces.Latitude,
				mdces.Longitude,
				MotorCarrier = fmc.Address + ', ' + fmc.City + ', ' + fmc.State + ' ' + fmc.PostalCode,
				feh2.InterstateMaxOnDutyHours,
				feh2.IntrastateMaxOnDutyHours,			
				feh2.InterstateMultiDayHours1,
				feh2.IntrastateMultiDayHours1,	
				feh2.InterstateMultiDayDays1,
				feh2.IntrastateMultiDayDays1,
				feh2.InterstateMaxDriveHours,
				feh2.IntrastateMaxDriveHours,
				feh2.InterstateDailyResetHours,
				feh2.IntrastateDailyResetHours,
				feh2.InterstateWeeklyResetHours,
				feh2.IntrastateWeeklyResetHours,
				feh2.InterstateMaxExemptionHours,
				fedrd.Is16HourRuleException,
				fedrd.IsOversizedLoad,
				fedrd.IsAdverseDriving
			FROM 
				dbo.FMS_Elog_DailyReport_Detail fedrd 	
				INNER JOIN dbo.HR_Employee he ON he.ID = fedrd.HR_EmployeeID and he.IsActive = 1	
				INNER JOIN dbo.System_CommonList_Item scli ON scli.ID = fedrd.CommonList_ElogStatusTypeID
				INNER JOIN dbo.FMS_Elog_DailyReport fedr ON fedr.ID = fedrd.FMS_Elog_DailyReportID
				INNER JOIN dbo.FMS_Elog_HOSRule feh2 ON feh2.ID = fedr.FMS_Elog_HOSRuleID			
				LEFT JOIN dbo.MCS_Device_EventSummary mdces ON mdces.ID = fedrd.MCS_EventSummaryID
				LEFT JOIN dbo.MCS_Device md ON md.ID = mdces.MCS_DeviceID
				LEFT JOIN dbo.FMS_Equipment fe ON fe.ID = mdces.FMS_EquipmentID
				LEFT JOIN dbo.FMS_MotorCarrier fmc on fmc.ID = fedr.MotorCarrierID	
				-- account info		DSIMaster	
				INNER JOIN [dbo].[Master_Account_Login] al ON al.ID = he.Account_LoginID and isnull(al.IsDelete, 0) = 0 and al.IsActive = 1			
			where fedrd.HR_EmployeeID = @HR_EmployeeID
				and fedrd.ELD_EventRecordStatus = 1
				and fedrd.EndTime is null
			order by fedrd.StartTime desc
		) t			
		
	)zz
	

END



GO
