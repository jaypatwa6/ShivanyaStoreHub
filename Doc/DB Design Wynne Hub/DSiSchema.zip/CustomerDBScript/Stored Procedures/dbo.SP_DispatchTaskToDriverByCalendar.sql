SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[SP_DispatchTaskToDriverByCalendar] @TaskId UNIQUEIDENTIFIER, @UserId UNIQUEIDENTIFIER
AS
BEGIN
	-- GET DATA
	--table containts some common item which are most used
	DECLARE @cachedCommonItemTable TABLE (ID UNIQUEIDENTIFIER, Keyword NVARCHAR(MAX), Sequence INT);
	DECLARE @cachedCommonItemCursor CURSOR;
	SET @cachedCommonItemCursor = CURSOR FOR (SELECT ID, Keyword, Sequence FROM  [System_CommonList_Item] WHERE Keyword LIKE 'TMS_OrderItemStatus_%' OR Keyword LIKE 'TMS_Order_Type_%' OR Keyword LIKE 'TMS_Order_Status_%');
	DECLARE @id UNIQUEIDENTIFIER, @keyword NVARCHAR(MAX), @sequence INT;
	OPEN @cachedCommonItemCursor FETCH NEXT FROM @cachedCommonItemCursor INTO @id, @keyword, @sequence;
	WHILE @@FETCH_STATUS = 0
	BEGIN
		INSERT INTO @cachedCommonItemTable (ID, Keyword, Sequence) VALUES (@id, @keyword, @sequence);
		FETCH NEXT FROM @cachedCommonItemCursor INTO @id, @keyword, @sequence;
	END
	CLOSE @cachedCommonItemCursor;
	DEALLOCATE @cachedCommonItemCursor;
	
	DECLARE @pendingStatusId UNIQUEIDENTIFIER = (SELECT [ID] FROM @cachedCommonItemTable WHERE [Keyword] = 'TMS_OrderItemStatus_Pending');
	DECLARE @dispatchStatusId UNIQUEIDENTIFIER = (SELECT [ID] FROM @cachedCommonItemTable WHERE [Keyword] = 'TMS_OrderItemStatus_Dispatched');
	DECLARE @dispatchStatusSequence INT = (SELECT [Sequence] FROM @cachedCommonItemTable WHERE [Keyword] = 'TMS_OrderItemStatus_Dispatched');
	DECLARE @pickupTaskTypeId UNIQUEIDENTIFIER = (SELECT [ID] FROM @cachedCommonItemTable WHERE [Keyword] = 'TMS_Order_Type_Pickup');
	DECLARE @deliveryTaskTypeId UNIQUEIDENTIFIER = (SELECT [ID] FROM @cachedCommonItemTable WHERE [Keyword] = 'TMS_Order_Type_Delivery');
	
	BEGIN TRAN;

	DECLARE @orderId UNIQUEIDENTIFIER;
	DECLARE @newOrderStatusId UNIQUEIDENTIFIER;
	DECLARE @orderItemId UNIQUEIDENTIFIER;
	DECLARE @newOrderItemStatusId UNIQUEIDENTIFIER;
	DECLARE @taskTypeId UNIQUEIDENTIFIER;
	DECLARE @driverId UNIQUEIDENTIFIER;
	DECLARE @topStatusId UNIQUEIDENTIFIER;
	DEClARE @mcsTaskID UNIQUEIDENTIFIER;
	DECLARE @sequenceStatus INT

	--get new status of order and order item by task status is dispatched
	SELECT @newOrderStatusId = CommonList_TMS_Order_StatusId, @newOrderItemStatusId = CommonList_TMS_Order_Item_StatusId FROM TMS_Order_Event_StatusMapping WHERE CommonList_TMS_Order_Item_Task_StatusId = @dispatchStatusId;
	SELECT @taskTypeId = CommonList_TMSOrderItemTaskTypeId, @driverId = Driver_HR_EmployeeID FROM TMS_Order_Item_Task WHERE ID = @taskId;
	--UPDATE TMS TASK STATUS
	--change to dispatched
	INSERT INTO [TMS_Order_Event_Summary]
			(DateCreated, CreatedBy, DateModified, ModifiedBy, TMS_OrderId, TMS_Order_ItemId, TMS_Order_Item_TaskId,
			CommonList_TMSOrder_StatusId, CommonList_TMSOrder_Item_StatusId, CommonList_TMSOrder_Item_Task_StatusId, CommonList_TMSOrder_Item_Task_TypeId, MCS_Device_EventSummaryID)
			VALUES(GETUTCDATE(), @userId, GETUTCDATE(), @userId, @OrderId, @orderItemId, @taskId, @newOrderStatusId, @newOrderItemStatusId, @dispatchStatusId, @taskTypeId, NULL);

	--DISPATCH TASK
	SET @orderItemId = (SELECT TMS_Order_ItemID FROM TMS_Order_Item_Task WHERE ID = @TaskId);
	SET @orderId = (SELECT TMS_OrderID FROM TMS_Order_Item WHERE ID = @orderItemId);
	SET @topStatusId = (SELECT TOP 1 ([CommonList_TMSOrder_Item_Task_StatusId]) FROM [TMS_Order_Event_Summary] WHERE [TMS_Order_Item_TaskId] = @TaskId ORDER BY [DateCreated] DESC);
	SET @sequenceStatus = (SELECT Sequence FROM @cachedCommonItemTable WHERE ID = @topStatusId);
	IF (@sequenceStatus >= @dispatchStatusSequence)
	BEGIN
		--Status is CANCEL -> dispatch to cancel task
		IF (@sequenceStatus = (SELECT Sequence FROM @cachedCommonItemTable WHERE Keyword = 'TMS_OrderItemStatus_Canceled'))
		BEGIN
			EXEC SP_Calendar_DispatchCanceledTask @userId, @taskId;
		END
		--Status is completed -> dispatch to complete task
		IF (@sequenceStatus = (SELECT Sequence FROM @cachedCommonItemTable WHERE Keyword = 'TMS_OrderItemStatus_DeliveryComplete'))
			BEGIN
				EXEC SP_Calendar_DispatchCompletedTask @userId, @taskId;
			END
		--Otherwise dispatch new task
		IF (@driverId IS NOT NULL AND EXISTS (SELECT ID FROM MCS_Device WHERE HR_EmployeeID = @driverId AND IsActive = 1))
		BEGIN
			IF (@mcsTaskID IS NULL)
			--PROCESS NEW DISPATCH
			BEGIN
				EXEC SP_Calendar_DispatchNewTask @userId, @orderId, @orderItemId, @taskId;
			END
			ELSE -- @mcsTaskID IS NOT NULL
			BEGIN
				EXEC SP_Calendar_ReDispatchTask @userId, @orderId, @orderItemId, @taskId;
			END
		END
	END

	--UPDATE ORDER ITEM STATUS
	-- if all pickup and delivery task >= dispatched, order item => dispatched
	DECLARE @IsAllTaskDispatched AS BIT;
	EXEC SP_Calendar_CheckAllTaskIsDispatched @orderItemId, @IsAllTaskDispatched = @IsAllTaskDispatched OUTPUT;
	IF (@IsAllTaskDispatched = 1)
	BEGIN
		SELECT @newOrderStatusId = CommonList_TMS_Order_StatusId, @newOrderItemStatusId = CommonList_TMS_Order_Item_StatusId FROM TMS_Order_Event_StatusMapping WHERE CommonList_TMS_Order_Item_Task_StatusId = @dispatchStatusId;
		--change order item status to dispatch
		UPDATE [TMS_Order_Item] SET CommonList_TMSOrderItemStatusID = @dispatchStatusId, [DateModified] = GETUTCDATE(), ModifiedBy = @UserId
		WHERE [ID] = @orderItemId
		-- add record into TMS_Order_Event_Summary for this
		INSERT INTO [TMS_Order_Event_Summary]
		(DateCreated, CreatedBy, DateModified, ModifiedBy, TMS_OrderId, TMS_Order_ItemId, TMS_Order_Item_TaskId,
		CommonList_TMSOrder_StatusId, CommonList_TMSOrder_Item_StatusId, CommonList_TMSOrder_Item_Task_StatusId, CommonList_TMSOrder_Item_Task_TypeId, MCS_Device_EventSummaryID)
		VALUES(GETUTCDATE(), @userId, GETUTCDATE(), @userId, @OrderId, @orderItemId, @taskId, @newOrderStatusId, @dispatchStatusId, @dispatchStatusId, @taskTypeId, NULL);
	END
	ELSE--not all task >= dispatch, change to pending
	BEGIN
		SELECT @newOrderStatusId = CommonList_TMS_Order_StatusId, @newOrderItemStatusId = CommonList_TMS_Order_Item_StatusId FROM TMS_Order_Event_StatusMapping WHERE CommonList_TMS_Order_Item_Task_StatusId = @pendingStatusId;
		--change order item status to pending
		UPDATE [TMS_Order_Item] SET CommonList_TMSOrderItemStatusID = @pendingStatusId, [DateModified] = GETUTCDATE(), ModifiedBy = @UserId
		WHERE [ID] = @orderItemId
		-- add record into TMS_Order_Event_Summary for this
		INSERT INTO [TMS_Order_Event_Summary]
		(DateCreated, CreatedBy, DateModified, ModifiedBy, TMS_OrderId, TMS_Order_ItemId, TMS_Order_Item_TaskId,
		CommonList_TMSOrder_StatusId, CommonList_TMSOrder_Item_StatusId, CommonList_TMSOrder_Item_Task_StatusId, CommonList_TMSOrder_Item_Task_TypeId, MCS_Device_EventSummaryID)
		VALUES(GETUTCDATE(), @userId, GETUTCDATE(), @userId, @OrderId, @orderItemId, @taskId, @newOrderStatusId, @pendingStatusId, @dispatchStatusId, @taskTypeId, NULL);
	END

	--UPDATE ORDER STATUS
	DECLARE @orderItemCursor AS CURSOR, @orderItemStatusId AS UNIQUEIDENTIFIER, @orderStatusKeyword AS NVARCHAR(50) = 'TMS_Order_Status_Open',  @statusKeyword AS NVARCHAR(50);
	DECLARE @orderItemCount AS INT = 0, @orderInProgressCount AS INT = 0,@orderCompleteCount AS INT = 0,@orderCancelCount AS INT = 0, @orderOnHoldCount AS INT = 0, @orderCloseCount AS INT = 0;
	SET @orderItemCursor = CURSOR FOR (SELECT ID, CommonList_TMSOrderItemStatusID FROM  TMS_Order_Item WHERE TMS_OrderID = @OrderId);
	OPEN @orderItemCursor FETCH NEXT FROM @orderItemCursor INTO @orderItemId, @orderItemStatusId;
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @orderItemCount = @orderItemCount + 1;
		SELECT @statusKeyword = Keyword FROM @cachedCommonItemTable WHERE ID = @orderItemStatusId
		IF (@statusKeyword IN ('TMS_OrderItemStatus_OutForPickup','TMS_OrderItemStatus_AtPickup',
						'TMS_OrderItemStatus_PickupComplete','TMS_OrderItemStatus_OutForDelivery', 'TMS_OrderItemStatus_AtDelivery'))
		BEGIN
			SET @orderInProgressCount = @orderInProgressCount + 1;
		END
		IF (@statusKeyword  = 'TMS_OrderItemStatus_DeliveryComplete')
		BEGIN
			SET @orderCompleteCount = @orderCompleteCount + 1;
		END
		IF (@statusKeyword  = 'TMS_OrderItemStatus_Canceled')
		BEGIN
			SET @orderCancelCount = @orderCancelCount + 1;
		END
		IF (@statusKeyword  = 'TMS_OrderItemStatus_OnHold')
		BEGIN
			SET @orderOnHoldCount = @orderOnHoldCount + 1;
		END
		IF (@statusKeyword  = 'TMS_OrderItemStatus_Closed')
		BEGIN
			SET @orderCloseCount = @orderCloseCount + 1;
		END
		FETCH NEXT FROM @orderItemCursor INTO @orderItemId, @orderItemStatusId;
	END
	CLOSE @orderItemCursor;
	DEALLOCATE @orderItemCursor;
	IF (@orderItemCount = @orderCloseCount)
	BEGIN
		SET @orderStatusKeyword = 'TMS_Order_Status_Closed';
	END
	IF (@orderItemCount = @orderOnHoldCount)
	BEGIN
		SET @orderStatusKeyword = 'TMS_Order_Status_OnHold';
	END
	IF (@orderItemCount = @orderCancelCount)
	BEGIN
		SET @orderStatusKeyword = 'TMS_Order_Status_Canceled';
	END
	IF (@orderItemCount = @orderCompleteCount)
	BEGIN
		SET @orderStatusKeyword = 'TMS_Order_Status_Complete';
	END
	IF (@orderItemCount = @orderInProgressCount)
	BEGIN
		SET @orderStatusKeyword = 'TMS_Order_Status_InProgress';
	END
	SELECT @newOrderStatusId = ID FROM @cachedCommonItemTable WHERE Keyword = @orderStatusKeyword;
	
	UPDATE TMS_Order SET CommonList_TMSOrderStatusID = @newOrderStatusId WHERE ID = @OrderId;

	IF EXISTS(SELECT ID FROM HR_Employee WHERE Account_LoginId = @UserId)
	BEGIN
		UPDATE TMS_Order SET Dispatcher = (SELECT ID FROM HR_Employee WHERE Account_LoginID = @UserId) WHERE ID = @OrderId;
	END

	COMMIT TRAN;
END

GO
