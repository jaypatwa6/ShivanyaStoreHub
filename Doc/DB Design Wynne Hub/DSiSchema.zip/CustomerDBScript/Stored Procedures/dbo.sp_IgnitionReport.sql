SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- Author:		Huan Nguyen
-- Create date: 3/8/2016 8:50:28 PM
-- Edited date: 6/1/2016 8:30:00 AM	Not show duration <60s
-- Description: Igniton Report
-- =============================================
CREATE PROCEDURE [dbo].[sp_IgnitionReport]
 @startdate datetime,
 @enddate datetime,
 @timezone float,
 @browser_colName nvarchar(256),
 @browser_colValue nvarchar(max)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for procedure here
select a.EmployeeNumber,a.EquipmentNumber,IsIgnitionOn,a.Address
,DATEADD(hour, @timezone , DATEADD(SECOND,- a.durationinsecond, a.GPSTime)) as TimeStart
,DATEADD(hour, @timezone ,a.GPSTime) as TimeEnd,
[dbo].[fn_GetDurationBySecond](durationinsecond) as durationinsecond,
case when IsIgnitionOn = 'ON' then [dbo].[fn_GetDurationBySecond](Sum(CAST(durationinsecond AS BIGINT)) Over (Partition By EmployeeNumber,IsIgnitionOn))  
else [dbo].[fn_GetDurationBySecond](Sum(CAST(durationinsecond AS BIGINT)) Over (Partition By EmployeeNumber) - Sum(CAST(durationinsecond AS BIGINT)) Over (Partition By EmployeeNumber,IsIgnitionOn)) end EmployeeNumberTotalON,
case when IsIgnitionOn = 'OFF' then [dbo].[fn_GetDurationBySecond](Sum(CAST(durationinsecond AS BIGINT)) Over (Partition By EmployeeNumber,IsIgnitionOn))  
else [dbo].[fn_GetDurationBySecond](Sum(CAST(durationinsecond AS BIGINT)) Over (Partition By EmployeeNumber) - Sum(CAST(durationinsecond AS BIGINT)) Over (Partition By EmployeeNumber,IsIgnitionOn)) end EmployeeNumberTotalOFF,
case when IsIgnitionOn = 'ON' then [dbo].[fn_GetDurationBySecond](Sum(CAST(durationinsecond AS BIGINT)) Over (Partition By EmployeeNumber,EquipmentNumber,IsIgnitionOn))  
else [dbo].[fn_GetDurationBySecond](Sum(CAST(durationinsecond AS BIGINT)) Over (Partition By EmployeeNumber,EquipmentNumber) - Sum(CAST(durationinsecond AS BIGINT)) Over (Partition By EmployeeNumber,EquipmentNumber,IsIgnitionOn)) end EquipmentNumberTotalON,
case when IsIgnitionOn = 'OFF' then [dbo].[fn_GetDurationBySecond](Sum(CAST(durationinsecond AS BIGINT)) Over (Partition By EmployeeNumber,EquipmentNumber,IsIgnitionOn))  
else [dbo].[fn_GetDurationBySecond](Sum(CAST(durationinsecond AS BIGINT)) Over (Partition By EmployeeNumber,EquipmentNumber) - Sum(CAST(durationinsecond AS BIGINT)) Over (Partition By EmployeeNumber,EquipmentNumber,IsIgnitionOn)) end EquipmentNumberTotalOFF
	 from
(select  concat(HR_Employee.Number,' ',HR_Employee.FirstName,'',HR_Employee.LastName) as EmployeeNumber
,case  MCS_Device_EventSummary.IsIgnitionOn when 1 then 'OFF' when 0 then 'ON' end IsIgnitionOn
,case when mcs_device_eventsummary.gpstimestamp < @startdate then datediff(second,mcs_device_eventsummary.gpstimestamp,getutcdate()) 
else mcs_device_eventsummary.durationinsecond end durationinsecond
,concat(MCS_Device_EventSummary.Address,'',MCS_Device_EventSummary.City,',',MCS_Device_EventSummary.State) as Address
,MCS_Device_EventSummary.GpsTimeStamp as GPSTime
,isnull(FMS_Equipment.Number,'') as EquipmentNumber
from MCS_Device_EventSummary
join MCS_Device on MCS_Device.Id = MCS_Device_EventSummary.MCS_DeviceID   
join System_CommonList_Item on System_CommonList_Item.Id = MCS_Device_EventSummary.CommonList_DeviceSummaryEventID 
join HR_Employee on HR_Employee.Id = MCS_Device_EventSummary.HR_EmployeeID  
join FMS_Equipment on FMS_Equipment.Id = MCS_Device_EventSummary.FMS_EquipmentID  
 where MCS_Device_EventSummary.GpsTimeStamp between @startdate and @enddate 
 and  MCS_Device_EventSummary.DurationInSecond > 0 and  ( MCS_Device.DeviceModel in ('AX5','AX7','AT1','AX9','AK7','AK11' )) 
 and   ( System_CommonList_Item.Keyword = 'Ignition_Off'  or    System_CommonList_Item.Keyword = 'Ignition_On' )   
 or (  system_commonlist_item.keyword = 'ignition_off'   and  mcs_device_eventsummary.ignitionofftime<=@enddate   
 and mcs_device_eventsummary.ignitionofftime >= @startdate   and mcs_device.devicemodel in ('AX5','AX7','AT1','AX9','AK7','AK11')) 
 or (  system_commonlist_item.keyword = 'ignition_on'   and  mcs_device_eventsummary.ignitionofftime > @enddate   
 and mcs_device_eventsummary.ignitionontime < @enddate   and mcs_device.devicemodel in ('AX5','AX7','AT1','AX9','AK7','AK11')  ) or 
 (  system_commonlist_item.keyword = 'ignition_off'   and  mcs_device_eventsummary.ignitionofftime > @enddate   
 and mcs_device_eventsummary.ignitionontime < @enddate   and mcs_device.devicemodel in ('AX5','AX7','AT1','AX9','AK7','AK11')  ) or 
 (  system_commonlist_item.keyword = 'ignition_on'   and  mcs_device_eventsummary.ignitionofftime<=@enddate   
 and mcs_device_eventsummary.ignitionofftime >= @startdate   and mcs_device.devicemodel in ('AX5','AX7','AT1','AX9','AK7','AK11')  ) 
	 )
as a
WHERE CASE @browser_colName 
				WHEN 'EmployeeNumber' THEN EmployeeNumber
				WHEN 'EquipmentNumber' THEN EquipmentNumber
				WHEN 'IsIgnitionOn' THEN IsIgnitionOn
				ELSE ''
			END = @browser_colValue
	  AND a.durationinsecond >= 60
order by a.EmployeeNumber,a.EquipmentNumber,a.GPSTime
END


GO
