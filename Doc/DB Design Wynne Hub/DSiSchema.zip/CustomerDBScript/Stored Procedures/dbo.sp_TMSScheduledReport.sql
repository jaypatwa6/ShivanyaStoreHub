SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[sp_TMSScheduledReport]
    @startdate DATETIME,
    @enddate DATETIME,
    @timezone FLOAT,
    @browser_colName NVARCHAR(256),
    @browser_colValue NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH MarkedTasks AS (
        SELECT 
            t.TMS_Order_ItemID,
            t.ScheduledTime,
            t.Driver_HR_EmployeeID,
            t.Truck_FMS_EquipmentID,
            sci.Keyword,
            js.Name AS JobsiteName,
            js.City,
            js.State,
            ROW_NUMBER() OVER (PARTITION BY t.TMS_Order_ItemID ORDER BY t.ScheduledTime DESC) AS rn
        FROM dbo.TMS_Order_Item_Task t
        JOIN dbo.System_CommonList_Item sci ON sci.ID = t.CommonList_TMSOrderItemTaskTypeId
        LEFT JOIN dbo.CRM_Jobsite js ON js.ID = t.TaskLocation_CRM_JobsiteID
    ),
    TaskSummary AS (
        SELECT 
            mt.TMS_Order_ItemID,
            MAX(CASE WHEN mt.rn = 1 THEN mt.ScheduledTime END) AS LatestScheduledTime,
            MAX(CASE WHEN mt.rn = 1 THEN mt.Driver_HR_EmployeeID END) AS Driver_HR_EmployeeID,
            MAX(CASE WHEN mt.rn = 1 THEN mt.Truck_FMS_EquipmentID END) AS Truck_FMS_EquipmentID,

            MIN(CASE WHEN mt.Keyword = 'TMS_Order_Type_Pickup' 
                     THEN DATEADD(HOUR,@timezone,mt.ScheduledTime) END) AS PickupPromiseTime,
            MIN(CASE WHEN mt.Keyword = 'TMS_Order_Type_Delivery' 
                     THEN DATEADD(HOUR,@timezone,mt.ScheduledTime) END) AS DeliveryPromiseTime,

            MIN(CASE WHEN mt.Keyword = 'TMS_Order_Type_Pickup' 
                     THEN ISNULL(mt.JobsiteName,'') + ' ('+ISNULL(mt.City,'')+', '+ISNULL(mt.State,'')+')' END) AS OriginLocation,
            MIN(CASE WHEN mt.Keyword = 'TMS_Order_Type_Delivery' 
                     THEN ISNULL(mt.JobsiteName,'') + ' ('+ISNULL(mt.City,'')+', '+ISNULL(mt.State,'')+')' END) AS DestinationLocation
        FROM MarkedTasks mt
        GROUP BY mt.TMS_Order_ItemID
    ),
    DriverInfo AS (
        SELECT emp.ID AS EmployeeID,
               ISNULL(emp.FirstName,'') + ' ' + ISNULL(emp.LastName,'') AS Driver,
               dbo.fn_GetWeeklyHOS(emp.ID) AS HOS
        FROM dbo.HR_Employee emp
        JOIN dbo.System_CommonList_Item sci ON emp.CommonList_EmployeeTypeID = sci.ID
        WHERE sci.Keyword IN ('HR_EmployeeType_Driver','HR_EmployeeType_SubHauler')
    ),
    ItemCount AS (
        SELECT TMS_OrderID, COUNT(*) AS Cnt
        FROM dbo.TMS_Order_Item
        GROUP BY TMS_OrderID
    )
    SELECT 
        CONVERT(DATE, DATEADD(HOUR,@timezone, ts.LatestScheduledTime)) AS ScheduledDate,
        drv.Driver,
        ord.OrderNumber,
        item.OrderItemNumber,
        dbo.fn_GetDurationBySecond(drv.HOS * 60) AS HOS,
        ts.OriginLocation,
        ts.DestinationLocation,
        ts.PickupPromiseTime,
        ts.DeliveryPromiseTime,
        item.FreightDescription,
        item.Notes,
        ISNULL(cus.Name,'') AS CustomerName,
        ISNULL(equip.Number,'') AS EquipmentNumber,
        ISNULL(cusdata.StockNumber,'') AS StockNumber,
        ISNULL(cusdata.Make,'') AS Make,
        ISNULL(cusdata.Model,'') AS Model,
        ISNULL(cusdata.Machine,'') AS Machine,
        ISNULL(cusdata.PIN,'') AS Pin,
        org.Name AS Orgranization, -- keep typo
        CAST(SUM(ROUND(ord.EstimatedTripDistanceInKM * 0.621371192, 2) / NULLIF(ic.Cnt,0))
             OVER (PARTITION BY CONVERT(DATE, DATEADD(HOUR,@timezone, ts.LatestScheduledTime)), drv.Driver)
             AS DECIMAL(11,2)) AS EstimatedTripDistanceInMiles,
        dbo.fn_GetDurationBySecond(
            SUM(CAST(ord.EstimatedTripDurationInMin AS BIGINT) * 60) 
            OVER (PARTITION BY CONVERT(DATE, DATEADD(HOUR,@timezone, ts.LatestScheduledTime)), drv.Driver)
        ) AS EstimatedTripDurationInMinutes
    FROM dbo.TMS_Order_Item item
    JOIN dbo.TMS_Order ord ON ord.ID = item.TMS_OrderID
    JOIN TaskSummary ts ON ts.TMS_Order_ItemID = item.ID
    JOIN DriverInfo drv ON drv.EmployeeID = ts.Driver_HR_EmployeeID
    LEFT JOIN dbo.CRM_Customer cus ON cus.ID = ord.CRM_CustomerID
    LEFT JOIN dbo.FMS_Equipment equip ON equip.ID = ts.Truck_FMS_EquipmentID
    LEFT JOIN dbo.TMS_Order_Item_CustomData cusdata ON cusdata.TMS_Order_ItemID = item.ID
    LEFT JOIN dbo.System_Organization org ON ord.System_OrganizationID = org.ID
    LEFT JOIN ItemCount ic ON ic.TMS_OrderID = ord.ID
    WHERE 
        (
            (ts.PickupPromiseTime BETWEEN @startdate AND @enddate)
            OR (ts.DeliveryPromiseTime BETWEEN @startdate AND @enddate)
        )
        AND (
            @browser_colName = '' OR
            (@browser_colName = 'Driver' AND drv.Driver = @browser_colValue) OR
            (@browser_colName = 'OrderNumber' AND ord.OrderNumber = @browser_colValue) OR
            (@browser_colName = 'OrderItemNumber' AND item.OrderItemNumber = @browser_colValue) OR
            (@browser_colName = 'CustomerName' AND cus.Name = @browser_colValue) OR
            (@browser_colName = 'EquipmentNumber' AND equip.Number = @browser_colValue) OR
            (@browser_colName = 'StockNumber' AND cusdata.StockNumber = @browser_colValue) OR
            (@browser_colName = 'Make' AND cusdata.Make = @browser_colValue) OR
            (@browser_colName = 'Model' AND cusdata.Model = @browser_colValue) OR
            (@browser_colName = 'Machine' AND cusdata.Machine = @browser_colValue) OR
            (@browser_colName = 'Pin' AND cusdata.PIN = @browser_colValue) OR
            (@browser_colName = 'Orgranization' AND org.Name = @browser_colValue)
        )
    ORDER BY ScheduledDate, drv.Driver, ord.OrderNumber, item.OrderItemNumber;
END
GO
