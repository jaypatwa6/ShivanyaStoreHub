SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[SP_Calendar_CreateNewMcsTask](@userId AS UNIQUEIDENTIFIER, @mcsStopId AS UNIQUEIDENTIFIER, @orderId AS UNIQUEIDENTIFIER, @orderItemId AS UNIQUEIDENTIFIER, @tmsTaskId AS UNIQUEIDENTIFIER, @returnedMcsTaskId AS UNIQUEIDENTIFIER OUTPUT)
AS
BEGIN
	DECLARE @tmsTaskTypeId AS UNIQUEIDENTIFIER, @tmsTaskTypeKeyword AS NVARCHAR(50), @mcsTaskType AS NVARCHAR(50);
	SELECT @tmsTaskTypeId = CommonList_TMSOrderItemTaskTypeId FROM TMS_Order_Item_Task WHERE ID = @tmsTaskId;
	SELECT @tmsTaskTypeKeyword = keyword from System_CommonList_Item WHERE ID = @tmsTaskTypeId;
	IF (@tmsTaskTypeKeyword = 'TMS_Order_Type_Pickup')
	BEGIN
		SET @mcsTaskType = 'Pickup';
	END
	IF (@tmsTaskTypeKeyword = 'TMS_Order_Type_Delivery')
	BEGIN
		SET @mcsTaskType = 'Delivery';
	END
	
	DECLARE @documentNumbers AS NVARCHAR(1000);
	SET @documentNumbers = CONCAT('<data><CustomerBillOfLading /><CustomerJobNumber /><CustomerPO /><LoadBillOfLading /><TicketNumber /><OrderNumber>',
		(SELECT OrderNumber FROM TMS_Order WHERE ID = @orderId),'</OrderNumber><LoadNumber>',
		(SELECT OrderItemNumber FROM TMS_Order_Item WHERE ID = @orderItemId),'</LoadNumber></data>');
	DECLARE @note AS NVARCHAR(4000);

	SET @note = (SELECT CONCAT('Freight: ' , I.FreightDescription , ', Qty: ' , I.QuantityOrdered , ', Note: ', I.Notes, ', Stock#: ', C.StockNumber, ', Machine#: ', C.Machine, ', Make: ', C.Make, ', Model: ', C.Model, ', PIN: ', C.PIN) FROM TMS_Order_Item I JOIN TMS_Order_Item_CustomData C ON I.ID = C.TMS_Order_ItemID WHERE I.ID = @orderItemId);
	
	SET @returnedMcsTaskId = NEWID();--TODO Sequence
	INSERT INTO MCS_Trip_Stop_Task
	([Sequence],ID, DateSynchronized, DateCreated, CreatedBy, CommonList_TaskStatusID, CommonList_OrderTypeID, CommonList_OrderPriorityID, MCS_Trip_StopID, CRM_CustomerID, DateModified, ModifiedBy, Note, Acknowledge, DocumentNumbers)
	VALUES (
	0,@returnedMcsTaskId, GETUTCDATE() ,GETUTCDATE(), @userId, 
	(SELECT ID FROM System_CommonList_Item WHERE Keyword = 'NotStarted' AND System_CommonListID = (SELECT ID FROM System_CommonList WHERE Keyword = 'Dispatch_TaskStatus')), 
	(SELECT ID FROM System_CommonList_Item WHERE Keyword = @mcsTaskType AND System_CommonListID = (SELECT ID FROM System_CommonList WHERE Keyword = 'Dispatch_TaskType')), 
	(SELECT ID FROM System_CommonList_Item WHERE Keyword = 'Medium' AND System_CommonListID = (SELECT ID FROM System_CommonList WHERE Keyword = 'Sales_OrderPriority')),
	@mcsStopId, (SELECT CRM_CustomerID FROM TMS_Order WHERE ID = @orderId), GETUTCDATE(), @userId, @note, 0, @documentNumbers);
	
END

GO
