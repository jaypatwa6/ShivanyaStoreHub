SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [dbo].[sp_GetTableSchema] (@query NVARCHAR(MAX), @linked_server NVARCHAR(1000) = NULL)
AS
BEGIN	
	DECLARE @xml AS XML, @sqlQuery AS NVARCHAR(max)	

	IF (@linked_server is NULL)
		BEGIN
			EXEC ('CREATE VIEW myViewDatatype AS SELECT TOP 0 t.*  FROM (' + @query +') AS t')

			SELECT c.name AS Name, 
				CASE t.name
					WHEN 'uniqueidentifier' THEN 'Guid'
					WHEN 'bit'				THEN 'Boolean'
					WHEN 'int'				THEN 'Int'
					WHEN 'varchar'			THEN 'String'
					WHEN 'nvarchar'			THEN 'String'
					WHEN 'datetime'			THEN 'DateTime'
					WHEN 'decimal'			THEN 'Decimal'
					WHEN 'numeric'			THEN 'Decimal'
					WHEN 'xml'				THEN 'XML'					
				END AS DataType
			FROM sys.columns c JOIN sys.types t
			ON t.system_type_id = c.system_type_id AND
				t.system_type_id = t.user_type_id
			WHERE object_id = (SELECT OBJECT_ID('dbo.myViewDatatype', 'VIEW'))

			EXEC ('DROP VIEW myViewDatatype')
		END
	ELSE
		BEGIN
			DECLARE @open_query AS NVARCHAR(MAX)
			SET @open_query = 'SELECT * FROM OpenQuery ("' + @linked_server + '",''' + @query + ''')'

			EXEC ('CREATE VIEW myViewDatatype AS SELECT TOP 0 t.*  FROM (' + @open_query +') AS t')

			SELECT c.name AS Name, 
				CASE 
					WHEN c.name LIKE '%MEMBER_CAPTION%' THEN 'Dimension'
					WHEN c.name LIKE '%Measures%' THEN 'Measure'			
				ELSE ''
				END AS CubeType
			FROM sys.columns c
			WHERE object_id = (SELECT OBJECT_ID('dbo.myViewDatatype', 'VIEW'))

			EXEC ('DROP VIEW myViewDatatype')		
		END
END   




GO
