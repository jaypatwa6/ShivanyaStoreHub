SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
	
CREATE PROCEDURE [dbo].[SP_CheckRecordUsedByOtherTables]
		@TableName NVARCHAR(MAX)
		, @Id UNIQUEIDENTIFIER
	AS
	 begin
		SET NOCOUNT ON;

		DECLARE @Command NVARCHAR(MAX)
		DECLARE @Table NVARCHAR(MAX)
		DECLARE @Column NVARCHAR(MAX)
		DECLARE @RowCount NVARCHAR(MAX)

		SELECT 
			t.name as TableWithForeignKey,
			fk.constraint_column_id as FK_PartNo, 
			c.name as ForeignKeyColumn 
		INTO #TempForeignKeyTable
		FROM sys.foreign_key_columns as fk
		INNER JOIN sys.tables AS t ON fk.parent_object_id = t.object_id
		INNER JOIN sys.columns AS c ON fk.parent_object_id = c.object_id AND fk.parent_column_id = c.column_id
		WHERE fk.referenced_object_id = (SELECT object_id FROM sys.tables WHERE name = @TableName)
		ORDER BY TableWithForeignKey, FK_PartNo

		SELECT TOP 1 @Table = TableWithForeignKey FROM #TempForeignKeyTable
		SELECT TOP 1 @Column = ForeignKeyColumn FROM #TempForeignKeyTable

		SET @Command = 'SELECT ' + @Column + ' AS ForeignKeyValue FROM ' + @Table + ' WHERE ' + @Column + '=''' + CAST(@Id AS CHAR(36))+''''
		DELETE #TempForeignKeyTable WHERE TableWithForeignKey = @Table AND ForeignKeyColumn = @Column

		SELECT @RowCount = COUNT(*) FROM #TempForeignKeyTable
		WHILE @RowCount > 0
		BEGIN
			SELECT TOP 1 @Table = TableWithForeignKey FROM #TempForeignKeyTable
			SELECT TOP 1 @Column = ForeignKeyColumn FROM #TempForeignKeyTable
			SET @Command = @Command + ' UNION ALL SELECT ' + @Column + ' AS ForeignKeyValue FROM ' + @Table + ' WHERE ' + @Column + '=''' + CAST(@Id AS CHAR(36))+''''
			DELETE #TempForeignKeyTable WHERE TableWithForeignKey = @Table AND ForeignKeyColumn = @Column
			SELECT @RowCount = COUNT(*) FROM #TempForeignKeyTable
		END
		EXEC (@Command)
		DROP TABLE #TempForeignKeyTable
	END





GO
