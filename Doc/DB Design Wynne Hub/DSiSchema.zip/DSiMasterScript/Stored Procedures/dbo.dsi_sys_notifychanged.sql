SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[dsi_sys_notifychanged]
	-- Add the parameters for the stored procedure here
	@tableName nvarchar(150),
	@key bigint,
	@objectKey varchar(50),
	@data nvarchar(max),
	@modifiedDate datetime,
	@mode tinyint,
	@isTombstone bit,
	@result bigint output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	--create a tracking table if it not existed
	declare @sqlTable varchar(500)
	select @sqlTable = 'if not exists(select * from sysobjects where [name] = ''' + @tableName +'_tracking' + ''')
	begin
		CREATE TABLE [dbo].['+@tableName+'_tracking](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[UpdateKey] [timestamp] NOT NULL,
	[ObjectKey] [varchar](50) NULL,
	[IsTombstone] [bit] NULL,
	[DateModified] [datetime] NULL,
	[MetaData] [nvarchar](max) NULL,
 CONSTRAINT [PK_'+@tableName+'_tracking] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)
)
	end'
	exec (@sqlTable)
	
	declare @sql nvarchar(max)
	select @sql = '
	if(@mode = 2) --update
		begin
			declare @t table (myKey bigint)
			update '+@tableName+'_tracking set
			MetaData = @data,
			IsTombstone = @isTombstone,
			DateModified = @modifiedDate
			output inserted.UpdateKey into @t(myKey)
			where ObjectKey = @objectKey and UpdateKey = convert(bigint,convert(timestamp,@key))
			if(select count(*) from @t) = 0
			begin
				set @result = -1
			end
			else
			begin
				select @result = convert(bigint,myKey) from @t
			end
		end
		else if (@mode = 1)--insert
		begin
			declare @countExist int;
			select @countExist = count(*) from '+@tableName+'_tracking where ObjectKey = @objectKey
			if(@countExist = 0)
			begin
			insert into '+@tableName+'_tracking
			(ObjectKey,IsTombstone,DateModified,MetaData)
			values(@objectKey,0,@modifiedDate,@data)
			select @result = convert(bigint,UpdateKey) from '+@tableName+'_tracking where Id = @@identity
			end
			else
			begin
				set @result = -2
			end
		end'
	declare @trackingTableName nvarchar(150)
	declare @paramDefine nvarchar(max)
	set @trackingTableName = @tableName + '_tracking'
	set @paramDefine = N'@key bigint,@objectKey varchar(50),@data nvarchar(max),@modifiedDate datetime,@mode tinyint,@isTombstone bit,@result bigint output';
	execute sp_executesql @sql , @paramDefine,
	@key,
	@objectKey,
	@data,
	@modifiedDate,
	@mode,
	@isTombstone,
	@result output
	--print (@sql)
END
GO
