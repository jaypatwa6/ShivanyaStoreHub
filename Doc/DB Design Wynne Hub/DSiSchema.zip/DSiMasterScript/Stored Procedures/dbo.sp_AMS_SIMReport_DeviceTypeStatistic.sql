SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

-- =============================================
-- Author:		HIEU 
-- Create date: 03/18/2020
-- Description:	get data for drop-down list
-- =============================================
-- [sp_AMS_SIMReport_DeviceTypeStatistic] 53, '2020-01-01'
CREATE PROCEDURE [dbo].[sp_AMS_SIMReport_DeviceTypeStatistic]	
	@ProviderID int,
	@DateOfInvoice datetime
AS
BEGIN	
	select isnull(dt.ID, '00000000-0000-0000-0000-000000000000') as ID, isnull(dt.Name, 'N/A') as Name, count(*) as Count
	from  [dbo].[Data_DataAccount_VendorBills] b WITH (NOLOCK) 
		left join dbo.Data_DataAccount data WITH (NOLOCK)  on data.iccid = b.iccid
		left JOIN dbo.Data_DataProvider p  WITH (NOLOCK) ON p.id = data.Data_DataProviderID
		left join [dbo].[Asset_Device] d WITH (NOLOCK) on d.DataAccountID = data.id
		left join [dbo].[Asset_DeviceModel] dm WITH (NOLOCK) on dm.id = d.[DeviceModelID]
		left join [dbo].[Asset_DeviceType] dt WITH (NOLOCK) on dt.id = dm.DeviceTypeID
	where data.Data_DataProviderID = @ProviderID
		and b.DateOfInvoice = @DateOfInvoice
	group by dt.ID, dt.Name
	order by dt.Name
END

GO
