SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

-- =============================================
-- Author:		HIEU 
-- Create date: 03/18/2020
-- Description:	get data for drop-down list
-- [sp_AMS_SIMReport_GetEvents] @DbName='Cust_LandmarkImplementInc_11796_Prod', @MCS_DeviceID='8eff1b1b-d926-11e7-8125-00155db47805'
-- =============================================
CREATE PROCEDURE [dbo].[sp_AMS_SIMReport_GetEvents]	
	@DbName varchar(100),
	@MCS_DeviceID uniqueidentifier,	
	@FromDate datetime = null,
	@ToDate datetime = null,

	@Page bigint = 1,
	@PageSize bigint = 20,
	@OrderBy varchar(100) = 'GpsTimeStamp',
	@OrderDirection nvarchar(4) = 'desc'
AS
BEGIN	
	set nocount on;

	DECLARE @Filter NVARCHAR(MAX)	
	SET @Filter = ''	

	IF @FromDate is not null
	BEGIN
		set @FromDate = CAST(@FromDate AS date)
		set @ToDate = CAST(@ToDate AS date)
		SET @Filter = @Filter + ' AND dce.GpsTimeStamp between '''+ CONVERT(NVARCHAR(100),@FromDate) +''' and '''+ CONVERT(NVARCHAR(100),@ToDate) +''' '
	END

	DECLARE @TotalRecords BIGINT
	SET @TotalRecords = 0

	DECLARE @SQL2 NVARCHAR(MAX)
		SET @SQL2 =  'SET  @TotalRecords =(
		SELECT
			COUNT(*)				
		from ['+@DbName+'].[dbo].[MCS_Device_CommEvent] dce
			inner join ['+@DbName+'].[dbo].[System_CommonList_Item] cmi on cmi.ID = dce.[CommonList_DeviceEventTypeID]
		where 
			dce.MCS_DeviceID = '''+CONVERT(NVARCHAR(100),@MCS_DeviceID)+'''	
			'+@Filter+'				
	)'

	EXEC sp_executesql @SQL2, N'@TotalRecords BIGINT OUTPUT', @TotalRecords OUTPUT

	DECLARE @logsql NVARCHAR(MAX)
		SET @logsql = '
			SELECT *
			FROM (
				SELECT ROW_NUMBER() OVER (ORDER BY dce.GpsTimeStamp desc) AS RowNum,	
				cmi.KeyWord, 
				dce.GpsTimeStamp,
				dce.IsIgnitionOn,
				dce.DurationBetweenPingsInSecond,
				dce.OdometerInKM,
				dce.VelocityInKPH,
				dce.Address,
				dce.City,
				dce.State,
				dce.PostalCode1,
				dce.DistanceTraveledInKM,
				dce.IsMoving,	
				'+CONVERT(NVARCHAR(20),@TotalRecords)+' as TotalRecords			
			from ['+@DbName+'].[dbo].[MCS_Device_CommEvent] dce WITH (NOLOCK)
				inner join ['+@DbName+'].[dbo].[System_CommonList_Item] cmi WITH (NOLOCK) on cmi.ID = dce.[CommonList_DeviceEventTypeID]
			where 
				dce.MCS_DeviceID = '''+CONVERT(NVARCHAR(100),@MCS_DeviceID)+'''
				'+@Filter+'		
			) 
			AS s
			WHERE s.RowNum BETWEEN (('+CONVERT(NVARCHAR(20),@Page)+'-1)*'+CONVERT(NVARCHAR(20),@PageSize)+')+1 AND '+CONVERT(NVARCHAR(20),@PageSize)+'*('+CONVERT(NVARCHAR(20),@Page)+')
			'
	exec ( @logsql)

END

GO
