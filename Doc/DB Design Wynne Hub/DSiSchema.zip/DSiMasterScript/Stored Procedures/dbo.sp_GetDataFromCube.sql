SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO


CREATE PROCEDURE [dbo].[sp_GetDataFromCube] (@mdx_query AS VARCHAR(MAX), @linked_server AS VARCHAR(1000))
AS
BEGIN
	DECLARE @open_query AS NVARCHAR(MAX)
	SET @open_query = 'SELECT * FROM OpenQuery ("' + @linked_server + '",''' + @mdx_query + ''')'

	EXEC (@open_query)	
END



GO
