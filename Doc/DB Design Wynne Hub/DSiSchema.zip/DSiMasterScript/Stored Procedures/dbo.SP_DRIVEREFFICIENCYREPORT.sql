SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_DRIVEREFFICIENCYREPORT]
 @startdate datetime,
 @enddate datetime 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for procedure here
	select	Number,EmployeeName,dbo.fn_GetDurationBySecond(TotalDrivingHours/NumDay) as AvgDailyDrivingHours, CAST(CAST(((TotalDrivingHours /60/60) /NumDay/ruledriving ) * 100  as decimal(8,1))as varchar(25)) + '%' as PercentMaxDriving,
		dbo.fn_GetDurationBySecond(TotalOndutyAndDrivingHours/NumDay) as AvgDailyOndutyDrivingHours,CAST(CAST(((TotalOndutyAndDrivingHours/60/60)/NumDay/ruleOnduty) * 100 as decimal(8,1))as varchar(25)) + '%' as PercentMaxOnduty,
		dbo.fn_GetDurationBySecond(TotalDrivingHours) as TotalDrivingHours, dbo.fn_GetDurationBySecond(TotalOndutyAndDrivingHours) as TotalOndutyAndDrivingHours
from (
	select  
	   employee.Number, concat(employee.FirstName, ' ', employee.LastName) as EmployeeName,
			 (select (Sum(modifiedOnduty.TotalInTicks) * POWER(10.00000000000,-7)) as DailyDriving 
				from [dbo].[FMS_Elog_Modify] as modifiedOnduty
					left join [dbo].[FMS_Elog_Header] as headerOnduty on headerOnduty.Id = modifiedOnduty.FMS_Elog_HeaderID
					left join [dbo].[HR_Employee] as employeeOnduty on employeeOnduty.Id = headerOnduty.HR_EmployeeId
				where modifiedOnduty.StartDate  between @startdate and @enddate and employeeOnduty.Number = employee.Number and modifiedOnduty.CommonList_ElogStatusTypeID = 'C61AE70D-9F4A-E311-9814-AC7289D9AC41' 
				group by employeeOnduty.Number) as TotalDrivingHours,
			(select (Sum(modifiedOnduty.TotalInTicks) * POWER(10.00000000000,-7)) as DailyDriving 
				from [dbo].[FMS_Elog_Modify] as modifiedOnduty
					left join [dbo].[FMS_Elog_Header] as headerOnduty on headerOnduty.Id = modifiedOnduty.FMS_Elog_HeaderID
					left join [dbo].[HR_Employee] as employeeOnduty on employeeOnduty.Id = headerOnduty.HR_EmployeeId
				where modifiedOnduty.StartDate  between @startdate and @enddate 
					and employeeOnduty.Number = employee.Number and (modifiedOnduty.CommonList_ElogStatusTypeID = 'C61AE70D-9F4A-E311-9814-AC7289D9AC41' 
					or modifiedOnduty.CommonList_ElogStatusTypeID = 'C51AE70D-9F4A-E311-9814-AC7289D9AC41')
				group by employeeOnduty.Number) as TotalOndutyAndDrivingHours,
			DATEDIFF(DAY,@startdate ,  @enddate) as NumDay,
			IIF((select count(*) 
				from [dbo].[FMS_Elog_Modify] as modified1 
					left join [dbo].[FMS_Elog_Header] as header1 on header1.Id = modified1.FMS_Elog_HeaderID
					left join [dbo].[HR_Employee] as employee1 on employee1.Id = header1.HR_EmployeeId
					left join [dbo].[MCS_Device_CommEvent] as commenvent on commenvent.Id = modified1.MCS_Device_CommEventID
					left join [dbo].[FMS_Equipment] as equipment on equipment.Id = commenvent.FMS_EquipmentID
					left join [dbo].[FMS_MotorCarrier] as motor on motor.Id = equipment.FMS_MotorCarrierID
				where modified1.StartDate <= @enddate  and modified1.StartDate >= DATEADD(day, -8, @enddate)
				and iif(motor.[State] = commenvent.[State],0,1) = 0 and employee1.Number = employee.Number) = 0,elogRule.IntrastateMaxDriveHours , elogRule.InterstateMaxDriveHours + 2) as ruledriving,
			IIF((select count(*) 
				from [dbo].[FMS_Elog_Modify] as modified1 
					left join [dbo].[FMS_Elog_Header] as header1 on header1.Id = modified1.FMS_Elog_HeaderID
					left join [dbo].[HR_Employee] as employee1 on employee1.Id = header1.HR_EmployeeId
					left join [dbo].[MCS_Device_CommEvent] as commenvent on commenvent.Id = modified1.MCS_Device_CommEventID
					left join [dbo].[FMS_Equipment] as equipment on equipment.Id = commenvent.FMS_EquipmentID
					left join [dbo].[FMS_MotorCarrier] as motor on motor.Id = equipment.FMS_MotorCarrierID
				where modified1.StartDate <= @enddate  and modified1.StartDate >= DATEADD(day, -8, @enddate)  
				and iif(motor.[State] = commenvent.[State],0,1) = 0 and employee1.Number = employee.Number) = 0,elogRule.IntrastateMaxOnDutyHours , elogRule.InterstateMaxOnDutyHours + 2) as ruleOnduty
	from [dbo].[FMS_Elog_Modify] as modified
	left join [dbo].[FMS_Elog_Header] as header on header.Id = modified.FMS_Elog_HeaderID
	left join [dbo].[HR_Employee] as employee on employee.Id = header.HR_EmployeeId
	left join [dbo].[FMS_Elog_HOSRule] as elogRule on elogRule.Id = header.FMS_Elog_HOSRuleID
	where modified.StartDate between @startdate and @enddate
	Group by  employee.Number ,employee.FirstName,employee.LastName, 
	elogRule.IntrastateMaxDriveHours , elogRule.InterstateMaxDriveHours,elogRule.IntrastateMaxOnDutyHours , elogRule.InterstateMaxOnDutyHours
	
) as newtable
Order by Number
END

GO
