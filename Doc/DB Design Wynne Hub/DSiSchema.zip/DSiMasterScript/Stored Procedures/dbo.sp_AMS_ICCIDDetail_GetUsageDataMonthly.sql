SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

-- =============================================
-- Author:		HIEU 
-- Create date: 04/14/2020
-- Description:	
-- [sp_AMS_ICCIDDetail_GetUsageDataMonthly] @ICCID='89011703278126725137'
-- =============================================
CREATE PROCEDURE [dbo].[sp_AMS_ICCIDDetail_GetUsageDataMonthly]	
	@ICCID varchar(50)
AS
BEGIN	
	set nocount on;	

	select b.DateOfInvoice,
		b.DataUsageInMB,
		b.InvoiceNumber,
		b.PlanName
	from [dbo].[Data_DataAccount_VendorBills] b
	where ICCID = @ICCID
	order by DateOfInvoice desc


END
GO
