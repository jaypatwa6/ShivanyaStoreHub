SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

-- =============================================
-- Author:		HIEU 
-- Create date: 03/18/2020
-- Description:	get data for drop-down list
-- =============================================
-- sp_AMS_SIMReport_GetVendorBills @ProviderID=53, @DateOfInvoice='2020-02-01', @PageSize=111111
CREATE PROCEDURE [dbo].[sp_AMS_SIMReport_GetVendorBills]	
	@ProviderID int,
	@DateOfInvoice datetime,
	@ActiveStatus int = null,
	@DataUsageLevel int = null, -- 1: 0MB, 2: <= 2MB, 3: > 2MB
	@DataUsageInMB int = 2,
	@Account_TypeID uniqueidentifier = null,
	@DeviceTypeID uniqueidentifier = null,
	@TextSearch nvarchar(200) = null,	
	@Page bigint = 1,
	@PageSize bigint = 20,
	@OrderBy varchar(100) = 'DataUsageInMB',
	@OrderDirection nvarchar(4) = 'desc'
AS
BEGIN	
	set nocount on;

	declare @TotalRecords bigint
	SET  @TotalRecords =(
		SELECT count(b.ICCID)
		from [dbo].[Data_DataAccount_VendorBills] b WITH (NOLOCK) 
			left join dbo.Data_DataAccount data WITH (NOLOCK)  on data.iccid = b.iccid and data.IsActive = 1
			left JOIN dbo.Data_DataProvider p  WITH (NOLOCK) ON p.id = data.Data_DataProviderID and p.IsActive = 1
			left join [dbo].[Asset_Device] d WITH (NOLOCK) on d.DataAccountID = data.id
			left join [dbo].[Asset_DeviceModel] dm WITH (NOLOCK) on dm.id = d.[DeviceModelID] and dm.IsActive = 1			
			left join [dbo].[Asset_DeviceType] dt WITH (NOLOCK) on dt.id = dm.DeviceTypeID
			left join [dbo].[Account] a WITH (NOLOCK) on a.id = d.accountid
			left join [dbo].[Account_Type] ate WITH (NOLOCK) on ate.id = a.[Account_TypeID]
		WHERE data.Data_DataProviderID = @ProviderID 
			and b.DateOfInvoice = @DateOfInvoice
			and (
				@ActiveStatus is null 
				or (
					(@ActiveStatus = 0 and data.IsActive is null) 
					or (@ActiveStatus = 1 and data.IsActive = 0)
					or (@ActiveStatus = 2 and data.IsActive = 1)
				)
			)
			and (
				@DataUsageLevel is null 
				or (
					(@DataUsageLevel = 0 and b.[DataUsageInMB] = 0) 
					or (@DataUsageLevel = 1 and b.[DataUsageInMB] > 0 and b.[DataUsageInMB] <= @DataUsageInMB)
					or (@DataUsageLevel = 2 and b.[DataUsageInMB] > @DataUsageInMB)
				)
			)
			and (@Account_TypeID is null or isnull(a.[Account_TypeID], '00000000-0000-0000-0000-000000000000') = @Account_TypeID)
			and (@DeviceTypeID is null or isnull(dm.DeviceTypeID, '00000000-0000-0000-0000-000000000000') = @DeviceTypeID)
			and ((@TextSearch is null or @TextSearch = '') or ( 
					b.ICCID like '%'+@TextSearch+'%'
					or b.InvoiceNumber like '%'+@TextSearch+'%'
					or a.[AccountName] like '%'+@TextSearch+'%'
					or d.SerialNumber like '%'+@TextSearch+'%'	
				)				
			)
	)


	SELECT *
	FROM (
		SELECT ROW_NUMBER() OVER (ORDER BY 
									case @OrderDirection 
										when 'desc' then
											case @OrderBy 
												when 'DataUsageInMB' then b.[DataUsageInMB]		
												when 'AccountName' then a.[AccountName]		
												when 'GPSTime' then d.[GPSTime]		
												when 'IsActive' then d.IsActive																				
											end
										end desc,
									case @OrderDirection
										when 'asc' then
											case @OrderBy 
												when 'DataUsageInMB' then b.[DataUsageInMB] 											
												when 'AccountName' then a.[AccountName]		
												when 'GPSTime' then d.[GPSTime]		
												when 'IsActive' then d.IsActive																				
											end
										end asc									  
									)  AS RowNum,	
			b.ICCID, 
		p.Name as ProviderName,
		b.[InvoiceNumber],
		b.[DateOfInvoice],
		b.[DataUsageInMB],  
		(select top 1 b1.[DataUsageInMB] from [dbo].[Data_DataAccount_VendorBills] b1 WITH (NOLOCK) where b1.iccid = b.iccid and convert(varchar(7), b1.DateOfInvoice, 126) = convert(varchar(7), dateadd(month, -1, @DateOfInvoice), 126)) as DataUsageInMB1,
		(select top 1 b1.[DataUsageInMB] from [dbo].[Data_DataAccount_VendorBills] b1 WITH (NOLOCK) where b1.iccid = b.iccid and convert(varchar(7), b1.DateOfInvoice, 126) = convert(varchar(7), dateadd(month, -2, @DateOfInvoice), 126)) as DataUsageInMB2,
		(select top 1 f1.[VersionName] from [dbo].[Asset_DeviceModel_DeviceFirmware] f1 WITH (NOLOCK) where f1.DeviceModelID = dm.id order by f1.DateCreated desc) as FirmwareVersion,
		a.[AccountName],
		a.DatabaseName,
		ate.Name as AccountType,
		d.SerialNumber,
		data.PhoneNumber,
		d.ID as AssetDeviceID,
		dt.Name as DeviceType,
		data.IsActive,
		d.[GPSTime],
		d.[GPSOnlyLastCommTime],
		@TotalRecords as TotalRecords
	from [dbo].[Data_DataAccount_VendorBills] b WITH (NOLOCK) 
		left join dbo.Data_DataAccount data WITH (NOLOCK)  on data.iccid = b.iccid
		left JOIN dbo.Data_DataProvider p  WITH (NOLOCK) ON p.id = data.Data_DataProviderID
		left join [dbo].[Asset_Device] d WITH (NOLOCK) on d.DataAccountID = data.id
		left join [dbo].[Asset_DeviceModel] dm WITH (NOLOCK) on dm.id = d.[DeviceModelID]
		left join [dbo].[Asset_DeviceType] dt WITH (NOLOCK) on dt.id = dm.DeviceTypeID
		left join [dbo].[Account] a WITH (NOLOCK) on a.id = d.accountid
		left join [dbo].[Account_Type] ate WITH (NOLOCK) on ate.id = a.[Account_TypeID]
	WHERE data.Data_DataProviderID = @ProviderID 
		and b.DateOfInvoice = @DateOfInvoice		
		and (
			@ActiveStatus is null 
			or (
				(@ActiveStatus = 0 and data.IsActive is null) 
				or (@ActiveStatus = 1 and data.IsActive = 0)
				or (@ActiveStatus = 2 and data.IsActive = 1)
			)
		)
		and (
			@DataUsageLevel is null 
			or (
				(@DataUsageLevel = 0 and b.[DataUsageInMB] = 0) 
				or (@DataUsageLevel = 1 and b.[DataUsageInMB] > 0 and b.[DataUsageInMB] <= @DataUsageInMB)
				or (@DataUsageLevel = 2 and b.[DataUsageInMB] > @DataUsageInMB)
			)
		)
		and (@Account_TypeID is null or isnull(a.[Account_TypeID], '00000000-0000-0000-0000-000000000000') = @Account_TypeID)
		and (@DeviceTypeID is null or isnull(dm.DeviceTypeID, '00000000-0000-0000-0000-000000000000') = @DeviceTypeID)
		and ((@TextSearch is null or @TextSearch = '') or ( 
					b.ICCID like '%'+@TextSearch+'%'
					or b.InvoiceNumber like '%'+@TextSearch+'%'
					or a.[AccountName] like '%'+@TextSearch+'%'
					or d.SerialNumber like '%'+@TextSearch+'%'	
				)				
			)
	) AS s
	WHERE s.RowNum BETWEEN ((@Page-1)*@PageSize)+1 AND @PageSize*(@Page)	


	--set nocount on;
	
	--DECLARE @Filter NVARCHAR(MAX)	
	--SET @Filter = ''

	--SET @Filter = ' data.Data_DataProviderID = '''+CONVERT(NVARCHAR(20),@ProviderID )+''' '
	--SET @Filter = @Filter + ' AND b.DateOfInvoice = '''+CONVERT(NVARCHAR(20),@DateOfInvoice)+''' '

	--IF @ActiveStatus = 0
	--	SET @Filter = @Filter + ' AND d.IsActive is null '
	--ELSE IF @ActiveStatus = 1
	--	SET @Filter = @Filter + ' AND d.IsActive = 0 '
	--ELSE IF @ActiveStatus = 2
	--	SET @Filter = @Filter + ' AND d.IsActive = 1 '

	--IF @DataUsageLevel = 0
	--	SET @Filter = @Filter + ' AND b.[DataUsageInMB] = 0 '
	--ELSE IF @DataUsageLevel = 1
	--	SET @Filter = @Filter + ' AND (b.[DataUsageInMB] > 0 and b.[DataUsageInMB] <= 2) '
	--ELSE IF @DataUsageLevel = 2
	--	SET @Filter = @Filter + ' AND b.[DataUsageInMB] > 2 '

	--IF @Account_TypeID <> null
	--	SET @Filter = @Filter + ' AND isnull(a.[Account_TypeID], ''00000000-0000-0000-0000-000000000000'') = '''+CONVERT(NVARCHAR(20),@Account_TypeID)+''' '

	--IF @DeviceTypeID <> null
	--	SET @Filter = @Filter + ' AND isnull(dm.DeviceTypeID, ''00000000-0000-0000-0000-000000000000'') = '''+CONVERT(NVARCHAR(20),@DeviceTypeID)+''' '

	
	--DECLARE @TotalRecords BIGINT
	--SET @TotalRecords = 0

	--DECLARE @SQL2 NVARCHAR(MAX)
	--	SET @SQL2 =  'SET  @TotalRecords =(
	--		SELECT count(b.ICCID)
	--		from [dbo].[Data_DataAccount_VendorBills] b WITH (NOLOCK) 
	--			left join dbo.Data_DataAccount data WITH (NOLOCK)  on data.iccid = b.iccid
	--			left JOIN dbo.Data_DataProvider p  WITH (NOLOCK) ON p.id = data.Data_DataProviderID
	--			left join [dbo].[Asset_Device] d WITH (NOLOCK) on d.DataAccountID = data.id
	--			left join [dbo].[Asset_DeviceModel] dm WITH (NOLOCK) on dm.id = d.[DeviceModelID]
	--			left join [dbo].[Asset_DeviceType] dt WITH (NOLOCK) on dt.id = dm.DeviceTypeID
	--			left join [dbo].[Account] a WITH (NOLOCK) on a.id = d.accountid
	--			left join [dbo].[Account_Type] ate WITH (NOLOCK) on ate.id = a.[Account_TypeID]
	--		WHERE '+@Filter+'
	--	)'

	--EXEC sp_executesql @SQL2, N'@TotalRecords BIGINT OUTPUT', @TotalRecords OUTPUT

	--DECLARE @logsql NVARCHAR(MAX)
	--	SET @logsql = '
	--		SELECT top 1 *
	--		FROM (
	--			SELECT ROW_NUMBER() OVER (ORDER BY '+(
	--					case when @OrderBy = 'DataUsageInMB' then 'b.[DataUsageInMB]'
	--						when @OrderBy = 'AccountName' then 'a.[AccountName]	'
	--						when @OrderBy = 'GPSTime' then 'd.[GPSTime]'
	--						when @OrderBy = 'IsActive' then 'd.IsActive'
	--						else 'b.[DataUsageInMB]' 
	--					end
	--				)+' '+CONVERT(NVARCHAR(20),@OrderDirection)+')  AS RowNum,	
	--				b.ICCID, 
	--				p.Name as ProviderName,
	--				b.[InvoiceNumber],
	--				b.[DateOfInvoice],
	--				b.[DataUsageInMB],  
	--				(select top 1 b1.[DataUsageInMB] from [dbo].[Data_DataAccount_VendorBills] b1 where b1.iccid = b.iccid and convert(varchar(7), b1.DateOfInvoice, 126) = convert(varchar(7), dateadd(month, -1, '''+CONVERT(NVARCHAR(20),@DateOfInvoice)+'''), 126)) as DataUsageInMB1,
	--				(select top 1 b1.[DataUsageInMB] from [dbo].[Data_DataAccount_VendorBills] b1 where b1.iccid = b.iccid and convert(varchar(7), b1.DateOfInvoice, 126) = convert(varchar(7), dateadd(month, -2, '''+CONVERT(NVARCHAR(20),@DateOfInvoice)+'''), 126)) as DataUsageInMB2,
	--				a.[AccountName],
	--				a.DatabaseName,
	--				ate.Name as AccountType,
	--				d.SerialNumber,
	--				d.ID as AssetDeviceID,
	--				dt.Name as DeviceType,
	--				d.IsActive,
	--				d.[GPSTime],
	--				d.[GPSOnlyLastCommTime],
	--				'+CONVERT(NVARCHAR(20),@TotalRecords)+' as TotalRecords
	--			from [dbo].[Data_DataAccount_VendorBills] b WITH (NOLOCK) 
	--				left join dbo.Data_DataAccount data WITH (NOLOCK)  on data.iccid = b.iccid
	--				left JOIN dbo.Data_DataProvider p  WITH (NOLOCK) ON p.id = data.Data_DataProviderID
	--				left join [dbo].[Asset_Device] d WITH (NOLOCK) on d.DataAccountID = data.id
	--				left join [dbo].[Asset_DeviceModel] dm WITH (NOLOCK) on dm.id = d.[DeviceModelID]
	--				left join [dbo].[Asset_DeviceType] dt WITH (NOLOCK) on dt.id = dm.DeviceTypeID
	--				left join [dbo].[Account] a WITH (NOLOCK) on a.id = d.accountid
	--				left join [dbo].[Account_Type] ate WITH (NOLOCK) on ate.id = a.[Account_TypeID]
	--			WHERE '+@Filter+'
	--			) AS s
	--			WHERE s.RowNum BETWEEN (('+CONVERT(NVARCHAR(20),@Page)+'-1)*'+CONVERT(NVARCHAR(20),@PageSize)+')+1 AND '+CONVERT(NVARCHAR(20),@PageSize)+'*('+CONVERT(NVARCHAR(20),@Page)+')	

	--		'

		
	--exec ( @logsql)	
	

END

GO
