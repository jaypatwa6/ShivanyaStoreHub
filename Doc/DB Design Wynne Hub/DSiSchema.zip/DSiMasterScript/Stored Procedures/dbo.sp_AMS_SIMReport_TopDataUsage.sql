SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

-- =============================================
-- Author:		HIEU 
-- Create date: 03/18/2020
-- Description:	get data for drop-down list
-- =============================================
CREATE PROCEDURE [dbo].[sp_AMS_SIMReport_TopDataUsage]	
	@ProviderID int,
	@DateOfInvoice datetime
AS
BEGIN	
	select top 50 b.ICCID, b.DataUsageInMB
	from  [dbo].[Data_DataAccount_VendorBills] b WITH (NOLOCK) 	
		left join dbo.Data_DataAccount data WITH (NOLOCK)  on data.iccid = b.iccid
	where data.Data_DataProviderID = @ProviderID
		and b.DateOfInvoice = @DateOfInvoice
	order by b.[DataUsageInMB] desc

END

GO
