SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

-- =============================================
-- Author:		HIEU 
-- Create date: 04/14/2020
-- Description:	
-- [sp_AMS_ICCIDDetail_GetRelatedDeviceInfo] @DbName='Cust_LandmarkImplementInc_11796_Prod', @MCS_DeviceID='8eff1b1b-d926-11e7-8125-00155db47805'
-- =============================================
CREATE PROCEDURE [dbo].[sp_AMS_ICCIDDetail_GetRelatedDeviceInfo]	
	@DbName varchar(100),
	@MCS_DeviceID uniqueidentifier
AS
BEGIN	
	set nocount on;	

	DECLARE @logsql NVARCHAR(MAX)
		SET @logsql = '
			select 
				em.FirstName + '' '' + em.LastName as EmployeeName,
				eq.[Name] as EquipmentName
			from ['+@DbName+'].[dbo].[MCS_Device] d WITH (NOLOCK)
				left join ['+@DbName+'].[dbo].[HR_Employee] em WITH (NOLOCK) on em.ID = d.[HR_EmployeeID]
				left join ['+@DbName+'].[dbo].[FMS_Equipment] eq WITH (NOLOCK) on eq.ID = d.[FMS_EquipmentID]
			where 
				d.ID = '''+CONVERT(NVARCHAR(100),@MCS_DeviceID)+'''
			
		'
	exec ( @logsql)
END
GO
