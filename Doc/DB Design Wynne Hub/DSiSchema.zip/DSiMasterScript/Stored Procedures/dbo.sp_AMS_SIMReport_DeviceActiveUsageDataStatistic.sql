SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

-- =============================================
-- Author:		HIEU 
-- Create date: 03/18/2020
-- Description:	get data for drop-down list
-- =============================================
-- [sp_AMS_SIMReport_DeviceActiveUsageDataStatistic] 53, '2020-01-01'
CREATE PROCEDURE [dbo].[sp_AMS_SIMReport_DeviceActiveUsageDataStatistic]	
	@ProviderID int,
	@DateOfInvoice datetime,
	@DataUsageInMB int = 2
AS
BEGIN	
	select 
		-- COUNT(case when data.IsActive is null then 1 end) as NoDevice,
		COUNT(case when isnull(d.IsActive, 0) = 0 then 1 end) as InActiveDevice,
		COUNT(case when d.IsActive = 1 then 1 end) as ActiveDevice,
		COUNT(case when b.[DataUsageInMB] = 0 then 1 end) as UnuseData,
		COUNT(case when b.[DataUsageInMB] > 0 and b.[DataUsageInMB] <= @DataUsageInMB then 1 end) as NormalData,
		COUNT(case when b.[DataUsageInMB] > @DataUsageInMB then 1 end) as BigData
	from [dbo].[Data_DataAccount_VendorBills] b  WITH (NOLOCK)
		left join dbo.Data_DataAccount data WITH (NOLOCK) on data.iccid = b.iccid	
		left join [dbo].[Asset_Device] d WITH (NOLOCK) on d.DataAccountID = data.id	
	where data.Data_DataProviderID = @ProviderID
		and b.DateOfInvoice = @DateOfInvoice
END

GO
