SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

-- =============================================
-- Author:		HIEU 
-- Create date: 03/18/2020
-- Description:	get data for drop-down list
-- =============================================
CREATE PROCEDURE [dbo].[sp_AMS_SIMReport_GetProviderAndInvoiceDate]	
AS
BEGIN
	select p.ID, p.Name as ProviderName, b.DateOfInvoice 
	from [dbo].[Data_DataAccount_VendorBills] b WITH (NOLOCK) 
		inner join dbo.Data_DataAccount data  WITH (NOLOCK)  on data.iccid = b.iccid
		inner JOIN dbo.Data_DataProvider p  WITH (NOLOCK) ON p.id = data.Data_DataProviderID
	group by p.ID, p.Name, b.DateOfInvoice 
	order by p.Name, b.DateOfInvoice desc
END

GO
