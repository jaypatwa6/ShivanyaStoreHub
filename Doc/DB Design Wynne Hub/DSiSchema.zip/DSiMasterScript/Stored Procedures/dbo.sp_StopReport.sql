SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- =============================================
-- Author:		Huan Nguyen
-- Create date: 3/8/2016 8:50:28 PM
-- Edited date: 6/1/2016 8:30:00 AM	Not show duration <60s
-- Description: Stop Report
-- =============================================
CREATE PROCEDURE [dbo].[sp_StopReport]
 @startdate datetime,
 @enddate datetime,
 @timezone float,
 @browser_colName nvarchar(256),
 @browser_colValue nvarchar(max)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for procedure here
	select a.EmployeeNumber,a.EquipmentNumber,a.Address,DATEADD(hour, @timezone ,a.StoppedMovingTime) as StoppedMovingTime,[dbo].[fn_GetDurationBySecond](durationinsecond) as durationinsecond,
        [dbo].[fn_GetDurationBySecond](Sum(CAST(durationinsecond AS BIGINT))
            Over (Partition By EmployeeNumber)) As EmployeeNumberTotal,
       [dbo].[fn_GetDurationBySecond](Sum(durationinsecond) 
           Over (Partition By EmployeeNumber,EquipmentNumber)) As EquipmentNumberTotal   from
 (select concat(HR_Employee.Number,' ',HR_Employee.FirstName,'',HR_Employee.LastName) as EmployeeNumber,
	FMS_Equipment.Number as EquipmentNumber
	,MCS_Device_EventSummary.StoppedMovingTime as StoppedMovingTime
	,concat(MCS_Device_EventSummary.Address,'',MCS_Device_EventSummary.City,',',MCS_Device_EventSummary.State) as Address
	,case when system_commonlist_item.keyword = 'moving_end' 
	then datediff(second,mcs_device_eventsummary.stoppedmovingtime,getutcdate()) else mcs_device_eventsummary.durationinsecond end durationinsecond
	from MCS_Device_EventSummary 
	join MCS_Device on MCS_Device.Id = MCS_Device_EventSummary.MCS_DeviceID  
	join System_CommonList_Item on System_CommonList_Item.Id = MCS_Device_EventSummary.CommonList_DeviceSummaryEventID  
	left join HR_Employee on HR_Employee.Id = MCS_Device_EventSummary.HR_EmployeeID  
	left join FMS_Equipment on FMS_Equipment.Id = MCS_Device_EventSummary.FMS_EquipmentID  
	where 
	(
	MCS_Device_EventSummary.StoppedMovingTime between @startdate and @enddate 
	and  System_CommonList_Item.Keyword = 'STOP_END'  
	)
	--or (system_commonlist_item.keyword = 'moving_end' 
	--and  mcs_device_eventsummary.stoppedmovingtime between @startdate and @enddate 
	--and not exists (   select alias1.id  from mcs_device_eventsummary alias1  
	--where alias1.mcs_deviceid = mcs_device_eventsummary.mcs_deviceid  
	--and  alias1.startedmovingtime >mcs_device_eventsummary.stoppedmovingtime  
	--and alias1.startedmovingtime < @enddate and alias1.startedmovingtime > @startdate  ) 
	--and not exists (select alias2.id from mcs_device_eventsummary alias2 
	--where alias2.mcs_deviceid = mcs_device.id and alias2.startedmovingtime = mcs_device_eventsummary.stoppedmovingtime 
	--and alias2.startedmovingtime > @enddate) )
	or (system_commonlist_item.keyword = 'stop_end' and mcs_device_eventsummary.startedmovingtime > @enddate 
	and mcs_device_eventsummary.stoppedmovingtime > @startdate and mcs_device_eventsummary.stoppedmovingtime < @enddate)
	or (system_commonlist_item.keyword ='stop_end' and mcs_device_eventsummary.stoppedmovingtime < @startdate 
	and mcs_device_eventsummary.startedmovingtime > @enddate)
	) as a
	WHERE CASE @browser_colName 
				WHEN 'EmployeeNumber' THEN EmployeeNumber
				WHEN 'EquipmentNumber' THEN EquipmentNumber
				WHEN 'Address' THEN Address
				ELSE ''
			END = @browser_colValue
		  AND a.durationinsecond >= 60
	order by EmployeeNumber,EquipmentNumber,StoppedMovingTime
END

GO
