SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- =============================================
-- Author:		<Nguyen Hoai>
-- Create date: <Create Date,,>
-- Description:	<create violation elog for report writter 2>
-- =============================================
CREATE PROCEDURE [dbo].[sp_eLogViolationReport]
	-- Add the parameters for the stored procedure here
 @startdate datetime,
 @enddate datetime,
 @timezone float
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for procedure here
	    select	EmployeeName ,  DATEADD(hour,@timezone,StartDate) as StartDate , ViolationType, CityState, dbo.fn_GetDurationBySecond(totalTime) as Duration
 from(
 select	EmployeeName ,StartDate , CityState, totalTime,
        iif((select count(*)
		from [dbo].[FMS_Elog_Modify] as modifiedSub 
			left join [dbo].[FMS_Elog_Header] as headerSub on headerSub.Id = modifiedSub.FMS_Elog_HeaderID
			left join [dbo].[MCS_Device_CommEvent] as commenventSub on commenventSub.Id = modifiedSub.MCS_Device_CommEventID				
		where modifiedSub.StartDate <=   LastStartDateInHeader 
		and modifiedSub.StartDate >= (DATEADD(day, -8, LastStartDateInHeader))
		and HeaderSub.CreatedBy = HeaderCreatedby and HeaderSub.HR_EmployeeID = EmployeeId 	
		and (
		(iif(motorState is not null and LTRIM(motorState) != '', motorState  ,(select defaulMC.[state]  from FMS_MotorCarrier as defaulMC where isdefault = 1))  != commenventSub.[State]
		or commenventSub.[State] is null
		)
		or modifiedSub.IsInterstateLoad = 1					
			)
		) > 0,
		-- interstate		
		concat(
		IIF(((DrivingViolationTime is not null and Keyword = 'Driving_On_Duty') and (DrivingViolationTime <=  StartDate )) , IIF( WeeklyOnDutyViolationTime is not null , IIF(WeeklyOnDutyViolationTime > startdate, 'Driving, ','') ,IIF(RestBreakViolation is not null,'Driving, ', 'Driving')),'') ,
		IIF(dbo.fn_GetResetBreaksViolation(HeaderID,'C51AE70D-9F4A-E311-9814-AC7289D9AC41','C61AE70D-9F4A-E311-9814-AC7289D9AC41' ) like '%' + CONVERT(NVARCHAR(50), StartDate, 113) + '%'   ,IIF(WeeklyOnDutyViolation is not null, 'Rest break, ' ,'Rest break'),''),
		IIF((WeeklyOnDutyViolation is not null  and WeeklyOnDutyViolationTime <= startdate) , 'Multi Hour' , '')),
				
		-- Intrastate		
		concat(
		IIF(((DrivingViolationTime is not null and Keyword = 'Driving_On_Duty') and (DrivingViolationTime <=  StartDate)) , IIF( WeeklyOnDutyViolationTime is not null , IIF(WeeklyOnDutyViolationTime > startdate, 'Driving, ','') ,'Driving'),'') , 
		IIF((WeeklyOnDutyViolation is not null  and WeeklyOnDutyViolationTime <= startdate) , 'Multi Hour' , ''))
			) as ViolationType 
				from (
						SELECT concat(employee.FirstName, ', ', employee.LastName) as EmployeeName,
						modified.StartDate as StartDate,
						CAST(modified.TotalInTicks * POWER(10.00000000000,-7) AS int) AS DurationInSeconds, dbo.fn_GetDurationBySecond(CAST(modified.TotalInTicks * POWER(10.00000000000,-7) AS int)) AS Duration, 
						-- get last startdate of Header to check interstate and intrastate
						(select top 1 modifiedSub.StartDate FROM [FMS_Elog_Modify] AS modifiedSub
						right join [FMS_Elog_Header] AS headerSub on modifiedSub.FMS_Elog_HeaderID = headerSub.ID
						where headerSub.ID = header.ID 
						order by modifiedSub.StartDate desc 
						)  as LastStartDateInHeader,						
						(select top 1 modifiedSub.EndDate FROM [FMS_Elog_Modify] AS modifiedSub
						right join [FMS_Elog_Header] AS headerSub on modifiedSub.FMS_Elog_HeaderID = headerSub.ID
						where headerSub.ID = header.ID 
						order by modifiedSub.StartDate 
						)  as FirstStartDateInHeader
						, concat(comevent.City , IIF(comevent.City is null and comevent.State is null, '' , ', ') , comevent.[State]) AS CityState
						, header.CreatedBy as HeaderCreatedBy, employee.ID as employeeID, header.DrivingViolation as DrivingViolation
						, header.RestBreakViolation as RestBreakViolation, header.WeeklyOnDutyViolation as WeeklyOnDutyViolation, header.RestBreakViolationTime as RestBreakViolationTime , header.WeeklyOnDutyViolationTime as WeeklyOnDutyViolationTime
						, header.DrivingViolationTime as DrivingViolationTime
						, comlist.Keyword as Keyword
						, motor.[State] as motorState
						,  header.ID as HeaderID
						, (modified.TotalInTicks * POWER(10.00000000000,-7)) as totalTime	
							FROM [FMS_Elog_Modify] AS modified
							right join [FMS_Elog_Header] AS header on modified.FMS_Elog_HeaderID = header.ID
							left join [HR_Employee] AS employee on header.HR_EmployeeID = employee.ID
							left join [System_CommonList_Item] AS comlist on modified.CommonList_ElogStatusTypeID = comlist.ID
							left join [MCS_Device_CommEvent] AS comevent on modified.MCS_Device_CommEventID = comevent.ID
							left join [DSIMaster].[dbo].[Account_Login] AS account on employee.Account_LoginID = account.ID
							left join [dbo].[FMS_Equipment] as equipment on equipment.Id = comevent.FMS_EquipmentID
							left join [dbo].[FMS_MotorCarrier] as motor on motor.Id = equipment.FMS_MotorCarrierID
							where account.IsActive = 1 and employee.IsActive = 1 and
							((header.RestBreakViolation is not null and (comlist.Keyword = 'On_Duty' or comlist.Keyword = 'Driving_On_Duty') and header.RestBreakViolationTime <= modified.StartDate ) 
							 or (header.WeeklyOnDutyViolation is not null and header.WeeklyOnDutyViolationTime <= modified.startdate)
							 or (header.DrivingViolationTime is not null and (comlist.Keyword = 'Driving_On_Duty' or comlist.Keyword = 'On_Duty') and header.DrivingViolationTime <=  modified.StartDate ) )
							and modified.StartDate between @startdate and @enddate
				) as newtable 
) as newtable2
where ViolationType != ''  
Order by 	EmployeeName ,StartDate
END
GO
