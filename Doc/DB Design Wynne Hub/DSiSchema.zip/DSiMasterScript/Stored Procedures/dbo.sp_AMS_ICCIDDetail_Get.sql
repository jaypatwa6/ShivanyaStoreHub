SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

-- =============================================
-- Author:		HIEU 
-- Create date: 04/14/2020
-- Description:	
-- [sp_AMS_ICCIDDetail_Get] '89011703278126725137'
-- =============================================
CREATE PROCEDURE [dbo].[sp_AMS_ICCIDDetail_Get]	
	@ICCID varchar(50)
AS
BEGIN	
	set nocount on;

	select 
		data.ICCID, 
		p.Name as ProviderName,				
		(select top 1 f1.[VersionName] from [dbo].[Asset_DeviceModel_DeviceFirmware] f1 WITH (NOLOCK) where f1.DeviceModelID = dm.id order by f1.DateCreated desc) as FirmwareVersion,
		a.[AccountName],
		a.DatabaseName,
		ate.Name as AccountType,
		d.SerialNumber,
		data.PhoneNumber,
		d.ID as AssetDeviceID,
		dt.Name as DeviceType,
		data.IsActive,
		data.[DateActivation],
		d.[GPSTime],
		d.[GPSOnlyLastCommTime],
		d.[IMEI]

	from [dbo].[Data_DataAccount] data WITH (NOLOCK)
		left join [dbo].Data_DataProvider p  WITH (NOLOCK) ON p.id = data.Data_DataProviderID
		left join [dbo].[Asset_Device] d WITH (NOLOCK) on d.DataAccountID = data.id
		left join [dbo].[Asset_DeviceModel] dm WITH (NOLOCK) on dm.id = d.[DeviceModelID]
		left join [dbo].[Asset_DeviceType] dt WITH (NOLOCK) on dt.id = dm.DeviceTypeID
		left join [dbo].[Account] a WITH (NOLOCK) on a.id = d.accountid
		left join [dbo].[Account_Type] ate WITH (NOLOCK) on ate.id = a.[Account_TypeID]
	where data.ICCID = @ICCID

END

GO
