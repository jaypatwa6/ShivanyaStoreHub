SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



CREATE Function [dbo].[fn_DatabaseName]
(
    @AccountID as int
)
Returns varchar(max) 
AS
BEGIN
   
    declare @DBName as varchar(max) 
				
			set @DBName = (select name from sys.databases where name like '%' + cast(@AccountID as varchar(100)) + '%')
	           
    IF ISNULL(@DBName,'') = ''
	begin
		return ''
	end

    RETURN @DBName
END



GO
