SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE function [dbo].[fn_GetTruckNov1]
( 
	@DBName as nvarchar(1000),
	@DeviceRowID as NVarchar(100)
)
returns nvarchar(max)
with execute as caller
as begin
	
	declare @SQL as varchar(max) 
	DECLARE @Output as nvarchar(max)
	
	set @SQL = 'use ' + @DBName + ' select e.name AS Truck from [dbo].[mcs_device] d left join [dbo].[fms_equipment] e on e.id = d.FMS_EquipmentID where d.id = ''' + @DeviceRowID + ''''
	
	EXEC sp_executesql @SQL, N'@Output as nvarchar(max) output', @Output output

	--select @t=* from 

	--USE [@DBName]
	--select e.name AS Truck from [dbo].[mcs_device] d left join [dbo].[fms_equipment] e on e.id = d.FMS_EquipmentID where d.id =  @DeviceRowID
	
	return @Output
end


GO
