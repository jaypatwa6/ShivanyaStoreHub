SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



Create Function [dbo].[fn_GetAccountLastLoginDate]
	(
		@AccountID as int
	)
	Returns Datetime 
	AS
	BEGIN
	                
		
			declare @LastLogin as datetime
			
			set @LastLogin = (select max(DateTimeLastLoginSuccess) from Account_Login where AccountID = @AccountID)
		    
			
		RETURN @LastLogin
	END
GO
