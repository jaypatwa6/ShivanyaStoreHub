SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



CREATE Function [dbo].[fn_GetUsernameByID]
(
	@Account_LoginID as nvarchar(150)
)
Returns nvarchar(150) 
AS
BEGIN
	
	Declare @USERNAME nvarchar(150)
	

	
	if isnull(@Account_LoginID,'') = ''
	begin
		RETURN 'Account_LoginID is required.'
	end
	else
	begin
		  SET @USERNAME = (SELECT USERNAME FROM ACCOUNT_LOGIN WHERE ID = @Account_LoginID)
		
	END
		
		

	
	RETURN isnull(@USERNAME,'Username not found')
end



GO
