SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO




CREATE Function [dbo].[fn_GetTruckNo]
(
    @DBName as nvarchar(1000),
	@DeviceRowID as NVarchar(100)
)
Returns varchar(max) 
AS
BEGIN
   
   if isnull(@DBName,'') = ''
   begin
	return 'NO DB'
   end

	DECLARE @whole_no as varchar(150);
	declare @SQL as varchar(max) = 'use ' + @DBName + ' select @whole_noOUT=e.name from [dbo].[mcs_device] d left join [dbo].[fms_equipment] e on e.id = d.FMS_EquipmentID where d.id = ''' + @DeviceRowID + ''''
	DECLARE @Parms nvarchar(500);  
	SET @Parms = N'@whole_noOUT nvarchar(150) OUTPUT';

	EXECUTE sp_executesql @SQL, @Parms, @whole_noOUT=@whole_no OUTPUT;

	--print SELECT @whole_no;

	--exec sp_executesql @SQL, N'@truck',  out
	--select @TruckName
	--set @TruckName = select @TruckName
	--EXEC(@SQL) -- (select @TruckName = e.name from [@DBName].[dbo].[mcs_device] d left join [@DBName].[dbo].[fms_equipment] e on e.id = d.FMS_EquipmentID where d.id = @DeviceRowID)
	           
    IF ISNULL(@whole_no,'') = ''
	begin
		return 'Unassigned'
	end

    RETURN @whole_no
END




GO
