SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



CREATE Function [dbo].[fn_GetCustomerNameByUserID]
(
	@Account_LoginID as nvarchar(150)
)
Returns nvarchar(150) 
AS
BEGIN
	
	Declare @CutomerName nvarchar(150)
	

	
	if isnull(@Account_LoginID,'') = ''
	begin
		RETURN 'Account_LoginID is required.'
	end
	else
	begin
		  SET @CutomerName = (select top 1  a.accountname  from account_login l inner join account a on a.id = l.accountid where l.id = @Account_LoginID)
		
	END
		
		

	
	RETURN isnull(@CutomerName,'Customer name not found')
end



GO
