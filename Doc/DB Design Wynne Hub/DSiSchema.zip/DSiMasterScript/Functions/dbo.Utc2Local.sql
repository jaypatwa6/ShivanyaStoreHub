SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE FUNCTION [dbo].[Utc2Local]
(
-- Function Input Parameter
@UtcDateYouWantToConvert datetime
)
RETURNS DateTime

AS
BEGIN

DECLARE @UTCDate datetime
DECLARE @LocalDate datetime
DECLARE @TimeDiff INT

-- Figure out the time difference between UTC and Local time
SET @UTCDate = GETUTCDATE()
SET @LocalDate = GETDATE()
SET @TimeDiff = DATEDIFF(hh, @UTCDate, @LocalDate)

-- convert UTC to local DateTime
DECLARE @ConvertedLocalTime datetime

SET @ConvertedLocalTime = DATEADD(hh, @TimeDiff, @UtcDateYouWantToConvert)

-- return local DateTime
RETURN @ConvertedLocalTime

END

GO
