SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO





CREATE Function [dbo].[fn_GetPingCount]
(
    @DBName as nvarchar(1000),
	@DeviceRowID as NVarchar(100)
)
Returns varchar(max) 
AS
BEGIN
   
   if isnull(@DBName,'') = ''
   begin
	return 'NO DB'
   end

   declare @sql as nvarchar(max)
   declare @rowcount as int

   set @sql = 'select count(*) from Cust_AveryAveryInternational_11827_Prod.dbo.mcs_device_commEvent d1 where  d1.datecreated > getdate()-1 and d1.MCS_DeviceID = ''' + @DeviceRowID + ''' )'

	EXEC sp_executesql @sql
	set @rowcount = @@RowCount

	--print @rowcount 

    RETURN @rowcount
END





GO
