CREATE TABLE [dbo].[System_Package]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[Name] [nvarchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[InitialCost] [money] NOT NULL CONSTRAINT [DF__System_Pa__Initi__3F6663D5] DEFAULT ((0.00)),
[MonthlyCost] [money] NOT NULL CONSTRAINT [DF__System_Pa__Month__405A880E] DEFAULT ((0.00)),
[IsActive] [bit] NOT NULL CONSTRAINT [DF_System_Packages_IsActive] DEFAULT ((1)),
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__System_Pa__IsDel__4242D080] DEFAULT ((0)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__System_Pa__Creat__4336F4B9] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NULL,
[ModifiedBy] [uniqueidentifier] NULL,
[Version] [nvarchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL CONSTRAINT [DF_System_Packages_Version] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Package] ADD CONSTRAINT [PK_System_Packages] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
