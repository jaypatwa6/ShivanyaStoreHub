CREATE TABLE [dbo].[System_Module_License]
(
[id] [int] NOT NULL IDENTITY(1, 1),
[IsActive] [bit] NOT NULL CONSTRAINT [DF_System_Module_LicenseTypeList_IsActive] DEFAULT ((1)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_System_Module_LicenseTypeList_DateCreated] DEFAULT (getdate()),
[Name] [nvarchar] (400) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Description] [nvarchar] (400) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Keyword] [nvarchar] (400) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DefaultPurchasePrice] [money] NULL,
[DefaultMaintenancePrice] [money] NULL,
[DefaultSubscriptionPrice] [money] NULL,
[System_ModuleID] [uniqueidentifier] NULL,
[System_Module_LicenseType] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Module_License] ADD CONSTRAINT [PK_System_Module_LicenseTypeList] PRIMARY KEY CLUSTERED  ([id]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Module_License] ADD CONSTRAINT [FK_System_Module_LicenseTypeList__System_Module_X__ID] FOREIGN KEY ([System_ModuleID]) REFERENCES [dbo].[System_Module] ([ID])
GO
