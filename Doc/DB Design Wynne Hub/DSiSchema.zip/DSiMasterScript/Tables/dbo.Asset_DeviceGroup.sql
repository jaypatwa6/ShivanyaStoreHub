CREATE TABLE [dbo].[Asset_DeviceGroup]
(
[Id] [uniqueidentifier] NOT NULL CONSTRAINT [DF__Asset_Device__Id__04308F6E] DEFAULT (newsequentialid()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Asset_DeviceGroup_DateCreated] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NULL,
[DateModified] [datetime] NULL CONSTRAINT [DF_Asset_DeviceGroup_DateModified] DEFAULT (getutcdate())
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_DeviceGroup] ADD CONSTRAINT [PK__Asset_De__3214EC07B068CBC3] PRIMARY KEY CLUSTERED  ([Id]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
