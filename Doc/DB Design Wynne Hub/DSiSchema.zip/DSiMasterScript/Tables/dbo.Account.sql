CREATE TABLE [dbo].[Account]
(
[ID] [bigint] NOT NULL IDENTITY(1, 1),
[AccountName] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[SignupToken] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ProgressStatus] [int] NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Account_DateCreated] DEFAULT (getutcdate()),
[TokenExpiration] [datetime] NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__Account__DateMod__7306036C] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF__Account__IsActiv__73FA27A5] DEFAULT ((1)),
[Account_TypeID] [uniqueidentifier] NULL,
[Notes] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[GUID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__Account__GUID__3B8BB150] DEFAULT (newsequentialid()),
[GPSServer] [nvarchar] (150) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[GPSServerPort] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ConfigurationBatched] [bit] NOT NULL CONSTRAINT [DF_Account_ConfigurationBatched] DEFAULT ((0)),
[GPSServerInternalIP] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DatabaseName] [varchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Account] ADD CONSTRAINT [PK_Account] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Account__Account_TypeID] ON [dbo].[Account] ([Account_TypeID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Account__AccountName] ON [dbo].[Account] ([AccountName]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Account] ADD CONSTRAINT [FK_Account__Account_TypeID_X_Account_Type__ID] FOREIGN KEY ([Account_TypeID]) REFERENCES [dbo].[Account_Type] ([ID]) ON DELETE CASCADE
GO
GRANT SELECT ON  [dbo].[Account] TO [guest]
GO
