CREATE TABLE [dbo].[Account_Login_History]
(
[ID] [bigint] NOT NULL IDENTITY(1, 1),
[AccessTime] [datetime] NOT NULL,
[AccessDate] [date] NOT NULL,
[DeviceID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[UserID] [uniqueidentifier] NOT NULL,
[EmployeeId] [uniqueidentifier] NULL,
[ExtendData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Method] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsSuccess] [bit] NOT NULL,
[ServiceName] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[TotalTimeExecuted] [bigint] NOT NULL,
[TransferDataSize] [int] NOT NULL,
[Result] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Account_Login_History] ADD CONSTRAINT [PK_Account_Login_History] PRIMARY KEY NONCLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Account_Login_History] ADD CONSTRAINT [FK_Account_Login_History__UserID_X_Account_Login__ID] FOREIGN KEY ([UserID]) REFERENCES [dbo].[Account_Login] ([ID]) ON DELETE CASCADE
GO
