CREATE TABLE [dbo].[Account_Module_Subscription_History]
(
[id] [int] NOT NULL IDENTITY(1, 1),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Account_Module_Subscription_History_DateCreated] DEFAULT (getdate()),
[Account_Module_SubscriptionID] [int] NOT NULL,
[OldLicenseCountPurchased] [int] NULL,
[NewLicenseCountPurchased] [int] NULL,
[purchaseprice] [money] NULL,
[maintenanceprice] [money] NULL,
[subscriptionprice] [money] NULL,
[Notes] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[LicenseAuditCount] [int] NULL,
[LicenseAuditPerformedBy] [nvarchar] (400) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[LicenseAuditNotes] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[System_Module_LicenseID] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Account_Module_Subscription_History] ADD CONSTRAINT [PK_Account_Module_Subscription_History] PRIMARY KEY CLUSTERED  ([id]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Account_Module_Subscription_History] ADD CONSTRAINT [FK_Account_Module_Subscription_History__System_Module_LicenseType_X_ID] FOREIGN KEY ([System_Module_LicenseID]) REFERENCES [dbo].[System_Module_License] ([id])
GO
