CREATE TABLE [dbo].[Asset_DeviceType]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Asset_DeviceType_ID] DEFAULT (newsequentialid()),
[Name] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Asset_DeviceType_DateCreated] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NULL,
[DateModified] [datetime] NULL CONSTRAINT [DF_Asset_DeviceType_DateModified] DEFAULT (getutcdate()),
[Description] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_DeviceType] ADD CONSTRAINT [PK_Asset_DeviceType] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
