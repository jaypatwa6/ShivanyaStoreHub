CREATE TABLE [dbo].[System_PhoneType]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[Name] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DateCreated] [datetime] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_System_PhoneType_IsActive] DEFAULT ((1))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_PhoneType] ADD CONSTRAINT [PK_System_PhoneType] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_PhoneType] ADD CONSTRAINT [UQ_System_PhoneType] UNIQUE NONCLUSTERED  ([Name]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
