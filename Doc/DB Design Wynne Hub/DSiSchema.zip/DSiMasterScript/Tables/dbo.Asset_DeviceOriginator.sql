CREATE TABLE [dbo].[Asset_DeviceOriginator]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_asset_DeviceOriginator_ID] DEFAULT (newsequentialid()),
[Name] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ExtendedData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_asset_DeviceOriginator_DateCreated] DEFAULT (getdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_asset_DeviceOriginator_DateModified] DEFAULT (getdate())
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_DeviceOriginator] ADD CONSTRAINT [PK_asset_DeviceOriginator] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
