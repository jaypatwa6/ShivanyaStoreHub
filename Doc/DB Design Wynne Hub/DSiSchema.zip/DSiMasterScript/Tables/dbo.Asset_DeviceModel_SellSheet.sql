CREATE TABLE [dbo].[Asset_DeviceModel_SellSheet]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Asset_DeviceModel_SellSheet_ID] DEFAULT (newid()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL,
[ProductName] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ProductDescription] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ProductPicture] [nvarchar] (1024) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[RetailSellPrice] [money] NULL,
[RetailRentalPrice] [money] NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_Asset_DeviceModel_SellSheet_IsActive] DEFAULT ((0)),
[OtherDescription] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_DeviceModel_SellSheet] ADD CONSTRAINT [PK_Asset_DeviceModel_SellSheet] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
