CREATE TABLE [dbo].[Account_Address]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[AccountID] [bigint] NOT NULL,
[AddressTypeID] [uniqueidentifier] NULL,
[Address1] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Address2] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[City] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[State] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PostalCode] [nvarchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Account_Address_DateCreated] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_Account_Address_DateModified] DEFAULT (getutcdate()),
[IsActive] [bit] NOT NULL CONSTRAINT [DF_Customer_Address_IsActive] DEFAULT ((1)),
[System_List_CountriesID] [uniqueidentifier] NULL,
[Latitude] [decimal] (9, 6) NULL,
[Longitude] [decimal] (9, 6) NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Account_Address] ADD CONSTRAINT [PK_Account_Address] PRIMARY KEY NONCLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [IX_Account_Address__AccountID] ON [dbo].[Account_Address] ([AccountID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Account_Address__AddressTypeID] ON [dbo].[Account_Address] ([AddressTypeID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Account_Address__IsActive] ON [dbo].[Account_Address] ([IsActive]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Account_Address__System_List_CountriesID] ON [dbo].[Account_Address] ([System_List_CountriesID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Account_Address] ADD CONSTRAINT [FK_Account_Address__AccountID_X_Account__ID] FOREIGN KEY ([AccountID]) REFERENCES [dbo].[Account] ([ID]) ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Account_Address] ADD CONSTRAINT [FK_Account_Address__System_List_CountriesID_X_System_List_Countries__ID] FOREIGN KEY ([System_List_CountriesID]) REFERENCES [dbo].[System_List_Countries] ([ID])
GO
