CREATE TABLE [dbo].[System_SiteMenu_QuickLink]
(
[ID] [uniqueidentifier] NOT NULL,
[Account_LoginID] [uniqueidentifier] NOT NULL,
[System_SiteMenuID] [int] NOT NULL,
[DisplayOrder] [int] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_System_SiteMenu_QuickLink_DateCreated] DEFAULT (getdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_System_SiteMenu_QuickLink_DateModified] DEFAULT (getdate()),
[Current_SiteMenuID] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_SiteMenu_QuickLink] ADD CONSTRAINT [PK_System_SiteMenu_QuickLink] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_System_SiteMenu_QuickLink__Account_LoginID] ON [dbo].[System_SiteMenu_QuickLink] ([Account_LoginID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_System_SiteMenu_QuickLink__System_SiteMenuID] ON [dbo].[System_SiteMenu_QuickLink] ([System_SiteMenuID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_SiteMenu_QuickLink] ADD CONSTRAINT [FK_System_SiteMenu_QuickLink__Account_LoginID_x_Account_Login__ID] FOREIGN KEY ([Account_LoginID]) REFERENCES [dbo].[Account_Login] ([ID]) ON DELETE CASCADE
GO
ALTER TABLE [dbo].[System_SiteMenu_QuickLink] WITH NOCHECK ADD CONSTRAINT [FK_System_SiteMenu_QuickLink__Current_SiteMenuID_X_System_SiteMenu__ID] FOREIGN KEY ([Current_SiteMenuID]) REFERENCES [dbo].[System_SiteMenu] ([MenuId])
GO
ALTER TABLE [dbo].[System_SiteMenu_QuickLink] WITH NOCHECK ADD CONSTRAINT [FK_System_SiteMenu_QuickLink__System_SiteMenuID_X_System_SiteMenu__ID] FOREIGN KEY ([System_SiteMenuID]) REFERENCES [dbo].[System_SiteMenu] ([MenuId])
GO
