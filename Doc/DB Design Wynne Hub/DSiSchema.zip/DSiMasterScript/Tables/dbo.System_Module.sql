CREATE TABLE [dbo].[System_Module]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_System_Module_ID] DEFAULT (newsequentialid()),
[Name] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_System_Module_DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_System_Module_DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[Description] [nvarchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF__System_Mo__IsAct__2E06CDA9] DEFAULT ((1)),
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__System_Mo__IsDel__2EFAF1E2] DEFAULT ((0)),
[CurrentVersion] [int] NOT NULL CONSTRAINT [DF__System_Mo__Curre__1995C0A8] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Module] ADD CONSTRAINT [PK_System_Module] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Module] ADD CONSTRAINT [UQ_System_Module] UNIQUE NONCLUSTERED  ([Name]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
