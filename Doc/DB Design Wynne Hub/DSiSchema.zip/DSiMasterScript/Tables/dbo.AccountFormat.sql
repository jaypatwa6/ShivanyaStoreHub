CREATE TABLE [dbo].[AccountFormat]
(
[ID] [bigint] NOT NULL IDENTITY(1, 1),
[AccountSettingID] [bigint] NOT NULL,
[Language] [nvarchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CellphoneFormat] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PhoneFormat] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DateModified] [datetime] NULL CONSTRAINT [DF_AccountFormat_DateModified] DEFAULT (getutcdate()),
[IsActive] [bit] NULL,
[UserSettingID] [uniqueidentifier] NULL,
[AddressFormat] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[AccountFormat] ADD CONSTRAINT [PK_AccountFormat] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_AccountFormat__AccountSettingID] ON [dbo].[AccountFormat] ([AccountSettingID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_AccountFormat__IsActive] ON [dbo].[AccountFormat] ([IsActive]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_AccountFormat__UserSetting] ON [dbo].[AccountFormat] ([UserSettingID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[AccountFormat] ADD CONSTRAINT [FK_AccountFormat__AccountSettingID_X_Account_Setting__ID] FOREIGN KEY ([AccountSettingID]) REFERENCES [dbo].[Account_Setting] ([ID]) ON DELETE CASCADE
GO
