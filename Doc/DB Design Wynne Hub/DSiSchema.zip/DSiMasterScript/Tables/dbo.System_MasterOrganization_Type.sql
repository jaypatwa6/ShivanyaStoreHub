CREATE TABLE [dbo].[System_MasterOrganization_Type]
(
[Id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_System_MasterOrganization_Type_Id] DEFAULT (newsequentialid()),
[Name] [nvarchar] (150) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Level] [int] NULL,
[ParentId] [uniqueidentifier] NULL,
[Note] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsActive] [bit] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[CreatedDate] [datetime] NOT NULL,
[ModifiedBy] [uniqueidentifier] NULL,
[ModifiedDate] [datetime] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_MasterOrganization_Type] ADD CONSTRAINT [PK_System_MasterOrganization_Type] PRIMARY KEY CLUSTERED  ([Id]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_MasterOrganization_Type] ADD CONSTRAINT [FK_System_MasterOrganization_Type__ParentId_X_System_MasterOrganization_Type__Id] FOREIGN KEY ([ParentId]) REFERENCES [dbo].[System_MasterOrganization_Type] ([Id])
GO
