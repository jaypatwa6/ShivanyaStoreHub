CREATE TABLE [dbo].[System_Token]
(
[ID] [bigint] NOT NULL IDENTITY(1, 1),
[TableName] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DataKey] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[TokenValue] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[TokenExpireDate] [datetime] NOT NULL,
[DateCreated] [datetime] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NULL,
[ModifiedBy] [uniqueidentifier] NULL,
[IsDelete] [bit] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Token] ADD CONSTRAINT [PK_System_Token] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
