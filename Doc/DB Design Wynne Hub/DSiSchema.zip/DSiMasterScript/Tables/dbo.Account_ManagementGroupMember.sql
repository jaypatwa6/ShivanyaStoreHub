CREATE TABLE [dbo].[Account_ManagementGroupMember]
(
[ID] [bigint] NOT NULL IDENTITY(1, 1),
[ManagementGroupID] [bigint] NOT NULL,
[UserID] [uniqueidentifier] NOT NULL,
[IsAdminGroup] [bit] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Account_ManagementGroupMember] ADD CONSTRAINT [PK_Account_ManagementGroupMember] PRIMARY KEY NONCLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [IX_Account_ManagementGroupMember__UserID__ManagementGroupID] ON [dbo].[Account_ManagementGroupMember] ([ManagementGroupID], [UserID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Account_ManagementGroupMember__UserID] ON [dbo].[Account_ManagementGroupMember] ([UserID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Account_ManagementGroupMember] ADD CONSTRAINT [FK_AccountManagementGroupMember__ManagementGroupID_X_AccountManagementGroup__ID] FOREIGN KEY ([ManagementGroupID]) REFERENCES [dbo].[Account_ManagementGroup] ([ID]) ON DELETE CASCADE
GO
GRANT SELECT ON  [dbo].[Account_ManagementGroupMember] TO [guest]
GO
