CREATE TABLE [dbo].[Account_Login]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Account_Login_ID] DEFAULT (newsequentialid()),
[AccountID] [bigint] NOT NULL,
[IsActive] [bit] NOT NULL,
[UserName] [nvarchar] (150) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Password] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Hashkey] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[FailedLoginAttemptCount] [int] NULL CONSTRAINT [DF_Account_Login_FailedLoginAttemptCount] DEFAULT ((0)),
[Locked] [bit] NULL CONSTRAINT [DF_Account_Login_Locked] DEFAULT ((0)),
[XTimesConsecutiveLocked] [int] NULL CONSTRAINT [DF_Account_Login_XTimesConsecutiveLocked] DEFAULT ((0)),
[DateTimeAccountLocked] [datetime] NULL,
[DateTimeTempPasswordIssued] [datetime] NULL,
[DateTimeLastLoginAttempt] [datetime] NULL,
[IsDelete] [bit] NULL CONSTRAINT [df_IsDeleteAccountLogin] DEFAULT ((0)),
[DateTimeLastLoginSuccess] [datetime] NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__Account_L__DateC__74EE4BDE] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__Account_L__DateM__75E27017] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[FirstName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[LastName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Email] [nvarchar] (150) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Address] [nvarchar] (150) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Address2] [nvarchar] (150) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[City] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[State] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PostalCode] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CountryID] [uniqueidentifier] NULL,
[Phone] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CellPhone] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Note] [nvarchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[License] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CurrentCulture] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CurrentUICulture] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[TimeZone] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsPrimary] [bit] NOT NULL CONSTRAINT [DF_Account_Login_IsPrimary] DEFAULT ((0)),
[DataProviderID] [int] NULL,
[IsSystemAccountLogin] [bit] NOT NULL CONSTRAINT [DF_AccountLogin_IsSystemAccountLogin] DEFAULT ((0)),
[PhoneExt] [nvarchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Account_Login] ADD CONSTRAINT [PK_Account_Login] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Account_Login__Email] ON [dbo].[Account_Login] ([Email]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Account_Login__IsActive] ON [dbo].[Account_Login] ([IsActive]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Account_Login__IsDelete] ON [dbo].[Account_Login] ([IsDelete]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_Account_Login__UserName] ON [dbo].[Account_Login] ([UserName]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Account_Login] ADD CONSTRAINT [FK_Account__AccountID_X_Account_Login__ID] FOREIGN KEY ([AccountID]) REFERENCES [dbo].[Account] ([ID]) ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Account_Login] ADD CONSTRAINT [FK_Account_Login_Data_DataProvider] FOREIGN KEY ([DataProviderID]) REFERENCES [dbo].[Data_DataProvider] ([ID])
GO
ALTER TABLE [dbo].[Account_Login] ADD CONSTRAINT [FK_Account_Login_System_List_Countries] FOREIGN KEY ([CountryID]) REFERENCES [dbo].[System_List_Countries] ([ID])
GO
GRANT SELECT ON  [dbo].[Account_Login] TO [guest]
GO
