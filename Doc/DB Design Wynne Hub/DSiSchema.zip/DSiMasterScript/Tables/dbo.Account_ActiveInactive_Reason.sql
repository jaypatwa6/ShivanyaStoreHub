CREATE TABLE [dbo].[Account_ActiveInactive_Reason]
(
[ID] [uniqueidentifier] NOT NULL,
[ReasonType] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Reason] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Action] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DateCreated] [datetime] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[AccountID] [bigint] NULL,
[UserID] [uniqueidentifier] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
EXEC sp_addextendedproperty N'MS_Description', N'This field will be generated automatically', 'SCHEMA', N'dbo', 'TABLE', N'Account_ActiveInactive_Reason', 'COLUMN', N'ID'
GO
