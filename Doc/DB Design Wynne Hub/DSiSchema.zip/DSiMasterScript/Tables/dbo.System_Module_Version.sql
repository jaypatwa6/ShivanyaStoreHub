CREATE TABLE [dbo].[System_Module_Version]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[ModuleID] [uniqueidentifier] NOT NULL,
[VersionNo] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[IsActive] [bit] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_System_Module_Version_DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_System_Module_Version_DateModified] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[Description] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Module_Version] ADD CONSTRAINT [PK_System_ModuleVersion] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
