CREATE TABLE [dbo].[System_Package_Module]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[PackageID] [int] NOT NULL,
[ModuleID] [uniqueidentifier] NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_System_LL_Packages_Module_IsActive] DEFAULT ((1)),
[IsDelete] [bit] NOT NULL CONSTRAINT [DF__System_LL__IsDel__4707859D] DEFAULT ((0)),
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__System_LL__Creat__47FBA9D6] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NULL,
[ModifiedBy] [uniqueidentifier] NULL,
[VersionNumberID] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Package_Module] ADD CONSTRAINT [PK_System_LL_Packages_Module] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
