CREATE TABLE [dbo].[Asset_SupportedSoftware]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[Name] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Asset_SupportedSoftware_DateCreated] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NULL,
[DateModified] [datetime] NULL CONSTRAINT [DF_Asset_SupportedSoftware_DateModified] DEFAULT (getutcdate()),
[IsActive] [bit] NOT NULL CONSTRAINT [DF_Asset_SupportedSoftware_IsActive] DEFAULT ((1))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_SupportedSoftware] ADD CONSTRAINT [PK_Asset_SupportedSoftware] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
