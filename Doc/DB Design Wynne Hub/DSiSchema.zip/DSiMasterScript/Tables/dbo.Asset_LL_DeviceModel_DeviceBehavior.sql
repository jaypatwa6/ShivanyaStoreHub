CREATE TABLE [dbo].[Asset_LL_DeviceModel_DeviceBehavior]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[DeviceModelID] [int] NOT NULL,
[DeviceBehaviorID] [int] NOT NULL,
[Notes] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Asset_LL_DeviceModel_DeviceBehavior_DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_LL_DeviceModel_DeviceBehavior] ADD CONSTRAINT [PK_Asset_LL_DeviceModel_DeviceBehavior] PRIMARY KEY NONCLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [IX_Asset_LL_DeviceModel_DeviceBehavior__DeviceModelID__DeviceBehaviorID] ON [dbo].[Asset_LL_DeviceModel_DeviceBehavior] ([DeviceModelID], [DeviceBehaviorID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_LL_DeviceModel_DeviceBehavior] ADD CONSTRAINT [FK_Asset_LL_DeviceModel_DeviceBehavior__DeviceBehaviorID_X_Asset_DeviceBehavior__ID] FOREIGN KEY ([DeviceBehaviorID]) REFERENCES [dbo].[Asset_DeviceBehavior] ([ID])
GO
ALTER TABLE [dbo].[Asset_LL_DeviceModel_DeviceBehavior] ADD CONSTRAINT [FK_Asset_LL_DeviceModel_DeviceBehavior__DeviceModelID_X_Asset_DeviceModel__ID] FOREIGN KEY ([DeviceModelID]) REFERENCES [dbo].[Asset_DeviceModel] ([ID])
GO
