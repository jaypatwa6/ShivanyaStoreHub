CREATE TABLE [dbo].[Asset_Device_CustomerDataPlan]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[Name] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__Asset_Dev__DateC__41B8C09B] DEFAULT (getdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__Asset_Dev__DateM__42ACE4D4] DEFAULT (getdate()),
[IsActive] [bit] NOT NULL CONSTRAINT [DF__Asset_Dev__IsAct__43A1090D] DEFAULT ((1))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_Device_CustomerDataPlan] ADD CONSTRAINT [PK_Asset_Device_CustomerDataPlan] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
