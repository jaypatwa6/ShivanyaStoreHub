CREATE TABLE [dbo].[Asset_DeviceModel]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[ManufacturerID] [int] NOT NULL,
[Name] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Asset_DeviceModel_DateCreated] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NULL,
[DateModified] [datetime] NULL CONSTRAINT [DF_Asset_DeviceModel_DateModified] DEFAULT (getutcdate()),
[IsActive] [bit] NOT NULL CONSTRAINT [DF_Asset_DeviceModel_IsActive] DEFAULT ((1)),
[Keyword] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DeviceReportingField] [uniqueidentifier] NULL,
[CommunicationWarningThreshold] [int] NOT NULL CONSTRAINT [DF__Asset_Dev__Commu__4865BE2A] DEFAULT ((60)),
[DeviceTypeID] [uniqueidentifier] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_DeviceModel] ADD CONSTRAINT [PK_Asset_DeviceModel] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_DeviceModel] ADD CONSTRAINT [FK_Asset_DeviceModel__DeviceReportingField_X_Asset_DeviceReportingFieldList__ID] FOREIGN KEY ([DeviceReportingField]) REFERENCES [dbo].[Asset_DeviceReportingFieldList] ([ID])
GO
ALTER TABLE [dbo].[Asset_DeviceModel] ADD CONSTRAINT [FK_Asset_DeviceModel__ManufacturerID_X_Asset_DeviceManufacurer__ID] FOREIGN KEY ([ManufacturerID]) REFERENCES [dbo].[Asset_DeviceManufacturer] ([ID])
GO
ALTER TABLE [dbo].[Asset_DeviceModel] ADD CONSTRAINT [FK_Asset_DeviceModel_Asset_DeviceType] FOREIGN KEY ([DeviceTypeID]) REFERENCES [dbo].[Asset_DeviceType] ([ID])
GO
