CREATE TABLE [dbo].[System_Module_LicenseType]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[DateCreated] [datetime] NOT NULL,
[DateModified] [datetime] NOT NULL,
[Name] [nvarchar] (400) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Keyword] [nvarchar] (400) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Description] [nvarchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
