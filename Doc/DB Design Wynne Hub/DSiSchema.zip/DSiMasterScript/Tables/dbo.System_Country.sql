CREATE TABLE [dbo].[System_Country]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[Code] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_System_Country_IsActive] DEFAULT ((1)),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Country] ADD CONSTRAINT [PK_System_Country] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_System_Country_Code] ON [dbo].[System_Country] ([Code]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
