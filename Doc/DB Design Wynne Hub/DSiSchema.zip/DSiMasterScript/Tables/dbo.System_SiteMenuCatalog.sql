CREATE TABLE [dbo].[System_SiteMenuCatalog]
(
[CatalogId] [tinyint] NOT NULL IDENTITY(1, 1),
[Name] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_SiteMenuCatalog] ADD CONSTRAINT [PK_System_SiteMenu] PRIMARY KEY CLUSTERED  ([CatalogId]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
