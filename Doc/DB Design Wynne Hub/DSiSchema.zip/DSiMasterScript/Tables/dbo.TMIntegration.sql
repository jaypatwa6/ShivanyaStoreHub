CREATE TABLE [dbo].[TMIntegration]
(
[ID] [bigint] NOT NULL IDENTITY(1, 1),
[AccountID] [bigint] NOT NULL,
[LastReqDate] [datetime] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMIntegration] ADD CONSTRAINT [PK_SDMSIntegration] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TMIntegration] ADD CONSTRAINT [FK_SDMSIntegration__AccountID_X_Account__ID] FOREIGN KEY ([AccountID]) REFERENCES [dbo].[Account] ([ID]) ON DELETE CASCADE
GO
