CREATE TABLE [dbo].[Asset_Device_Setting]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__Asset_Device__ID__4A98EAB6] DEFAULT (newsequentialid()),
[DeviceID] [uniqueidentifier] NOT NULL,
[ATCommandID] [int] NOT NULL,
[SettingValue] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Asset_Device_Setting_DateTimeCreated] DEFAULT (getdate()),
[DateModified] [datetime] NULL CONSTRAINT [DF_Asset_Device_Setting_DateTimeModified] DEFAULT (getdate()),
[IsSuccessful] [bit] NULL,
[QueryCommand] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ICCID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PhoneNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ProviderName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[RetryCount] [int] NULL CONSTRAINT [DF_Asset_Device_Setting_RetryCount] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_Device_Setting] ADD CONSTRAINT [PK_Asset_Device_Setting_ID] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_Device_Setting] ADD CONSTRAINT [FK_Asset_Device_Asset_Device_Setting] FOREIGN KEY ([DeviceID]) REFERENCES [dbo].[Asset_Device] ([ID]) ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Asset_Device_Setting] ADD CONSTRAINT [FK_Asset_DeviceBehavior_Asset_Device_Setting] FOREIGN KEY ([ATCommandID]) REFERENCES [dbo].[Asset_DeviceBehavior] ([ID])
GO
