CREATE TABLE [dbo].[Account_Type]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Account_Type_ID] DEFAULT (newsequentialid()),
[Name] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (400) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Account_Type_DateCreated] DEFAULT (getdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF_Account_Type_DateModified] DEFAULT (getdate()),
[IsActive] [bit] NOT NULL CONSTRAINT [DF_Account_Type_IsActive] DEFAULT ((1))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Account_Type] ADD CONSTRAINT [PK_Account_Type] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
