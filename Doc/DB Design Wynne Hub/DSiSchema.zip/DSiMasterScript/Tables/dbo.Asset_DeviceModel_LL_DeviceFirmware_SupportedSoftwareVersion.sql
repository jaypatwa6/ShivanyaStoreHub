CREATE TABLE [dbo].[Asset_DeviceModel_LL_DeviceFirmware_SupportedSoftwareVersion]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[DeviceFimwareID] [int] NOT NULL,
[SupportedSoftwareVersionID] [int] NOT NULL,
[Notes] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Asset_DeviceModel_LL_DeviceFirmware_SupportedSoftwareVersion_DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_DeviceModel_LL_DeviceFirmware_SupportedSoftwareVersion] ADD CONSTRAINT [PK_Asset_DeviceModel_LL_DeviceFirmware_SupportedSoftwareVersion] PRIMARY KEY NONCLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [IX_Asset_DeviceModel_LL_DeviceFirmware_SupportedSoftwareVersion__DeviceFimwareID__SupportedSoftwareVersionID] ON [dbo].[Asset_DeviceModel_LL_DeviceFirmware_SupportedSoftwareVersion] ([DeviceFimwareID], [SupportedSoftwareVersionID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_DeviceModel_LL_DeviceFirmware_SupportedSoftwareVersion] ADD CONSTRAINT [FK_Asset_LL_DeviceFirmware_SupportedSoftwareVersion__DeviceFimwareID_X_Asset_DeviceFirmware__ID] FOREIGN KEY ([DeviceFimwareID]) REFERENCES [dbo].[Asset_DeviceModel_DeviceFirmware] ([ID]) ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Asset_DeviceModel_LL_DeviceFirmware_SupportedSoftwareVersion] ADD CONSTRAINT [FK_Asset_LL_DeviceFirmware_SupportedSoftwareVersion__SupportedSoftwareVersionID_X_Asset_SupportedSoftwareVersion__ID] FOREIGN KEY ([SupportedSoftwareVersionID]) REFERENCES [dbo].[Asset_SuppportedSoftware_SupportedSoftwareVersion] ([ID])
GO
