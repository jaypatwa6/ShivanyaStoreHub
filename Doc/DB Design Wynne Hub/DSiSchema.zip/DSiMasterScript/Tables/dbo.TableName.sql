CREATE TABLE [dbo].[TableName]
(
[ID] [bigint] NOT NULL IDENTITY(1, 1),
[Table] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Columns] [xml] NOT NULL,
[AccountID] [bigint] NULL,
[AccountLoginID] [uniqueidentifier] NULL,
[IsPersonalize] [bit] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TableName] ADD CONSTRAINT [PK_TableName] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TableName] ADD CONSTRAINT [FK_TableName__AccountID_X_Account__ID] FOREIGN KEY ([AccountID]) REFERENCES [dbo].[Account] ([ID])
GO
ALTER TABLE [dbo].[TableName] ADD CONSTRAINT [FK_TableName__AccountLoginID_X_Account_Login__ID] FOREIGN KEY ([AccountLoginID]) REFERENCES [dbo].[Account_Login] ([ID]) ON DELETE CASCADE
GO
