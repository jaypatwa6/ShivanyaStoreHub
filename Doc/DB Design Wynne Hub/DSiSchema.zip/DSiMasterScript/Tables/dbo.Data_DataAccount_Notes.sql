CREATE TABLE [dbo].[Data_DataAccount_Notes]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[Data_DataAccountID] [int] NOT NULL,
[Notes] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL,
[ModifiedBy] [uniqueidentifier] NULL,
[DateModified] [datetime] NULL,
[ICCID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DataProvider_ID] [int] NOT NULL,
[PhoneNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[AccountNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IMEI] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Data_DataPlansID] [int] NULL,
[Data_AccountStatusID] [uniqueidentifier] NULL,
[Cost] [money] NULL,
[DateActivation] [datetime] NULL,
[DateDeactivation] [datetime] NULL,
[DateSuspension] [datetime] NULL,
[DateEndofContract] [datetime] NULL,
[VoiceEnabled] [bit] NULL CONSTRAINT [DF_Data_DataAccount_Notes_VoiceEnabled] DEFAULT ((0)),
[SMSEnabled] [bit] NULL CONSTRAINT [DF_Data_DataAccount_Notes_SMSEnabled] DEFAULT ((0)),
[DataEnabled] [bit] NULL CONSTRAINT [DF_Data_DataAccount_Notes_DataEnabled] DEFAULT ((0)),
[IsActive] [bit] NOT NULL CONSTRAINT [DF_Data_DataAccount_Notes_IsActive] DEFAULT ((1)),
[ChangeSummary] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Data_DataAccount_Notes] ADD CONSTRAINT [PK_Data_DataAccount_Notes] PRIMARY KEY NONCLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [IX_Data_DataAccount_Notes__Data_DataAccountID] ON [dbo].[Data_DataAccount_Notes] ([Data_DataAccountID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Data_DataAccount_Notes] ADD CONSTRAINT [FK_Data_DataAccount_Notes__Data_DataAccountID_X_Data_DataAccount__ID] FOREIGN KEY ([Data_DataAccountID]) REFERENCES [dbo].[Data_DataAccount] ([ID]) ON DELETE CASCADE
GO
