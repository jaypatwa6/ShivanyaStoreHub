CREATE TABLE [dbo].[Asset_OSVersion]
(
[ID] [uniqueidentifier] NOT NULL,
[Name] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Asset_OSVersion_DateCreated] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NULL,
[DateModified] [datetime] NULL CONSTRAINT [DF_Asset_OSVersion_DateModified] DEFAULT (getutcdate()),
[OSTypeID] [uniqueidentifier] NOT NULL,
[Description] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_OSVersion] ADD CONSTRAINT [PK_Asset_OSVersion] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_OSVersion] ADD CONSTRAINT [FK_Asset_OSVersion_Asset_OSType] FOREIGN KEY ([OSTypeID]) REFERENCES [dbo].[Asset_OSType] ([ID])
GO
