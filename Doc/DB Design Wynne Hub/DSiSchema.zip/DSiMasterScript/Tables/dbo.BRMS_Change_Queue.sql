CREATE TABLE [dbo].[BRMS_Change_Queue]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[Type] [char] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedOn] [datetime] NULL,
[ServerName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DBName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[TableName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[FieldName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[OriginalValue] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[NewValue] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PrimaryKey] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsProcessed] [bit] NULL,
[ActionCode] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[BRMS_Change_Queue] ADD CONSTRAINT [PK_Change_Queue] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
