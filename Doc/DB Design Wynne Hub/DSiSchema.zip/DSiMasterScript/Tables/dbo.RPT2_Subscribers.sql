CREATE TABLE [dbo].[RPT2_Subscribers]
(
[ID] [uniqueidentifier] NOT NULL,
[Email] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[SubscriptionID] [uniqueidentifier] NOT NULL,
[UserLoginID] [uniqueidentifier] NOT NULL,
[FirstName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[LastName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DateCreated] [datetime] NOT NULL,
[DateModified] [datetime] NOT NULL,
[CreateadBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[RPT2_Subscribers] ADD CONSTRAINT [PK_RPT2_Subscribers] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[RPT2_Subscribers] ADD CONSTRAINT [FK_RPT2_Subscribers_RPT2_Subscription] FOREIGN KEY ([SubscriptionID]) REFERENCES [dbo].[RPT2_Subscription] ([ID]) ON DELETE CASCADE
GO
