CREATE TABLE [dbo].[Account_ManagementGroup]
(
[ID] [bigint] NOT NULL IDENTITY(1, 1),
[ManagementGroupName] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[AccountID] [bigint] NOT NULL,
[IsSystem] [bit] NOT NULL CONSTRAINT [DF__AccountMa__IsSys__764C846B] DEFAULT ((0)),
[IsActive] [bit] NOT NULL CONSTRAINT [DF__AccountMa__IsAct__7834CCDD] DEFAULT ((0)),
[Description] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsDisplay] [bit] NOT NULL CONSTRAINT [DF_Account_ManagementGroup_IsDisplay] DEFAULT ((0))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Account_ManagementGroup] ADD CONSTRAINT [PK_AccountManagementGroup] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Account_ManagementGroup__AccountID] ON [dbo].[Account_ManagementGroup] ([AccountID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Account_ManagementGroup] ADD CONSTRAINT [FK_AccountManagementGroup__AccountID_X_Account__ID] FOREIGN KEY ([AccountID]) REFERENCES [dbo].[Account] ([ID]) ON DELETE CASCADE
GO
GRANT SELECT ON  [dbo].[Account_ManagementGroup] TO [guest]
GO
