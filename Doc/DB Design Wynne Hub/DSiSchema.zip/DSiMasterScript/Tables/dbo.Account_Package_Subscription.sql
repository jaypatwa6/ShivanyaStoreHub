CREATE TABLE [dbo].[Account_Package_Subscription]
(
[Id] [bigint] NOT NULL IDENTITY(1, 1),
[AccountID] [bigint] NOT NULL,
[PackageID] [int] NOT NULL,
[VersionNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[InitialCost] [money] NOT NULL,
[MonthlyCost] [money] NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_Account_Package_Subscription_IsActive] DEFAULT ((1)),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Account_Package_Subscription_DateCreated] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NULL,
[DateModified] [datetime] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Account_Package_Subscription] ADD CONSTRAINT [PK_Account_Package_Subscription] PRIMARY KEY NONCLUSTERED  ([Id]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [IX_Account_Package_Subscription__AccountID__PackageID] ON [dbo].[Account_Package_Subscription] ([AccountID], [PackageID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Account_Package_Subscription__IsActive] ON [dbo].[Account_Package_Subscription] ([IsActive]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Account_Package_Subscription] ADD CONSTRAINT [FK_Account_Package_Subscription__AccountID_X_Account__ID] FOREIGN KEY ([AccountID]) REFERENCES [dbo].[Account] ([ID]) ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Account_Package_Subscription] ADD CONSTRAINT [FK_Account_Package_Subscription__PackageID_X_System_Packages__ID] FOREIGN KEY ([PackageID]) REFERENCES [dbo].[System_Package] ([ID])
GO
