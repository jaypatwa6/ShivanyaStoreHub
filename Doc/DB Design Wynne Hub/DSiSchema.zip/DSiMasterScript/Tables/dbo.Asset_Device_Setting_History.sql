CREATE TABLE [dbo].[Asset_Device_Setting_History]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__Asset_Device__ID__5145E845] DEFAULT (newsequentialid()),
[DeviceSerialNo] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ATCommand] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[SettingValue] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[PhoneNumber] [nvarchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[FirmwareName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[AppVersion] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsSuccessful] [bit] NULL,
[ResultMessage] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[ModifiedBy] [uniqueidentifier] NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Asset_Device_Setting_History_DateTimeCreated] DEFAULT (getdate()),
[DateModified] [datetime] NULL CONSTRAINT [DF_Asset_Device_Setting_History_DateTimeModified] DEFAULT (getdate()),
[ICCID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ProviderName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[AssetDeviceSettingID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_Device_Setting_History] ADD CONSTRAINT [PK_Asset_Device_Setting_History_ID] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_Device_Setting_History] ADD CONSTRAINT [FK_Asset_Device_Setting_History__Asset_Device_Setting] FOREIGN KEY ([AssetDeviceSettingID]) REFERENCES [dbo].[Asset_Device_Setting] ([ID])
GO
