CREATE TABLE [dbo].[Account_Setting]
(
[ID] [bigint] NOT NULL IDENTITY(1, 1),
[ConnectionStr] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CurrentCulture] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CurrentUICulture] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[TokenModeID] [bigint] NULL,
[AccountID] [bigint] NULL,
[IsActive] [bit] NOT NULL,
[UserID] [uniqueidentifier] NULL,
[TokenDateExpired] [datetime] NULL,
[Phone] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Name] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Email] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Logo] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[State] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[City] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Address] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Country] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[TimeZone] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PostalCode] [varchar] (11) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DBThreshold] [int] NOT NULL CONSTRAINT [DF__Account_S__DBThr__4336F4B9] DEFAULT ((4096)),
[DefaultPage] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PhoneExt] [nvarchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Account_Setting] ADD CONSTRAINT [PK_Account_Setting] PRIMARY KEY NONCLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [IX_Account_Setting__AccountID] ON [dbo].[Account_Setting] ([AccountID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Account_Setting__IsActive] ON [dbo].[Account_Setting] ([IsActive]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Account_Setting__TokenModeID] ON [dbo].[Account_Setting] ([TokenModeID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Account_Setting] ADD CONSTRAINT [FK_Account_Setting__AccountID_X_Account__ID] FOREIGN KEY ([AccountID]) REFERENCES [dbo].[Account] ([ID]) ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Account_Setting] ADD CONSTRAINT [FK_Account_Setting__TokenModeID_X_TokenMode__ID] FOREIGN KEY ([TokenModeID]) REFERENCES [dbo].[TokenMode] ([ID])
GO
