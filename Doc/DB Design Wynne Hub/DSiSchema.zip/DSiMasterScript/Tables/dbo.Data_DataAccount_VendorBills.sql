CREATE TABLE [dbo].[Data_DataAccount_VendorBills]
(
[ICCID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DateOfInvoice] [date] NOT NULL,
[DataUsageInMB] [float] NULL,
[SMSSentReceived] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[InvoiceNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ReferenceNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PlanName] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PlanDescription] [nvarchar] (200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DataUsageAllowedInMB] [float] NULL,
[MinutesUsed] [float] NULL,
[MinutesIncludedInPlan] [float] NULL,
[MinutesOverage] [float] NULL,
[RoamingOverageCost] [float] NULL,
[TotalCost] [float] NULL,
[CostCenter] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Reference2] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Reference3] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Data_DataAccount_VendorBills] ADD CONSTRAINT [PK_Data_DataAccount_VendorBills] PRIMARY KEY CLUSTERED  ([ICCID], [DateOfInvoice]) ON [PRIMARY]
GO
