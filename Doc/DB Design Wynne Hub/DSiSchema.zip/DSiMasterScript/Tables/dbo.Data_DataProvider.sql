CREATE TABLE [dbo].[Data_DataProvider]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[Name] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_Data_DataProvider_IsActive] DEFAULT ((1)),
[GUID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__Data_DataP__GUID__3C7FD589] DEFAULT (newsequentialid()),
[SMSParameter] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Data_DataProviderPlanID] [int] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Data_DataProvider] ADD CONSTRAINT [PK_Data_DataProvider] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Data_DataProvider] ADD CONSTRAINT [FK_Data_DataProvider__Data_DataProviderPlanID_x_Data_DataProviderPlans__ID] FOREIGN KEY ([Data_DataProviderPlanID]) REFERENCES [dbo].[Data_DataProviderPlans] ([ID])
GO
