CREATE TABLE [dbo].[Asset_LL_DeviceModel_DeviceFeature]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[DeviceModelID] [int] NOT NULL,
[DeviceFeatureID] [int] NOT NULL,
[Notes] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Asset_LL_DeviceModel_DeviceFeature_DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_LL_DeviceModel_DeviceFeature] ADD CONSTRAINT [PK_Asset_LL_DeviceModel_DeviceFeature] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Asset_LL_DeviceModel_DeviceFeature__DeviceModelID__DeviceFeatureID] ON [dbo].[Asset_LL_DeviceModel_DeviceFeature] ([DeviceModelID], [DeviceFeatureID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_LL_DeviceModel_DeviceFeature] ADD CONSTRAINT [FK_Asset_LL_DeviceFirmware_DeviceFeature__DeviceModelID_X_Asset_DeviceModel__ID] FOREIGN KEY ([DeviceModelID]) REFERENCES [dbo].[Asset_DeviceModel] ([ID]) ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Asset_LL_DeviceModel_DeviceFeature] ADD CONSTRAINT [FK_Asset_LL_DeviceModel_DeviceFeature__DeviceFeatureID_X_Asset_DeviceFeature__ID] FOREIGN KEY ([DeviceFeatureID]) REFERENCES [dbo].[Asset_DeviceFeature] ([ID])
GO
