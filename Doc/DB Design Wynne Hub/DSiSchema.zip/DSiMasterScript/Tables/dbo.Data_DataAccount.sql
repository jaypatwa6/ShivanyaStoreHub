CREATE TABLE [dbo].[Data_DataAccount]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[ICCID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Data_DataProviderID] [int] NULL,
[PhoneNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[AccountNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Cost] [money] NULL,
[DateActivation] [datetime] NULL,
[DateDeactivation] [datetime] NULL,
[DateSuspension] [datetime] NULL,
[DateEndofContract] [datetime] NULL,
[Notes] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL,
[ModifiedBy] [uniqueidentifier] NULL,
[DateModified] [datetime] NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_Data_DataAccount_IsActive] DEFAULT ((1)),
[CurrentBillingCycle] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CurrentUsageMB] [decimal] (11, 6) NULL,
[LastMBUsageUpdate] [datetime] NULL,
[UsageMBToDate] [decimal] (11, 6) NULL,
[CurrentSMSUsage] [int] NULL,
[LastSMSUsageUpdate] [datetime] NULL,
[UsageSMSToDate] [int] NULL,
[VoiceEnabled] [bit] NOT NULL CONSTRAINT [DF_Data_DataAccount_VoiceEnabled] DEFAULT ((0)),
[SMSEnabled] [bit] NOT NULL CONSTRAINT [DF_Data_DataAccount_SMSEnabled] DEFAULT ((0)),
[DataEnabled] [bit] NOT NULL CONSTRAINT [DF_Data_DataAccount_DataEnabled] DEFAULT ((0)),
[Data_DataProviderPlanID] [int] NULL,
[Data_AccountStatusID] [uniqueidentifier] NULL,
[GUID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__Data_DataA__GUID__3D73F9C2] DEFAULT (newsequentialid()),
[IMEI] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Data_DataAccount] ADD CONSTRAINT [PK_Data_DataAccount] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_Data_DataAccount] ON [dbo].[Data_DataAccount] ([ICCID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Data_DataAccount] ADD CONSTRAINT [FK_Data_DataAccount__Data_AccountStatusID_X_Data_AccountStatus__ID] FOREIGN KEY ([Data_AccountStatusID]) REFERENCES [dbo].[Data_AccountStatus] ([ID])
GO
ALTER TABLE [dbo].[Data_DataAccount] ADD CONSTRAINT [FK_data_dataAccount__Data_DataProviderID_x_Data_DataProvider__ID] FOREIGN KEY ([Data_DataProviderID]) REFERENCES [dbo].[Data_DataProvider] ([ID])
GO
ALTER TABLE [dbo].[Data_DataAccount] ADD CONSTRAINT [FK_data_dataAccount__Data_DataProviderPlanID_x_Data_DataProviderPlans__ID] FOREIGN KEY ([Data_DataProviderPlanID]) REFERENCES [dbo].[Data_DataProviderPlans] ([ID])
GO
