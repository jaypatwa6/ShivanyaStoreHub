CREATE TABLE [dbo].[TokenMode]
(
[ID] [bigint] NOT NULL IDENTITY(1, 1),
[Name] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[TimeOutValue] [int] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[TokenMode] ADD CONSTRAINT [PK_TokenMode] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
