CREATE TABLE [dbo].[DSIAuditTrail]
(
[AuditID] [int] NOT NULL IDENTITY(1, 1),
[TYPE] [char] (1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[TableName] [varchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PK] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[FieldName] [varchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[OldValue] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[NewValue] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[UpdateDate] [datetime] NULL,
[UserName] [varchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[GUID] [uniqueidentifier] NULL
) ON [PRIMARY]
GO
