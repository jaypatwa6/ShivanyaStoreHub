CREATE TABLE [dbo].[Data_DataProviderPlans]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[Name] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF__Data_Data__DateC__4A4E069C] DEFAULT (getdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL CONSTRAINT [DF__Data_Data__DateM__4B422AD5] DEFAULT (getdate()),
[IsActive] [bit] NOT NULL CONSTRAINT [DF__Data_Data__IsAct__4C364F0E] DEFAULT ((1))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Data_DataProviderPlans] ADD CONSTRAINT [PK_Data_DataPlans_1] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
