CREATE TABLE [dbo].[Security_Token]
(
[ID] [bigint] NOT NULL IDENTITY(1, 1),
[AppID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DateCreated] [datetime] NOT NULL,
[Description] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DeviceID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CustDB_HR_Employee] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ExpireDate] [datetime] NOT NULL,
[DateModified] [datetime] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[Value] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[TimeOutValue] [int] NOT NULL,
[UserID] [uniqueidentifier] NOT NULL,
[TokenModeID] [bigint] NOT NULL,
[AccountID] [bigint] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Security_Token] ADD CONSTRAINT [PK_Token] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Security_Token__AccountID] ON [dbo].[Security_Token] ([AccountID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Security_Token__UserID] ON [dbo].[Security_Token] ([UserID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Security_Token__Value] ON [dbo].[Security_Token] ([Value]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Security_Token] ADD CONSTRAINT [FK_Security_Token__TokenModeID_X_TokenMode__ID] FOREIGN KEY ([TokenModeID]) REFERENCES [dbo].[TokenMode] ([ID]) ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Security_Token] ADD CONSTRAINT [FK_Token__UserID_X_Account_Login__ID] FOREIGN KEY ([UserID]) REFERENCES [dbo].[Account_Login] ([ID]) ON DELETE CASCADE
GO
