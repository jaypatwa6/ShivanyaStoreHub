CREATE TABLE [dbo].[Account_PhoneNumber]
(
[Id] [int] NOT NULL IDENTITY(1, 1),
[AccountID] [bigint] NOT NULL,
[PhoneTypeID] [int] NOT NULL,
[PhoneNumber] [nvarchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Account_PhoneNumber_DateCreated] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_Customer_Phone_IsActive] DEFAULT ((1))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Account_PhoneNumber] ADD CONSTRAINT [PK_Account_PhoneNumber] PRIMARY KEY NONCLUSTERED  ([Id]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [IX_Account_PhoneNumber__AccountID] ON [dbo].[Account_PhoneNumber] ([AccountID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Account_PhoneNumber__PhoneTypeID] ON [dbo].[Account_PhoneNumber] ([PhoneTypeID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Account_PhoneNumber] ADD CONSTRAINT [FK_Account_PhoneNumber__AccountID_X_Account__ID] FOREIGN KEY ([AccountID]) REFERENCES [dbo].[Account] ([ID]) ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Account_PhoneNumber] ADD CONSTRAINT [FK_Customer_Phone__PhoneTypeID_X_System_PhoneType__ID] FOREIGN KEY ([PhoneTypeID]) REFERENCES [dbo].[System_PhoneType] ([ID]) ON DELETE CASCADE
GO
