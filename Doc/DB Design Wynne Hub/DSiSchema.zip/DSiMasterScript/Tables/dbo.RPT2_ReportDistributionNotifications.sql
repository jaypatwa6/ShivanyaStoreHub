CREATE TABLE [dbo].[RPT2_ReportDistributionNotifications]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_RW2_ReportDistributionNotifications_Id] DEFAULT (newsequentialid()),
[DistributionName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[IsActive] [bit] NOT NULL,
[Account_LoginID] [uniqueidentifier] NULL,
[GroupID] [bigint] NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL,
[RPT2_ReportScheduleID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[RPT2_ReportDistributionNotifications] ADD CONSTRAINT [PK_RW2_ReportDistributionNotifications] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
