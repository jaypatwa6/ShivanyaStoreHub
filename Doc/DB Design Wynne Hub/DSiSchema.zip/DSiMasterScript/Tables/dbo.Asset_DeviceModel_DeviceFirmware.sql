CREATE TABLE [dbo].[Asset_DeviceModel_DeviceFirmware]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[DeviceModelID] [int] NULL,
[VersionName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Asset_DeviceModel_DeviceFirmware_DateCreated] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NULL,
[DateModified] [datetime] NULL CONSTRAINT [DF_Asset_DeviceModel_DeviceFirmware_DateModified] DEFAULT (getutcdate()),
[IsActive] [bit] NOT NULL CONSTRAINT [DF_Asset_DeviceFirmware_IsActive] DEFAULT ((1)),
[Keyword] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[FirmwarePackage] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DownloadMethod] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_DeviceModel_DeviceFirmware] ADD CONSTRAINT [PK_Asset_DeviceFirmware] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Asset_DeviceModel_DeviceFirmware__DeviceModelID] ON [dbo].[Asset_DeviceModel_DeviceFirmware] ([DeviceModelID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Asset_DeviceModel_DeviceFirmware__IsActive] ON [dbo].[Asset_DeviceModel_DeviceFirmware] ([IsActive]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_DeviceModel_DeviceFirmware] ADD CONSTRAINT [FK_Asset_DeviceFirmware__DeviceModelID_X_Asset_DeviceModel__ID] FOREIGN KEY ([DeviceModelID]) REFERENCES [dbo].[Asset_DeviceModel] ([ID])
GO
