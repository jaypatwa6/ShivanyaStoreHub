CREATE TABLE [dbo].[System_Announcements]
(
[Id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_System_Announcements_Id] DEFAULT (newsequentialid()),
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL,
[DateModified] [datetime] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_System_Announcements_IsActive] DEFAULT ((1)),
[IsCritical] [bit] NOT NULL CONSTRAINT [DF_System_Announcements_IsCritical] DEFAULT ((0)),
[ShowOnlyOnce] [bit] NOT NULL CONSTRAINT [DF_System_Announcements_ShowOnlyOnce] DEFAULT ((0)),
[ShowAsPopup] [bit] NOT NULL CONSTRAINT [DF_System_Announcements_ShowAsPopup] DEFAULT ((0)),
[Module] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[AnnouncementHeaderHTML] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[AnnouncementTextHTML] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ShowUntilDate] [datetime] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Announcements] ADD CONSTRAINT [PK_System_Announcements] PRIMARY KEY CLUSTERED  ([Id]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
