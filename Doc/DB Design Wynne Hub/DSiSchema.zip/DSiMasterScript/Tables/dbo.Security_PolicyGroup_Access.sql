CREATE TABLE [dbo].[Security_PolicyGroup_Access]
(
[ID] [bigint] NOT NULL IDENTITY(1, 1),
[PolicyGroupID] [bigint] NOT NULL,
[AccountID] [bigint] NULL,
[AccountLoginID] [uniqueidentifier] NULL,
[UserGroupID] [bigint] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Security_PolicyGroup_Access] ADD CONSTRAINT [PK_Security_PolicyGroup_Access] PRIMARY KEY NONCLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Security_PolicyGroup_Access__AccountID] ON [dbo].[Security_PolicyGroup_Access] ([AccountID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_SecurityPolicyGroup_Access__AccountID_PolicyGroupID_ID] ON [dbo].[Security_PolicyGroup_Access] ([AccountID], [PolicyGroupID], [ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [IX_Security_PolicyGroup_Access__AccountLoginID__PolicyGroupID] ON [dbo].[Security_PolicyGroup_Access] ([AccountLoginID], [PolicyGroupID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Security_PolicyGroup_Access__PolicyGroupID_AccountID_ID] ON [dbo].[Security_PolicyGroup_Access] ([PolicyGroupID], [AccountID], [ID]) INCLUDE ([AccountLoginID], [UserGroupID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Security_PolicyGroup_Access__UserGroupID] ON [dbo].[Security_PolicyGroup_Access] ([UserGroupID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Security_PolicyGroup_Access] ADD CONSTRAINT [FK_PolicyGroupAccess__AccountLoginID_X_Account_Login__ID] FOREIGN KEY ([AccountLoginID]) REFERENCES [dbo].[Account_Login] ([ID]) ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Security_PolicyGroup_Access] WITH NOCHECK ADD CONSTRAINT [FK_PolicyGroupAccess__PolicyGroupID_X_PolicyGroup__ID] FOREIGN KEY ([PolicyGroupID]) REFERENCES [dbo].[Security_PolicyGroup] ([ID]) ON DELETE CASCADE
GO
