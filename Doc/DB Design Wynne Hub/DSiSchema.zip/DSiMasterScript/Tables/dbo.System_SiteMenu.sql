CREATE TABLE [dbo].[System_SiteMenu]
(
[MenuId] [int] NOT NULL IDENTITY(1, 1),
[CatalogId] [tinyint] NOT NULL,
[ParentId] [int] NULL,
[DisplayText] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DisplayTextLocalizeKey] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ToolTip] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ToolTipLocalizeKey] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Href] [nvarchar] (1024) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Target] [nvarchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL CONSTRAINT [DF_System_SiteMenu_Target] DEFAULT (N'_self'),
[Icon] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[OnClientClick] [nvarchar] (1024) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsDefault] [bit] NOT NULL CONSTRAINT [DF_System_SiteMenu_IsDefault] DEFAULT ((0)),
[Order] [int] NOT NULL CONSTRAINT [DF_System_SiteMenu_Order] DEFAULT ((0)),
[IsActive] [bit] NOT NULL CONSTRAINT [DF_System_SiteMenu_IsActive] DEFAULT ((1))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_SiteMenu] ADD CONSTRAINT [PK_System_SiteMenu_1] PRIMARY KEY CLUSTERED  ([MenuId]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_SiteMenu] WITH NOCHECK ADD CONSTRAINT [FK_System_SiteMenu__CatalogId_X_System_SiteMenuCatalog__CatalogID] FOREIGN KEY ([CatalogId]) REFERENCES [dbo].[System_SiteMenuCatalog] ([CatalogId])
GO
