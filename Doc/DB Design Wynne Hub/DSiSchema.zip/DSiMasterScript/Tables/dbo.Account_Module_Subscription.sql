CREATE TABLE [dbo].[Account_Module_Subscription]
(
[ID] [bigint] NOT NULL IDENTITY(1, 1),
[AccountID] [bigint] NOT NULL,
[ModuleID] [uniqueidentifier] NOT NULL,
[VersionID] [int] NOT NULL,
[IsActive] [bit] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Account_Module_Subscription_DateCreated] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NULL,
[DateModified] [datetime] NULL CONSTRAINT [DF_Account_Module_Subscription_DateModified] DEFAULT (getutcdate()),
[Description] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[LicenseCountPurchased] [int] NOT NULL CONSTRAINT [DF_Account_Module_Subscription_LicenseCountPurchased] DEFAULT ((0)),
[purchaseprice] [money] NULL,
[maintenanceprice] [money] NULL,
[subscriptionprice] [money] NULL,
[System_Module_LicenseID] [int] NULL,
[Notes] [ntext] COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Account_Module_Subscription] ADD CONSTRAINT [PK_Account_Module_Subscription] PRIMARY KEY NONCLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Account_Module_Subscription__IsActive] ON [dbo].[Account_Module_Subscription] ([IsActive]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Account_Module_Subscription] ADD CONSTRAINT [FK_Account_Module_Subscription__AccountID_X_Account__ID] FOREIGN KEY ([AccountID]) REFERENCES [dbo].[Account] ([ID]) ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Account_Module_Subscription] ADD CONSTRAINT [FK_Account_Module_Subscription__System_Module_LicenseType_X_ID] FOREIGN KEY ([System_Module_LicenseID]) REFERENCES [dbo].[System_Module_License] ([id])
GO
