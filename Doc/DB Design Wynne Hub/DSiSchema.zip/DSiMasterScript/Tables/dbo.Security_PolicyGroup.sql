CREATE TABLE [dbo].[Security_PolicyGroup]
(
[ID] [bigint] NOT NULL IDENTITY(1, 1),
[PolicyName] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DateCreated] [datetime] NULL,
[CreatedBy] [uniqueidentifier] NULL,
[DateModified] [datetime] NULL,
[ModifiedBy] [uniqueidentifier] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Security_PolicyGroup] ADD CONSTRAINT [PK_PolicyGroup] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
