CREATE TABLE [dbo].[CRM_Customer]
(
[ID] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateModified] [datetime] NOT NULL,
[ModifiedBy] [uniqueidentifier] NOT NULL,
[Name] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Number] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[IsActive] [bit] NOT NULL,
[Note] [nvarchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[System_OrganizationID] [uniqueidentifier] NULL,
[CommonList_CustomerTypeID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[CRM_Customer] ADD CONSTRAINT [PK_CRM_Customer] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
