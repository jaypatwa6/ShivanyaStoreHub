CREATE TABLE [dbo].[Security_PolicyGroup_Permission]
(
[ID] [bigint] NOT NULL IDENTITY(1, 1),
[MethodName] [nvarchar] (400) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CanRead] [bit] NOT NULL,
[CanModify] [bit] NOT NULL,
[CanWrite] [bit] NOT NULL,
[AccountID] [bigint] NULL,
[AccountLoginID] [uniqueidentifier] NULL,
[PolicyGroupID] [bigint] NULL,
[CreatedBy] [uniqueidentifier] NULL,
[DateCreated] [datetime] NULL,
[ModifiedBy] [uniqueidentifier] NULL,
[DateModified] [datetime] NULL,
[DisplayName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CanViewOnly] [bit] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Security_PolicyGroup_Permission] ADD CONSTRAINT [PK_Security_PolicyGroup_Permission] PRIMARY KEY NONCLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Security_PolicyGroup_Permission__AccountID] ON [dbo].[Security_PolicyGroup_Permission] ([AccountID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [IX_Security_PolicyGroup_Permission__AccountLoginID__PolicyGroupID] ON [dbo].[Security_PolicyGroup_Permission] ([AccountLoginID], [PolicyGroupID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Security_PolicyGroup_Permission__With12Columns] ON [dbo].[Security_PolicyGroup_Permission] ([PolicyGroupID]) INCLUDE ([AccountID], [AccountLoginID], [CanModify], [CanRead], [CanViewOnly], [CanWrite], [CreatedBy], [DateCreated], [DateModified], [DisplayName], [ID], [MethodName], [ModifiedBy]) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Security_PolicyGroup_Permission] WITH NOCHECK ADD CONSTRAINT [FK_Security_PolicyGroup_Permission__AccountLoginID_X_Account_Login__ID] FOREIGN KEY ([AccountLoginID]) REFERENCES [dbo].[Account_Login] ([ID]) ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Security_PolicyGroup_Permission] WITH NOCHECK ADD CONSTRAINT [FK_Security_PolicyGroup_Permission__PolicyGroupID_X_PolicyGroup__ID] FOREIGN KEY ([PolicyGroupID]) REFERENCES [dbo].[Security_PolicyGroup] ([ID]) ON DELETE CASCADE
GO
