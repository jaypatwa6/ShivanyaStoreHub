CREATE TABLE [dbo].[System_MasterOrganization]
(
[Id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_System_MasterOrganization_Id] DEFAULT (newsequentialid()),
[Name] [nvarchar] (150) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[System_MasterOrganization_TypeId] [uniqueidentifier] NOT NULL,
[ParentId] [uniqueidentifier] NULL,
[IsActive] [bit] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[CreatedDate] [datetime] NOT NULL,
[ModifiedBy] [uniqueidentifier] NULL,
[ModifiedDate] [datetime] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_MasterOrganization] ADD CONSTRAINT [PK_System_MasterOrganization] PRIMARY KEY CLUSTERED  ([Id]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_MasterOrganization] ADD CONSTRAINT [FK_System_MasterOrganization__ParentId_x_System_MasterOrganization__Id] FOREIGN KEY ([ParentId]) REFERENCES [dbo].[System_MasterOrganization] ([Id])
GO
ALTER TABLE [dbo].[System_MasterOrganization] WITH NOCHECK ADD CONSTRAINT [FK_System_MasterOrganization__System_MasterOrganization_TypeId_x_System_MasterOrganization_Type__Id] FOREIGN KEY ([System_MasterOrganization_TypeId]) REFERENCES [dbo].[System_MasterOrganization_Type] ([Id])
GO
