CREATE TABLE [dbo].[Asset_Device_Notes]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[DeviceID] [uniqueidentifier] NOT NULL,
[Notes] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Asset_Device_Notes_DateCreated] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NULL,
[DateModified] [datetime] NULL CONSTRAINT [DF_Asset_Device_Notes_DateModified] DEFAULT (getutcdate()),
[OtherIDNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[SecondarySerialNumber] [nvarchar] (300) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[MEID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsActive] [bit] NOT NULL CONSTRAINT [DF_Asset_Device_Notes_IsActive] DEFAULT ((0)),
[AccountID] [bigint] NULL,
[DeviceFirmwareID] [int] NULL,
[DeviceStatusID] [int] NULL,
[ModemTypeID] [int] NULL,
[AntennaTypeID] [int] NULL,
[SerialNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IMEI] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[OSType] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DataAccountID] [int] NULL,
[ChangeSummary] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IPAddress] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[OldIPAddress] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DeviceModelID] [int] NULL,
[GUID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__Asset_Devi__GUID__1530FE3E] DEFAULT (newsequentialid()),
[OldPort] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[NewPort] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[NewGPSServer] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[OldGPSServer] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_Device_Notes] ADD CONSTRAINT [PK_Asset_Device_Notes] PRIMARY KEY NONCLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Asset_Device_Notes__AccountID] ON [dbo].[Asset_Device_Notes] ([AccountID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Asset_Device_Notes__AntennaTypeID] ON [dbo].[Asset_Device_Notes] ([AntennaTypeID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Asset_Device_Notes__DataAccountID] ON [dbo].[Asset_Device_Notes] ([DataAccountID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Asset_Device_Notes__DeviceFirmwareID] ON [dbo].[Asset_Device_Notes] ([DeviceFirmwareID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [IX_Asset_Device_Notes__DeviceID__ID] ON [dbo].[Asset_Device_Notes] ([DeviceID], [ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Asset_Device_Notes__DeviceStatusID] ON [dbo].[Asset_Device_Notes] ([DeviceStatusID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Asset_Device_Notes__IMEI] ON [dbo].[Asset_Device_Notes] ([IMEI]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Asset_Device_Notes__IsActive] ON [dbo].[Asset_Device_Notes] ([IsActive]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Asset_Device_Notes__MEID] ON [dbo].[Asset_Device_Notes] ([MEID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Asset_Device_Notes__ModemTypeID] ON [dbo].[Asset_Device_Notes] ([ModemTypeID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Asset_Device_Notes__SecondarySerialNumber] ON [dbo].[Asset_Device_Notes] ([SecondarySerialNumber]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Asset_Device_Notes__SerialNumber] ON [dbo].[Asset_Device_Notes] ([SerialNumber]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_Device_Notes] ADD CONSTRAINT [FK_Asset_Device_Notes__DeviceID_X_Asset_Device__ID] FOREIGN KEY ([DeviceID]) REFERENCES [dbo].[Asset_Device] ([ID]) ON DELETE CASCADE
GO
