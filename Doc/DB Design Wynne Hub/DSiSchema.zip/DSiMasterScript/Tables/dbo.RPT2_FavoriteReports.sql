CREATE TABLE [dbo].[RPT2_FavoriteReports]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_RW2_FavoriteReports_Id] DEFAULT (newsequentialid()),
[Account_LoginID] [uniqueidentifier] NOT NULL,
[GroupID] [bigint] NULL,
[RPT2_ReportID] [uniqueidentifier] NOT NULL,
[DateLastRun] [datetime] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[RPT2_FavoriteReports] ADD CONSTRAINT [PK_RPT2_FavoriteReports] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[RPT2_FavoriteReports] WITH NOCHECK ADD CONSTRAINT [FK_RW_FavoriteReports__RPT2_ReportID_X_RW_Cus_Report__ID] FOREIGN KEY ([RPT2_ReportID]) REFERENCES [dbo].[RPT2_Report] ([ID]) ON DELETE CASCADE
GO
