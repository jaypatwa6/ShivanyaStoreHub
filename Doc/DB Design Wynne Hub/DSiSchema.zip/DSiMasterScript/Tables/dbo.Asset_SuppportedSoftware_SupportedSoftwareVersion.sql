CREATE TABLE [dbo].[Asset_SuppportedSoftware_SupportedSoftwareVersion]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[SupportedSoftwareID] [int] NULL,
[VersionName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Asset_SuppportedSoftware_SupportedSoftwareVersion_DateCreated] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NULL,
[DateModified] [datetime] NULL CONSTRAINT [DF_Asset_SuppportedSoftware_SupportedSoftwareVersion_DateModified] DEFAULT (getutcdate()),
[IsActive] [bit] NOT NULL CONSTRAINT [DF_Asset_SupportedSoftwareVersion_IsActive] DEFAULT ((1))
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_SuppportedSoftware_SupportedSoftwareVersion] ADD CONSTRAINT [PK_Asset_SupportedSoftwareVersion] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_SuppportedSoftware_SupportedSoftwareVersion] ADD CONSTRAINT [FK_Asset_SupportedSoftwareVersion__SupportedSoftwareID_X_Asset_SupportedSoftware__ID] FOREIGN KEY ([SupportedSoftwareID]) REFERENCES [dbo].[Asset_SupportedSoftware] ([ID])
GO
