CREATE TABLE [dbo].[Asset_DeviceModel_LL_DeviceFirmware_DeviceFeature]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[DeviceFimwareID] [int] NOT NULL,
[DeviceFeatureID] [int] NOT NULL,
[Notes] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Asset_DeviceModel_LL_DeviceFirmware_DeviceFeature_DateCreated] DEFAULT (getutcdate()),
[CreatedBy] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_DeviceModel_LL_DeviceFirmware_DeviceFeature] ADD CONSTRAINT [PK_Asset_DeviceModel_LL_DeviceFirmware_DeviceFeature] PRIMARY KEY NONCLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [IX_Asset_DeviceModel_LL_DeviceFirmware_DeviceFeature__DeviceFimwareID__DeviceFeatureID] ON [dbo].[Asset_DeviceModel_LL_DeviceFirmware_DeviceFeature] ([DeviceFimwareID], [DeviceFeatureID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_DeviceModel_LL_DeviceFirmware_DeviceFeature] ADD CONSTRAINT [FK_Asset_LL_DeviceFirmware_DeviceFeature__DeviceFeatureID_X_Asset_DeviceFeature__ID] FOREIGN KEY ([DeviceFeatureID]) REFERENCES [dbo].[Asset_DeviceFeature] ([ID])
GO
ALTER TABLE [dbo].[Asset_DeviceModel_LL_DeviceFirmware_DeviceFeature] ADD CONSTRAINT [FK_Asset_LL_DeviceFirmware_DeviceFeature__DeviceFimwareID_X_Asset_DeviceFirmware__ID] FOREIGN KEY ([DeviceFimwareID]) REFERENCES [dbo].[Asset_DeviceModel_DeviceFirmware] ([ID]) ON DELETE CASCADE
GO
