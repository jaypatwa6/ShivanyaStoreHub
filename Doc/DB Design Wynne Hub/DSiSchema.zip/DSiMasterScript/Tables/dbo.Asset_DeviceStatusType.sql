CREATE TABLE [dbo].[Asset_DeviceStatusType]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[Name] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Asset_DeviceStatusType_DateCreated] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NULL,
[DateModified] [datetime] NULL CONSTRAINT [DF_Asset_DeviceStatusType_DateModified] DEFAULT (getutcdate()),
[IsActive] [bit] NOT NULL CONSTRAINT [DF_Asset_DeviceStatusType_IsActive] DEFAULT ((1)),
[GUID] [uniqueidentifier] NOT NULL CONSTRAINT [DF__Asset_Devi__GUID__4238AEDF] DEFAULT (newsequentialid())
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_DeviceStatusType] ADD CONSTRAINT [PK_Asset_DeviceStatusType] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
