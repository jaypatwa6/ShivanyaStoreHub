CREATE TABLE [dbo].[System_EnvironmentStatus]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[IPAddress] [nvarchar] (45) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[HostName] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[OSName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[OSVersion] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Processors] [nvarchar] (400) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[BuildType] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Manufacturer] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[OSArchitecture] [nvarchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[RegisteredUser] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CurrentTimeZone] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[LocalDateTime] [datetime] NOT NULL,
[TotalPhysicalMemory] [float] NOT NULL,
[AvailablePhysicalMemory] [float] NOT NULL,
[TotalVirtualMemorySize] [float] NOT NULL,
[AvailableVirtualMemory] [float] NOT NULL,
[Drives] [varbinary] (max) NULL,
[SystemDrive] [nvarchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CPUUsageHistories] [varbinary] (max) NULL,
[RAMUsageHistories] [varbinary] (max) NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_EnvironmentStatus] ADD CONSTRAINT [PK_System_EnvironmentStatus] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
