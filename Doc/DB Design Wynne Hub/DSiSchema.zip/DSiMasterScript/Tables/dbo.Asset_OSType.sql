CREATE TABLE [dbo].[Asset_OSType]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Asset_OSType_ID] DEFAULT (newsequentialid()),
[Name] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Asset_OSType_DateCreated] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NULL,
[DateModified] [datetime] NULL CONSTRAINT [DF_Asset_OSType_DateModified] DEFAULT (getutcdate())
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_OSType] ADD CONSTRAINT [PK_Asset_OSType] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
