CREATE TABLE [dbo].[System_MasterOrganization_Account]
(
[Id] [uniqueidentifier] NOT NULL CONSTRAINT [DF_System_MasterOrganization_Account_Id] DEFAULT (newsequentialid()),
[System_MasterOrganizationId] [uniqueidentifier] NOT NULL,
[AccountId] [bigint] NOT NULL,
[IsActive] [bit] NOT NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[CreatedDate] [datetime] NOT NULL,
[ModifiedBy] [uniqueidentifier] NULL,
[ModifiedDate] [datetime] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_MasterOrganization_Account] ADD CONSTRAINT [PK_System_MasterOrganization_Account] PRIMARY KEY CLUSTERED  ([Id]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_MasterOrganization_Account] ADD CONSTRAINT [FK_System_MasterOrganization_Account__AccountId_x_Account__Id] FOREIGN KEY ([AccountId]) REFERENCES [dbo].[Account] ([ID])
GO
ALTER TABLE [dbo].[System_MasterOrganization_Account] ADD CONSTRAINT [FK_System_MasterOrganization_Account__System_MasterOrganizationId_x_System_MasterOrganization__Id] FOREIGN KEY ([System_MasterOrganizationId]) REFERENCES [dbo].[System_MasterOrganization] ([Id])
GO
