CREATE TABLE [dbo].[Asset_Device]
(
[ID] [uniqueidentifier] NOT NULL CONSTRAINT [DF_Asset_Device_ID1] DEFAULT (newsequentialid()),
[DeviceFimwareID] [int] NOT NULL,
[DeviceStatusID] [int] NOT NULL,
[ModemTypeID] [int] NOT NULL,
[AntennaTypeID] [int] NULL,
[SerialNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[IMEI] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[OSType] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[GUID] [varbinary] (256) NULL,
[DataAccountID] [int] NULL,
[Notes] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CommunicationTime] [datetime] NULL,
[Latitude] [decimal] (9, 6) NULL,
[Longitude] [decimal] (9, 6) NULL,
[Heading] [smallint] NULL,
[Velocity] [int] NULL,
[GPSTime] [datetime] NOT NULL CONSTRAINT [DF_Asset_Device_GPSTime] DEFAULT (getutcdate()),
[Satellites] [int] NULL,
[Address] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[City] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[State] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PostalCode] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Country] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[AccountID] [bigint] NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL CONSTRAINT [DF_Asset_Device_DateCreated] DEFAULT (getutcdate()),
[ModifiedBy] [uniqueidentifier] NULL,
[DateModified] [datetime] NULL CONSTRAINT [DF_Asset_Device_DateModified] DEFAULT (getutcdate()),
[IsActive] [bit] NOT NULL CONSTRAINT [DF_Asset_Device_IsActive] DEFAULT ((1)),
[ExtendedData] [xml] NULL,
[DeviceOriginatorID] [uniqueidentifier] NULL CONSTRAINT [DF_Asset_Device_DeviceOriginatorID] DEFAULT ('EF6A03AC-DC78-E311-816A-00155DBB4A2D'),
[MEID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[SecondarySerialNumber] [nvarchar] (300) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[OtherIDNumber] [nvarchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IPAddress] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PhoneNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DeviceModelID] [int] NULL,
[Asset_Device_CustomerDataPlanID] [int] NULL,
[IsConfigured] [bit] NOT NULL CONSTRAINT [DF__Asset_Dev__IsCon__3FD07829] DEFAULT ((0)),
[Parser] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PacketSize] [int] NULL,
[PingRateInMinutes] [int] NULL,
[Asset_DeviceGroupID] [uniqueidentifier] NULL,
[OSVersionID] [uniqueidentifier] NULL,
[GPSServer] [nvarchar] (150) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[GPSServerPort] [nvarchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[MustUpdate] [bit] NOT NULL CONSTRAINT [DF__Asset_Dev__MustU__1C9228E4] DEFAULT ((0)),
[J1939LastCommTime] [datetime] NULL,
[ODBIILastCommTime] [datetime] NULL,
[GPSOnlyLastCommTime] [datetime] NULL
) ON [PRIMARY]
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE TRIGGER [dbo].[tr_Asset_Device]
   ON [dbo].[Asset_Device]
   AFTER UPDATE
AS 
BEGIN

IF UPDATE (IPAddress)
begin
        INSERT INTO [Asset_Device_Notes] ([DeviceID], [Notes], [CreatedBy], [ModifiedBy], [IsActive], [AccountID], [SerialNumber],[ChangeSummary],[IPAddress],[OldIPAddress],[OldPort],[NewPort])
		SELECT S.ID, 'IPChangeLog', '00000000-0000-0000-0000-000000000000','00000000-0000-0000-0000-000000000000',1,s.AccountID,s.SerialNumber,'IP Address changed from ' + CAST(d.IPAddress AS NVARCHAR(55)) + ' to ' + CAST(s.IPAddress AS NVARCHAR(55)),s.IPAddress,d.ipaddress,s.GPSServerPort,d.GPSServerPort FROM dbo.Asset_Device S
        INNER JOIN Inserted I ON S.id = I.id -- and S.PartNumber = I.PartNumber
        INNER JOIN Deleted D ON S.id = D.id --and S.PartNumber = D.PartNumber 
        WHERE I.IPAddress <> D.IPAddress
END
end
GO
DISABLE TRIGGER [dbo].[tr_Asset_Device] ON [dbo].[Asset_Device]
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
CREATE TRIGGER [dbo].[trg_Asset_Device] ON [dbo].[Asset_Device] FOR INSERT, UPDATE, DELETE
AS

DECLARE @bit INT ,
      @FIELD INT ,
      @maxfield INT ,
      @CHAR INT ,
      @fieldname VARCHAR(128) ,
      @TableName VARCHAR(128) ,
      @PKCols VARCHAR(1000) ,
      @SQL VARCHAR(2000), 
      @UpdateDate VARCHAR(21) ,
      @UserName VARCHAR(128) ,
      @TYPE CHAR(1) ,
      @PKSelect VARCHAR(1000)

      SELECT @TableName = 'Asset_Device'

      -- date and user
      SELECT      @UserName = system_user ,
            @UpdateDate = CONVERT(VARCHAR(8), getdate(), 112) + ' ' + CONVERT(VARCHAR(12), getdate(), 114)

      -- Action
      IF EXISTS (SELECT * FROM inserted)
            IF EXISTS (SELECT * FROM deleted)
                  SELECT @TYPE = 'U'
            ELSE
                  SELECT @TYPE = 'I'
      ELSE
            SELECT @TYPE = 'D'

      -- get list of columns
      SELECT * INTO #ins FROM inserted
      SELECT * INTO #del FROM deleted

      -- Get primary key columns for full outer join
      SELECT      @PKCols = COALESCE(@PKCols + ' and', ' on') + ' i.' + c.COLUMN_NAME + ' = d.' + c.COLUMN_NAME
      FROM  INFORMATION_SCHEMA.TABLE_CONSTRAINTS pk ,
            INFORMATION_SCHEMA.KEY_COLUMN_USAGE c
      WHERE       pk.TABLE_NAME = @TableName
      AND   CONSTRAINT_TYPE = 'PRIMARY KEY'
      AND   c.TABLE_NAME = pk.TABLE_NAME
      AND   c.CONSTRAINT_NAME = pk.CONSTRAINT_NAME

      -- Get primary key select for insert
      SELECT @PKSelect = COALESCE(@PKSelect+'+','') + '''<' + COLUMN_NAME + '=''+convert(varchar(100),coalesce(i.' + COLUMN_NAME +',d.' + COLUMN_NAME + '))+''>''' 
      FROM  INFORMATION_SCHEMA.TABLE_CONSTRAINTS pk ,
            INFORMATION_SCHEMA.KEY_COLUMN_USAGE c
      WHERE       pk.TABLE_NAME = @TableName
      AND   CONSTRAINT_TYPE = 'PRIMARY KEY'
      AND   c.TABLE_NAME = pk.TABLE_NAME
      AND   c.CONSTRAINT_NAME = pk.CONSTRAINT_NAME
	   
				 
      
      
      IF @PKCols IS NULL
      BEGIN
            raiserror('no PK on table %s', 16, -1, @TableName)
            RETURN
      END

      SELECT @FIELD = 0, @maxfield = MAX(ORDINAL_POSITION) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = @TableName
      while @FIELD < @maxfield
      BEGIN
            SELECT @FIELD = MIN(ORDINAL_POSITION) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = @TableName AND ORDINAL_POSITION > @FIELD
            SELECT @bit = (@FIELD - 1 )% 8 + 1
            SELECT @bit = POWER(2,@bit - 1)
            SELECT @CHAR = ((@FIELD - 1) / 8) + 1
            IF SUBSTRING(COLUMNS_UPDATED(),@CHAR, 1) & @bit > 0 OR @TYPE IN ('I','D')
            BEGIN
                  SELECT @fieldname = COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = @TableName AND ORDINAL_POSITION = @FIELD
                  SELECT @SQL =           'insert DSIAuditTrail (Type, TableName, PK,[GUID], FieldName, OldValue, NewValue, UpdateDate, UserName)'
                  SELECT @SQL = @SQL +    ' select ''' + @TYPE + ''''
                  SELECT @SQL = @SQL +    ',''' + @TableName + ''''
                  SELECT @SQL = @SQL +    ',' + @PKSelect
                  SELECT @SQL = @SQL +    ',' + REPLACE(REPLACE(@PKSelect,'<ID=','') ,'>','')
                  SELECT @SQL = @SQL +    ',''' + @fieldname + ''''
                  SELECT @SQL = @SQL +    ',convert(varchar(1000),d.' + @fieldname + ')'
                  SELECT @SQL = @SQL +    ',convert(varchar(1000),i.' + @fieldname + ')'
                  SELECT @SQL = @SQL +    ',''' + @UpdateDate + ''''
                  SELECT @SQL = @SQL +    ',''' + @UserName + ''''
                  SELECT @SQL = @SQL +    ' from #ins i full outer join #del d'
                  SELECT @SQL = @SQL +    @PKCols
                  SELECT @SQL = @SQL +    ' where i.' + @fieldname + ' <> d.' + @fieldname 
                  SELECT @SQL = @SQL +    ' or (i.' + @fieldname + ' is null and  d.' + @fieldname + ' is not null)' 
                  SELECT @SQL = @SQL +    ' or (i.' + @fieldname + ' is not null and  d.' + @fieldname + ' is null)' 
				  if @fieldname = 'ID' or @fieldname = 'DeviceFirmwareID' or @fieldname = 'DeviceStatusID' or @fieldname = 'SerialNumber' or @fieldname = 'IMEI' or @fieldname = 'GUID' or @fieldname = 'DataAccountID' or @fieldname = 'Notes' or @fieldname = 'AccountID' or @fieldname = 'IsActive' or @fieldname = 'DeviceOriginatorID' or @fieldname = 'MEID' or @fieldname = 'SecondarySerialNumber' or @fieldname = 'OtherIDNumber' or @fieldname = 'DeviceModelID' or @fieldname = 'PhoneNumber'
				  begin
					EXEC (@SQL)
				   end
            END
      END
GO
DISABLE TRIGGER [dbo].[trg_Asset_Device] ON [dbo].[Asset_Device]
GO
ALTER TABLE [dbo].[Asset_Device] ADD CONSTRAINT [PK_Asset_Device] PRIMARY KEY CLUSTERED  ([ID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Asset_Device__AccountID] ON [dbo].[Asset_Device] ([AccountID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Asset_Device__AntennaTypeID] ON [dbo].[Asset_Device] ([AntennaTypeID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Asset_Device__DataAccountID] ON [dbo].[Asset_Device] ([DataAccountID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Asset_Device__DeviceFimwareID] ON [dbo].[Asset_Device] ([DeviceFimwareID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Asset_Device__DeviceOriginatorID] ON [dbo].[Asset_Device] ([DeviceOriginatorID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Asset_Device__DeviceStatusID] ON [dbo].[Asset_Device] ([DeviceStatusID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Asset_Device__IMEI] ON [dbo].[Asset_Device] ([IMEI]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Asset_Device__IsActive] ON [dbo].[Asset_Device] ([IsActive]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Asset_Device__MEID] ON [dbo].[Asset_Device] ([MEID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Asset_Device__ModemTypeID] ON [dbo].[Asset_Device] ([ModemTypeID]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Asset_Device__OtherIDNumber] ON [dbo].[Asset_Device] ([OtherIDNumber]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Asset_Device__SecondarySerialNumber] ON [dbo].[Asset_Device] ([SecondarySerialNumber]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Asset_Device__SerialNumber] ON [dbo].[Asset_Device] ([SerialNumber]) WITH (FILLFACTOR=90) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_Device] ADD CONSTRAINT [FK_Asset_Device__AccountID_x_Account__ID] FOREIGN KEY ([AccountID]) REFERENCES [dbo].[Account] ([ID]) ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Asset_Device] ADD CONSTRAINT [FK_Asset_Device__AntennaTypeID_X_Asset_AntennaType__ID] FOREIGN KEY ([AntennaTypeID]) REFERENCES [dbo].[Asset_AntennaType] ([ID])
GO
ALTER TABLE [dbo].[Asset_Device] ADD CONSTRAINT [FK_Asset_Device__Asset_Device_CustomerDataPlanID_x_Asset_Device_CustomerDataPlan__ID] FOREIGN KEY ([Asset_Device_CustomerDataPlanID]) REFERENCES [dbo].[Asset_Device_CustomerDataPlan] ([ID])
GO
ALTER TABLE [dbo].[Asset_Device] ADD CONSTRAINT [FK_Asset_Device__DataAccountID_X_Data_DataAccount__ID] FOREIGN KEY ([DataAccountID]) REFERENCES [dbo].[Data_DataAccount] ([ID])
GO
ALTER TABLE [dbo].[Asset_Device] ADD CONSTRAINT [FK_Asset_Device__DeviceFimwareID_X_Asset_DeviceFirmware__ID] FOREIGN KEY ([DeviceFimwareID]) REFERENCES [dbo].[Asset_DeviceModel_DeviceFirmware] ([ID])
GO
ALTER TABLE [dbo].[Asset_Device] ADD CONSTRAINT [FK_Asset_Device__DeviceOriginatorID_x_asset_DeviceOriginator__ID] FOREIGN KEY ([DeviceOriginatorID]) REFERENCES [dbo].[Asset_DeviceOriginator] ([ID])
GO
ALTER TABLE [dbo].[Asset_Device] ADD CONSTRAINT [FK_Asset_Device__DeviceStatusID_X_Asset_DeviceStatusType__ID] FOREIGN KEY ([DeviceStatusID]) REFERENCES [dbo].[Asset_DeviceStatusType] ([ID])
GO
ALTER TABLE [dbo].[Asset_Device] ADD CONSTRAINT [FK_Asset_Device__ModemTypeID_X_Asset_ModemType__ID] FOREIGN KEY ([ModemTypeID]) REFERENCES [dbo].[Asset_ModemType] ([ID])
GO
ALTER TABLE [dbo].[Asset_Device] ADD CONSTRAINT [FK_Asset_Device_Asset_DeviceGroup] FOREIGN KEY ([Asset_DeviceGroupID]) REFERENCES [dbo].[Asset_DeviceGroup] ([Id])
GO
ALTER TABLE [dbo].[Asset_Device] ADD CONSTRAINT [FK_Asset_Device_Asset_DeviceModel] FOREIGN KEY ([DeviceModelID]) REFERENCES [dbo].[Asset_DeviceModel] ([ID])
GO
ALTER TABLE [dbo].[Asset_Device] ADD CONSTRAINT [FK_Asset_Device_Asset_OSVersion] FOREIGN KEY ([OSVersionID]) REFERENCES [dbo].[Asset_OSVersion] ([ID])
GO
