SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE view [dbo].[vw_DSiMobileActiveDeviceNetworkType]
as 
select  
cast(ac.AccountName as varchar(500)) as AccountName, 

case when cast(ac.IsActive as nvarchar(15)) = '1' then 'Active' 
	when cast(ac.IsActive as nvarchar(15)) = '0' then 'InActive'
	else cast( ac.IsActive as nvarchar(15)) 
end as IsAcctActive,  

dm.Name as Make,

case 
when 
m.name in ('AK7', 'AK7 (CV)','AK7 (UA-B)','AK7 (UG)','AK7 (UG-B)','AU7 (UG-B)','AX7','AX7 (CV)','AX7 (CV-BX)','AX7 (UG)','TREQ-VM','TreqVMx 4273R GPRS','TreqVMx 4281R GPRS','TreqVMx-4455R GPRS','TreqVMx-4456R CDMA')
THEN '3G' 
when 
m.Name in ('AT1','AX5','AX5 C','CE507','GL505','Net-960EX','WhereQube','wherequbeavl') 
then '2G' 
WHEN 
M.Name IN ('C811 4G','DROID RAZR','iPad','iPhone','iPhone5-1','iPhone5-2','iPhone5-3','iPhone6-1','iPhone7-1','iPhone7-2','iPhone8-1','SAMSUNG-SM-G870A','SAMSUNG-SM-G900A','SAMSUNG-SM-G920A','SAMSUNG-SM-G935A','SAMSUNG-SM-N900A','SCH-I545','SM-G900P','SM-G900V','SM-G930V','SM-N910V','XT1080','XT1254')
THEn 'Mobile'

when 
m.name in ('OmniTrac') then '3RD Party'
when 
m.name in ('Transport Tracker') then '2G/3G'
ELSE 'Unknown'
END As NetworkType
,m.Name as Model,
d.SerialNumber as Serial
,[dbo].[Utc2Local](d.GPSTime) as GPSTime,
[dbo].[Utc2Local](d.CommunicationTime) as LastComm,dst.name as DeviceStatus,
do.name as Originator,d.id as DeviceRowID,isnull(dacct.PhoneNumber,'N/A') as PhoneNumber,
d.Latitude as Latitude,d.Longitude as Longitude, d.Address as Address,d.City as City,d.State as State,d.PostalCode as PostalCode, d.Country as Country,
d.DateCreated as DateCreated,d.OSType as OSType,d.Velocity as VelocityKm,
d.IsActive IsActive
from [dbo].[Asset_Device] d 
inner join [dbo].[Account] ac on d.AccountID = ac.ID
inner join [dbo].[Asset_DeviceModel_DeviceFirmware] f 
inner join [dbo].[Asset_DeviceModel] m on m.ID = f.DeviceModelID 
inner join [dbo].[Asset_DeviceManufacturer] dm on dm.ID = m.ManufacturerID on d.DeviceFimwareID = f.ID   
left join [dbo].[Asset_DeviceOriginator] do on do.id = d.DeviceOriginatorID
left join [dbo].[Asset_DeviceStatusType] dst on dst.id = d.DeviceStatusID
left join [dbo].[Data_DataAccount] dacct on dacct.id = d.DataAccountID
where d.CommunicationTime >= dateadd(day, -15, getdate())
GO
