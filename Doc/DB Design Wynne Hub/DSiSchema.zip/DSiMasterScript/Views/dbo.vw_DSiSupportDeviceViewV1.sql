SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO



CREATE view [dbo].[vw_DSiSupportDeviceViewV1]
as 


SELECT
	
	Device.*, AssetDDS.Equipment as CustomerEquipment, AssetDDS.DateCreated as LastBatchDate, AssetDDS.Employee as CustomerEmployee,
	AssetDDS.PingsToday as PingsToday,AssetDDS.PingsWithIgnitionOff as PingsWithIgnitionOff,AssetDDS.PingsWithNoVelocity as PingsWithNoVelocity,
	ISNULL(AssetDDS.LastOdoReading,0.00) as LastKnownOdometerValue, ISNULL(AssetDDS.DistanceMovedToday,0.00) AS DistanceMovedToday
FROM 
(
select  

ac.AccountName as AccountName
, dm.Name as Make
,m.Name as Model
,d.SerialNumber as Serial
,[dbo].[Utc2Local](d.GPSTime) as GPSTime
,[dbo].[Utc2Local](d.CommunicationTime) as LastComm
,dst.name as DeviceStatus,
do.name as Originator,
d.id as DeviceRowID,
isnull(dacct.PhoneNumber,'N/A') as PhoneNumber,
d.Latitude as Latitude,
d.Longitude as Longitude, 
d.Address as Address,
d.City as City,
d.State as State,
d.PostalCode as PostalCode, 
d.Country as Country,
d.DateCreated as DateCreated,
d.OSType as OSType,
d.Velocity as VelocityKm,
d.IsActive IsActive,
Test.DateCreated AS EquipmentDateCreated
from [dbo].[Asset_Device] d 
inner join [dbo].[Account] ac on d.AccountID = ac.ID
inner join [dbo].[Asset_DeviceModel_DeviceFirmware] f 
inner join [dbo].[Asset_DeviceModel] m on m.ID = f.DeviceModelID 
inner join [dbo].[Asset_DeviceManufacturer] dm on dm.ID = m.ManufacturerID on d.DeviceFimwareID = f.ID   
left join [dbo].[Asset_DeviceOriginator] do on do.id = d.DeviceOriginatorID
left join [dbo].[Asset_DeviceStatusType] dst on dst.id = d.DeviceStatusID
left join [dbo].[Data_DataAccount] dacct on dacct.id = d.DataAccountID

left join 
(
	select  adds.DeviceID, MAX(adds.DateCreated) AS DateCreated
	from DSIDeviceComm.dbo.Asset_Device_DailySummary adds 
	GROUP BY adds.DeviceID
) Test on Test.deviceid = d.ID
where d.isactive = 1 and ISNULL(d.CommunicationTime,'') <> ''
) AS Device

LEFT JOIN 
	DSIDeviceComm.dbo.Asset_Device_DailySummary AssetDDS ON Device.DeviceRowID = AssetDDS.DeviceID AND DEVICE.EquipmentDateCreated = AssetDDS.DateCreated



GO
