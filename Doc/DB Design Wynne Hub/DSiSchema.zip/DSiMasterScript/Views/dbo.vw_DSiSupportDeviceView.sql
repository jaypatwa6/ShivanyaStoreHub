SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO





CREATE view [dbo].[vw_DSiSupportDeviceView]
as 
select  
cast(ac.AccountName as varchar(max)) as AccountName
, dm.Name as Make,m.Name as Model,d.SerialNumber as Serial
,[dbo].[Utc2Local](d.GPSTime) as GPSTime,
[dbo].[Utc2Local](d.CommunicationTime) as LastComm,dst.name as DeviceStatus,
do.name as Originator,d.id as DeviceRowID,isnull(dacct.PhoneNumber,'N/A') as PhoneNumber,
d.Latitude as Latitude,d.Longitude as Longitude, d.Address as Address,d.City as City,d.State as State,d.PostalCode as PostalCode, d.Country as Country,
d.DateCreated as DateCreated,d.OSType as OSType,d.Velocity as VelocityKm,
d.IsActive IsActive
from [dbo].[Asset_Device] d 
inner join [dbo].[Account] ac on d.AccountID = ac.ID
inner join [dbo].[Asset_DeviceModel_DeviceFirmware] f 
inner join [dbo].[Asset_DeviceModel] m on m.ID = f.DeviceModelID 
inner join [dbo].[Asset_DeviceManufacturer] dm on dm.ID = m.ManufacturerID on d.DeviceFimwareID = f.ID   
left join [dbo].[Asset_DeviceOriginator] do on do.id = d.DeviceOriginatorID
left join [dbo].[Asset_DeviceStatusType] dst on dst.id = d.DeviceStatusID
left join [dbo].[Data_DataAccount] dacct on dacct.id = d.DataAccountID
where d.isactive = 1 and ISNULL(d.CommunicationTime,'') <> ''
--order by ac.accountname asc,d.CommunicationTime desc





GO
