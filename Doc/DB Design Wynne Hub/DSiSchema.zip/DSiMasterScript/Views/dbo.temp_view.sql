SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE VIEW [dbo].[temp_view]
AS
select DISTINCT NEWID() Id,
org.Id System_MasterOrganizationId, 
a.Id AccountId, 
1 IsActive, 
'00000000-0000-0000-0000-000000000000' CreatedBy, 
'2016-02-24 09:30:00.000' CreatedDate, 
'00000000-0000-0000-0000-000000000000' ModifiedBy, 
'2016-02-24 09:30:00.000' ModifiedDate 
from Account a
join System_MasterOrganization org on a.AccountName=org.Name
where datediff(day, org.CreatedDate, '2016-02-24') = 0
GO
