SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

--/****** Object:  View [dbo].[vw_DSiMobileAccounts]    Script Date: 5/5/2016 9:34:47 AM ******/
--SET ANSI_NULLS ON
--GO

--SET QUOTED_IDENTIFIER ON
--GO



CREATE view [dbo].[vw_DSiMobileAccounts]
as 

select distinct a.id,
a.accountname,

case 
	when cast(a.IsActive as nvarchar(15)) = 1 then 'Active'
	when cast(a.IsActive as nvarchar(15)) = 0 then 'Inactive'
	else cast(a.IsActive as nvarchar(15)) 
end
as AccountStatus,

a.datecreated,
case 
	when isnull(acs.ConnectionStr,'') <> '' then 'Y' 
	ELSE 'N' 
end as DatabaseExist,

case 
	when cast(a.ProgressStatus as nvarchar(35)) = '0' then 'DSiMobile Registered' 
	when cast(a.ProgressStatus as nvarchar(35))  = '1' then 'User signed up. Registration not complete'
	when cast(a.ProgressStatus as nvarchar(35)) = '2' then 'Signup Process saved. Not completed'
	when isnull(cast(a.ProgressStatus as nvarchar(35)) ,'') = '' then 'Imported from Pinpoints.'
	else CAST(a.ProgressStatus as  nvarchar(35)) 
end as ProgressStatus
	,
t.name as accounttype,

case 
	when isnull(max(l.DateTimeLastLoginAttempt),'') = '' and isnull(acs.ConnectionStr,'') <> '' then 'Database exist. Users never logged in'  
	when isnull(max(l.DateTimeLastLoginAttempt),'') = '' and isnull(acs.ConnectionStr,'') = '' then 'No DB'  
	else Convert(nvarchar(23), max([dbo].[Utc2Local](l.DateTimeLastLoginAttempt)),121)  
end as lastlogin,
max([dbo].[Utc2Local](l.DateTimeLastLoginAttempt)) as lastloginTimestamp,
(select count(*) from Account_Login where DateTimeLastLoginAttempt >= dateadd(day, -21, getdate()) and accountID = a.ID) as ActiveLoginsCountInPast21Days,
(select count(*) from Account_Login where IsActive = 1 and  accountID = a.ID) as TotalActiveLogins,
(select count(*) from Account_Login where IsActive = 0 and  accountID = a.ID) as TotalInActiveLogins,
(select count(*) from Account_Login where IsDelete = 1 and  accountID = a.ID) as TotalDeleteLogins,
(select count(*) from asset_device where isactive = 1 and accountID = a.ID) as ActiveDevices,
(select count(*) from asset_device where isactive = 1 and CommunicationTime >=  dateadd(day, -2, getdate()) and accountID = a.ID) as ActiveLast48HrCommunicatingDevices,
(select count(*) from asset_device where isactive = 1 and CommunicationTime <=  dateadd(day, -2, getdate()) and accountID = a.ID) as ActiveLast48HrNonCommunicatingDevices,
(select count(*) from asset_device where isactive = 0 and accountID = a.ID) as InActiveDevices,

(
select 
	case when isnull(max(CommunicationTime),'') = '' then 'No Devices Reporting' 
	else CONVERT(nvarchar(23),max([dbo].[Utc2Local](CommunicationTime)),121) 
end 
from asset_device where  accountID = a.ID
) as LastDeviceComm,
(
select 
	max([dbo].[Utc2Local](CommunicationTime))

from asset_device where  accountID = a.ID ) as LastDeviceCommTimestamp

from account a left join Account_Type t on a.Account_TypeID = t.ID
 left join account_login l on a.id = l.accountID
 left join Account_Setting acs on  a.id = acs.accountid 
where 1=1
group by a.id,
a.accountname,
a.IsActive,
a.datecreated,
a.ProgressStatus,
t.name,
acs.ConnectionStr
-- order by a.accountname asc



GO
