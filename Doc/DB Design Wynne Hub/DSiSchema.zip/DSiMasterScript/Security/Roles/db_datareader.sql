ALTER ROLE [db_datareader] ADD MEMBER [BAUser]
GO
ALTER ROLE [db_datareader] ADD MEMBER [DsiReader]
GO
ALTER ROLE [db_datareader] ADD MEMBER [JohnS]
GO
ALTER ROLE [db_datareader] ADD MEMBER [QAUser]
GO
