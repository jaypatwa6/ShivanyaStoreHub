CREATE TABLE [dbo].[System_Hits_Statistic]
(
[BingHits] [int] NULL,
[CacheHits] [int] NULL,
[DateCreated] [date] NOT NULL,
[BingLastHit] [datetime] NULL,
[CacheLastHit] [datetime] NULL,
[GoogleLastHit] [datetime] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Hits_Statistic] ADD CONSTRAINT [PK_System_Hits_Statistic] PRIMARY KEY CLUSTERED  ([DateCreated]) ON [PRIMARY]
GO
