CREATE TABLE [dbo].[System_Logs_GPS_RawData]
(
[Id] [int] NOT NULL IDENTITY(1, 1),
[DateCreated] [datetime] NULL,
[ReceivedPort] [int] NULL,
[ReceivedIP] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[LoggedByApplication] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Payload] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[RawData] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DateTime] [datetime] NOT NULL CONSTRAINT [DF_System_Logs_GPS_RawData_DateTime] DEFAULT (getutcdate()),
[RawBinary] [varbinary] (5000) NULL,
[ParsedXML] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[SerialNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Logs_GPS_RawData] ADD CONSTRAINT [PK_System_Logs_GPS_RawData] PRIMARY KEY CLUSTERED  ([Id]) ON [PRIMARY]
GO
