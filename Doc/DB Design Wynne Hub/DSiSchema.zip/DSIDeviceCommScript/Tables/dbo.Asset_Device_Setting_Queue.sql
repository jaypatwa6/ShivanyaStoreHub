CREATE TABLE [dbo].[Asset_Device_Setting_Queue]
(
[ID] [uniqueidentifier] NOT NULL,
[DeviceSerialNo] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[ATCommand] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CommandType] [int] NOT NULL CONSTRAINT [DF_Asset_Device_Setting_Queue_CommandType] DEFAULT ((1)),
[SettingValue] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[PhoneNumber] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DeviceModel] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DeviceManufacturer] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[FirmwareName] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[AppVersion] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsSuccessful] [bit] NULL CONSTRAINT [DF_Asset_Device_Setting_Queue_IsSuccessful] DEFAULT (NULL),
[ResultMessage] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[CreatedBy] [uniqueidentifier] NOT NULL,
[DateCreated] [datetime] NOT NULL,
[DateSent] [datetime] NULL,
[DateReceived] [datetime] NULL,
[RetryTimes] [int] NULL,
[IPAddress] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Port] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[SmsSid] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[SmsStatus] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DeviceId] [uniqueidentifier] NULL,
[CustomerName] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[BatchNumber] [nvarchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[SequenceNo] [int] NULL,
[SmsSidReceived] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[FirmwareId] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[Asset_Device_Setting_Queue] ADD CONSTRAINT [PK_Asset_Device_Setting_Queue] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
