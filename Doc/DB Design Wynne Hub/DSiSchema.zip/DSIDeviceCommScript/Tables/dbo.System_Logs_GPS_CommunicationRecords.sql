CREATE TABLE [dbo].[System_Logs_GPS_CommunicationRecords]
(
[Id] [int] NOT NULL IDENTITY(1, 1),
[DateCreated] [datetime] NULL,
[RecievedPort] [int] NULL,
[SendPort] [int] NULL,
[ReceivedIP] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[SendIP] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[LoggedByApplication] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DeviceID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[InOut] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Protocol] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[MessageType] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ACK] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Logs_GPS_CommunicationRecords] ADD CONSTRAINT [PK_System_Logs_GPS_CommunicationRecords] PRIMARY KEY CLUSTERED  ([Id]) ON [PRIMARY]
GO
