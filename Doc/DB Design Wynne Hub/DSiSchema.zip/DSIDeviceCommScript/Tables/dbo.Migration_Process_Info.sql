CREATE TABLE [dbo].[Migration_Process_Info]
(
[ID] [bigint] NOT NULL IDENTITY(1, 1),
[CustomerId] [bigint] NOT NULL,
[CustomerName] [varchar] (150) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Processed] [bigint] NOT NULL,
[Total] [bigint] NOT NULL,
[StartedOn] [datetime] NULL,
[EndedOn] [datetime] NULL,
[DateCreated] [datetime] NOT NULL,
[DateModified] [datetime] NULL,
[CurrentMode] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ProcessedDate] [datetime] NULL,
[LastProcessedId] [uniqueidentifier] NULL,
[Message] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[Migration_Process_Info] ADD CONSTRAINT [PK_Migration_Process_Info] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
