CREATE TABLE [dbo].[System_Logs_ApplicationExceptions]
(
[id] [int] NOT NULL IDENTITY(1, 1),
[DateCreated] [datetime2] NULL,
[Message] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Level] [nvarchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Logger] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Logs_ApplicationExceptions] ADD CONSTRAINT [PK__System_L__3213E83F0519C6AF] PRIMARY KEY CLUSTERED  ([id]) ON [PRIMARY]
GO
