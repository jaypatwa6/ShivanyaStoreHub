CREATE TABLE [dbo].[Migration_Process_Log]
(
[Id] [bigint] NOT NULL IDENTITY(1, 1),
[CustomerId] [bigint] NOT NULL,
[DeviceCommEventId] [uniqueidentifier] NULL,
[Status] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Message] [varchar] (2000) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Exception] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[DateCreated] [datetime] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[Migration_Process_Log] ADD CONSTRAINT [PK_Migration_Process_Log_1] PRIMARY KEY CLUSTERED  ([Id]) ON [PRIMARY]
GO
