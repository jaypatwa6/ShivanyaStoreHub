CREATE TABLE [dbo].[System_Logs_GPS_BadPackets]
(
[Id] [int] NOT NULL IDENTITY(1, 1),
[DateCreated] [datetime] NULL,
[ReceivedPort] [int] NULL,
[ReceivedIP] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[LoggedByApplication] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Payload] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[ErrorMessage] [varchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[RawBinary] [varbinary] (5000) NULL,
[SerialNumber] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Logs_GPS_BadPackets] ADD CONSTRAINT [PK_System_Logs_GPS_BadPackets] PRIMARY KEY CLUSTERED  ([Id]) ON [PRIMARY]
GO
