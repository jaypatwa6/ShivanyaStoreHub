CREATE TABLE [dbo].[System_Message_Queue]
(
[ID] [int] NOT NULL IDENTITY(1, 1),
[QueueName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Description] [nvarchar] (500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DateCreated] [datetime] NOT NULL,
[LastUpdate] [datetime] NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Message_Queue] ADD CONSTRAINT [PK_System_MessageQueue] PRIMARY KEY CLUSTERED  ([ID]) ON [PRIMARY]
GO
