CREATE TABLE [dbo].[System_Logs_WebserviceCalls]
(
[ID] [bigint] NOT NULL IDENTITY(1, 1),
[DateCreated] [datetime] NOT NULL,
[DeviceID] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[EmployeeId] [uniqueidentifier] NULL,
[UserID] [uniqueidentifier] NOT NULL,
[IPAddress] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[RequestData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Method] [nvarchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[IsSuccess] [bit] NOT NULL,
[ServiceName] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[RequestUri] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[TotalTimeExecuted] [bigint] NOT NULL,
[TransferDataSize] [int] NOT NULL,
[ResponseData] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Logs_WebserviceCalls] ADD CONSTRAINT [PK_System_Logs_WebserviceCalls] PRIMARY KEY NONCLUSTERED  ([ID]) ON [PRIMARY]
GO
