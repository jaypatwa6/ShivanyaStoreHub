CREATE TABLE [dbo].[System_Address_Cache]
(
[GeoHashCode] [nvarchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[Address] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[City] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[State] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PostalCode1] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[PostalCode2] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[Country] [nvarchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[DateCreated] [datetime] NOT NULL,
[DateModified] [datetime] NULL,
[Latitude] [decimal] (9, 6) NOT NULL,
[Longitude] [decimal] (9, 6) NOT NULL,
[BuildFrom] [nvarchar] (max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[GeoHashCode9] [nvarchar] (9) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[GeoHashCode8] [nvarchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
[SpeedLimitInKPH] [smallint] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[System_Address_Cache] ADD CONSTRAINT [PK_AddressCache] PRIMARY KEY NONCLUSTERED  ([GeoHashCode]) ON [PRIMARY]
GO
